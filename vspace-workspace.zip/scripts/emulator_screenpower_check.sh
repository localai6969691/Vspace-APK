#!/usr/bin/env bash
# P0-11 (G-18): ScreenPower có tắt PANEL mà Android vẫn "thức" không? Chạy bằng quyền shell của adb (cùng quyền Shizuku/ADB cấp).
# Không cần cài APK hay engine: dùng thẳng APK làm CLASSPATH của app_process, nên chạy được trên emulator x86 (chỉ cần dex Java).
#   bash scripts/emulator_screenpower_check.sh path/to.apk
# Kết quả 3 trạng thái, KHÔNG báo đạt giả:
#   PASS          : lệnh chạy không lỗi, máy vẫn Awake trong lúc panel tắt, và (nếu SurfaceFlinger khai) powerMode Off -> On.
#   FAIL          : lệnh lỗi (setDisplayPowerMode that bai), hoặc máy bị ngủ (Wakefulness != Awake) khi tắt panel.
#   INCONCLUSIVE  : chạy không lỗi + máy vẫn Awake nhưng dumpsys của bản Android này không cho thấy trạng thái panel.
set -u
APK="${1:?cách dùng: emulator_screenpower_check.sh duong-dan.apk}"
REMOTE=/data/local/tmp/vspace-sp.apk
LOG="$(mktemp)"
CLS=dev.vspace.workspace.ScreenPower
adb wait-for-device
API=$(adb shell getprop ro.build.version.sdk | tr -d '\r')
echo "Android API $API"
adb push "$APK" "$REMOTE" >/dev/null
adb shell input keyevent KEYCODE_WAKEUP
adb shell wm dismiss-keyguard 2>/dev/null || true
sleep 2

wake() { adb shell dumpsys power | tr -d '\r' | grep -m1 -o 'mWakefulness=[A-Za-z]*' ; }
sfmode() { adb shell dumpsys SurfaceFlinger 2>/dev/null | tr -d '\r' | grep -i -m1 -o 'powerMode=[A-Za-z]*\|power mode: *[A-Za-z]*\|Display power mode: *[A-Za-z]*' ; }

echo "TRƯỚC  : $(wake) | SF: $(sfmode)"
# Tắt panel 40 giây (tối thiểu hợp lệ là 10), chạy nền; ghi stdout/stderr để bắt lỗi
adb shell "CLASSPATH=$REMOTE app_process / $CLS off 40" > $LOG 2>&1 &
SP=$!
sleep 8
W_OFF=$(wake); S_OFF=$(sfmode)
echo "TẮT    : $W_OFF | SF: $S_OFF"
echo "--- log lệnh (8s đầu):"; cat $LOG
# Chờ hết giờ để tự bật lại, rồi đo lại
wait "$SP" 2>/dev/null
RC=$?
sleep 3
W_ON=$(wake); S_ON=$(sfmode)
echo "SAU    : $W_ON | SF: $S_ON | mã thoát lệnh=$RC"
adb shell rm -f "$REMOTE" >/dev/null 2>&1 || true

if grep -q "that bai\|Exception\|Error" $LOG; then
  echo "SCREENPOWER FAIL: lệnh báo lỗi (xem log ở trên)"; exit 1
fi
if [ "$W_OFF" != "mWakefulness=Awake" ]; then
  echo "SCREENPOWER FAIL: máy không còn Awake khi tắt panel ($W_OFF) — mục đích (game vẫn chạy) không đạt"; exit 1
fi
if echo "$S_OFF" | grep -qi "off" && echo "$S_ON" | grep -qi "on\|normal"; then
  echo "SCREENPOWER PASS (API $API): panel Off trong khi Awake, tự bật lại sau khi hết giờ"; exit 0
fi
echo "SCREENPOWER INCONCLUSIVE (API $API): lệnh không lỗi và máy vẫn Awake, nhưng dumpsys không cho thấy trạng thái panel -> cần máy thật"
exit 0
