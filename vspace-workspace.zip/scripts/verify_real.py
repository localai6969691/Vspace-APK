#!/usr/bin/env python3
"""Kiểm chứng bằng CÔNG CỤ THẬT (cần mạng tới GitHub và vài gói apt); bổ sung cho check.py/compile_check.py (offline).

Phiên 7 phát hiện sandbox có mạng tới github.com / raw.githubusercontent.com / archive.ubuntu.com (KHÔNG có dl.google.com và
maven nên vẫn không chạy được Gradle/AGP — P0-1 vẫn cần CI). Từ đó có các bằng chứng mà stub không cho được:

  1. android.jar THẬT (API 35) + SOURCE THẬT của lõi ở SHA đã ghim + overlay.sh THẬT → javac cho workspace/testguest.
     Lỗi trong core (thiếu AIDL/BR sinh tự động, androidx...) bị bỏ qua có chủ ý; lỗi nằm trong mã của dự án là lỗi thật.
     Có kiểm ĐỘT BIẾN: chèn một lời gọi hàm không tồn tại của core, phải bị bắt — chứng minh phép kiểm có tác dụng.
  2. aapt thật: biên dịch tài nguyên + manifest với android.jar API 28 (bắt lỗi kiểu `windowBackground` nhận màu thẳng).
  3. apksigner thật (AOSP): xác minh APK do ApkSigner ký (và một ca âm: sửa 1 byte phải bị từ chối).
  4. Chuỗi ghép split → ký: APKEditor thật (đối chiếu sha256 đã ghim) ghép một bộ split do aapt thật tạo, ApkSigner ký, apksigner xác minh.
  5. actionlint (nếu tải được) cho .github/workflows/*.yml.

Cách dùng:  python3 scripts/verify_real.py --fetch     # tải android.jar, lõi, APKEditor, actionlint vào ~/.cache/vspace
            python3 scripts/verify_real.py             # chỉ dùng cái đã có; bước thiếu công cụ thì BỎ QUA (ghi rõ), không báo giả đạt
Mã thoát: 0 nếu mọi bước đã chạy đều đạt (kể cả khi có bước bị bỏ qua); 1 nếu có bước thất bại.
"""
import glob
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE = os.path.expanduser(os.environ.get("VSPACE_CACHE", "~/.cache/vspace"))
CORE_URL = "https://github.com/ALEX5402/NewBlackbox"
CORE_SHA = "89b59836c66f173756a4ae258cf379a957649820"   # phải trùng CORE_REF trong workflow và README
SDK_BASE = "https://raw.githubusercontent.com/Sable/android-platforms/master"
APKEDITOR_URL = "https://github.com/REAndroid/APKEditor/releases/download/V1.4.9/APKEditor-1.4.9.jar"
ACTIONLINT_URL = "https://github.com/rhysd/actionlint/releases/download/v1.7.7/actionlint_1.7.7_linux_amd64.tar.gz"
PINS = {
    "android-35.jar": "4566663c3876e022b4fa4ced8c8697c4ab1688267f090114fd92d027b32e619b",
    "android-28.jar": "d20853d289a5161d9cf1c1268d7923076487d4fa68c970b0733e2d5a0ccfc3c5",
    "android-26.jar": "cdc1846376a14b0370cc63454a129606b4a52cc50ada75ef0d4cf956b1ad2daa",   # minSdk: dùng cho scripts/api_audit.py
    "APKEditor.jar": "a9cd40df818845456be6d696de6110c89edf4b0a0580cb83438ed6b25a366e67",
    "android-sdk-tools-static-x86_64.zip": "30110518265f0f6e8fb18bcce9ef29a7f1caf507e8d6a37ae92d26b11e44bf07",   # Lzhiyong/android-sdk-tools 35.0.2 (aapt2 mới, đọc được android.jar API 35)
}
RESULTS = []   # (tên, trạng thái, ghi chú)


def log(name, status, note=""):
    RESULTS.append((name, status, note))
    print(f"[{status:^6}] {name}" + (f" — {note}" if note else ""))


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def javac():
    if shutil.which("javac"):
        return ["javac"]
    if shutil.which("java"):
        return ["java", "-m", "jdk.compiler/com.sun.tools.javac.Main"]
    return None


def fetch(url, dest, pin=None):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    if os.path.isfile(dest) and (pin is None or sha256(dest) == pin):
        return True
    tmp = dest + ".part"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "vspace-verify"})
        with urllib.request.urlopen(req, timeout=180) as r, open(tmp, "wb") as f:
            shutil.copyfileobj(r, f)
    except Exception as e:  # noqa: BLE001
        print(f"  không tải được {url}: {e}")
        return False
    if pin and sha256(tmp) != pin:
        print(f"  SHA256 KHÔNG KHỚP cho {os.path.basename(dest)}: {sha256(tmp)} ≠ {pin}")
        os.remove(tmp)
        return False
    os.replace(tmp, dest)
    return True


def ensure_core(do_fetch):
    d = os.path.join(CACHE, "core")
    if os.path.isdir(os.path.join(d, "Bcore")):
        head = subprocess.run(["git", "-C", d, "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()
        if head == CORE_SHA:
            return d
    if not do_fetch:
        return None
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    try:
        for cmd in (["git", "init", "-q"], ["git", "remote", "add", "origin", CORE_URL],
                    ["git", "fetch", "-q", "--depth", "1", "origin", CORE_SHA], ["git", "checkout", "-q", "FETCH_HEAD"]):
            subprocess.run(cmd, cwd=d, check=True, capture_output=True, timeout=600)
    except Exception as e:  # noqa: BLE001
        print(f"  không lấy được lõi ở SHA {CORE_SHA[:7]}: {e}")
        return None
    head = subprocess.run(["git", "-C", d, "rev-parse", "HEAD"], cwd=d, capture_output=True, text=True).stdout.strip()
    return d if head == CORE_SHA else None


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


# ------------------------------------------------------------------ 1. biên dịch với SDK thật + lõi thật
def step_real_compile(jar35, core):
    name = "javac với android.jar API 35 + lõi thật"
    jc = javac()
    if not (jc and jar35 and core):
        log(name, "BỎ QUA", "thiếu " + ", ".join(x for x, ok in (("java", jc), ("android-35.jar", jar35), ("lõi (dùng --fetch)", core)) if not ok))
        return
    tmp = tempfile.mkdtemp(prefix="vspace-real-")
    try:
        c = os.path.join(tmp, "core")
        shutil.copytree(core, c, ignore=shutil.ignore_patterns(".git"))
        ov = run(["bash", os.path.join(ROOT, "scripts/overlay.sh"), c])
        if ov.returncode != 0:
            log(name, "LỖI", "overlay.sh thất bại: " + (ov.stdout + ov.stderr)[-300:])
            return
        sys.path.insert(0, os.path.join(ROOT, "scripts"))
        import compile_check as cc  # noqa: WPS433
        gen = os.path.join(tmp, "gen")
        cc.gen_r(os.path.join(c, "workspace/src/main/res"), gen)
        # android.jar thật không có AndroidX (xem androidx_api.spec): dựng stub thủ công vào -sourcepath cùng lõi.
        axstubs = os.path.join(tmp, "androidx-stubs")
        cc.gen_stubs(cc.parse_spec(os.path.join(ROOT, "scripts/stubs/androidx_api.spec")), axstubs)
        sp = os.pathsep.join([os.path.join(c, "Bcore/src/main/java"), os.path.join(c, "black-reflection/src/main/java"), axstubs])

        def compile_once(workdir_srcs, tag):
            listing = os.path.join(tmp, tag + ".txt")
            with open(listing, "w") as f:
                f.write("\n".join(workdir_srcs))
            r = run(jc + ["-source", "17", "-target", "17", "-Xlint:-options", "-proc:none", "-encoding", "UTF-8",
                          "-XDshould-stop.ifError=FLOW", "-Xmaxerrs", "100000", "-sourcepath", sp, "-cp", jar35,
                          "-d", os.path.join(tmp, "out-" + tag), "@" + listing])
            mine = [l for l in r.stderr.splitlines() if "error:" in l and (os.sep + "workspace" + os.sep in l or os.sep + "gen" + os.sep in l or "/testguest/" in l)]
            core_err = sum(1 for l in r.stderr.splitlines() if "error:" in l) - len(mine)
            return mine, core_err

        srcs = glob.glob(os.path.join(c, "workspace/src/main/java/**/*.java"), recursive=True) + glob.glob(os.path.join(gen, "**/*.java"), recursive=True)
        mine, core_err = compile_once(srcs, "ws")
        if mine:
            log(name, "LỖI", f"{len(mine)} lỗi trong mã dự án, ví dụ: {mine[0][-220:]}")
            return
        # ĐỘT BIẾN: nếu phép kiểm mù thì kết quả "đạt" vô nghĩa
        eng = os.path.join(c, "workspace/src/main/java/dev/vspace/workspace/Engine.java")
        orig = open(eng, encoding="utf-8").read()
        i = orig.index("BlackBoxCore.get()")
        open(eng, "w", encoding="utf-8").write(orig[:i] + "BlackBoxCore.get().notARealMethod(1);\n        " + orig[i:])
        mut, _ = compile_once(srcs, "mut")
        open(eng, "w", encoding="utf-8").write(orig)
        if not any("Engine.java" in l for l in mut):
            log(name, "LỖI", "đột biến KHÔNG bị bắt: phép kiểm không đáng tin")
            return
        log(name, "ĐẠT", f"{len(srcs)} file; 0 lỗi trong mã dự án; đột biến bị bắt; (bỏ qua {core_err} lỗi nằm trong core do thiếu mã sinh tự động)")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------------------ 2. aapt
def step_aapt(jar28):
    name = "aapt: tài nguyên + manifest (android.jar API 28)"
    if not (shutil.which("aapt") and jar28):
        log(name, "BỎ QUA", "thiếu " + ", ".join(x for x, ok in (("aapt (apt install aapt)", shutil.which("aapt")), ("android-28.jar", jar28)) if not ok))
        return None
    tmp = tempfile.mkdtemp(prefix="vspace-aapt-")
    try:
        ws = os.path.join(ROOT, "workspace/src/main")
        res = os.path.join(tmp, "res")
        shutil.copytree(os.path.join(ws, "res"), res)
        # aapt v1 + API 28 chưa biết thuộc tính/tài nguyên mới hơn → loại đúng những thứ đó (đã rà từng cái)
        for d in glob.glob(os.path.join(res, "*-v29")) + glob.glob(os.path.join(res, "*-v3?")):
            shutil.rmtree(d, ignore_errors=True)
        man = open(os.path.join(ws, "AndroidManifest.xml"), encoding="utf-8").read()
        man = man.replace("<manifest ", '<manifest package="dev.vspace.workspace" ', 1)
        man = man.replace("${updateRepo}", "owner/repo").replace("${applicationId}", "dev.vspace.workspace")
        man = re.sub(r' android:foregroundServiceType="[^"]*"', "", man)
        man = re.sub(r' android:(enableOnBackInvokedCallback|localeConfig)="[^"]*"', "", man)
        mp = os.path.join(tmp, "AndroidManifest.xml")
        open(mp, "w", encoding="utf-8").write(man)
        os.makedirs(os.path.join(tmp, "gen"))
        apk = os.path.join(CACHE, "aapt-base.apk")
        r = run(["aapt", "package", "-f", "-m", "-J", os.path.join(tmp, "gen"), "-M", mp, "-S", res, "-I", jar28,
                 "--min-sdk-version", "26", "--target-sdk-version", "28", "--version-code", "1", "--version-name", "t", "-F", apk])
        if r.returncode != 0:
            log(name, "LỖI", (r.stdout + r.stderr).strip()[:300])
            return None
        log(name, "ĐẠT", "mọi layout/chuỗi/style/drawable/manifest hợp lệ (trừ phần mới hơn API 28 đã loại ra khỏi bản kiểm)")
        return apk
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------------------ 3 + 4. ký + ghép
def compile_signer(tmp):
    jc = javac()
    out = os.path.join(tmp, "signer")
    os.makedirs(out)
    base = os.path.join(ROOT, "workspace/src")
    files = [os.path.join(base, "main/java/dev/vspace/workspace/ApkSigner.java"),
             os.path.join(base, "test/java/dev/vspace/workspace/ApkSignerCli.java"),
             os.path.join(base, "test/java/dev/vspace/workspace/MergePipelineCli.java")]
    r = run(jc + ["-d", out] + files)
    return out if r.returncode == 0 else None


def step_sign(apk, apkeditor):
    n1 = "apksigner thật xác minh APK do ApkSigner ký (+ ca âm)"
    n2 = "ghép split (APKEditor thật) → ký → apksigner + aapt đọc được"
    if not (javac() and shutil.which("apksigner")):
        log(n1, "BỎ QUA", "thiếu java hoặc apksigner (apt install apksigner)")
        log(n2, "BỎ QUA", "thiếu java hoặc apksigner")
        return
    tmp = tempfile.mkdtemp(prefix="vspace-sign-")
    try:
        cls = compile_signer(tmp)
        if not cls:
            log(n1, "LỖI", "không biên dịch được ApkSigner")
            return
        if not apk or not os.path.isfile(apk):
            log(n1, "BỎ QUA", "chưa có APK nền từ bước aapt")
        else:
            signed = os.path.join(tmp, "s.apk")
            r = run(["java", "-cp", cls, "dev.vspace.workspace.ApkSignerCli", apk, signed, os.path.join(tmp, "keys")])
            v = run(["apksigner", "verify", "-v", "--min-sdk-version", "26", signed])
            ok = r.returncode == 0 and v.returncode == 0 and "v2 scheme (APK Signature Scheme v2): true" in v.stdout
            data = bytearray(open(signed, "rb").read())
            data[100] ^= 0xFF
            bad = os.path.join(tmp, "bad.apk")
            open(bad, "wb").write(data)
            neg = run(["apksigner", "verify", "--min-sdk-version", "26", bad])
            if ok and neg.returncode != 0:
                log(n1, "ĐẠT", "v2 = true; bản bị sửa 1 byte bị từ chối")
            else:
                log(n1, "LỖI", (v.stdout + v.stderr + r.stderr)[-300:] if not ok else "ca âm KHÔNG bị từ chối")
        # --- chuỗi ghép
        if not (apkeditor and shutil.which("aapt")):
            log(n2, "BỎ QUA", "thiếu APKEditor.jar (--fetch) hoặc aapt")
            return
        jar28 = os.path.join(CACHE, "android-28.jar")
        fx = os.path.join(tmp, "fx")
        os.makedirs(os.path.join(fx, "res/drawable-hdpi"))
        os.makedirs(os.path.join(fx, "res/drawable-xhdpi"))
        os.makedirs(os.path.join(fx, "res/drawable"))
        os.makedirs(os.path.join(fx, "res/values"))
        import struct
        import zlib

        def png(n):
            raw = b"".join(b"\x00" + bytes((10, 20, 30)) * n for _ in range(n))

            def ch(t, d):
                c = struct.pack(">I", len(d)) + t + d
                return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
            return b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", n, n, 8, 2, 0, 0, 0)) + ch(b"IDAT", zlib.compress(raw)) + ch(b"IEND", b"")
        for d, n in (("drawable", 8), ("drawable-hdpi", 12), ("drawable-xhdpi", 16)):
            open(os.path.join(fx, "res", d, "pic.png"), "wb").write(png(n))
        open(os.path.join(fx, "res/values/strings.xml"), "w").write('<resources><string name="app_name">Fixture</string></resources>')
        open(os.path.join(fx, "AndroidManifest.xml"), "w").write(
            '<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="fixture.split" android:versionCode="3" android:versionName="1.2">'
            '<uses-sdk android:minSdkVersion="26" android:targetSdkVersion="28"/>'
            '<application android:label="@string/app_name" android:icon="@drawable/pic" android:hasCode="false"/></manifest>')   # hasCode=false: APK mẫu không có dex; thiếu cờ này PackageManager báo "code is missing" (CI lượt #12)
        a = run(["aapt", "package", "-f", "-M", "AndroidManifest.xml", "-S", "res", "-I", jar28, "--split", "hdpi", "--split", "xhdpi", "-F", "base.apk"], cwd=fx)
        if a.returncode != 0:
            log(n2, "LỖI", "aapt không tạo được bộ split mẫu: " + a.stderr[-200:])
            return
        stage = os.path.join(tmp, "stage")
        os.makedirs(os.path.join(stage, "Android/obb/fixture.split"))
        shutil.copy(os.path.join(fx, "base.apk"), os.path.join(stage, "base.apk"))
        shutil.copy(os.path.join(fx, "base_hdpi-v4.apk"), os.path.join(stage, "config.hdpi.apk"))
        shutil.copy(os.path.join(fx, "base_xhdpi-v4.apk"), os.path.join(stage, "config.xhdpi.apk"))
        open(os.path.join(stage, "Android/obb/fixture.split/main.3.fixture.split.obb"), "w").write("x")
        import zipfile
        xapk = os.path.join(tmp, "t.xapk")
        with zipfile.ZipFile(xapk, "w") as z:
            for root, _, files in os.walk(stage):
                for f in files:
                    p = os.path.join(root, f)
                    z.write(p, os.path.relpath(p, stage))
        merged = os.path.join(tmp, "merged.apk")
        m = run(["java", "-cp", cls + os.pathsep + apkeditor, "dev.vspace.workspace.MergePipelineCli", xapk, merged, os.path.join(tmp, "keys2")])
        v = run(["apksigner", "verify", "-v", "--min-sdk-version", "26", merged]) if os.path.isfile(merged) else None
        b = run(["aapt", "dump", "badging", merged]) if os.path.isfile(merged) else None
        hc = run(["aapt", "dump", "xmltree", merged, "AndroidManifest.xml"]) if os.path.isfile(merged) else None
        if m.returncode == 0 and v and v.returncode == 0 and "fixture.split" in (b.stdout if b else "") and "hasCode" in (hc.stdout if hc else ""):
            out = os.environ.get("VSPACE_FIXTURE_OUT")   # CI: xuất APK đã ghép+ký để emulator cài bằng PackageManager thật (scripts/emulator_install_check.sh)
            if out:
                os.makedirs(out, exist_ok=True)
                shutil.copy(merged, os.path.join(out, "merged-signed.apk"))
            with zipfile.ZipFile(merged) as z:
                names = z.namelist()
            dens = sum(1 for x in names if x.startswith("res/") and x.endswith("pic.png"))
            log(n2, "ĐẠT", f"merged+signed, apksigner v2 = true, aapt đọc được gói; {dens} bản pic.png (các mật độ đã gộp)")
        else:
            log(n2, "LỖI", (m.stdout + m.stderr + (v.stdout + v.stderr if v else ""))[-400:])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------------------ 5. actionlint
AAPT2_URL = "https://github.com/Lzhiyong/android-sdk-tools/releases/download/35.0.2/android-sdk-tools-static-x86_64.zip"


def fetch_aapt2(do_fetch):
    """aapt2 35.0.2 dựng sẵn (aapt2 của apt quá cũ: không đọc được android.jar API 35)."""
    if not sys.platform.startswith("linux"):
        return None
    exe = os.path.join(CACHE, "aapt2-35", "aapt2")
    if os.path.isfile(exe):
        return exe
    if not do_fetch:
        return None
    zp = os.path.join(CACHE, "android-sdk-tools-static-x86_64.zip")
    if not fetch(AAPT2_URL, zp, PINS["android-sdk-tools-static-x86_64.zip"]):
        return None
    import zipfile
    os.makedirs(os.path.dirname(exe), exist_ok=True)
    with zipfile.ZipFile(zp) as z, open(exe, "wb") as out:
        out.write(z.read("build-tools/aapt2"))
    os.chmod(exe, 0o755)
    return exe


def step_aapt2_api35(aapt2, jar35):
    """Link tài nguyên + manifest THẬT với android.jar API 35 bằng aapt2 mới: kiểm được thuộc tính Android 12-15
    (localeConfig, enableOnBackInvokedCallback, networkSecurityConfig...) mà aapt cũ (API 28) không biết. Có đột biến."""
    name = "aapt2: tài nguyên + manifest với android.jar API 35"
    if not aapt2 or not os.path.isfile(jar35):
        log(name, "BỎ QUA", "thiếu aapt2 mới hoặc android-35.jar (chạy --fetch)")
        return
    main = os.path.join(ROOT, "workspace/src/main")
    with tempfile.TemporaryDirectory() as t:
        comp = os.path.join(t, "c")
        os.makedirs(comp)
        r = run([aapt2, "compile", "--dir", os.path.join(main, "res"), "-o", comp])
        if r.returncode:
            log(name, "LỖI", "compile: " + (r.stdout + r.stderr)[-400:])
            return
        flats = sorted(glob.glob(os.path.join(comp, "*.flat")))
        man = open(os.path.join(main, "AndroidManifest.xml"), encoding="utf-8").read()
        def link(manifest_text, out):
            mp = os.path.join(t, "AndroidManifest.xml")
            open(mp, "w", encoding="utf-8").write(manifest_text.replace("<manifest ", '<manifest package="dev.vspace.workspace" ', 1))
            return run([aapt2, "link", "-I", jar35, "--manifest", mp, "--min-sdk-version", "26", "--target-sdk-version", "28",
                        "--auto-add-overlay", "-o", out] + flats)
        out = os.path.join(t, "ok.apk")
        r = link(man, out)
        if r.returncode or not os.path.isfile(out):
            log(name, "LỖI", "link: " + (r.stdout + r.stderr)[-500:])
            return
        tree = run([aapt2, "dump", "xmltree", "--file", "AndroidManifest.xml", out]).stdout
        need = ["localeConfig", "enableOnBackInvokedCallback", "networkSecurityConfig"]
        miss = [a for a in need if a not in tree]
        if miss:
            log(name, "LỖI", "manifest sau link thiếu thuộc tính: " + ", ".join(miss))
            return
        # đột biến: thuộc tính không tồn tại phải làm link thất bại
        bad = man.replace("android:enableOnBackInvokedCallback=", "android:enableOnBackInvokedCallbackBOGUS=", 1)
        rb = link(bad, os.path.join(t, "bad.apk"))
        if rb.returncode == 0:
            log(name, "LỖI", "đột biến (thuộc tính giả) KHÔNG làm link thất bại — kiểm vô dụng")
            return
    log(name, "ĐẠT", f"{len(flats)} tệp tài nguyên; manifest có {', '.join(need)}; thuộc tính giả bị từ chối")


def step_dobby_x86(core, do_fetch):
    """Dobby ở SHA ghim trong scripts/build_dobby.sh có biên dịch được thành libdobby.a x86_64 và xuất ĐÚNG tập ký hiệu của libdobby.a
    dựng sẵn trong lõi không? (build trên host x86_64 bằng g++, chèn shim __has_feature; trình biên dịch NDK là clang nên mạnh hơn.)
    Đây là bằng chứng rằng đường x86_64 khả thi, KHÔNG thay cho build NDK thật trong CI."""
    name = "Dobby x86_64 (SHA ghim) biên dịch được và khớp ký hiệu của lõi"
    if not (shutil.which("cmake") and shutil.which("g++") and shutil.which("make") and shutil.which("nm")):
        log(name, "BỎ QUA", "thiếu cmake/g++/make/nm")
        return
    ref = re.search(r'^DOBBY_REF="([0-9a-f]{40})"', open(os.path.join(ROOT, "scripts/build_dobby.sh"), encoding="utf-8").read(), re.M)
    if not ref:
        log(name, "LỖI", "không đọc được DOBBY_REF trong build_dobby.sh")
        return
    ref = ref.group(1)
    core_lib = os.path.join(core or "", "Bcore/src/main/cpp/Dobby/arm64-v8a/libdobby.a")
    src = os.path.join(CACHE, "dobby-src")
    if not os.path.isdir(os.path.join(src, "include")) or run(["git", "-C", src, "rev-parse", "HEAD"]).stdout.strip() != ref:
        if not do_fetch:
            log(name, "BỎ QUA", "chưa có mã Dobby (chạy --fetch)")
            return
        shutil.rmtree(src, ignore_errors=True)
        os.makedirs(src)
        try:
            for cmd in (["git", "init", "-q"], ["git", "remote", "add", "origin", "https://github.com/jmpews/Dobby.git"],
                        ["git", "fetch", "-q", "origin", ref], ["git", "checkout", "-q", "FETCH_HEAD"]):
                subprocess.run(cmd, cwd=src, check=True, capture_output=True, timeout=600)
        except Exception as e:  # noqa: BLE001
            log(name, "BỎ QUA", f"không lấy được Dobby {ref[:7]}: {e}")
            return
    with tempfile.TemporaryDirectory() as t:
        shim = os.path.join(t, "hf.h")
        open(shim, "w").write("#ifndef __has_feature\n#define __has_feature(x) 0\n#endif\n")
        fl = f"-include {shim} -w"
        b = os.path.join(t, "b")
        r = run(["cmake", "-S", src, "-B", b, "-DCMAKE_BUILD_TYPE=Release", "-DDOBBY_GENERATE_SHARED=OFF", "-DDOBBY_DEBUG=OFF",
                 "-DNearBranch=ON", f"-DCMAKE_C_FLAGS={fl}", f"-DCMAKE_CXX_FLAGS={fl}"])
        if r.returncode:
            log(name, "LỖI", "cmake: " + (r.stdout + r.stderr)[-300:])
            return
        r = run(["cmake", "--build", b, "-j4"], timeout=280)
        lib = os.path.join(b, "libdobby.a")
        if r.returncode or not os.path.isfile(lib):
            log(name, "LỖI", "build: " + (r.stdout + r.stderr)[-400:])
            return
        def syms(path):
            out = run(["nm", path]).stdout
            return {l.split()[-1] for l in out.splitlines() if re.search(r" T Dobby\w+$", l)}
        mine = syms(lib)
        want = syms(core_lib) if os.path.isfile(core_lib) else {"DobbyHook", "DobbyDestroy", "DobbyInstrument", "DobbyBuildVersion", "DobbySymbolResolver"}
        if not want or not want <= mine:
            log(name, "LỖI", f"thiếu ký hiệu so với lõi: {sorted(want - mine)}")
            return
    log(name, "ĐẠT", f"Dobby {ref[:7]} biên dịch x86_64; xuất đủ {len(want)} ký hiệu của libdobby.a trong lõi ({', '.join(sorted(want))})")


def step_dobby_android_logging():
    """Tái tạo lỗi THẬT của CI lượt #12: Dobby 223aabc đặt #include <android/log.h> trong thân hàm; NDK mới có hàm static inline trong
    header đó nên clang báo "function definition is not allowed here". Dùng android/log.h GIẢ có hàm static inline: bản chưa vá phải lỗi
    đúng thông báo đó, bản đã vá (scripts/patch_dobby.py) phải biên dịch. Cần clang (hoặc ziglang cc)."""
    name = "Dobby: vá include android/log.h (lỗi thật của CI #12)"
    src = os.path.join(CACHE, "dobby-src")
    logging_c = os.path.join(src, "external/logging/logging.c")
    cc = shutil.which("clang")
    cc = [cc] if cc else ([sys.executable, "-m", "ziglang", "cc"] if run([sys.executable, "-m", "ziglang", "version"]).returncode == 0 else None)
    if not cc or not os.path.isfile(logging_c):
        log(name, "BỎ QUA", "thiếu clang/ziglang hoặc mã Dobby (chạy --fetch; cài clang hoặc pip install ziglang)")
        return
    sys.path.insert(0, os.path.join(ROOT, "scripts"))
    import patch_dobby
    with tempfile.TemporaryDirectory() as t:
        os.makedirs(os.path.join(t, "android"))
        open(os.path.join(t, "android/log.h"), "w").write(
            "#pragma once\n#include <stdarg.h>\nenum { ANDROID_LOG_INFO = 4 };\n"
            "int __android_log_vprint(int prio, const char* tag, const char* fmt, va_list ap);\n"
            "static inline int __android_log_helper(int x) { return x; }   /* như NDK mới: hàm inline trong header */\n")
        def compile_(path):
            return run(cc + ["-c", "-o", os.path.join(t, "out.o"), "-D__ANDROID__", "-I" + t, "-I" + os.path.join(src, "external/logging"), path])
        orig = open(logging_c, encoding="utf-8").read()
        before = os.path.join(t, "before.c")
        open(before, "w").write(orig)
        r0 = compile_(before)
        if r0.returncode == 0 or "function definition is not allowed here" not in (r0.stdout + r0.stderr):
            log(name, "LỖI", "không tái tạo được lỗi gốc trên bản CHƯA vá: " + (r0.stdout + r0.stderr)[-200:])
            return
        fixed = os.path.join(t, "after.c")
        open(fixed, "w").write(patch_dobby.patch(orig))
        r1 = compile_(fixed)
        if r1.returncode:
            log(name, "LỖI", "bản đã vá vẫn lỗi: " + (r1.stdout + r1.stderr)[-300:])
            return
        if patch_dobby.patch(open(fixed).read()) != open(fixed).read():
            log(name, "LỖI", "vá không idempotent")
            return
    log(name, "ĐẠT", "bản chưa vá lỗi đúng thông báo của CI; bản đã vá biên dịch được; chạy lại vá không đổi gì")


def step_symbol_check():
    """Hồi quy cho lỗi thật của CI lượt #13: `nm | grep -q` dưới pipefail báo SAI là thiếu symbol khi đầu ra lớn và symbol nằm sớm (SIGPIPE).
    Dùng `nm` giả in symbol ở ĐẦU rồi 300000 dòng; chạy dưới `bash -o pipefail`: có symbol phải đạt, thiếu symbol phải thất bại."""
    name = "check_lib_symbols.sh: đầu ra nm lớn không gây báo thiếu giả"
    with tempfile.TemporaryDirectory() as t:
        fake = os.path.join(t, "fake-nm")
        open(fake, "w").write("#!/usr/bin/env bash\necho '0000000000000000 T DobbyHook'\nseq 1 300000 | sed 's/^/0000000000000000 t sym_/'\n")
        os.chmod(fake, 0o755)
        lib = os.path.join(t, "lib.a")
        open(lib, "w").write("x")
        script = os.path.join(ROOT, "scripts/check_lib_symbols.sh")
        ok = subprocess.run(["bash", "-o", "pipefail", script, fake, lib, "DobbyHook"], capture_output=True, text=True)
        bad = subprocess.run(["bash", "-o", "pipefail", script, fake, lib, "DobbyHook", "KhongCoHam"], capture_output=True, text=True)
        # đối chứng: cách cũ có đúng là lỗi không (để phép kiểm này có ý nghĩa)
        old = subprocess.run(["bash", "-c", f"set -o pipefail; '{fake}' | grep -q ' T DobbyHook$'"], capture_output=True, text=True)
    if ok.returncode != 0:
        log(name, "LỖI", "symbol CÓ MẶT mà bị báo thiếu: " + (ok.stdout + ok.stderr)[-200:])
    elif bad.returncode == 0 or "KhongCoHam" not in bad.stdout:
        log(name, "LỖI", "symbol THIẾU mà không bị phát hiện")
    elif old.returncode == 0:
        log(name, "LỖI", "không tái tạo được lỗi SIGPIPE của cách cũ (phép kiểm chưa có ý nghĩa trên máy này)")
    else:
        log(name, "ĐẠT", f"có symbol: đạt; thiếu symbol: thất bại; cách cũ `nm|grep -q` trả {old.returncode} (SIGPIPE) trên cùng dữ liệu")


def step_x86_overlay(core):
    """VSPACE_X86_64=1: thêm x86_64 vào APP_ABI + abiFilters của lõi THẬT, lặp lại không nhân đôi, mặc định không đổi gì,
    thiếu Dobby/x86_64/libdobby.a thì từ chối (không được báo đạt giả)."""
    name = "overlay x86_64 (APP_ABI + abiFilters) trên lõi thật"
    if not core or not os.path.isdir(core):
        log(name, "BỎ QUA", "chưa có lõi (--fetch)")
        return
    ov = os.path.join(ROOT, "scripts/overlay.sh")
    with tempfile.TemporaryDirectory() as t:
        def fresh(tag, lib=True):
            d = os.path.join(t, tag)
            shutil.copytree(core, d, ignore=shutil.ignore_patterns(".git"))
            if lib:
                os.makedirs(os.path.join(d, "Bcore/src/main/cpp/Dobby/x86_64"))
                open(os.path.join(d, "Bcore/src/main/cpp/Dobby/x86_64/libdobby.a"), "wb").write(b"!<arch>\n")
            return d
        mk = lambda d: os.path.join(d, "Bcore/src/main/cpp/Application.mk")
        gr = lambda d: os.path.join(d, "Bcore/build.gradle")
        rd = lambda p: open(p, encoding="utf-8").read()
        off = fresh("off")
        r0 = run(["bash", ov, off])
        if r0.returncode or "x86_64" in rd(mk(off)) or "x86_64" in rd(gr(off)):
            log(name, "LỖI", "mặc định (không đặt VSPACE_X86_64) không được thêm x86_64\n" + r0.stderr[-300:])
            return
        on = fresh("on")
        env = dict(os.environ, VSPACE_X86_64="1")
        r1 = subprocess.run(["bash", ov, on], capture_output=True, text=True, env=env)
        r2 = subprocess.run(["bash", ov, on], capture_output=True, text=True, env=env)
        if r1.returncode or r2.returncode or rd(mk(on)).count("x86_64") != 1 or rd(gr(on)).count("x86_64") != 1:
            log(name, "LỖI", f"rc={r1.returncode}/{r2.returncode} mk={rd(mk(on)).count('x86_64')} gr={rd(gr(on)).count('x86_64')}\n{r1.stderr[-300:]}")
            return
        nolib = fresh("nolib", lib=False)
        rn = subprocess.run(["bash", ov, nolib], capture_output=True, text=True, env=env)
        if rn.returncode == 0:
            log(name, "LỖI", "thiếu libdobby.a x86_64 mà overlay VẪN thành công — chốt chặn vô dụng")
            return
    log(name, "ĐẠT", "mặc định không đổi; bật: APP_ABI và abiFilters thêm đúng 1 lần, lặp lại ổn; thiếu libdobby.a x86_64 bị từ chối")


def step_harden_exports(core):
    """O-17: VSPACE_HARDEN_EXPORTS=1 phải siết ĐÚNG 300 stub trên manifest lõi thật, chạy lại không đổi thêm, XML hợp lệ,
    chỉ ProxyBroadcastReceiver còn exported; mặc định (không đặt biến) KHÔNG được đổi gì. Kèm đột biến: manifest thiếu 1 stub
    phải bị từ chối (không báo đạt giả)."""
    name = "overlay O-17 (siết exported) trên lõi thật"
    if not core or not os.path.isdir(core):
        log(name, "BỎ QUA", "chưa có lõi (--fetch)")
        return
    import xml.dom.minidom
    ov = os.path.join(ROOT, "scripts/overlay.sh")
    with tempfile.TemporaryDirectory() as t:
        def fresh(tag):
            d = os.path.join(t, tag)
            shutil.copytree(core, d, ignore=shutil.ignore_patterns(".git"))
            return d
        mf = lambda d: os.path.join(d, "Bcore/src/main/AndroidManifest.xml")
        cnt = lambda d: open(mf(d), encoding="utf-8").read().count('android:exported="true"')
        base = cnt(fresh("probe"))
        off = fresh("off")
        r0 = run(["bash", ov, off])
        if r0.returncode or cnt(off) != base:
            log(name, "LỖI", f"mặc định không được đổi manifest: {base} -> {cnt(off)}\n{r0.stdout[-300:]}{r0.stderr[-300:]}")
            return
        on = fresh("on")
        env = dict(os.environ, VSPACE_HARDEN_EXPORTS="1")
        r1 = subprocess.run(["bash", ov, on], capture_output=True, text=True, env=env)
        r2 = subprocess.run(["bash", ov, on], capture_output=True, text=True, env=env)   # lặp lại phải vẫn đạt
        try:
            xml.dom.minidom.parse(mf(on))
        except Exception as e:
            log(name, "LỖI", f"XML hỏng sau khi siết: {e}")
            return
        left = cnt(on)
        if r1.returncode or r2.returncode or left != 1 or base - left != 300:
            log(name, "LỖI", f"base={base} left={left} rc={r1.returncode}/{r2.returncode}\n{r1.stderr[-300:]}")
            return
        # đột biến: xóa 1 stub khỏi manifest -> số lượng != 300 -> overlay phải thất bại
        mut = fresh("mut")
        txt = open(mf(mut), encoding="utf-8").read()
        m = re.search(r'<activity\b[^>]*?android:name="\.proxy\.ProxyActivity\$P0"[^>]*?/>', txt, re.S) \
            or re.search(r'<activity\b[^>]*?android:name="\.proxy\.ProxyActivity\$P0".*?</activity>', txt, re.S)
        if not m:
            log(name, "LỖI", "không dựng được đột biến (không thấy ProxyActivity$P0)")
            return
        open(mf(mut), "w", encoding="utf-8").write(txt.replace(m.group(0), ""))
        rm = subprocess.run(["bash", ov, mut], capture_output=True, text=True, env=env)
        if rm.returncode == 0:
            log(name, "LỖI", "đột biến (thiếu 1 stub) KHÔNG bị từ chối — chốt chặn vô dụng")
            return
    log(name, "ĐẠT", f"mặc định không đổi; bật: 300 stub -> false (exported=true {base} -> {left}), lặp lại ổn, XML hợp lệ, đột biến bị từ chối")


def step_actionlint(binary):
    name = "actionlint: .github/workflows"
    wf = glob.glob(os.path.join(ROOT, ".github/workflows/*.yml"))
    if not binary or not os.path.isfile(binary):
        log(name, "BỎ QUA", "thiếu actionlint (--fetch)")
        return
    if not wf:
        log(name, "LỖI", "không có workflow nào trong .github/workflows")
        return
    r = run([binary, "-color"] + wf)
    if r.returncode == 0:
        log(name, "ĐẠT", f"{len(wf)} workflow, 0 cảnh báo")
    else:
        log(name, "LỖI", (r.stdout + r.stderr)[-800:])


def fetch_actionlint(do_fetch):
    binary = os.path.join(CACHE, "actionlint")
    if os.path.isfile(binary):
        return binary
    if not do_fetch:
        return None
    tgz = os.path.join(CACHE, "actionlint.tgz")
    if not fetch(ACTIONLINT_URL, tgz):
        return None
    import tarfile
    with tarfile.open(tgz) as t:
        t.extract("actionlint", CACHE)
    os.chmod(binary, 0o755)
    return binary


def main():
    do_fetch = "--fetch" in sys.argv
    os.makedirs(CACHE, exist_ok=True)
    paths = {}
    for n, url in (("android-35.jar", f"{SDK_BASE}/android-35/android.jar"), ("android-28.jar", f"{SDK_BASE}/android-28/android.jar"),
                   ("android-26.jar", f"{SDK_BASE}/android-26/android.jar"), ("APKEditor.jar", APKEDITOR_URL)):
        p = os.path.join(CACHE, n)
        if do_fetch:
            fetch(url, p, PINS[n])
        paths[n] = p if os.path.isfile(p) and sha256(p) == PINS[n] else None
    core = ensure_core(do_fetch)
    step_real_compile(paths["android-35.jar"], core)
    apk = step_aapt(paths["android-28.jar"])
    step_sign(apk, paths["APKEditor.jar"])
    step_aapt2_api35(fetch_aapt2(do_fetch), os.path.join(CACHE, "android-35.jar"))
    step_harden_exports(core)
    step_x86_overlay(core)
    step_dobby_x86(core, do_fetch)
    step_dobby_android_logging()
    step_symbol_check()
    step_actionlint(fetch_actionlint(do_fetch))
    print("\nTỔNG KẾT")
    for n, s, note in RESULTS:
        print(f"  {s:<7} {n}")
    failed = [r for r in RESULTS if r[1] == "LỖI"]
    skipped = [r for r in RESULTS if r[1] == "BỎ QUA"]
    if skipped:
        print(f"\n{len(skipped)} bước BỎ QUA (thiếu công cụ/mạng) — KHÔNG được tính là đạt.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
