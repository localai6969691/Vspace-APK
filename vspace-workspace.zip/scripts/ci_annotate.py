#!/usr/bin/env python3
"""Phát một Annotation của GitHub Actions (::error::/::warning::/::notice::) chứa các dòng quan trọng của một tệp log.

Vì sao: log đầy đủ của từng bước cần đăng nhập mới xem được, còn Annotations thì công khai trên trang lượt chạy, nên người/AI không có
quyền vẫn đọc được lý do lỗi. Dùng:  python3 scripts/ci_annotate.py error "Tiêu đề" file.log [--grep REGEX] [--tail N]
  - có --grep: lấy tối đa N dòng KHỚP đầu tiên (lỗi biên dịch thường nằm sớm) rồi thêm vài dòng cuối;
  - không có --grep: lấy N dòng cuối.
"""
import argparse
import re


def esc_data(s):
    return s.replace("%", "%25").replace("\r", "%0D").replace("\n", "%0A")


def esc_prop(s):
    return esc_data(s).replace(":", "%3A").replace(",", "%2C")


def build(level, title, lines, grep=None, tail=15, max_chars=1800):
    if grep:
        hits = [l for l in lines if re.search(grep, l)][:tail]
        sel = hits + (["---"] if hits else []) + lines[-6:]
    else:
        sel = lines[-tail:]
    text = "\n".join(l.rstrip()[:300] for l in sel)[:max_chars]
    return f"::{level} title={esc_prop(title)}::{esc_data(text)}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("level", choices=["error", "warning", "notice"])
    ap.add_argument("title")
    ap.add_argument("file")
    ap.add_argument("--grep")
    ap.add_argument("--tail", type=int, default=15)
    a = ap.parse_args()
    try:
        lines = open(a.file, encoding="utf-8", errors="replace").read().splitlines()
    except OSError:
        lines = [f"(không đọc được {a.file})"]
    print(build(a.level, a.title, lines, a.grep, a.tail))


if __name__ == "__main__":
    main()
