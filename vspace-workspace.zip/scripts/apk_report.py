#!/usr/bin/env python3
"""Báo cáo APK: dung lượng + căn lề 16 KB của thư viện native.

Thiết bị dùng trang bộ nhớ 16 KB (Android 15+, thiết bị arm64/x86_64 mới) yêu cầu mọi segment PT_LOAD của .so
được căn >= 16384 byte. Thư viện không đạt có thể cài được nhưng crash khi nạp. Thư viện 32-bit không áp dụng.

Dùng:  python3 scripts/apk_report.py <file.apk> [--budget-mb 150] [--strict]
Luôn thoát 0 trừ khi có --strict và có thư viện arm64/x86_64 không đạt.
"""
import argparse, os, struct, sys, zipfile

PAGE16K = 16384
PT_LOAD = 1


def elf_load_aligns(data):
    """Trả về (bits, [p_align của các segment PT_LOAD]) hoặc None nếu không phải ELF."""
    if len(data) < 64 or data[:4] != b"\x7fELF":
        return None
    bits = 64 if data[4] == 2 else 32
    en = "<" if data[5] == 1 else ">"
    try:
        if bits == 64:
            phoff, = struct.unpack_from(en + "Q", data, 0x20)
            phentsize, phnum = struct.unpack_from(en + "HH", data, 0x36)
        else:
            phoff, = struct.unpack_from(en + "I", data, 0x1C)
            phentsize, phnum = struct.unpack_from(en + "HH", data, 0x2A)
        aligns = []
        for i in range(phnum):
            off = phoff + i * phentsize
            p_type, = struct.unpack_from(en + "I", data, off)
            if p_type != PT_LOAD:
                continue
            if bits == 64:
                align, = struct.unpack_from(en + "Q", data, off + 48)
            else:
                align, = struct.unpack_from(en + "I", data, off + 28)
            aligns.append(align)
        return bits, aligns
    except struct.error:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("apk")
    ap.add_argument("--budget-mb", type=float, default=float(os.environ.get("APK_BUDGET_MB", "150")))
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args()

    size_mb = os.path.getsize(a.apk) / (1024 * 1024)
    lines = [f"### APK: {os.path.basename(a.apk)}", f"- Dung lượng: {size_mb:.1f} MB (ngân sách {a.budget_mb:.0f} MB)"]
    if size_mb > a.budget_mb:
        print(f"::warning::{os.path.basename(a.apk)} {size_mb:.1f} MB vượt ngân sách {a.budget_mb:.0f} MB")
        lines.append("- ⚠ VƯỢT NGÂN SÁCH")

    bad, checked, skipped = [], 0, 0
    with zipfile.ZipFile(a.apk) as z:
        for info in z.infolist():
            n = info.filename
            if not (n.startswith("lib/") and n.endswith(".so")):
                continue
            abi = n.split("/")[1]
            res = elf_load_aligns(z.read(n))
            if res is None:
                continue
            bits, aligns = res
            if abi not in ("arm64-v8a", "x86_64"):
                skipped += 1
                continue
            checked += 1
            if not aligns or min(aligns) < PAGE16K:
                bad.append((n, min(aligns) if aligns else 0))

    lines.append(f"- Thư viện native 64-bit đã kiểm: {checked} (bỏ qua 32-bit: {skipped})")
    if bad:
        lines.append(f"- ⚠ {len(bad)} thư viện chưa căn 16 KB (có thể crash trên máy 16 KB):")
        for n, al in bad[:40]:
            lines.append(f"  - `{n}` p_align={al}")
        print(f"::warning::{len(bad)} thư viện native chưa căn 16 KB")
    else:
        lines.append("- ✓ Mọi thư viện 64-bit đều căn >= 16 KB" if checked else "- (không có thư viện 64-bit để kiểm)")

    text = "\n".join(lines)
    print(text)
    summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary:
        with open(summary, "a", encoding="utf-8") as f:
            f.write(text + "\n")
    return 1 if (a.strict and bad) else 0


if __name__ == "__main__":
    sys.exit(main())
