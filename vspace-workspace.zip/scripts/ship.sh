#!/usr/bin/env bash
# Một lệnh: đẩy mã lên GitHub -> chạy CI build APK thật (P0-1) + smoke test emulator -> tải kết quả về ./ci-out.
# Cần: git, GitHub CLI `gh` đã đăng nhập (`gh auth login`). Không cần Android SDK trên máy bạn.
#   bash scripts/ship.sh <chu-so-huu>/<ten-repo> [--harden] [--strip-spoof]
#   (workflow_dispatch tự build cả Debug lẫn Release; Release ký bằng khóa debug nếu chưa có 4 secret khóa ký — P1-19)
#   --harden        bật harden_exports (O-17)      --strip-spoof  bật strip_core_spoof (O-11)
set -euo pipefail
REPO="${1:?usage: ship.sh <owner/repo> [--harden] [--strip-spoof]}"; shift || true
command -v gh >/dev/null || { echo "Cần cài GitHub CLI: https://cli.github.com"; exit 1; }
gh auth status >/dev/null 2>&1 || { echo "Chạy: gh auth login"; exit 1; }
cd "$(dirname "$0")/.."

FLAGS=()
for a in "$@"; do
  case "$a" in
    --harden) FLAGS+=(-f harden_exports=true) ;;
    --strip-spoof) FLAGS+=(-f strip_core_spoof=true) ;;
    *) echo "tham số lạ: $a"; exit 1 ;;
  esac
done

[ -d .git ] || git init -q -b main
git add -A && { git diff --cached --quiet || git commit -q -m "vspace workspace: CI build"; }
if gh repo view "$REPO" >/dev/null 2>&1; then
  git remote get-url origin >/dev/null 2>&1 || git remote add origin "https://github.com/$REPO.git"
  git push -u origin HEAD:main
else
  gh repo create "$REPO" --private --source . --remote origin --push
fi

echo "Chạy workflow build.yml ..."
gh workflow run build.yml --repo "$REPO" --ref main "${FLAGS[@]}"
sleep 10
RUN_ID="$(gh run list --repo "$REPO" --workflow build.yml --limit 1 --json databaseId -q '.[0].databaseId')"
echo "Run: https://github.com/$REPO/actions/runs/$RUN_ID"
gh run watch "$RUN_ID" --repo "$REPO" --exit-status || echo "CI có bước đỏ — vẫn tải log/artifact để xem"
rm -rf ci-out && mkdir -p ci-out
gh run download "$RUN_ID" --repo "$REPO" -D ci-out || true
gh run view "$RUN_ID" --repo "$REPO" --log-failed > ci-out/failed.log 2>&1 || true
echo "Xong. APK/artifact/log ở ./ci-out (gửi ci-out/failed.log nếu có lỗi)."
