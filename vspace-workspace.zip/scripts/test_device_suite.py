import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import device_suite as ds


class T(unittest.TestCase):
    def test_abi(self):
        self.assertEqual(ds.first_abi("arm64-v8a,armeabi-v7a,armeabi"), "arm64-v8a")
        self.assertEqual(ds.first_abi("armeabi-v7a,armeabi"), "armeabi-v7a")
        self.assertEqual(ds.first_abi("x86_64,x86,arm64-v8a"), "x86_64")
        self.assertIsNone(ds.first_abi("x86,armeabi"))
        self.assertEqual(ds.workspace_pkg("armeabi-v7a"), "dev.vspace.workspace.a32")
        self.assertEqual(ds.workspace_pkg("arm64-v8a"), "dev.vspace.workspace")

    def test_choose_abi_follows_available_apks(self):
        emu = "x86_64,x86,arm64-v8a,armeabi-v7a,armeabi"
        both = ["workspace-x86_64-Debug.apk", "workspace-arm64-v8a-Debug.apk"]
        self.assertEqual(ds.choose_abi(emu, both), "x86_64")                       # ưu tiên native
        self.assertEqual(ds.choose_abi(emu, ["workspace-arm64-v8a-Debug.apk"]), "arm64-v8a")   # chỉ có arm64: chạy qua dịch lệnh
        self.assertEqual(ds.choose_abi("arm64-v8a,armeabi-v7a", both), "arm64-v8a")           # máy ARM thật không dùng bản x86
        self.assertIsNone(ds.choose_abi("x86,armeabi", both))
        self.assertIsNone(ds.choose_abi(emu, []))
        self.assertEqual(ds.workspace_pkg("x86_64"), "dev.vspace.workspace")

    def test_pick_apks_prefers_debug_and_abi(self):
        paths = ["x/workspace-arm64-v8a-Release.apk", "x/workspace-arm64-v8a-Debug.apk", "x/workspace-armeabi-v7a-Debug.apk", "x/testguest-Debug.apk"]
        ws, tg, notes = ds.pick_apks(paths, "arm64-v8a")
        self.assertTrue(ws.endswith("arm64-v8a-Debug.apk"))
        self.assertTrue(tg.endswith("testguest-Debug.apk"))
        self.assertEqual(notes, [])
        ws, tg, notes = ds.pick_apks(["workspace-arm64-v8a-Release.apk"], "arm64-v8a")
        self.assertTrue(ws.endswith("Release.apk"))
        self.assertTrue(notes)   # cảnh báo không dùng được run-as
        self.assertIsNone(tg)
        self.assertEqual(ds.pick_apks(["workspace-arm64-v8a-Debug.apk"], "armeabi-v7a")[0], None)

    def test_patch_prefs(self):
        x = ds.patch_prefs_xml("", pin_processes=False, keep_alive=True)
        self.assertIs(ds.read_flag(x, "pin_processes"), False)
        self.assertIs(ds.read_flag(x, "keep_alive"), True)
        x2 = ds.patch_prefs_xml(x, pin_processes=True)
        self.assertIs(ds.read_flag(x2, "pin_processes"), True)
        self.assertEqual(x2.count("pin_processes"), 1)            # thay chứ không nhân đôi
        self.assertIs(ds.read_flag(x2, "keep_alive"), True)       # cờ khác giữ nguyên
        existing = "<?xml version='1.0'?>\n<map>\n    <string name=\"sort\">a</string>\n    <boolean name=\"keep_alive\" value=\"false\" />\n</map>\n"
        x3 = ds.patch_prefs_xml(existing, keep_alive=True)
        self.assertIn('<string name="sort">a</string>', x3)       # không làm mất khóa khác
        self.assertIs(ds.read_flag(x3, "keep_alive"), True)
        self.assertIsNone(ds.read_flag(x3, "nope"))

    def test_scenarios(self):
        a = ds.scenarios(10, False)
        self.assertEqual([s["id"] for s in a], ["S1", "S2", "S3"])
        self.assertFalse(a[0]["pin"]); self.assertTrue(a[1]["pin"])
        self.assertTrue(a[2]["panel"]); self.assertEqual(a[2]["screen"], "keep")
        self.assertEqual(ds.scenarios(10, True)[-1]["id"], "S4")
        self.assertTrue(all(s["minutes"] == 10 for s in a))

    def test_report(self):
        md = ds.report_markdown({"model": "Pixel", "api": "34"}, [{"id": "S1", "label": "x", "verdict": "RUNS", "reason": "ok"},
                                                                   {"id": "S2", "label": "y", "error": "không thấy nhịp tim"}], ["P0-8: ..."])
        self.assertIn("S1", md); self.assertIn("**RUNS**", md); self.assertIn("không thấy nhịp tim", md); self.assertIn("P0-8", md)

    UI_PREVIEW = (
        '<?xml version="1.0" encoding="UTF-8"?><hierarchy rotation="0">'
        '<node index="0" text="" resource-id="" class="android.widget.FrameLayout" package="dev.vspace.workspace" bounds="[0,0][1080,2400]">'
        '<node text="Xem trước" resource-id="android:id/alertTitle" class="android.widget.TextView" package="dev.vspace.workspace" bounds="[100,800][980,900]" />'
        '<node text="Hủy" resource-id="android:id/button2" class="android.widget.Button" package="dev.vspace.workspace" bounds="[500,1500][700,1620]" />'
        '<node text="Cài" resource-id="android:id/button1" class="android.widget.Button" package="dev.vspace.workspace" bounds="[760,1500][960,1620]" />'
        '</node></hierarchy>')
    UI_SPACES = (
        '<hierarchy><node text="" resource-id="android:id/select_dialog_listview" class="android.widget.ListView" package="dev.vspace.workspace" bounds="[100,900][980,1500]">'
        '<node text="Không gian 2" resource-id="android:id/text1" class="android.widget.CheckedTextView" package="dev.vspace.workspace" bounds="[100,1100][980,1200]" />'
        '<node text="Không gian 1" resource-id="android:id/text1" class="android.widget.CheckedTextView" package="dev.vspace.workspace" bounds="[100,900][980,1000]" />'
        '</node></hierarchy>')
    UI_SYSTEM = (
        '<hierarchy><node text="Cho phép" resource-id="android:id/button1" class="android.widget.Button" package="com.android.systemui" bounds="[100,100][300,200]" /></hierarchy>')

    def test_ui_tap_choices(self):
        n = ds.parse_ui_nodes(self.UI_PREVIEW)
        self.assertEqual(len(n), 4)
        x, y, why = ds.choose_dialog_tap(n, "dev.vspace.workspace")
        self.assertEqual((x, y), (860, 1560))                       # tâm nút "Cài" (button1), không phải "Hủy"
        sp = ds.choose_dialog_tap(ds.parse_ui_nodes(self.UI_SPACES), "dev.vspace.workspace")
        self.assertEqual((sp[0], sp[1]), (540, 950))                # mục ĐẦU theo toạ độ y (Không gian 1) dù đứng sau trong XML
        self.assertIsNone(ds.choose_dialog_tap(ds.parse_ui_nodes(self.UI_SYSTEM), "dev.vspace.workspace"))   # hộp thoại hệ thống: bỏ qua
        self.assertIsNone(ds.choose_dialog_tap(ds.parse_ui_nodes(""), "dev.vspace.workspace"))
        self.assertIsNone(ds.choose_dialog_tap(ds.parse_ui_nodes("<hierarchy></hierarchy>"), "dev.vspace.workspace"))

    def test_stop_report(self):
        md = ds.stop_markdown({"model": "sdk_gphone", "api": "34", "abi": "x86_64"}, "Vẫn không thấy nhịp tim testguest")
        self.assertIn("DỪNG SỚM", md)
        self.assertIn("Vẫn không thấy nhịp tim", md)
        self.assertIn("logcat_all.txt", md)

    def test_dry_run_does_not_crash(self):
        with tempfile.TemporaryDirectory() as t:
            for n in ("workspace-arm64-v8a-Debug.apk", "testguest-Debug.apk"):
                open(os.path.join(t, n), "wb").write(b"x")
            out = os.path.join(t, "out")
            self.assertEqual(ds.main(["--apk-dir", t, "--dry-run", "--no-manual", "--out", out, "--minutes", "1"]), 0)

    def test_missing_apks_exit(self):
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaises(SystemExit):
                ds.main(["--apk-dir", t, "--dry-run"])


if __name__ == "__main__":
    unittest.main()
