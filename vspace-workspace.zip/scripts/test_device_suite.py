import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import device_suite as ds


class T(unittest.TestCase):
    def test_abi(self):
        self.assertEqual(ds.first_abi("arm64-v8a,armeabi-v7a,armeabi"), "arm64-v8a")
        self.assertEqual(ds.first_abi("armeabi-v7a,armeabi"), "armeabi-v7a")
        self.assertIsNone(ds.first_abi("x86_64,x86"))
        self.assertEqual(ds.workspace_pkg("armeabi-v7a"), "dev.vspace.workspace.a32")
        self.assertEqual(ds.workspace_pkg("arm64-v8a"), "dev.vspace.workspace")

    def test_pick_apks_prefers_debug_and_abi(self):
        paths = ["x/workspace-arm64-v8a-Release.apk", "x/workspace-arm64-v8a-Debug.apk", "x/workspace-armeabi-v7a-Debug.apk", "x/testguest-Debug.apk"]
        ws, tg, notes = ds.pick_apks(paths, "arm64-v8a")
        self.assertTrue(ws.endswith("arm64-v8a-Debug.apk"))
        self.assertTrue(tg.endswith("testguest-Debug.apk"))
        self.assertEqual(notes, [])
        ws, tg, notes = ds.pick_apks(["workspace-arm64-v8a-Release.apk"], "arm64-v8a")
        self.assertTrue(ws.endswith("Release.apk"))
        self.assertTrue(notes)   # cảnh báo không dùng được run-as
        self.assertIsNone(tg)
        self.assertEqual(ds.pick_apks(["workspace-arm64-v8a-Debug.apk"], "armeabi-v7a")[0], None)

    def test_patch_prefs(self):
        x = ds.patch_prefs_xml("", pin_processes=False, keep_alive=True)
        self.assertIs(ds.read_flag(x, "pin_processes"), False)
        self.assertIs(ds.read_flag(x, "keep_alive"), True)
        x2 = ds.patch_prefs_xml(x, pin_processes=True)
        self.assertIs(ds.read_flag(x2, "pin_processes"), True)
        self.assertEqual(x2.count("pin_processes"), 1)            # thay chứ không nhân đôi
        self.assertIs(ds.read_flag(x2, "keep_alive"), True)       # cờ khác giữ nguyên
        existing = "<?xml version='1.0'?>\n<map>\n    <string name=\"sort\">a</string>\n    <boolean name=\"keep_alive\" value=\"false\" />\n</map>\n"
        x3 = ds.patch_prefs_xml(existing, keep_alive=True)
        self.assertIn('<string name="sort">a</string>', x3)       # không làm mất khóa khác
        self.assertIs(ds.read_flag(x3, "keep_alive"), True)
        self.assertIsNone(ds.read_flag(x3, "nope"))

    def test_scenarios(self):
        a = ds.scenarios(10, False)
        self.assertEqual([s["id"] for s in a], ["S1", "S2", "S3"])
        self.assertFalse(a[0]["pin"]); self.assertTrue(a[1]["pin"])
        self.assertTrue(a[2]["panel"]); self.assertEqual(a[2]["screen"], "keep")
        self.assertEqual(ds.scenarios(10, True)[-1]["id"], "S4")
        self.assertTrue(all(s["minutes"] == 10 for s in a))

    def test_report(self):
        md = ds.report_markdown({"model": "Pixel", "api": "34"}, [{"id": "S1", "label": "x", "verdict": "RUNS", "reason": "ok"},
                                                                   {"id": "S2", "label": "y", "error": "không thấy nhịp tim"}], ["P0-8: ..."])
        self.assertIn("S1", md); self.assertIn("**RUNS**", md); self.assertIn("không thấy nhịp tim", md); self.assertIn("P0-8", md)

    def test_dry_run_does_not_crash(self):
        with tempfile.TemporaryDirectory() as t:
            for n in ("workspace-arm64-v8a-Debug.apk", "testguest-Debug.apk"):
                open(os.path.join(t, n), "wb").write(b"x")
            out = os.path.join(t, "out")
            self.assertEqual(ds.main(["--apk-dir", t, "--dry-run", "--no-manual", "--out", out, "--minutes", "1"]), 0)

    def test_missing_apks_exit(self):
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaises(SystemExit):
                ds.main(["--apk-dir", t, "--dry-run"])


if __name__ == "__main__":
    unittest.main()
