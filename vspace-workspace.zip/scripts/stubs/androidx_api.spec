# Stub THỦ CÔNG cho androidx.recyclerview (phiên 8) — android.jar thật (Sable/android-platforms) không có AndroidX,
# nên không thể tải artifact thật của androidx vào sandbox (mọi mirror tìm được — Google Maven, CERN Nexus,
# jitpack — đều không nằm trong allowlist mạng của bash_tool). File này KHÔNG phải để chạy, KHÔNG được đóng vào
# APK, và luôn được nạp CÙNG với android.jar thật (không bị loại như phần android.* của android_api.spec).
#
# Mỗi chữ ký dưới đây đã đối chiếu với developer.android.com (RecyclerView.ViewHolder, RecyclerView.Adapter,
# ItemTouchHelper.Callback/SimpleCallback — xem PROJECT_HANDOFF.md mục 20). Giá trị các hằng số (LEFT/RIGHT/
# ACTION_STATE_*) không cần khớp tuyệt đối với bản thật: chúng chỉ dùng NỘI BỘ trong sandbox để javac chạy qua,
# không bao giờ liên kết với androidx thật — build CI thật sẽ dùng giá trị thật của androidx, không dùng file này.
#
# Chỉ stub ĐÚNG những gì MainActivity.java (GuestAdapter/GuestSwipeCallback) thực sự gọi — không thêm bề mặt thừa.
# Thêm API androidx mới: viết thêm @@ hoặc khối lồng, rồi chạy `python3 scripts/compile_check.py` để kiểm.

@@ androidx.recyclerview.widget.RecyclerView | public class RecyclerView extends android.view.ViewGroup
    public static final int NO_POSITION = -1;
    public RecyclerView(android.content.Context c) { super(c); }
    protected void onLayout(boolean changed, int l, int t, int r, int b) {}
    public void setLayoutManager(LayoutManager manager);
    public void setAdapter(Adapter adapter);
    public Adapter getAdapter();
    public void setHasFixedSize(boolean hasFixedSize);

    public abstract static class LayoutManager {
    }

    public abstract static class ViewHolder {
        public final android.view.View itemView;
        public ViewHolder(android.view.View itemView) { this.itemView = itemView; }
        public final int getAdapterPosition();
        public final int getLayoutPosition();
    }

    public abstract static class Adapter<VH extends ViewHolder> {
        public abstract VH onCreateViewHolder(android.view.ViewGroup parent, int viewType);
        public abstract void onBindViewHolder(VH holder, int position);
        public abstract int getItemCount();
        public void notifyDataSetChanged();
        public void notifyItemChanged(int position);
        public void notifyItemInserted(int position);
        public void notifyItemRemoved(int position);
        public void notifyItemRangeChanged(int positionStart, int itemCount);
    }
@@ androidx.recyclerview.widget.LinearLayoutManager | public class LinearLayoutManager extends androidx.recyclerview.widget.RecyclerView.LayoutManager
    public LinearLayoutManager(android.content.Context context) {}
@@ androidx.recyclerview.widget.ItemTouchHelper | public class ItemTouchHelper
    public static final int ACTION_STATE_IDLE = 0;
    public static final int ACTION_STATE_SWIPE = 1;
    public static final int ACTION_STATE_DRAG = 2;
    public static final int UP = 1;
    public static final int DOWN = 1 << 1;
    public static final int LEFT = 1 << 2;
    public static final int RIGHT = 1 << 3;
    public ItemTouchHelper(Callback callback) {}
    public void attachToRecyclerView(androidx.recyclerview.widget.RecyclerView recyclerView);

    public abstract static class Callback {
        public static int makeMovementFlags(int dragFlags, int swipeFlags);
        public abstract boolean onMove(androidx.recyclerview.widget.RecyclerView recyclerView,
                androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder,
                androidx.recyclerview.widget.RecyclerView.ViewHolder target);
        public abstract void onSwiped(androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder, int direction);
        public void onChildDraw(android.graphics.Canvas c, androidx.recyclerview.widget.RecyclerView recyclerView,
                androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState,
                boolean isCurrentlyActive) {}
    }

    public abstract static class SimpleCallback extends Callback {
        public SimpleCallback(int dragDirs, int swipeDirs) {}
    }
