# Chữ ký tối thiểu của Android API + lõi BlackBox, chỉ đủ để BIÊN DỊCH mã của dự án trong sandbox (không có android.jar).
# Định dạng: dòng "@@ tên.đầy.đủ | khai báo lớp" bắt đầu một lớp; các dòng sau là thành viên (viết như Java, không thân hàm).
# compile_check.py tự thêm `native` cho phương thức không phải abstract/interface và thêm {} cho constructor.
# QUY TẮC: chữ ký phải giống Android thật. Không chắc thì ghi chú "UNSURE" để người sau kiểm.
@@ android.Manifest | public class Manifest
    public static final class permission {
        public static final String POST_NOTIFICATIONS = "android.permission.POST_NOTIFICATIONS";
    }
@@ android.R | public final class R
    public static final class string {
        public static final int ok = 17039370;
        public static final int cancel = 17039360;
    }
@@ android.annotation.SuppressLint | public @interface SuppressLint
    String[] value();
@@ android.content.Context | public abstract class Context
    public static final String POWER_SERVICE = "power";
    public static final String ACTIVITY_SERVICE = "activity";
    public static final String ALARM_SERVICE = "alarm";
    public static final String WINDOW_SERVICE = "window";
    public static final String AUDIO_SERVICE = "audio";
    public static final String WIFI_SERVICE = "wifi";
    public static final String CLIPBOARD_SERVICE = "clipboard";
    public static final int MODE_PRIVATE = 0;
    public static final int BIND_AUTO_CREATE = 1;
    public static final int BIND_IMPORTANT = 64;
    public String getPackageName();
    public PackageManager getPackageManager();
    public Context getApplicationContext();
    public ApplicationInfo getApplicationInfo();
    public Object getSystemService(String name);
    public final <T> T getSystemService(Class<T> serviceClass) { return null; }
    public final String getString(int resId) { return null; }
    public final String getString(int resId, Object... formatArgs) { return null; }
    public android.content.res.Resources getResources();
    public ContentResolver getContentResolver();
    public java.io.File getCacheDir();
    public java.io.File getExternalFilesDir(String type);
    public java.io.File getFilesDir();
    public java.io.File getDataDir();
    public void startActivity(Intent intent);
    public ComponentName startForegroundService(Intent service);
    public ComponentName startService(Intent service);
    public boolean stopService(Intent service);
    public boolean bindService(Intent service, ServiceConnection conn, int flags);
    public void unbindService(ServiceConnection conn);
    public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter);
    public void unregisterReceiver(BroadcastReceiver receiver);
    public void sendBroadcast(Intent intent);
    public SharedPreferences getSharedPreferences(String name, int mode);
    public int checkSelfPermission(String permission);
    public static final String USAGE_STATS_SERVICE = "usagestats";
    public static final String CONNECTIVITY_SERVICE = "connectivity";
@@ android.content.res.Resources | public class Resources
    public DisplayMetrics getDisplayMetrics();
@@ android.util.DisplayMetrics | public class DisplayMetrics
    public float density;
@@ android.content.Intent | public class Intent
    public static final String ACTION_MAIN = "android.intent.action.MAIN";
    public static final String ACTION_VIEW = "android.intent.action.VIEW";
    public static final String ACTION_SEND = "android.intent.action.SEND";
    public static final String ACTION_BOOT_COMPLETED = "android.intent.action.BOOT_COMPLETED";
    public static final String ACTION_SCREEN_OFF = "android.intent.action.SCREEN_OFF";
    public static final String ACTION_BATTERY_CHANGED = "android.intent.action.BATTERY_CHANGED";
    public static final String ACTION_OPEN_DOCUMENT = "android.intent.action.OPEN_DOCUMENT";
    public static final String ACTION_OPEN_DOCUMENT_TREE = "android.intent.action.OPEN_DOCUMENT_TREE";
    public static final String ACTION_CREATE_DOCUMENT = "android.intent.action.CREATE_DOCUMENT";
    public static final String CATEGORY_OPENABLE = "android.intent.category.OPENABLE";
    public static final String EXTRA_ALLOW_MULTIPLE = "android.intent.extra.ALLOW_MULTIPLE";
    public static final String EXTRA_MIME_TYPES = "android.intent.extra.MIME_TYPES";
    public static final String EXTRA_STREAM = "android.intent.extra.STREAM";
    public static final String EXTRA_TITLE = "android.intent.extra.TITLE";
    public static final int FLAG_ACTIVITY_NEW_TASK = 268435456;
    public static final int FLAG_ACTIVITY_SINGLE_TOP = 536870912;
    public static final int FLAG_ACTIVITY_CLEAR_TOP = 67108864;
    public static final int FLAG_GRANT_READ_URI_PERMISSION = 1;
    public static final int FLAG_GRANT_WRITE_URI_PERMISSION = 2;
    public static final int FLAG_GRANT_PERSISTABLE_URI_PERMISSION = 64;
    public Intent();
    public Intent(String action);
    public Intent(Context packageContext, Class<?> cls);
    public Intent(String action, Uri uri);
    public String getAction();
    public Intent setAction(String action);
    public Uri getData();
    public Intent setComponent(ComponentName c);
    public Intent setType(String type);
    public Intent addCategory(String c);
    public Intent addFlags(int flags);
    public Intent putExtra(String name, String value);
    public Intent putExtra(String name, int value);
    public Intent putExtra(String name, boolean value);
    public Intent putExtra(String name, String[] value);
    public Intent putExtra(String name, android.os.Parcelable value);
    public String getStringExtra(String name);
    public int getIntExtra(String name, int def);
    public boolean getBooleanExtra(String name, boolean def);
    public <T extends android.os.Parcelable> T getParcelableExtra(String name);
    public ClipData getClipData();
    public static Intent createChooser(Intent target, CharSequence title);
@@ android.content.IntentFilter | public class IntentFilter
    public IntentFilter(String action);
@@ android.content.ComponentName | public final class ComponentName
    public ComponentName(String pkg, String cls);
    public String getShortClassName();
    public ComponentName(Context pkg, Class<?> cls);
@@ android.content.ContentValues | public final class ContentValues
    public ContentValues();
@@ android.content.ContentResolver | public abstract class ContentResolver
    public final Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder);
    public final java.io.InputStream openInputStream(Uri uri) throws java.io.FileNotFoundException;
    public final java.io.OutputStream openOutputStream(Uri uri) throws java.io.FileNotFoundException;
    public void takePersistableUriPermission(Uri uri, int modeFlags);
@@ android.content.ContentProvider | public abstract class ContentProvider
    public abstract boolean onCreate();
    public abstract Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder);
    public abstract String getType(Uri uri);
    public abstract Uri insert(Uri uri, ContentValues values);
    public abstract int delete(Uri uri, String selection, String[] selectionArgs);
    public abstract int update(Uri uri, ContentValues values, String selection, String[] selectionArgs);
    public android.os.ParcelFileDescriptor openFile(Uri uri, String mode) throws java.io.FileNotFoundException { return null; }
    public final Context getContext() { return null; }
@@ android.content.BroadcastReceiver | public abstract class BroadcastReceiver
    public BroadcastReceiver();
    public abstract void onReceive(Context context, Intent intent);
@@ android.content.ServiceConnection | public interface ServiceConnection
    void onServiceConnected(ComponentName name, android.os.IBinder service);
    void onServiceDisconnected(ComponentName name);
    default void onBindingDied(ComponentName name) {}
    default void onNullBinding(ComponentName name) {}
@@ android.content.ClipData | public class ClipData
    public static ClipData newPlainText(CharSequence label, CharSequence text);
    public int getItemCount();
    public Item getItemAt(int index);
    public static class Item {
        public Uri getUri();
    }
@@ android.content.ClipboardManager | public class ClipboardManager
    public void setPrimaryClip(ClipData clip);
@@ android.content.SharedPreferences | public interface SharedPreferences
    String getString(String key, String defValue);
    boolean getBoolean(String key, boolean defValue);
    int getInt(String key, int defValue);
    long getLong(String key, long defValue);
    Editor edit();
    interface Editor {
        Editor putString(String key, String value);
        Editor putBoolean(String key, boolean value);
        Editor putInt(String key, int value);
        Editor putLong(String key, long value);
        Editor remove(String key);
        boolean commit();
        void apply();
    }
    java.util.Map<String, ?> getAll();
@@ android.content.pm.PackageManager | public abstract class PackageManager
    public static final int GET_PERMISSIONS = 4096;
    public static final int GET_SERVICES = 4;
    public static final int GET_RECEIVERS = 2;
    public static final int GET_SIGNATURES = 64;
    public static final int GET_SIGNING_CERTIFICATES = 134217728;
    public static final int PERMISSION_GRANTED = 0;
    public abstract PackageInfo getPackageInfo(String packageName, int flags) throws NameNotFoundException;
    public abstract PackageInfo getPackageArchiveInfo(String archiveFilePath, int flags);
    public abstract List<ApplicationInfo> getInstalledApplications(int flags);
    public abstract CharSequence getApplicationLabel(ApplicationInfo info);
    public abstract android.graphics.drawable.Drawable getDefaultActivityIcon();
    public abstract PermissionInfo getPermissionInfo(String name, int flags) throws NameNotFoundException;
    public static class NameNotFoundException extends Exception {
        public NameNotFoundException();
    }
    public abstract boolean isAutoRevokeWhitelisted();
@@ android.content.pm.ApplicationInfo | public class ApplicationInfo
    public static final int FLAG_SYSTEM = 1;
    public String packageName;
    public String sourceDir;
    public String publicSourceDir;
    public int flags;
    public int targetSdkVersion;
    public CharSequence loadLabel(PackageManager pm);
    public android.graphics.drawable.Drawable loadIcon(PackageManager pm);
    public static final int FLAG_DEBUGGABLE = 2;
@@ android.content.pm.PackageInfo | public class PackageInfo
    public String packageName;
    public String versionName;
    public int versionCode;
    public long getLongVersionCode();
    public ApplicationInfo applicationInfo;
    public String[] requestedPermissions;
    public ServiceInfo[] services;
    public ActivityInfo[] receivers;
    public Signature[] signatures;
    public SigningInfo signingInfo;
@@ android.content.pm.ServiceInfo | public class ServiceInfo
    public static final int FOREGROUND_SERVICE_TYPE_SPECIAL_USE = 1073741824;
    public String name;
    public String packageName;
    public String processName;
    public String permission;
    public boolean enabled;
@@ android.content.pm.ActivityInfo | public class ActivityInfo
    public String permission;
@@ android.content.pm.PermissionInfo | public class PermissionInfo
    public static final int PROTECTION_DANGEROUS = 1;
    public static final int PROTECTION_MASK_BASE = 15;
    public int protectionLevel;
@@ android.content.pm.Signature | public class Signature
    public byte[] toByteArray();
@@ android.content.pm.SigningInfo | public final class SigningInfo
    public boolean hasMultipleSigners();
    public Signature[] getApkContentsSigners();
    public Signature[] getSigningCertificateHistory();
@@ android.content.pm.ShortcutManager | public class ShortcutManager
    public boolean isRequestPinShortcutSupported();
    public boolean requestPinShortcut(ShortcutInfo shortcut, android.content.IntentSender resultIntent);
@@ android.content.IntentSender | public class IntentSender
@@ android.content.pm.ShortcutInfo | public final class ShortcutInfo
    public static class Builder {
        public Builder(Context context, String id);
        public Builder setShortLabel(CharSequence shortLabel);
        public Builder setIcon(android.graphics.drawable.Icon icon);
        public Builder setIntent(Intent intent);
        public ShortcutInfo build();
    }
@@ android.database.Cursor | public interface Cursor extends java.io.Closeable
    boolean moveToNext();
    String getString(int columnIndex);
    void close();
@@ android.database.MatrixCursor | public class MatrixCursor implements Cursor
    public MatrixCursor(String[] columnNames);
    public void addRow(Object[] columnValues);
    public boolean moveToNext() { return false; }
    public String getString(int columnIndex) { return null; }
    public void close() {}
@@ android.net.Uri | public abstract class Uri implements android.os.Parcelable
    public static Uri parse(String uriString);
    public static String encode(String s);
    public static String decode(String s);
    public String getLastPathSegment();
    public abstract String toString();
@@ android.net.LocalSocketAddress | public class LocalSocketAddress
    public enum Namespace { ABSTRACT, RESERVED, FILESYSTEM }
    public LocalSocketAddress(String name, Namespace namespace);
@@ android.net.LocalSocket | public class LocalSocket implements java.io.Closeable
    public LocalSocket();
    public void connect(LocalSocketAddress endpoint) throws java.io.IOException;
    public java.io.InputStream getInputStream() throws java.io.IOException;
    public java.io.OutputStream getOutputStream() throws java.io.IOException;
    public android.net.Credentials getPeerCredentials() throws java.io.IOException;
    public void close() throws java.io.IOException;
@@ android.net.Credentials | public class Credentials
    public int getUid();
@@ android.net.LocalServerSocket | public class LocalServerSocket implements java.io.Closeable
    public LocalServerSocket(String name) throws java.io.IOException;
    public LocalSocket accept() throws java.io.IOException;
    public void close() throws java.io.IOException;
@@ android.net.TrafficStats | public class TrafficStats
    public static long getUidRxBytes(int uid);
    public static long getUidTxBytes(int uid);
@@ android.net.wifi.WifiManager | public class WifiManager
    public static final int WIFI_MODE_FULL_HIGH_PERF = 3;
    public static final int WIFI_MODE_FULL_LOW_LATENCY = 4;
    public WifiLock createWifiLock(int lockType, String tag);
    public class WifiLock {
        public void setReferenceCounted(boolean refCounted);
        public void acquire();
        public void release();
        public boolean isHeld();
    }
@@ android.os.Parcelable | public interface Parcelable
@@ android.os.IBinder | public interface IBinder
@@ android.os.Bundle | public final class Bundle
    public Bundle();
@@ android.os.Looper | public final class Looper
    public static Looper getMainLooper();
@@ android.os.Handler | public class Handler
    public Handler();
    public Handler(Looper looper);
    public final boolean post(Runnable r);
    public final boolean postDelayed(Runnable r, long delayMillis);
    public final void removeCallbacks(Runnable r);
    public final void removeCallbacksAndMessages(Object token);
@@ android.os.Process | public class Process
    public static final int myPid();
    public static final int myUid();
    public static final void killProcess(int pid);
    public static final boolean is64Bit();
    public static final int THREAD_PRIORITY_DISPLAY = -4;
    public static final int THREAD_PRIORITY_DEFAULT = 0;
    public static final void setThreadPriority(int tid, int priority);
    public static final void setThreadPriority(int priority);
@@ android.os.SystemClock | public final class SystemClock
    public static long elapsedRealtime();
    public static long uptimeMillis();
@@ android.os.StatFs | public class StatFs
    public StatFs(String path);
    public long getAvailableBytes();
@@ android.os.ParcelFileDescriptor | public class ParcelFileDescriptor
    public static final int MODE_READ_ONLY = 268435456;
    public static ParcelFileDescriptor open(java.io.File file, int mode) throws java.io.FileNotFoundException;
@@ android.os.BatteryManager | public class BatteryManager
    public static final String EXTRA_LEVEL = "level";
    public static final String EXTRA_SCALE = "scale";
    public static final String EXTRA_PLUGGED = "plugged";
    public static final String EXTRA_TEMPERATURE = "temperature";
@@ android.os.PowerManager | public final class PowerManager
    public static final int PARTIAL_WAKE_LOCK = 1;
    public static final int THERMAL_STATUS_SEVERE = 3;
    public WakeLock newWakeLock(int levelAndFlags, String tag);
    public boolean isIgnoringBatteryOptimizations(String packageName);
    public int getCurrentThermalStatus();
    public final class WakeLock {
        public void setReferenceCounted(boolean value);
        public void acquire(long timeout);
        public void release();
        public boolean isHeld();
    }
@@ android.os.Build | public class Build
    public static final String MODEL = "";
    public static final String MANUFACTURER = "";
    public static final String FINGERPRINT = "";
    public static final String[] SUPPORTED_ABIS = {};
    public static class VERSION {
        public static final int SDK_INT = 35;
        public static final String RELEASE = "15";
    }
@@ android.provider.OpenableColumns | public interface OpenableColumns
    String DISPLAY_NAME = "_display_name";
    String SIZE = "_size";
@@ android.provider.Settings | public final class Settings
    public static final String ACTION_APPLICATION_DETAILS_SETTINGS = "android.settings.APPLICATION_DETAILS_SETTINGS";
    public static final String ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS = "android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS";
    public static final String ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS = "android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS";
    public static final String ACTION_APPLICATION_DEVELOPMENT_SETTINGS = "android.settings.APPLICATION_DEVELOPMENT_SETTINGS";
    public static final String ACTION_MANAGE_OVERLAY_PERMISSION = "android.settings.action.MANAGE_OVERLAY_PERMISSION";
    public static final String ACTION_APP_NOTIFICATION_SETTINGS = "android.settings.APP_NOTIFICATION_SETTINGS";
    public static final String EXTRA_APP_PACKAGE = "android.provider.extra.APP_PACKAGE";
    public static boolean canDrawOverlays(Context context);
    public static final class Secure {
        public static final String ANDROID_ID = "android_id";
        public static String getString(ContentResolver resolver, String name);
    }
@@ android.provider.DocumentsContract | public final class DocumentsContract
    public static final class Document {
        public static final String COLUMN_DOCUMENT_ID = "document_id";
        public static final String COLUMN_DISPLAY_NAME = "_display_name";
    }
    public static String getTreeDocumentId(Uri documentUri);
    public static Uri buildDocumentUriUsingTree(Uri treeUri, String documentId);
    public static Uri buildChildDocumentsUriUsingTree(Uri treeUri, String parentDocumentId);
    public static Uri createDocument(ContentResolver content, Uri parentDocumentUri, String mimeType, String displayName) throws java.io.FileNotFoundException;
    public static boolean deleteDocument(ContentResolver content, Uri documentUri) throws java.io.FileNotFoundException;
@@ android.system.Os | public final class Os
    public static long sysconf(int name);
@@ android.system.OsConstants | public class OsConstants
    public static final int _SC_CLK_TCK = 2;
@@ android.util.Log | public final class Log
    public static int d(String tag, String msg);
    public static int i(String tag, String msg);
    public static int w(String tag, String msg);
    public static int e(String tag, String msg);
    public static int e(String tag, String msg, Throwable tr);
@@ android.text.Editable | public interface Editable extends CharSequence
@@ android.text.TextWatcher | public interface TextWatcher
    void beforeTextChanged(CharSequence s, int start, int count, int after);
    void onTextChanged(CharSequence s, int start, int before, int count);
    void afterTextChanged(Editable s);
@@ android.text.TextUtils | public class TextUtils
    public static String join(CharSequence delimiter, Iterable tokens);
@@ android.graphics.Color | public class Color
    public static final int BLACK = -16777216;
@@ android.graphics.PixelFormat | public class PixelFormat
    public static final int OPAQUE = -1;
@@ android.graphics.Typeface | public class Typeface
    public static final Typeface MONOSPACE = null;
@@ android.graphics.Bitmap | public final class Bitmap
    public static Bitmap createBitmap(int width, int height, Config config);
    public enum Config { ARGB_8888 }
@@ android.graphics.Canvas | public class Canvas
    public Canvas(Bitmap bitmap);
@@ android.graphics.drawable.Drawable | public abstract class Drawable
    public void setBounds(int left, int top, int right, int bottom);
    public abstract void draw(android.graphics.Canvas canvas);
@@ android.graphics.drawable.Icon | public final class Icon
    public static Icon createWithResource(Context context, int resId);
    public static Icon createWithBitmap(android.graphics.Bitmap bits);
@@ android.media.AudioManager | public class AudioManager
    public static final int STREAM_MUSIC = 3;
    public int getStreamVolume(int streamType);
    public void setStreamVolume(int streamType, int index, int flags);
@@ android.app.Application | public class Application extends Context
    public static String getProcessName();
    public void onCreate() {}
    protected void attachBaseContext(Context base) {}
    public void registerActivityLifecycleCallbacks(ActivityLifecycleCallbacks callback);
    public interface ActivityLifecycleCallbacks {
        void onActivityCreated(Activity activity, android.os.Bundle savedInstanceState);
        void onActivityStarted(Activity activity);
        void onActivityResumed(Activity activity);
        void onActivityPaused(Activity activity);
        void onActivityStopped(Activity activity);
        void onActivitySaveInstanceState(Activity activity, android.os.Bundle outState);
        void onActivityDestroyed(Activity activity);
    }
    public void onTrimMemory(int level) {}
@@ android.app.Activity | public class Activity extends Context
    public static final int RESULT_OK = -1;
    protected void onCreate(android.os.Bundle savedInstanceState) {}
    protected void onResume() {}
    protected void onPause() {}
    protected void onDestroy() {}
    protected void onNewIntent(Intent intent) {}
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {}
    public void setContentView(int layoutResID);
    public void setContentView(android.view.View view);
    public <T extends android.view.View> T findViewById(int id);
    public Intent getIntent();
    public void setIntent(Intent newIntent);
    public void startActivityForResult(Intent intent, int requestCode);
    public void finish();
    public boolean isFinishing();
    public android.view.LayoutInflater getLayoutInflater();
    public final void requestPermissions(String[] permissions, int requestCode);
    public android.view.Window getWindow();
    public boolean enterPictureInPictureMode(PictureInPictureParams params);
    public final void runOnUiThread(Runnable action);
@@ android.app.PictureInPictureParams | public final class PictureInPictureParams
    public static class Builder {
        public Builder();
        public PictureInPictureParams build();
    }
@@ android.app.Service | public abstract class Service extends Context
    public static final int START_STICKY = 1;
    public static final int START_NOT_STICKY = 2;
    public static final int STOP_FOREGROUND_REMOVE = 1;
    public void onCreate() {}
    public int onStartCommand(Intent intent, int flags, int startId) { return 0; }
    public void onDestroy() {}
    public abstract android.os.IBinder onBind(Intent intent);
    public final void startForeground(int id, Notification notification);
    public final void startForeground(int id, Notification notification, int foregroundServiceType);
    public final void stopForeground(int notificationBehavior);
    public final void stopSelf();
@@ android.app.AlertDialog | public class AlertDialog
    public void show();
    public static class Builder {
        public Builder(Context context);
        public Builder setTitle(CharSequence title);
        public Builder setTitle(int titleId);
        public Builder setMessage(CharSequence message);
        public Builder setMessage(int messageId);
        public Builder setView(android.view.View view);
        public Builder setItems(CharSequence[] items, android.content.DialogInterface.OnClickListener listener);
        public Builder setPositiveButton(CharSequence text, android.content.DialogInterface.OnClickListener listener);
        public Builder setPositiveButton(int textId, android.content.DialogInterface.OnClickListener listener);
        public Builder setNegativeButton(CharSequence text, android.content.DialogInterface.OnClickListener listener);
        public Builder setNegativeButton(int textId, android.content.DialogInterface.OnClickListener listener);
        public Builder setNeutralButton(CharSequence text, android.content.DialogInterface.OnClickListener listener);
        public Builder setNeutralButton(int textId, android.content.DialogInterface.OnClickListener listener);
        public Builder setOnCancelListener(android.content.DialogInterface.OnCancelListener listener);
        public AlertDialog show();
    }
@@ android.content.DialogInterface | public interface DialogInterface
    int BUTTON_POSITIVE = -1;
    interface OnClickListener {
        void onClick(DialogInterface dialog, int which);
    }
    interface OnCancelListener {
        void onCancel(DialogInterface dialog);
    }
@@ android.app.TimePickerDialog | public class TimePickerDialog
    public TimePickerDialog(Context context, OnTimeSetListener listener, int hourOfDay, int minute, boolean is24HourView);
    public void show();
    public interface OnTimeSetListener {
        void onTimeSet(android.widget.TimePicker view, int hourOfDay, int minute);
    }
@@ android.widget.TimePicker | public class TimePicker
@@ android.app.AlarmManager | public class AlarmManager
    public static final int RTC_WAKEUP = 0;
    public static final int ELAPSED_REALTIME_WAKEUP = 2;
    public void cancel(PendingIntent operation);
    public void setAndAllowWhileIdle(int type, long triggerAtMillis, PendingIntent operation);
    public void setExactAndAllowWhileIdle(int type, long triggerAtMillis, PendingIntent operation);
    public boolean canScheduleExactAlarms();
@@ android.app.PendingIntent | public final class PendingIntent
    public static final int FLAG_IMMUTABLE = 67108864;
    public static final int FLAG_UPDATE_CURRENT = 134217728;
    public static PendingIntent getActivity(Context context, int requestCode, Intent intent, int flags);
    public static PendingIntent getService(Context context, int requestCode, Intent intent, int flags);
    public static PendingIntent getBroadcast(Context context, int requestCode, Intent intent, int flags);
@@ android.app.NotificationChannel | public final class NotificationChannel
    public NotificationChannel(String id, CharSequence name, int importance);
    public void setShowBadge(boolean showBadge);
@@ android.app.NotificationManager | public class NotificationManager
    public static final int IMPORTANCE_LOW = 2;
    public static final int IMPORTANCE_DEFAULT = 3;
    public void createNotificationChannel(NotificationChannel channel);
    public void notify(int id, Notification notification);
    public boolean areNotificationsEnabled();
@@ android.app.Notification | public class Notification
    public static final int FOREGROUND_SERVICE_IMMEDIATE = 1;
    public static final String CATEGORY_SERVICE = "service";
    public static class Action {
        public static class Builder {
            public Builder(android.graphics.drawable.Icon icon, CharSequence title, PendingIntent intent);
            public Action build();
        }
    }
    public static class BigTextStyle extends Style {
        public BigTextStyle();
        public BigTextStyle bigText(CharSequence cs);
    }
    public static class Style {
    }
    public static class Builder {
        public Builder(Context context, String channelId);
        public Builder setSmallIcon(int icon);
        public Builder setContentTitle(CharSequence title);
        public Builder setContentText(CharSequence text);
        public Builder setContentIntent(PendingIntent intent);
        public Builder setOngoing(boolean ongoing);
        public Builder setShowWhen(boolean show);
        public Builder setCategory(String category);
        public Builder setAutoCancel(boolean autoCancel);
        public Builder setStyle(Style style);
        public Builder addAction(Action action);
        public Builder setForegroundServiceBehavior(int behavior);
        public Notification build();
    }
@@ android.app.ActivityManager | public class ActivityManager
    public List<RunningAppProcessInfo> getRunningAppProcesses();
    public List<ApplicationExitInfo> getHistoricalProcessExitReasons(String packageName, int pid, int maxNum);
    public static class RunningAppProcessInfo {
        public static final int IMPORTANCE_FOREGROUND = 100;
        public static final int IMPORTANCE_FOREGROUND_SERVICE = 125;
        public static final int IMPORTANCE_TOP_SLEEPING = 150;
        public static final int IMPORTANCE_VISIBLE = 200;
        public static final int IMPORTANCE_PERCEPTIBLE = 230;
        public static final int IMPORTANCE_CANT_SAVE_STATE = 270;
        public static final int IMPORTANCE_SERVICE = 300;
        public static final int IMPORTANCE_CACHED = 400;
        public String processName;
        public int pid;
        public int importance;
    }
    public void getMemoryInfo(MemoryInfo outInfo);
    public android.os.Debug.MemoryInfo[] getProcessMemoryInfo(int[] pids);
    public static class MemoryInfo {
        public long availMem;
        public long totalMem;
        public boolean lowMemory;
        public MemoryInfo();
    }
@@ android.app.ApplicationExitInfo | public final class ApplicationExitInfo
    public int getReason();
    public int getStatus();
    public int getImportance();
    public int getPid();
    public long getTimestamp();
    public String getProcessName();
    public String getDescription();
    public java.io.InputStream getTraceInputStream() throws java.io.IOException;
@@ android.view.Gravity | public class Gravity
    public static final int TOP = 48;
    public static final int START = 8388611;
    public static final int CENTER = 17;
@@ android.view.MotionEvent | public final class MotionEvent
    public static final int ACTION_DOWN = 0;
    public final int getActionMasked();
    public final float getX();
    public final float getY();
@@ android.view.Choreographer | public final class Choreographer
    public static Choreographer getInstance();
    public void postFrameCallback(FrameCallback callback);
    public void removeFrameCallback(FrameCallback callback);
    public interface FrameCallback {
        void doFrame(long frameTimeNanos);
    }
@@ android.view.LayoutInflater | public abstract class LayoutInflater
    public View inflate(int resource, ViewGroup root, boolean attachToRoot);
@@ android.view.View | public class View
    protected View() {}
    public static final int VISIBLE = 0;
    public static final int INVISIBLE = 4;
    public static final int GONE = 8;
    public View(Context context);
    public final Context getContext() { return null; }
    public <T extends View> T findViewById(int id);
    public void setVisibility(int visibility);
    public void setBackgroundColor(int color);
    public void setPadding(int left, int top, int right, int bottom);
    public final int getWidth();
    public final int getHeight();
    public boolean onTouchEvent(MotionEvent event) { return false; }
    protected void onDetachedFromWindow() {}
    public void setOnClickListener(OnClickListener l);
    public interface OnClickListener {
        void onClick(View v);
    }
    public void setContentDescription(CharSequence contentDescription);
@@ android.view.ViewGroup | public abstract class ViewGroup extends View
    protected ViewGroup() {}
    public ViewGroup(Context context);
    public void addView(View child);
    public void addView(View child, LayoutParams params);
    public static class LayoutParams {
        public static final int MATCH_PARENT = -1;
        public static final int WRAP_CONTENT = -2;
    }
    public int getChildCount();
    public View getChildAt(int index);
@@ android.view.Window | public abstract class Window
    public abstract WindowManager.LayoutParams getAttributes();
    public void setAttributes(WindowManager.LayoutParams a);
    public abstract View getDecorView();
@@ android.view.WindowManager | public interface WindowManager
    void addView(View view, ViewGroup.LayoutParams params);
    void removeViewImmediate(View view);
    public static class LayoutParams extends ViewGroup.LayoutParams {
        public static final int TYPE_APPLICATION_OVERLAY = 2038;
        public static final int FLAG_NOT_FOCUSABLE = 8;
        public static final int FLAG_KEEP_SCREEN_ON = 128;
        public static final int FLAG_LAYOUT_IN_SCREEN = 256;
        public static final int FLAG_LAYOUT_NO_LIMITS = 512;
        public static final float BRIGHTNESS_OVERRIDE_OFF = 0.0f;
        public static final int LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES = 1;
        public static final int LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS = 3;
        public int flags;
        public int gravity;
        public float screenBrightness;
        public float preferredRefreshRate;
        public int preferredDisplayModeId;
        public int layoutInDisplayCutoutMode;
        public LayoutParams(int w, int h, int type, int flags, int format);
    }
    Display getDefaultDisplay();
@@ android.widget.TextView | public class TextView extends android.view.View
    protected TextView() {}
    public TextView(Context context);
    public void setText(CharSequence text);
    public void setText(int resid);
    public void setTextColor(int color);
    public void setTextSize(float size);
    public void setGravity(int gravity);
    public void setTextIsSelectable(boolean selectable);
    public void setTypeface(android.graphics.Typeface tf);
    public void setSingleLine(boolean singleLine);
    public void setHint(int resid);
    public void addTextChangedListener(android.text.TextWatcher watcher);
    public CharSequence getText();
@@ android.widget.EditText | public class EditText extends TextView
    public EditText(Context context);
    public android.text.Editable getText();
@@ android.widget.Button | public class Button extends TextView
@@ android.widget.CompoundButton | public abstract class CompoundButton extends Button
    public void setChecked(boolean checked);
    public boolean isChecked();
    public void setOnCheckedChangeListener(OnCheckedChangeListener listener);
    public static interface OnCheckedChangeListener {
        void onCheckedChanged(CompoundButton buttonView, boolean isChecked);
    }
@@ android.widget.CheckBox | public class CheckBox extends CompoundButton
@@ android.widget.RadioButton | public class RadioButton extends CompoundButton
@@ android.widget.Switch | public class Switch extends CompoundButton
@@ android.widget.ImageView | public class ImageView extends android.view.View
    public void setImageDrawable(android.graphics.drawable.Drawable drawable);
@@ android.widget.FrameLayout | public class FrameLayout extends android.view.ViewGroup
    protected FrameLayout() {}
    public FrameLayout(Context context);
    public static class LayoutParams extends android.view.ViewGroup.LayoutParams {
        public LayoutParams(int width, int height, int gravity);
    }
@@ android.widget.ScrollView | public class ScrollView extends FrameLayout
    public ScrollView(Context context);
@@ android.widget.Adapter | public interface Adapter
@@ android.widget.BaseAdapter | public abstract class BaseAdapter implements ListAdapter
    public abstract int getCount();
    public abstract Object getItem(int position);
    public abstract long getItemId(int position);
    public abstract android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent);
    public void notifyDataSetChanged();
@@ android.widget.AdapterView | public abstract class AdapterView<T extends Adapter> extends android.view.ViewGroup
    protected AdapterView() {}
    public AdapterView(Context context);
    public void setEmptyView(android.view.View emptyView);
    public void setOnItemClickListener(OnItemClickListener listener);
    public void setOnItemLongClickListener(OnItemLongClickListener listener);
    public interface OnItemClickListener {
        void onItemClick(AdapterView<?> parent, android.view.View view, int position, long id);
    }
    public interface OnItemLongClickListener {
        boolean onItemLongClick(AdapterView<?> parent, android.view.View view, int position, long id);
    }
@@ android.widget.AbsListView | public abstract class AbsListView extends AdapterView<ListAdapter>
    protected AbsListView() {}
    public AbsListView(Context context);
@@ android.widget.ListAdapter | public interface ListAdapter extends Adapter
@@ android.widget.ListView | public class ListView extends AbsListView
    public ListView(Context context);
    public void setAdapter(ListAdapter adapter);
@@ android.widget.Toast | public class Toast
    public static final int LENGTH_SHORT = 0;
    public static final int LENGTH_LONG = 1;
    public static Toast makeText(Context context, CharSequence text, int duration);
    public static Toast makeText(Context context, int resId, int duration);
    public void show();
@@ org.json.JSONException | public class JSONException extends Exception
    public JSONException(String s);
@@ org.json.JSONObject | public class JSONObject
    public JSONObject();
    public JSONObject(String json) throws JSONException;
    public JSONObject put(String name, Object value) throws JSONException;
    public JSONObject put(String name, int value) throws JSONException;
    public JSONObject put(String name, long value) throws JSONException;
    public JSONObject put(String name, boolean value) throws JSONException;
    public int getInt(String name) throws JSONException;
    public String getString(String name) throws JSONException;
    public int optInt(String name);
    public int optInt(String name, int fallback);
    public long optLong(String name, long fallback);
    public boolean optBoolean(String name);
    public boolean optBoolean(String name, boolean fallback);
    public String optString(String name);
    public String optString(String name, String fallback);
    public String toString();

# ---------------------------------------------------------------- lõi BlackBox giả (chữ ký theo README; để gen_guest_hooks.py đọc)
@@ top.niunaijun.blackbox.app.configuration.ClientConfiguration | public abstract class ClientConfiguration
    public abstract String getHostPackageName();
    # Các hàm dưới XÁC NHẬN thật ở phiên 6 (đọc source), chữ ký + giá trị mặc định đúng như core thật.
    public boolean isHideRoot() { return false; }
    public boolean isEnableDaemonService() { return true; }
    public boolean isEnableLauncherActivity() { return true; }
    public boolean isUseVpnNetwork() { return false; }
    public boolean isDisableFlagSecure() { return false; }
    public boolean requestInstallPackage(java.io.File file, int userId) { return false; }
    # Mặc định THẬT là "-1003719573856" (chat Telegram của tác giả core) — xem Engine.attach() để biết vì sao phải override về null.
    public String getLogSenderChatId() { return "-1003719573856"; }
@@ top.niunaijun.blackbox.app.configuration.AppLifecycleCallback | public interface AppLifecycleCallback
    default void beforeCreateApplication(String packageName, String processName, android.content.Context context, int userId) {}
    default void beforeApplicationOnCreate(String packageName, String processName, android.app.Application application, int userId) {}
    default void afterApplicationOnCreate(String packageName, String processName, android.app.Application application, int userId) {}
@@ top.niunaijun.blackbox.entity.pm.InstallResult | public class InstallResult
    public boolean success = true;
    public String packageName;
    public String msg;
@@ top.niunaijun.blackbox.BlackBoxCore | public class BlackBoxCore
    public static BlackBoxCore get() { return null; }
    public void doAttachBaseContext(android.content.Context context, ClientConfiguration config) {}
    public void doCreate() {}
    # Chữ ký thật (phiên 5, SHA 89b5983, source trực tiếp): trả InstallResult, không phải boolean như bản cũ đoán theo README.
    public top.niunaijun.blackbox.entity.pm.InstallResult installPackageAsUser(java.io.File apk, int userId) { return null; }
    public top.niunaijun.blackbox.entity.pm.InstallResult installPackageAsUser(String packageName, int userId) { return null; }
    public boolean launchApk(String packageName, int userId) { return false; }
    public void stopPackage(String packageName, int userId) {}
    public void uninstallPackageAsUser(String packageName, int userId) {}
    public void uninstallPackage(String packageName) {}
    public java.util.List<android.content.pm.ApplicationInfo> getInstalledApplications(int flags, int userId) { return null; }
    public void addAppLifecycleCallback(AppLifecycleCallback callback) {}
    # Phiên 7: đối chiếu từng dòng với BlackBoxCore.java thật (SHA 89b5983) bằng scripts/verify_real.py
    public void clearPackage(String packageName, int userId) {}
    public void deleteUser(int userId) {}
    public boolean isSupportGms() { return false; }
    public boolean isInstallGms(int userId) { return false; }
    public top.niunaijun.blackbox.entity.pm.InstallResult installGms(int userId) { return null; }
    public boolean uninstallGms(int userId) { return false; }
@@ android.os.Debug | public class Debug
    public static class MemoryInfo {
        public MemoryInfo();
        public int getTotalPss();
    }
@@ android.view.Display | public class Display
    public Mode[] getSupportedModes();
    public Mode getMode();
    public static final class Mode {
        public int getModeId();
        public float getRefreshRate();
        public int getPhysicalWidth();
        public int getPhysicalHeight();
    }
@@ android.view.Surface | public class Surface
    public static final int FRAME_RATE_COMPATIBILITY_DEFAULT = 0;
    public static final int FRAME_RATE_COMPATIBILITY_FIXED_SOURCE = 1;
    public boolean isValid();
    public void setFrameRate(float frameRate, int compatibility);
@@ android.view.SurfaceHolder | public interface SurfaceHolder
    Surface getSurface();
    void setFixedSize(int width, int height);
    void setSizeFromLayout();
@@ android.view.SurfaceView | public class SurfaceView extends View
    public SurfaceView(Context context);
    public SurfaceHolder getHolder();
@@ android.os.StrictMode | public final class StrictMode
    public static void setThreadPolicy(ThreadPolicy policy);
    public static void setVmPolicy(VmPolicy policy);
    public static final class ThreadPolicy {
        public static final class Builder {
            public Builder();
            public Builder detectAll();
            public Builder penaltyLog();
            public ThreadPolicy build();
        }
    }
    public static final class VmPolicy {
        public static final class Builder {
            public Builder();
            public Builder detectLeakedClosableObjects();
            public Builder detectLeakedSqlLiteObjects();
            public Builder penaltyLog();
            public VmPolicy build();
        }
    }
@@ android.app.usage.UsageStatsManager | public final class UsageStatsManager
    public int getAppStandbyBucket();
@@ android.net.ConnectivityManager | public class ConnectivityManager
    public int getRestrictBackgroundStatus();
@@ android.appwidget.AppWidgetProvider | public class AppWidgetProvider extends BroadcastReceiver
    public AppWidgetProvider() {}
    public void onReceive(Context context, Intent intent) {}
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {}
@@ android.appwidget.AppWidgetManager | public class AppWidgetManager
    public static AppWidgetManager getInstance(Context context);
    public int[] getAppWidgetIds(ComponentName provider);
    public void updateAppWidget(int[] appWidgetIds, android.widget.RemoteViews views);
@@ android.widget.RemoteViews | public class RemoteViews
    public RemoteViews(String packageName, int layoutId);
    public void setTextViewText(int viewId, CharSequence text);
    public void setOnClickPendingIntent(int viewId, PendingIntent pendingIntent);
    public void setViewVisibility(int viewId, int visibility);
