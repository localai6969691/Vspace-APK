#!/usr/bin/env python3
"""Test cho scripts/measure_background.py (chỉ các hàm thuần; phần adb cần thiết bị thật)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import measure_background as m  # noqa: E402

LOG = """\
11-12 10:00:00.100  1234  1234 I VSpaceTestGuest: 10:00:00 create wall=0s game=0s worker=0 frames=0
11-12 10:00:00.120  1234  1234 I VSpaceTestGuest: ident uid=10123 pid=1234 androidId=abc123 filesDir=/data/x/space0/files token=T1
11-12 10:00:10.100  1234  1300 I VSpaceTestGuest: 10:00:10 worker wall=10s game=10s worker=10 frames=600
11-12 10:00:20.100  1234  1300 I VSpaceTestGuest: 10:00:20 worker wall=20s game=20s worker=20 frames=1200
"""


def hb(wall, worker, game, frames=0):
    return {"src": "worker", "wall": wall, "worker": worker, "game": game, "frames": frames}


class Heartbeats(unittest.TestCase):
    def test_parse_skips_ident_and_reads_fields(self):
        r = m.parse_heartbeats(LOG)
        self.assertEqual(len(r), 3)
        self.assertEqual(r[0]["src"], "create")
        self.assertEqual(r[2], {"src": "worker", "wall": 20, "game": 20, "worker": 20, "frames": 1200})

    def test_parse_ignores_noise(self):
        self.assertEqual(m.parse_heartbeats("không liên quan\nwall=abc"), [])

    def test_window_and_restart_detection(self):
        w = m.compute_window(hb(100, 100, 100, 6000), hb(400, 395, 390, 24000))
        self.assertEqual((w["dwall"], w["dworker"], w["dgame"], w["dframes"]), (300, 295, 290, 18000))
        self.assertFalse(w["restarted"])
        self.assertTrue(m.compute_window(hb(500, 500, 500), hb(20, 20, 20))["restarted"])


class Verdicts(unittest.TestCase):
    def v(self, dwall, dworker, dgame, restarted=False):
        return m.verdict({"dwall": dwall, "dworker": dworker, "dgame": dgame, "dframes": 0, "restarted": restarted})[0]

    def test_runs(self):
        self.assertEqual(self.v(1800, 1790, 1780), "RUNS")

    def test_frame_loop_stopped(self):
        self.assertEqual(self.v(1800, 1790, 20), "FRAME-LOOP-STOPPED")

    def test_frozen(self):
        self.assertEqual(self.v(1800, 300, 0), "FROZEN")

    def test_partial(self):
        self.assertEqual(self.v(1800, 1790, 1200), "PARTIAL")

    def test_killed_and_no_data(self):
        self.assertEqual(self.v(1800, 0, 0, restarted=True), "KILLED")
        self.assertEqual(self.v(30, 30, 30), "NO-DATA")

    def test_boundaries(self):
        self.assertEqual(self.v(1000, 800, 900), "RUNS")            # đúng ngưỡng
        self.assertEqual(self.v(1000, 799, 1000), "FROZEN")         # luồng dưới 80%
        self.assertEqual(self.v(1000, 1000, 499), "FRAME-LOOP-STOPPED")
        self.assertEqual(self.v(1000, 1000, 500), "PARTIAL")


class Segments(unittest.TestCase):
    def test_split_on_wall_decrease(self):
        recs = [hb(10, 10, 10), hb(20, 20, 20), hb(5, 5, 5), hb(15, 15, 15)]
        self.assertEqual([len(s) for s in m.segments(recs)], [2, 2])

    def test_analyze_reports_restart_even_if_longest_segment_runs(self):
        recs = [hb(0, 0, 0), hb(600, 600, 600), hb(5, 5, 5)]
        res = m.analyze_records(recs)
        self.assertEqual(res["restarts"], 1)
        self.assertEqual(res["verdict"], "KILLED")

    def test_analyze_clean_run(self):
        recs = [hb(0, 0, 0), hb(300, 300, 300)]
        res = m.analyze_records(recs)
        self.assertEqual(res["verdict"], "RUNS")
        self.assertEqual(res["restarts"], 0)

    def test_analyze_too_few(self):
        self.assertEqual(m.analyze_records([hb(0, 0, 0)])["verdict"], "NO-DATA")


class Dumpsys(unittest.TestCase):
    BATTERY = """Current Battery Service state:
  AC powered: false
  USB powered: true
  Wireless powered: false
  level: 83
  scale: 100
  temperature: 351
"""
    PROCS = """  *APP* UID 10123 ProcessRecord{4f3a2b1 1234:dev.vspace.workspace/u0a123}
    dir=/data/app/x
    oom: max=1001 curRaw=200 setRaw=200 cur=200 set=200
  *APP* UID 10123 ProcessRecord{9c8d7e6 2345:dev.vspace.workspace:p0/u0a123}
    oom: max=1001 curRaw=950 setRaw=950 cur=950 set=950
  *APP* UID 10123 ProcessRecord{1a2b3c4 2999:dev.vspace.workspace:daemon/u0a123}
    oom: max=1001 curRaw=200 setRaw=200 cur=200 set=200
  *APP* UID 10200 ProcessRecord{aaaaaaa 4000:com.other.app/u0a200}
    oom: max=1001 curRaw=0 setRaw=0 cur=0 set=0
"""

    def test_battery(self):
        b = m.parse_battery(self.BATTERY)
        self.assertEqual(b["level"], 83)
        self.assertEqual(b["temp_deci"], 351)
        self.assertTrue(b["plugged"])
        self.assertFalse(m.parse_battery("level: 50\ntemperature: 300\nAC powered: false")["plugged"])

    def test_oom_parse_only_our_package(self):
        p = m.parse_oom(self.PROCS)
        self.assertEqual({x["proc"] for x in p}, {"dev.vspace.workspace", "dev.vspace.workspace:p0", "dev.vspace.workspace:daemon"})
        self.assertEqual(m.guest_adj_summary(p), 950)
        self.assertEqual(m.adj_class(950), "CACHED")
        self.assertEqual(m.adj_class(200), "PERCEPTIBLE/FGS")
        self.assertEqual(m.adj_class(0), "FOREGROUND")

    def test_oom_unknown_format_returns_empty_not_wrong(self):
        self.assertEqual(m.parse_oom("định dạng lạ hoàn toàn"), [])
        self.assertIsNone(m.guest_adj_summary([]))


class Isolation(unittest.TestCase):
    def ident(self, fd, token, aid="id1", uid=10123):
        return {"uid": uid, "pid": 1, "android_id": aid, "files_dir": fd, "token": token}

    def test_shared_data(self):
        r = m.compare_idents(self.ident("/d/files", "T"), self.ident("/d/files", "T"))
        self.assertEqual(r["verdict"], "SHARED-DATA")

    def test_shared_token_alone_is_shared(self):
        r = m.compare_idents(self.ident("/d/0/files", "T"), self.ident("/d/1/files", "T"))
        self.assertEqual(r["verdict"], "SHARED-DATA")

    def test_isolated_but_same_id(self):
        r = m.compare_idents(self.ident("/d/0/files", "T1"), self.ident("/d/1/files", "T2"))
        self.assertEqual(r["verdict"], "ISOLATED-DATA/SAME-ID")

    def test_fully_isolated(self):
        r = m.compare_idents(self.ident("/d/0/files", "T1", "a"), self.ident("/d/1/files", "T2", "b"))
        self.assertEqual(r["verdict"], "ISOLATED")

    def test_parse_idents(self):
        i = m.parse_idents(LOG)
        self.assertEqual(len(i), 1)
        self.assertEqual(i[0]["token"], "T1")
        self.assertEqual(i[0]["files_dir"], "/data/x/space0/files")


class Markdown(unittest.TestCase):
    def test_row_shape(self):
        w = {"dwall": 1800, "dworker": 1790, "dgame": 1780, "dframes": 100}
        row = m.markdown_row("pin-bat", 30, w, "RUNS", 90, 82, 412, 200, 200)
        self.assertEqual(row.count("|"), m.MD_HEADER.splitlines()[0].count("|"))
        self.assertIn("90→82", row)
        self.assertIn("41.2°C", row)
        self.assertIn("RUNS", row)


if __name__ == "__main__":
    unittest.main(verbosity=1)
