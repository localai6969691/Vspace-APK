#!/usr/bin/env python3
"""Đo "app ảo có thật sự chạy khi tắt màn hình không" bằng adb, thay cho việc đoán (P0-3, P0-4, P0-5, P0-6, P0-7 của PROJECT_HANDOFF).

Các hàm parse/phán quyết là THUẦN và có test (scripts/test_measure_background.py, chạy trong check.py).
Phần gọi adb thì CHƯA chạy được trong sandbox (không có thiết bị): hãy chạy trên máy có adb + điện thoại bật gỡ lỗi USB.

Lệnh:
  python3 scripts/measure_background.py run --label "ghim-bat-tat-man-hinh" --minutes 30 [--serial S] [--screen off|keep] [--out kq.json]
      Chuẩn bị: cài workspace + testguest, thêm testguest vào Workspace, MỞ nó (để heartbeat ra logcat), rồi chạy lệnh này.
      --screen off  : script gửi KEYCODE_SLEEP (tắt màn hình thật, giống bấm nút nguồn)  -> thử "Tắt màn hình thật"
      --screen keep : không đụng màn hình (dùng khi bạn đã bật chế độ game "Màn hình đen/mờ" trong app)
  python3 scripts/measure_background.py analyze FILE_LOGCAT
      Phân tích file logcat đã lưu (logcat -d -s VSpaceTestGuest:I > file) mà không cần adb.
  python3 scripts/measure_background.py isolation [--serial S] [--wait 180]
      Kiểm tra hai không gian có DÙNG CHUNG dữ liệu không: mở testguest ở Không gian 1 rồi Không gian 2 khi script đang chờ.
  python3 scripts/measure_background.py selftest
"""
import argparse
import json
import re
import subprocess
import sys
import time

TAG = "VSpaceTestGuest"
WORKSPACE_PKG = "dev.vspace.workspace"

HB_RE = re.compile(r"(?P<src>[A-Za-z]+) wall=(?P<wall>\d+)s game=(?P<game>\d+)s worker=(?P<worker>\d+) frames=(?P<frames>\d+)")
IDENT_RE = re.compile(r"ident uid=(?P<uid>\d+) pid=(?P<pid>\d+) androidId=(?P<aid>\S*) filesDir=(?P<fd>\S+) token=(?P<token>\S+)")

# Ngưỡng phán quyết (tỉ lệ trên thời gian thật của cửa sổ đo)
WORKER_OK = 0.8
GAME_OK = 0.9
GAME_STOPPED = 0.5
MIN_WINDOW_S = 60  # cửa sổ ngắn hơn thì quá nhiễu (nhịp tim 10 giây một dòng)

# Ngưỡng OOM adj của AOSP (ProcessList): dùng để gọi tên mức ưu tiên từ `dumpsys activity processes`
ADJ_CACHED_MIN = 900


# ------------------------------------------------------------------ hàm thuần

def parse_heartbeats(text):
    """Các dòng nhịp tim của testguest: [{src, wall, game, worker, frames}], theo thứ tự xuất hiện."""
    out = []
    for line in text.splitlines():
        if TAG not in line and " wall=" not in line:
            continue
        m = HB_RE.search(line)
        if not m:
            continue
        out.append({k: (v if k == "src" else int(v)) for k, v in m.groupdict().items()})
    return out


def parse_idents(text):
    out = []
    for line in text.splitlines():
        m = IDENT_RE.search(line)
        if m:
            out.append({"uid": int(m["uid"]), "pid": int(m["pid"]), "android_id": m["aid"], "files_dir": m["fd"], "token": m["token"]})
    return out


def compute_window(r0, r1):
    """Chênh lệch giữa hai bản ghi nhịp tim. wall của testguest tính từ lúc tiến trình tạo: giảm đi nghĩa là tiến trình đã khởi động lại (bị kill)."""
    w = {
        "dwall": r1["wall"] - r0["wall"],
        "dworker": r1["worker"] - r0["worker"],
        "dgame": r1["game"] - r0["game"],
        "dframes": r1["frames"] - r0["frames"],
    }
    w["restarted"] = r1["wall"] < r0["wall"]
    return w


def verdict(w):
    """Phán quyết cho một cửa sổ đo. Trả về (mã, giải thích)."""
    if w.get("restarted"):
        return "KILLED", "tiến trình testguest đã khởi động lại giữa chừng (bị hệ thống/OEM kill hoặc bị dừng)"
    dwall = w["dwall"]
    if dwall < MIN_WINDOW_S:
        return "NO-DATA", "cửa sổ đo %d giây, quá ngắn (cần ≥ %d)" % (dwall, MIN_WINDOW_S)
    worker = w["dworker"] / dwall
    game = w["dgame"] / dwall
    if worker < WORKER_OK:
        return "FROZEN", "luồng 1 Hz chỉ chạy %.0f%% thời gian thật: tiến trình bị đóng băng/hết CPU" % (worker * 100)
    if game >= GAME_OK:
        return "RUNS", "luồng chạy %.0f%%, vòng lặp khung hình chạy %.0f%%: logic game vẫn tiến" % (worker * 100, game * 100)
    if game < GAME_STOPPED:
        return "FRAME-LOOP-STOPPED", "tiến trình sống (luồng %.0f%%) nhưng vòng lặp khung hình chỉ chạy %.0f%%: game frame-driven sẽ đứng" % (worker * 100, game * 100)
    return "PARTIAL", "vòng lặp khung hình chạy %.0f%% (giữa %d%% và %d%%): chạy một phần/giật" % (game * 100, GAME_STOPPED * 100, GAME_OK * 100)


def segments(records):
    """Tách danh sách nhịp tim thành các đoạn liên tục (mỗi lần wall giảm là một lần tiến trình khởi động lại)."""
    segs = []
    cur = []
    for r in records:
        if cur and r["wall"] < cur[-1]["wall"]:
            segs.append(cur)
            cur = []
        cur.append(r)
    if cur:
        segs.append(cur)
    return segs


def analyze_records(records):
    """Phân tích toàn bộ một log: đoạn dài nhất + số lần khởi động lại."""
    if len(records) < 2:
        return {"verdict": "NO-DATA", "reason": "cần ít nhất 2 dòng nhịp tim", "restarts": 0}
    segs = segments(records)
    longest = max(segs, key=lambda s: s[-1]["wall"] - s[0]["wall"])
    w = compute_window(longest[0], longest[-1]) if len(longest) >= 2 else {"dwall": 0, "dworker": 0, "dgame": 0, "dframes": 0, "restarted": False}
    code, why = verdict(w)
    if len(segs) > 1 and code in ("RUNS", "NO-DATA"):
        code, why = "KILLED", "log có %d lần khởi động lại tiến trình; đoạn dài nhất: %s" % (len(segs) - 1, why)
    return {"verdict": code, "reason": why, "restarts": len(segs) - 1, "window": w}


def parse_battery(text):
    """Từ `dumpsys battery`: {level, temp_deci, plugged(bool)}. temp tính theo 0.1°C."""
    res = {"level": None, "temp_deci": None, "plugged": False}
    for line in text.splitlines():
        line = line.strip()
        m = re.match(r"level:\s*(\d+)", line)
        if m:
            res["level"] = int(m.group(1))
        m = re.match(r"temperature:\s*(-?\d+)", line)
        if m:
            res["temp_deci"] = int(m.group(1))
        m = re.match(r"(AC|USB|Wireless|Dock) powered:\s*true", line)
        if m:
            res["plugged"] = True
    return res


PROC_RE = re.compile(r"ProcessRecord\{[0-9a-f]+\s+(?P<pid>\d+):(?P<proc>[^/\s]+)/")
OOM_RE = re.compile(r"\boom:\s*max=(?P<max>-?\d+)\s+curRaw=(?P<raw>-?\d+)\s+setRaw=(?P<setraw>-?\d+)\s+cur=(?P<cur>-?\d+)\s+set=(?P<set>-?\d+)")


def parse_oom(text, pkg=WORKSPACE_PKG):
    """Từ `dumpsys activity processes`: [{proc, pid, adj}] cho các tiến trình của pkg (workspace + :pN + :daemon).
    Định dạng dumpsys thay đổi giữa các bản Android; không khớp thì trả về danh sách rỗng chứ không báo sai."""
    out = []
    cur = None
    for line in text.splitlines():
        m = PROC_RE.search(line)
        if m:
            cur = {"proc": m["proc"], "pid": int(m["pid"]), "adj": None}
            if m["proc"] == pkg or m["proc"].startswith(pkg + ":"):
                out.append(cur)
            else:
                cur = None
            continue
        if cur is not None and cur["adj"] is None:
            o = OOM_RE.search(line)
            if o:
                cur["adj"] = int(o["cur"])
    return [p for p in out if p["adj"] is not None]


def adj_class(adj):
    if adj is None:
        return "?"
    if adj >= ADJ_CACHED_MIN:
        return "CACHED"
    if adj >= 500:
        return "SERVICE/HOME/PREVIOUS"
    if adj >= 200:
        return "PERCEPTIBLE/FGS"
    if adj >= 100:
        return "VISIBLE"
    return "FOREGROUND"


def guest_adj_summary(procs):
    """Mức ưu tiên tệ nhất (adj lớn nhất) trong các tiến trình :pN; None nếu không thấy."""
    adjs = [p["adj"] for p in procs if re.search(r":p\d+$", p["proc"])]
    return max(adjs) if adjs else None


def compare_idents(a, b):
    """So hai lần khởi chạy testguest (hai không gian khác nhau). Cùng filesDir/token = dữ liệu dùng chung (KHÔNG cô lập)."""
    r = {
        "same_files_dir": a["files_dir"] == b["files_dir"],
        "same_token": a["token"] == b["token"],
        "same_android_id": a["android_id"] == b["android_id"],
        "same_uid": a["uid"] == b["uid"],
    }
    if r["same_files_dir"] or r["same_token"]:
        r["verdict"] = "SHARED-DATA"
        r["reason"] = "hai không gian dùng chung thư mục dữ liệu: engine KHÔNG cô lập dữ liệu giữa các guest (không dùng cho đa tài khoản)"
    elif r["same_android_id"]:
        r["verdict"] = "ISOLATED-DATA/SAME-ID"
        r["reason"] = "dữ liệu tách riêng nhưng ANDROID_ID giống nhau: game theo dõi theo ID thiết bị có thể coi hai tài khoản là cùng máy"
    else:
        r["verdict"] = "ISOLATED"
        r["reason"] = "dữ liệu và ANDROID_ID khác nhau giữa hai không gian"
    return r


def markdown_row(label, minutes, w, code, bat0, bat1, max_temp_deci, adj0, adj1):
    def adj(v):
        return "?" if v is None else "%s(%d)" % (adj_class(v), v)
    drop = "?" if bat0 is None or bat1 is None else "%d→%d" % (bat0, bat1)
    temp = "?" if max_temp_deci is None else "%.1f°C" % (max_temp_deci / 10.0)
    return "| %s | %s | %d | %d | %d | %d | %s | %s→%s | %s | %s |" % (
        label, minutes, w["dwall"], w["dworker"], w["dgame"], w["dframes"], code, adj(adj0), adj(adj1), drop, temp)


MD_HEADER = ("| Nhãn | Phút | Δwall (s) | Δworker | Δgame (s) | Δframes | Kết luận | Ưu tiên :pN trước→sau | Pin % | Nhiệt cao nhất |\n"
             "|---|---|---|---|---|---|---|---|---|---|")


# ------------------------------------------------------------------ adb

def adb(serial, *args, timeout=60):
    cmd = ["adb"] + (["-s", serial] if serial else []) + list(args)
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError:
        sys.exit("Không tìm thấy lệnh adb. Cài Android platform-tools và thêm vào PATH.")
    except subprocess.TimeoutExpired:
        sys.exit("adb quá thời gian: " + " ".join(cmd))
    return p.stdout


def require_device(serial):
    out = adb(serial, "get-state").strip()
    if out != "device":
        sys.exit("Không thấy thiết bị (adb get-state = %r). Bật gỡ lỗi USB và xác nhận cho máy tính này." % out)


def read_heartbeats(serial):
    return parse_heartbeats(adb(serial, "logcat", "-d", "-s", TAG + ":I"))


def sample(serial):
    bat = parse_battery(adb(serial, "shell", "dumpsys", "battery"))
    procs = parse_oom(adb(serial, "shell", "dumpsys", "activity", "processes"))
    return bat, procs


def cmd_run(a):
    require_device(a.serial)
    hb0 = read_heartbeats(a.serial)
    if not hb0:
        sys.exit("Không thấy nhịp tim '%s' trong logcat. Mở testguest trong Workspace (Không gian bạn muốn đo) rồi chạy lại." % TAG)
    r0 = hb0[-1]
    bat0, procs0 = sample(a.serial)
    adj0 = guest_adj_summary(procs0)
    print("Bắt đầu: testguest wall=%ds worker=%d game=%ds | pin %s%% | ưu tiên :pN %s" % (
        r0["wall"], r0["worker"], r0["game"], bat0["level"], adj_class(adj0)))
    if bat0["plugged"]:
        print("CẢNH BÁO: máy đang cắm sạc, số đo pin sẽ không có ý nghĩa.")
    if a.screen == "off":
        adb(a.serial, "shell", "input", "keyevent", "223")  # KEYCODE_SLEEP
        print("Đã gửi KEYCODE_SLEEP (tắt màn hình).")
    end = time.time() + a.minutes * 60
    max_temp = bat0["temp_deci"]
    last_procs = procs0
    while time.time() < end:
        time.sleep(min(a.interval, max(1, end - time.time())))
        bat, procs = sample(a.serial)
        if bat["temp_deci"] is not None:
            max_temp = bat["temp_deci"] if max_temp is None else max(max_temp, bat["temp_deci"])
        if procs:
            last_procs = procs
        print("  [%3.0f%%] pin %s%% nhiệt %s ưu tiên :pN %s" % (
            min(100.0, 100 - (end - time.time()) / (a.minutes * 60) * 100), bat["level"],
            "?" if bat["temp_deci"] is None else "%.1f°C" % (bat["temp_deci"] / 10.0), adj_class(guest_adj_summary(procs))))
    if a.screen == "off":
        adb(a.serial, "shell", "input", "keyevent", "224")  # KEYCODE_WAKEUP
        time.sleep(5)
    hb1 = read_heartbeats(a.serial)
    bat1, _ = sample(a.serial)
    if not hb1 or hb1[-1] is r0 or hb1[-1] == r0:
        sys.exit("Không có nhịp tim mới sau cửa sổ đo (logcat có thể đã tràn hoặc tiến trình đã chết). Lưu logcat sớm hơn và dùng 'analyze'.")
    r1 = hb1[-1]
    w = compute_window(r0, r1)
    code, why = verdict(w)
    adj1 = guest_adj_summary(last_procs)
    print("\nKẾT LUẬN: %s — %s" % (code, why))
    print("\n" + MD_HEADER)
    print(markdown_row(a.label, a.minutes, w, code, bat0["level"], bat1["level"], max_temp, adj0, adj1))
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            json.dump({"label": a.label, "minutes": a.minutes, "screen": a.screen, "window": w, "verdict": code, "reason": why,
                       "battery": [bat0["level"], bat1["level"]], "max_temp_deci": max_temp,
                       "adj_before": adj0, "adj_after": adj1, "plugged_at_start": bat0["plugged"]}, f, ensure_ascii=False, indent=2)
        print("\nĐã ghi " + a.out)


def cmd_analyze(a):
    text = open(a.file, encoding="utf-8", errors="replace").read()
    recs = parse_heartbeats(text)
    res = analyze_records(recs)
    print("%d dòng nhịp tim, %d lần khởi động lại" % (len(recs), res["restarts"]))
    print("KẾT LUẬN: %s — %s" % (res["verdict"], res["reason"]))
    return 0 if res["verdict"] != "NO-DATA" else 1


def cmd_isolation(a):
    require_device(a.serial)
    print("Mở testguest ở KHÔNG GIAN 1, rồi ở KHÔNG GIAN 2 (trong Workspace). Đang chờ tối đa %d giây..." % a.wait)
    seen = []
    deadline = time.time() + a.wait
    while time.time() < deadline:
        idents = parse_idents(adb(a.serial, "logcat", "-d", "-s", TAG + ":I"))
        seen = []
        for i in idents:  # mỗi (pid) một lần
            if all(i["pid"] != s["pid"] for s in seen):
                seen.append(i)
        if len(seen) >= 2:
            break
        time.sleep(3)
    if len(seen) < 2:
        sys.exit("Chưa thấy đủ 2 lần khởi chạy testguest (thấy %d)." % len(seen))
    r = compare_idents(seen[-2], seen[-1])
    print(json.dumps({"a": seen[-2], "b": seen[-1], "result": r}, ensure_ascii=False, indent=2))
    print("\nKẾT LUẬN: %s — %s" % (r["verdict"], r["reason"]))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--label", required=True)
    r.add_argument("--minutes", type=float, default=30)
    r.add_argument("--interval", type=int, default=60)
    r.add_argument("--screen", choices=["off", "keep"], default="off")
    r.add_argument("--serial")
    r.add_argument("--out")
    an = sub.add_parser("analyze")
    an.add_argument("file")
    iso = sub.add_parser("isolation")
    iso.add_argument("--serial")
    iso.add_argument("--wait", type=int, default=180)
    sub.add_parser("selftest")
    a = ap.parse_args(argv)
    if a.cmd == "run":
        return cmd_run(a)
    if a.cmd == "analyze":
        return cmd_analyze(a)
    if a.cmd == "isolation":
        return cmd_isolation(a)
    if a.cmd == "selftest":
        import test_measure_background  # noqa: F401  (import chạy unittest khi gọi trực tiếp bằng python3 scripts/test_measure_background.py)
        import unittest
        suite = unittest.defaultTestLoader.loadTestsFromModule(test_measure_background)
        res = unittest.TextTestRunner(verbosity=1).run(suite)
        return 0 if res.wasSuccessful() else 1
    return 2


if __name__ == "__main__":
    sys.exit(main() or 0)
