#!/usr/bin/env python3
"""Kiểm tra API Android MỚI HƠN minSdk (26) được gọi mà phương thức chứa nó không có kiểm Build.VERSION.SDK_INT.

Lý do: lỗi này không bị javac bắt (biên dịch với compileSdk 35 vẫn xanh) nhưng sập NoSuchMethodError/NoClassDefFoundError trên máy
Android 8–9 (Android Lint gọi là NewApi). Đây là bản thay Lint tối thiểu, chạy được trong sandbox bằng javap + android.jar API 26 thật.

Cách làm: javap -c -p trên các lớp đã biên dịch → mọi tham chiếu android/* (invoke*/getstatic/new/checkcast...) → tra trong android.jar API 26
(đi lên chuỗi lớp cha/interface) → tham chiếu KHÔNG có ở API 26 là "mới hơn 26" → nếu phương thức chứa nó không đọc Build.VERSION.SDK_INT
thì báo. Lambda/lớp ẩn danh có phương thức riêng nên có thể báo nhầm khi chốt SDK_INT nằm ở phương thức bao ngoài — đọc kết quả bằng mắt.

Dùng:  python3 scripts/api_audit.py <thư-mục-class-đã-biên-dịch> [android-26.jar]   (compile_check.py --keep in ra thư mục `out`)
Thoát 1 nếu còn mục chưa được bảo vệ VÀ không nằm trong ALLOW (danh sách đã được người xem xét, kèm lý do).
"""
import os
import re
import shutil
import subprocess
import sys

MIN_JAR = os.path.expanduser("~/.cache/vspace/android-26.jar")

# (lớp.chứa, phương thức.chứa-chuỗi, ký hiệu API) đã xem xét thủ công và an toàn; mỗi mục phải có lý do.
ALLOW = {
    ("dev.vspace.workspace.ExitReasons", "line"): "chỉ được gọi từ describe(), hàm này đã return khi SDK_INT < 30 (ExitReasons.java dòng 56)",
    ("dev.vspace.workspace.ExitReasons", "saveTrace"): "chỉ được gọi từ describe() sau khi kiểm SDK_INT >= 30",
    ("dev.vspace.workspace.ExitReasons$1", "run"): "Runnable chỉ được tạo trong logRecent() sau khi return nếu SDK_INT < 30 (dòng 130)",
}

REF_RE = re.compile(r"//\s*(?:Method|InterfaceMethod|Field|class)\s+(android/[\w/$]+)(?:\.([\w$<>]+):(\S+))?")


def javap_cmd():
    # JRE-only (như sandbox) không có `javap` nhưng có module jdk.jdeps
    return ["javap"] if shutil.which("javap") else ["java", "-m", "jdk.jdeps/com.sun.tools.javap.Main"]


def javap(args):
    r = subprocess.run(javap_cmd() + args, capture_output=True, text=True)
    return r.stdout


def class_info(jar, cls, cache):
    """(thành viên khai báo, lớp cha, interface) của cls trong jar; None nếu lớp không tồn tại."""
    if cls in cache:
        return cache[cls]
    out = subprocess.run(javap_cmd() + ["-p", "-cp", jar, cls.replace("/", ".")], capture_output=True, text=True)
    if out.returncode != 0 or not out.stdout.strip():
        cache[cls] = None
        return None
    members, sup, ifs = set(), None, []
    for line in out.stdout.splitlines():
        line = line.strip()
        if line.startswith(("public ", "protected ", "private ", "static ", "final ", "abstract ", "interface ", "class ")) and " class " in line + " " and "(" not in line and "{" in line:
            m = re.search(r"\bextends\s+([\w.$]+)", line)
            if m:
                sup = m.group(1).replace(".", "/")
            m2 = re.search(r"\bimplements\s+([\w.$, ]+)\s*\{", line)
            if m2:
                ifs += [x.strip().replace(".", "/") for x in m2.group(1).split(",")]
            if "interface " in line:
                m3 = re.search(r"\bextends\s+([\w.$, ]+)\s*\{", line)
                if m3:
                    ifs += [x.strip().replace(".", "/") for x in m3.group(1).split(",")]
                    sup = None
            continue
        m = re.match(r".*?([\w$<>]+)\(([^)]*)\)", line)
        if m and "(" in line:
            members.add(m.group(1))
        else:
            m = re.match(r".*?\b([\w$]+);$", line)
            if m:
                members.add(m.group(1))
    cache[cls] = (members, sup, ifs)
    return cache[cls]


def has_member(jar, cls, name, cache, seen=None):
    seen = seen or set()
    if cls in seen:
        return False
    seen.add(cls)
    info = class_info(jar, cls, cache)
    if info is None:
        return False
    members, sup, ifs = info
    # phương thức của java.lang.Object luôn có (interface không khai báo lại toString/equals/hashCode)
    if name in ("<init>", "toString", "equals", "hashCode", "getClass", "wait", "notify", "notifyAll", "clone", "finalize") or name in members:
        return True
    for p in ([sup] if sup else []) + ifs:
        if p.startswith("android/") or p.startswith("java/"):
            if p.startswith("java/"):
                continue
            if has_member(jar, p, name, cache, seen):
                return True
    return False


def main():
    out_dir = sys.argv[1]
    jar = sys.argv[2] if len(sys.argv) > 2 else MIN_JAR
    if not os.path.isfile(jar):
        print("Thiếu android-26.jar (tải từ https://raw.githubusercontent.com/Sable/android-platforms/master/android-26/android.jar)")
        return 2
    classes = []
    for root, _, files in os.walk(os.path.join(out_dir, "dev", "vspace", "workspace")):
        for f in files:
            if f.endswith(".class"):
                classes.append(os.path.join(root, f))
    text = javap(["-c", "-p", "-cp", out_dir] + [c for c in classes])
    cache = {}
    findings = {}
    cur_cls, cur_method, body = None, None, []

    def flush():
        if cur_cls is None or cur_method is None:
            return
        guarded = any("Build$VERSION.SDK_INT" in l for l in body)
        refs = set()
        for l in body:
            m = REF_RE.search(l)
            if m:
                refs.add((m.group(1), m.group(2)))
        for owner, member in sorted(refs, key=lambda x: (x[0], x[1] or "")):
            info = class_info(jar, owner, cache)
            if info is None:
                new = True      # cả lớp chưa có ở API 26
            elif member is None:
                new = False
            else:
                new = not has_member(jar, owner, member, cache)
            if new and not guarded:
                findings.setdefault((cur_cls, cur_method), []).append(f"{owner}.{member or '(lớp)'}")

    for line in text.splitlines():
        m = re.match(r"^(?:public |final |abstract )*(?:class|interface) ([\w.$]+)", line)
        if m:
            flush()
            cur_cls, cur_method, body = m.group(1), None, []
            continue
        m = re.match(r"^  (?:public |private |protected |static |final |synchronized |abstract |native )*[\w.$<>\[\], ?]+ ([\w$<>]+)\(.*\)[^;]*;$", line)
        if m:
            flush()
            cur_method, body = m.group(1), []
            continue
        if cur_method is not None:
            body.append(line)
    flush()

    bad = 0
    for (c, m), refs in sorted(findings.items()):
        key = (c, m)
        if key in ALLOW:
            continue
        bad += 1
        print(f"CHƯA BẢO VỆ  {c}.{m}: " + ", ".join(sorted(set(refs))))
    print(f"\n{len(findings)} phương thức có tham chiếu API > 26 mà không đọc SDK_INT; {bad} chưa nằm trong ALLOW.")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
