#!/usr/bin/env bash
# Chạy trong emulator-runner của job x86-engine-test: chạy device_suite.py rồi (dù thành công hay lỗi) đưa dấu vết ra Annotations
# (công khai, đọc được không cần đăng nhập): crash native/Java và nhật ký của chính app (tag VSpace*), danh sách tiến trình.
#   bash scripts/x86_ci.sh <đối số của device_suite.py>
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
python3 "$HERE/device_suite.py" "$@" 2>&1 | tee device-suite.log
RC="${PIPESTATUS[0]}"
adb logcat -d -t 8000 > x86-logcat.txt 2>/dev/null || true
adb shell "ps -A | grep -i -E 'vspace|testguest'" > x86-ps.txt 2>/dev/null || true
# nhật ký riêng của app (LogBuffer: files/vspace.log, đọc bằng run-as với bản Debug): đầy đủ hơn logcat vốn bị tràn bởi tiến trình hệ thống
adb shell run-as dev.vspace.workspace cat files/vspace.log > x86-applog.txt 2>/dev/null || true
python3 "$HERE/ci_annotate.py" warning "x86_64 logcat: crash native/Java" x86-logcat.txt \
  --grep 'FATAL EXCEPTION|AndroidRuntime|UnsatisfiedLinkError|dlopen failed|Fatal signal|SIGSEGV|SIGABRT|Abort message|libblackbox|DEBUG   :' --tail 22
python3 "$HERE/ci_annotate.py" warning "x86_64: nhật ký riêng của app (vspace.log)" x86-applog.txt --tail 40
python3 "$HERE/ci_annotate.py" notice "x86_64: tiến trình vspace đang chạy" x86-ps.txt --tail 12
if [ "$RC" -ne 0 ]; then
  python3 "$HERE/ci_annotate.py" error "device_suite x86_64 (mã thoát $RC)" device-suite.log --grep 'Vẫn không|Dừng|Error|error|Traceback|thất bại|UI dump|bấm|hộp thoại|Back|đặt cờ|ghi' --tail 16
fi
exit "$RC"
