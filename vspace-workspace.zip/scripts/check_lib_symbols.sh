#!/usr/bin/env bash
# Kiểm một thư viện tĩnh có xuất đủ các ký hiệu hàm (loại T). KHÔNG dùng `nm | grep -q`: dưới `set -o pipefail`, grep -q thoát ngay khi thấy
# khớp nên nm bị SIGPIPE (mã 141) khi đầu ra lớn và phép kiểm báo SAI là thiếu — lỗi thật đã gặp ở CI lượt #13 (NDK build có -g).
# Cách làm đúng: ghi đầu ra nm ra tệp rồi grep tệp.
#   bash scripts/check_lib_symbols.sh <nm> <lib.a> <ký hiệu>...
set -u
NM="${1:?usage: check_lib_symbols.sh <nm> <lib> <sym>...}"
LIB="${2:?usage: check_lib_symbols.sh <nm> <lib> <sym>...}"
shift 2
TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT
"$NM" "$LIB" > "$TMP" 2>&1 || true
missing=0
for sym in "$@"; do
  if ! grep -q " T ${sym}\$" "$TMP"; then
    echo "ERROR: thư viện không xuất $sym"
    missing=1
  fi
done
if [ "$missing" -ne 0 ]; then
  echo "--- các ký hiệu chứa 'dobby' có trong thư viện (tối đa 25):"
  grep -i dobby "$TMP" | head -n 25 || true
  exit 1
fi
echo "OK: xuất đủ: $*"
