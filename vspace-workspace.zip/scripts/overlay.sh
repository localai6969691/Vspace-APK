#!/usr/bin/env bash
# Chép các module (workspace, testguest) vào bản clone của NewBlackbox và đăng ký chúng trong settings.gradle.
# Dùng:  bash scripts/overlay.sh <thư-mục-core> [tham-số-cũ-được-bỏ-qua]
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CORE_DIR="${1:?usage: overlay.sh <core-dir>}"

SETTINGS=""
for f in "$CORE_DIR/settings.gradle.kts" "$CORE_DIR/settings.gradle"; do
  if [ -f "$f" ]; then SETTINGS="$f"; break; fi
done
[ -n "$SETTINGS" ] || { echo "ERROR: không thấy settings.gradle(.kts) trong $CORE_DIR"; exit 1; }

for MODULE in workspace testguest; do
  [ -d "$ROOT/$MODULE" ] || { echo "WARN: thiếu module $MODULE, bỏ qua"; continue; }
  rm -rf "$CORE_DIR/$MODULE"
  cp -R "$ROOT/$MODULE" "$CORE_DIR/$MODULE"
  if ! grep -Eq "[\"']:$MODULE[\"']" "$SETTINGS"; then
    printf '\ninclude(":%s")\n' "$MODULE" >> "$SETTINGS"
  fi
done

# Sinh GuestGenerated.java (AppLifecycleCallback) và activity proxy PiP từ SOURCE THẬT của core.
# Lỗi ở bước này không được làm hỏng build: bản stub trong repo vẫn dùng được.
if command -v python3 >/dev/null 2>&1; then
  python3 "$ROOT/scripts/gen_guest_hooks.py" "$CORE_DIR" "$CORE_DIR/workspace" || echo "WARN: gen_guest_hooks.py lỗi, dùng bản stub"
else
  echo "WARN: không có python3, bỏ qua gen_guest_hooks.py"
fi

# Tự dò package thật của BlackBoxCore / ClientConfiguration, sửa import trong Engine.java
ENGINE="$CORE_DIR/workspace/src/main/java/dev/vspace/workspace/Engine.java"
resolve_import() {
  local cls="$1" default_fqcn="$2" f pkg
  f=$(find "$CORE_DIR" -type f \( -name "$cls.java" -o -name "$cls.kt" \) -not -path '*/build/*' -not -path "$CORE_DIR/workspace/*" -not -path "$CORE_DIR/testguest/*" | head -n1 || true)
  if [ -z "$f" ]; then
    echo "WARN: không tìm thấy $cls trong core, giữ import mặc định $default_fqcn"
    return 0
  fi
  pkg=$(grep -m1 -E '^package ' "$f" | sed -E 's/^package ([A-Za-z0-9_.]+).*/\1/')
  sed -i "s#${default_fqcn}#${pkg}.${cls}#g" "$ENGINE"
  echo "import $cls -> ${pkg}.${cls}"
}
resolve_import BlackBoxCore        top.niunaijun.blackbox.BlackBoxCore
resolve_import ClientConfiguration top.niunaijun.blackbox.app.configuration.ClientConfiguration

# O-11 (phiên 7, đọc source thật): lõi có hai hàm __attribute__((constructor)) CHẠY NGAY KHI NẠP thư viện native, độc lập với
# ClientConfiguration: Utils/VirtualSpoof.cpp hook __system_property_get toàn tiến trình để trả model/fingerprint/serial GIẢ
# (Pixel 6, Android 12...) cho mọi app ảo; Utils/AntiDetection.cpp chỉ ghi log (không cài hook nào thật). MẶC ĐỊNH giữ nguyên
# hành vi của lõi (Workspace không tự đổi hành vi mặc định của phụ thuộc khi người dùng chưa yêu cầu), nhưng có công tắc:
#   VSPACE_STRIP_CORE_SPOOF=1 bash scripts/overlay.sh <core>   → bỏ hai file đó khỏi LOCAL_SRC_FILES của Android.mk.
if [ "${VSPACE_STRIP_CORE_SPOOF:-0}" = "1" ]; then
  MK="$CORE_DIR/Bcore/src/main/cpp/Android.mk"
  [ -f "$MK" ] || { echo "ERROR: không thấy $MK để gỡ VirtualSpoof/AntiDetection"; exit 1; }
  sed -i -e '/Utils\/VirtualSpoof\.cpp/d' -e '/Utils\/AntiDetection\.cpp/d' "$MK"
  if grep -Eq 'VirtualSpoof\.cpp|AntiDetection\.cpp' "$MK"; then
    echo "ERROR: vẫn còn VirtualSpoof/AntiDetection trong $MK"; exit 1
  fi
  echo "Đã gỡ VirtualSpoof.cpp + AntiDetection.cpp khỏi Android.mk (VSPACE_STRIP_CORE_SPOOF=1)"
else
  echo "LƯU Ý: lõi giả mạo thuộc tính thiết bị toàn tiến trình (VirtualSpoof.cpp, O-11). Đặt VSPACE_STRIP_CORE_SPOOF=1 để gỡ."
fi

# O-17 (phiên 11, đọc tab Issues thật của lõi — issue #39 + đối chiếu source ở SHA ghim): Bcore/AndroidManifest.xml khai
# 300 component stub (ProxyActivity / ProxyPendingActivity / TransparentProxyActivity / ProxyService / ProxyJobService /
# ProxyContentProvider (6 loại × 50 slot :pN) với android:exported="true". Chúng do HỆ THỐNG khởi chạy hộ app ảo (system_server không
# bị chặn bởi exported=false) và app ảo chạy cùng UID host nên không cần exported; để true thì bất kỳ app nào trên máy cũng
# gọi được trực tiếp (nhận extras riêng của lõi → dispatch trái phép/DoS). MẶC ĐỊNH giữ nguyên hành vi lõi vì CHƯA thử trên máy
# thật (nếu sai, app ảo không khởi chạy được — hỏng toàn bộ sản phẩm). Công tắc:
#   VSPACE_HARDEN_EXPORTS=1 bash scripts/overlay.sh <core>   → đặt exported="false" cho 300 stub trên.
# KHÔNG đụng ProxyBroadcastReceiver (có intent-filter ${applicationId}.stub_receiver, thiết kế để nhận broadcast/PendingIntent).
if [ "${VSPACE_HARDEN_EXPORTS:-0}" = "1" ]; then
  MF="$CORE_DIR/Bcore/src/main/AndroidManifest.xml"
  [ -f "$MF" ] || { echo "ERROR: không thấy $MF để siết exported"; exit 1; }
  python3 - "$MF" <<'PY'
import re, sys
p = sys.argv[1]
s = open(p, encoding="utf-8").read()
KINDS = r"(?:ProxyActivity|ProxyPendingActivity|TransparentProxyActivity|ProxyService|ProxyJobService|ProxyContentProvider)"
NAME = r'android:name="\.proxy\.' + KINDS + r'\$P\d+"'
# khớp theo tên component (không theo số dòng); mỗi thẻ mở là một chuỗi không chứa '>'
tag = re.compile(r'<(?:activity|service|provider)\b[^>]*?' + NAME + r'[^>]*>', re.S)
n = 0
def fix(m):
    global n
    t = m.group(0)
    if 'android:exported="true"' in t:
        n += 1
        return t.replace('android:exported="true"', 'android:exported="false"')
    return t
s = tag.sub(fix, s)
open(p, "w", encoding="utf-8").write(s)
tags = tag.findall(s)
total = len(tags)
left = sum('android:exported="true"' in t for t in tags)
print(f"Siết exported: {n} stub đổi -> false; tổng stub nhóm này: {total}; còn exported=true: {left}")
if total != 300 or left:
    sys.exit("ERROR: kỳ vọng đúng 300 stub, không còn exported=true (lõi đã đổi? kiểm lại O-17)")
PY
  echo "Đã siết exported cho stub proxy (VSPACE_HARDEN_EXPORTS=1)"
else
  echo "LƯU Ý: 300 stub proxy của lõi exported=true (O-17, issue #39 của lõi). Đặt VSPACE_HARDEN_EXPORTS=1 để siết (cần thử máy thật, G-40)."
fi

echo "Overlay xong (settings: $SETTINGS)"
