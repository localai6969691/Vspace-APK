#!/usr/bin/env python3
"""Ghim mọi GitHub Action trong .github/workflows/*.yml theo SHA commit (chuỗi cung ứng: tag như v4 là con trỏ trôi được).

  python3 scripts/pin_actions.py --check   # offline: mọi `uses:` bên ngoài phải là @<40 hex>; mã thoát 1 nếu không
  python3 scripts/pin_actions.py --apply   # cần mạng tới github.com: đổi `@vN` -> `@<sha> # vN` (git ls-remote, tag có chú thích được bóc ^{})
  python3 scripts/pin_actions.py --verify  # cần mạng: SHA đã ghim vẫn tồn tại và vẫn là đầu của tag ghi ở chú thích (cảnh báo nếu tag đã trôi)
Cập nhật action: đổi tag trong chú thích rồi chạy --apply sau khi gỡ SHA cũ, hoặc sửa tay SHA + chú thích rồi --verify.
"""
import glob, os, re, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES = sorted(glob.glob(os.path.join(ROOT, ".github/workflows/*.y*ml")))
USES = re.compile(r'^(\s*(?:-\s*)?uses:\s*)([\w./-]+)@([^\s#]+)(\s*#\s*(\S+))?\s*$', re.M)
HEX40 = re.compile(r'^[0-9a-f]{40}$')

def resolve(repo, tag):
    out = subprocess.run(["git", "ls-remote", "--tags", f"https://github.com/{repo}", f"refs/tags/{tag}", f"refs/tags/{tag}^{{}}"],
                         capture_output=True, text=True, timeout=90).stdout.strip().split("\n")
    d = {l.split("\t")[1]: l.split("\t")[0] for l in out if l}
    return d.get(f"refs/tags/{tag}^{{}}") or d.get(f"refs/tags/{tag}")

def external(repo):   # bỏ qua action cục bộ (./...)
    return not repo.startswith(".")

def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "--check"
    bad = 0
    for f in FILES:
        s = open(f, encoding="utf-8").read()
        if mode == "--apply":
            cache = {}
            def sub(m):
                pre, repo, ref, _, _ = m.groups()
                if not external(repo) or HEX40.match(ref):
                    return m.group(0)
                sha = cache.get((repo, ref)) or resolve(repo, ref)
                if not sha:
                    print(f"KHÔNG phân giải được {repo}@{ref}"); sys.exit(1)
                cache[(repo, ref)] = sha
                return f"{pre}{repo}@{sha} # {ref}"
            s2 = USES.sub(sub, s)
            if s2 != s:
                open(f, "w", encoding="utf-8").write(s2)
                print(f"đã ghim: {os.path.relpath(f, ROOT)}")
        for m in USES.finditer(open(f, encoding="utf-8").read()):
            _, repo, ref, _, tag = m.groups()
            if not external(repo):
                continue
            if not HEX40.match(ref):
                print(f"CHƯA GHIM: {os.path.relpath(f, ROOT)}: {repo}@{ref}"); bad += 1
            elif mode == "--verify":
                if not tag:
                    print(f"thiếu chú thích tag: {repo}@{ref[:8]}"); bad += 1; continue
                now = resolve(repo, tag)
                if now is None:
                    print(f"KHÔNG thấy tag {tag} của {repo}"); bad += 1
                elif now != ref:
                    print(f"TRÔI: {repo} {tag} nay = {now[:12]} (đang ghim {ref[:12]}) — bình thường với tag chính vN; xem changelog rồi cập nhật")
                else:
                    print(f"ok: {repo}@{ref[:12]} = {tag}")
    if mode == "--check":
        print("mọi action đã ghim SHA" if not bad else f"{bad} action chưa ghim")
    return 1 if bad and mode != "--verify" else 0

if __name__ == "__main__":
    sys.exit(main())
