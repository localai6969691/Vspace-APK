#!/usr/bin/env python3
"""Thử scripts/gen_guest_hooks.py trên 4 kiểu core giả. Thoát khác 0 nếu có ca sai."""
import os, re, shutil, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

CB_IFACE = """package top.niunaijun.blackbox.app.configuration;
import android.app.Application;
import android.content.Context;
// comment with void fake(String x) here
public interface AppLifecycleCallback {
    default void beforeCreateApplication(String packageName, String processName, Context context, int userId) {}
    default void beforeApplicationOnCreate(String packageName, String processName, Application application, int userId) {}
    default void afterApplicationOnCreate(String packageName, String processName, Application application, int userId) {}
}
"""
CB_CLASS = """package com.fork.cb;
import android.app.Application;
import android.content.Context;
import androidx.annotation.Nullable;
public abstract class AppLifecycleCallback {
    public static final AppLifecycleCallback EMPTY = new AppLifecycleCallback() {};
    public static void helper(int x) {}
    public void beforeCreateApplication(@Nullable String packageName, final String processName, Context context, int userId) {}
    public void afterApplicationOnCreate(String packageName, String processName, java.util.Map<String, Integer> extra, int userId) {}
}
"""
CORE = """package top.niunaijun.blackbox;
public class BlackBoxCore {
    public static BlackBoxCore get() { return null; }
    public void removeAppLifecycleCallback(AppLifecycleCallback c) {}
    public void addAppLifecycleCallback(AppLifecycleCallback appLifecycleCallback) {}
}
"""
MANIFEST = """<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application>
<activity android:name="top.niunaijun.blackbox.proxy.ProxyActivity$P0" android:process=":p0"/>
<activity android:name="top.niunaijun.blackbox.proxy.ProxyActivity$P1" android:process=":p1"/>
<activity android:name="top.niunaijun.blackbox.proxy.ProxyActivity$P0Dialog" android:process=":p0"/>
<service android:name="top.niunaijun.blackbox.proxy.ProxyService$P0" android:process=":p0"/>
</application></manifest>"""

FAILS = []

def balanced(s):
    t = re.sub(r'"(\\.|[^"\\])*"', '""', s)
    return all(t.count(a) == t.count(b) for a, b in ("{}", "()", "[]"))

def run(name, cb, core_src=CORE):
    tmp = tempfile.mkdtemp()
    try:
        core = os.path.join(tmp, "core")
        os.makedirs(core + "/Bcore/src/main/java/x")
        if cb: open(core + "/Bcore/src/main/java/x/AppLifecycleCallback.java", "w").write(cb)
        if core_src: open(core + "/Bcore/src/main/java/x/BlackBoxCore.java", "w").write(core_src)
        open(core + "/Bcore/src/main/AndroidManifest.xml", "w").write(MANIFEST)
        mod = os.path.join(tmp, "mod")
        shutil.copytree("workspace", mod)
        r = subprocess.run([sys.executable, "scripts/gen_guest_hooks.py", core, mod], capture_output=True, text=True)
        gen = open(mod + "/src/main/java/dev/vspace/workspace/GuestGenerated.java", encoding="utf-8").read()
        man = open(mod + "/src/main/AndroidManifest.xml", encoding="utf-8").read()
        return r.returncode, gen, man
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

def check(cond, msg):
    if not cond:
        FAILS.append(msg); print("  FAIL", msg)

rc, g, m = run("interface", CB_IFACE)
check(rc == 0 and "implements AppLifecycleCallback" in g and g.count("@Override") == 3, "interface: implements + 3 @Override")
check("addAppLifecycleCallback(new GuestCallback())" in g and "removeApp" not in g and "AVAILABLE = true" in g, "interface: đăng ký đúng hàm add")
check("String packageName, String processName, Application application, int userId" in g, "interface: chữ ký giữ nguyên")
check("new Object[]{packageName, processName, application, userId}" in g and balanced(g), "interface: mảng tham số + ngoặc cân bằng")
check(m.count("supportsPictureInPicture") == 2 and "P0Dialog" not in m and "ProxyService" not in m, "interface: 2 proxy activity PiP, bỏ Dialog/Service")

rc, g, m = run("abstract class", CB_CLASS)
check("extends AppLifecycleCallback" in g and g.count("@Override") == 2 and "helper" not in g and balanced(g), "class: extends + bỏ static")
check("@Nullable" not in g.split("final class GuestCallback")[1] and "final String processName" not in g, "class: bỏ annotation/final")
check("java.util.Map<String, Integer> extra" in g and "import com.fork.cb.AppLifecycleCallback;" in g, "class: generic + import")

rc, g, m = run("thiếu callback", None)
check("AVAILABLE = false" in g and balanced(g), "thiếu callback -> stub")

rc, g, m = run("thiếu hàm đăng ký", CB_IFACE, "package top.niunaijun.blackbox;\npublic class BlackBoxCore { public static BlackBoxCore get(){return null;} }\n")
check("AVAILABLE = false" in g and "hàm đăng ký" in g, "thiếu hàm đăng ký -> stub")

stub = open("workspace/src/main/java/dev/vspace/workspace/GuestGenerated.java", encoding="utf-8").read()
check("AVAILABLE = false" in stub and balanced(stub), "stub trong repo hợp lệ")
check("<!-- GENERATED_PROXY_ACTIVITIES -->" in open("workspace/src/main/AndroidManifest.xml", encoding="utf-8").read(), "manifest có marker")

print("gen_guest_hooks: " + ("TẤT CẢ ĐẠT" if not FAILS else f"{len(FAILS)} LỖI"))
sys.exit(1 if FAILS else 0)
