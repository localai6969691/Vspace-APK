#!/usr/bin/env bash
# Build libdobby.a cho một ABI mà lõi KHÔNG kèm sẵn (lõi chỉ có arm64-v8a, armeabi-v7a) — chủ yếu x86_64 để engine chạy được
# trên emulator x86 có KVM trong CI (thay cho điện thoại ARM). Lõi chỉ gọi MỘT hàm của Dobby: DobbyHook (đã kiểm trên mã lõi ở SHA ghim).
#   bash scripts/build_dobby.sh <core-dir> [abi]     # abi mặc định x86_64; cần Android NDK (ANDROID_NDK_HOME hoặc $ANDROID_HOME/ndk/*) và cmake
set -euo pipefail
CORE_DIR="${1:?usage: build_dobby.sh <core-dir> [abi]}"
ABI="${2:-x86_64}"
DOBBY_REPO="https://github.com/jmpews/Dobby.git"
# PHẢI đúng bản mà lõi đã dùng: libdobby.a dựng sẵn của lõi mang chuỗi "Dobby-20210616-223aabc". Đầu nhánh master (2024) KHÔNG biên dịch được
# phần nền tảng Linux/Android (thiếu core/arch/Cpu.h, đổi tên load_address) — đã thử ở phiên 11, nên không dùng master.
DOBBY_REF="223aabced0431525c7d45196f9409fc505d58ac8"

NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
if [ -z "$NDK" ] && [ -n "${ANDROID_HOME:-}" ]; then
  NDK="$(find "$ANDROID_HOME/ndk" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort -V | tail -n 1)"
fi
[ -n "$NDK" ] && [ -f "$NDK/build/cmake/android.toolchain.cmake" ] || { echo "ERROR: không thấy Android NDK (đặt ANDROID_NDK_HOME)"; exit 1; }
command -v cmake >/dev/null || { echo "ERROR: cần cmake"; exit 1; }

W="$(mktemp -d)"
trap 'rm -rf "$W"' EXIT
git clone -q "$DOBBY_REPO" "$W/src"
git -C "$W/src" checkout -q "$DOBBY_REF"
# Dobby 223aabc có #include <android/log.h> trong thân hàm: lỗi với NDK mới (CI lượt #12). Vá bằng scripts/patch_dobby.py
python3 "$(dirname "$0")/patch_dobby.py" "$W/src"

cmake -S "$W/src" -B "$W/b" \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI="$ABI" -DANDROID_PLATFORM=android-24 \
  -DCMAKE_BUILD_TYPE=Release -DDOBBY_GENERATE_SHARED=OFF -DDOBBY_DEBUG=OFF -DNearBranch=ON \
  -DCMAKE_POSITION_INDEPENDENT_CODE=ON
cmake --build "$W/b" -j"$(nproc)"

LIB="$(find "$W/b" -name 'libdobby.a' | head -n 1)"
[ -f "$LIB" ] || { echo "ERROR: build xong nhưng không thấy libdobby.a"; exit 1; }
NM="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-nm"
if [ -x "$NM" ]; then
  for sym in DobbyHook DobbyDestroy DobbyInstrument DobbyBuildVersion DobbySymbolResolver; do   # đúng tập ký hiệu của libdobby.a dựng sẵn trong lõi
    "$NM" "$LIB" 2>/dev/null | grep -q " T $sym\$" || { echo "ERROR: libdobby.a không xuất $sym"; exit 1; }
  done
fi
DEST="$CORE_DIR/Bcore/src/main/cpp/Dobby/$ABI"
mkdir -p "$DEST"
cp "$LIB" "$DEST/libdobby.a"
echo "OK: $DEST/libdobby.a ($(du -k "$DEST/libdobby.a" | cut -f1) KB, Dobby $DOBBY_REF)"
