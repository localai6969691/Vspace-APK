#!/usr/bin/env bash
# Kiểm chữ ký ApkSigner v2 + APK đã ghép split bằng trình cài đặt/PackageParser THẬT của Android (P0-9, P1-20).
# Cần emulator/máy đang kết nối (adb) và thư mục fixture do verify_real.py xuất ra (VSPACE_FIXTURE_OUT).
#   bash scripts/emulator_install_check.sh fixtures
# Thoát 1 nếu có ca sai. Không cần engine chạy được: APK mẫu chỉ có tài nguyên + manifest nên chạy được trên emulator x86.
set -u
DIR="${1:?cách dùng: emulator_install_check.sh thu-muc-fixture}"
OK="$DIR/merged-signed.apk"
PKG="fixture.split"
FAILS=0
fail() { echo "FAIL: $*"; FAILS=$((FAILS+1)); }
pass() { echo "OK:   $*"; }

[ -f "$OK" ] || { echo "FAIL: thiếu $OK (chạy verify_real.py với VSPACE_FIXTURE_OUT)"; exit 1; }
adb wait-for-device
adb uninstall "$PKG" >/dev/null 2>&1 || true

# 1. APK đã ghép + ký v2 phải cài được
OUT=$(adb install -r -t "$OK" 2>&1 | tr -d '\r')
if echo "$OUT" | grep -q "Success"; then pass "cài APK ghép split + ký v2 (PackageParser thật)"; else fail "cài APK ghép: $OUT"; fi

# 2. Gói phải hiện đúng thông tin
INFO=$(adb shell dumpsys package "$PKG" 2>/dev/null | tr -d '\r')
echo "$INFO" | grep -q "versionCode=3" && pass "versionCode=3 đúng" || fail "versionCode không phải 3"
echo "$INFO" | grep -q "versionName=1.2" && pass "versionName=1.2 đúng" || fail "versionName không phải 1.2"
echo "$INFO" | grep -qi "apkSigningVersion=2\|signatures=\[" && pass "hệ thống ghi nhận chữ ký" || fail "không thấy thông tin chữ ký"
echo "$INFO" | grep -q "pkgFlags" || echo "WARN: dumpsys không có pkgFlags (định dạng đổi theo bản Android)"

# 3. Cài đè cùng khóa (cập nhật) phải được — chứng minh khóa/chữ ký ổn định
OUT=$(adb install -r -t "$OK" 2>&1 | tr -d '\r')
echo "$OUT" | grep -q "Success" && pass "cài đè cùng chữ ký" || fail "cài đè: $OUT"

# 4. Ca âm: sửa 1 byte vùng nội dung -> phải bị từ chối
BAD="$DIR/tampered.apk"
cp "$OK" "$BAD"
printf '\xff' | dd of="$BAD" bs=1 seek=300 conv=notrunc 2>/dev/null
adb uninstall "$PKG" >/dev/null 2>&1 || true
OUT=$(adb install -r -t "$BAD" 2>&1 | tr -d '\r')
if echo "$OUT" | grep -q "Success"; then fail "APK bị sửa 1 byte VẪN cài được (chữ ký không bảo vệ)"; else pass "APK bị sửa bị từ chối: $(echo "$OUT" | tail -1)"; fi

adb uninstall "$PKG" >/dev/null 2>&1 || true
if [ "$FAILS" -eq 0 ]; then echo "INSTALL CHECK: TẤT CẢ ĐẠT"; exit 0; fi
echo "INSTALL CHECK: $FAILS ca sai"
exit 1
