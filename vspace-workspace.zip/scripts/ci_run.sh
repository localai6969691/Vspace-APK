#!/usr/bin/env bash
# Chạy một lệnh trong CI; nếu thất bại thì phát Annotation (công khai) chứa các dòng lỗi đầu tiên + vài dòng cuối của log.
#   bash scripts/ci_run.sh "Tiêu đề" <lệnh> [đối số...]
set -u
TITLE="${1:?usage: ci_run.sh <tiêu đề> <lệnh...>}"
shift
HERE="$(cd "$(dirname "$0")" && pwd)"
LOG="$(mktemp "${RUNNER_TEMP:-/tmp}/ci_run.XXXXXX")"
set -o pipefail
"$@" 2>&1 | tee "$LOG"
RC="${PIPESTATUS[0]}"
if [ "$RC" -ne 0 ]; then
  python3 "$HERE/ci_annotate.py" error "$TITLE (mã thoát $RC)" "$LOG" \
    --grep 'error|Error|ERROR|FAILED|fatal|undefined reference|What went wrong|No such file|not found|Exception' --tail 18
fi
exit "$RC"
