#!/usr/bin/env python3
"""Kiểm đường mạng THẬT của UpdateChecker (G-37) trên JVM — không cần Android.

Chạy lớp UpdateChecker thật (Java thuần) với: tải qua chuyển hướng GitHub, sha256 đúng/sai, size sai, hủy giữa chừng,
chặn host/giao thức lạ, và gọi api.github.com (có thể bị giới hạn tốc độ -> ghi SKIP, không báo đạt giả).
Cần: mạng tới github.com, javac. Không nằm trong CI mặc định (test mạng không nên làm CI đỏ vì mạng).

  python3 scripts/net_check.py [owner/repo]
"""
import os, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "workspace/src")
URL = "https://github.com/REAndroid/APKEditor/releases/download/V1.4.9/APKEditor-1.4.9.jar"
SHA = "a9cd40df818845456be6d696de6110c89edf4b0a0580cb83438ed6b25a366e67"  # trùng PINS trong verify_real.py

def main():
    repo = sys.argv[1] if len(sys.argv) > 1 else "REAndroid/APKEditor"
    with tempfile.TemporaryDirectory() as t:
        out = os.path.join(t, "cls")
        os.makedirs(out)
        files = [os.path.join(SRC, "main/java/dev/vspace/workspace/UpdateChecker.java"),
                 os.path.join(SRC, "main/java/dev/vspace/workspace/MiniJson.java"),
                 os.path.join(SRC, "test/java/dev/vspace/workspace/NetCheckCli.java")]
        r = subprocess.run(["javac", "-encoding", "UTF-8", "-d", out] + files, capture_output=True, text=True)
        if r.returncode:
            print(r.stderr); return 2
        r = subprocess.run(["java", "-cp", out, "dev.vspace.workspace.NetCheckCli", URL, SHA, os.path.join(t, "dl"), repo],
                           text=True, capture_output=True)
        print(r.stdout, end="")
        if r.stderr.strip(): print(r.stderr)
        return r.returncode

if __name__ == "__main__":
    sys.exit(main())
