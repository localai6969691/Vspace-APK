#!/usr/bin/env python3
"""Biên dịch THẬT (javac) toàn bộ mã Java của dự án trong sandbox KHÔNG có Android SDK, rồi chạy test đơn vị.

Cách làm:
  1. Sinh stub chữ ký Android API + lõi BlackBox giả từ scripts/stubs/android_api.spec (phương thức `native`, không có thân).
  2. Sinh R.java từ tài nguyên.
  3. Chép module workspace, chạy scripts/gen_guest_hooks.py trên lõi giả (kiểm luôn mã sinh tự động).
  4. javac (-source/-target 17) mọi thứ (workspace + testguest). Mọi lỗi còn lại là lỗi THẬT trong mã dự án (hoặc stub sai).
  5. Biên dịch và chạy test đơn vị bằng runner mini (không cần JUnit).

Giới hạn: stub chỉ đúng nếu chữ ký giống Android thật. Đây là lưới an toàn mạnh, KHÔNG thay thế build thật bằng Android SDK.
Dùng: python3 scripts/compile_check.py [--keep]
"""
import glob, os, re, shutil, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPEC = os.path.join(ROOT, "scripts/stubs/android_api.spec")
# Phiên 8: stub thủ công cho androidx.recyclerview (không fetch được thật trong sandbox, xem đầu file đó).
# LUÔN nạp, kể cả khi có android.jar thật — android.jar không có AndroidX.
SPEC_ANDROIDX = os.path.join(ROOT, "scripts/stubs/androidx_api.spec")

# android.jar THẬT (phiên 7, nhờ có mạng tới GitHub): nếu có, biên dịch với nó thay cho stub viết tay (stub dễ sai/thiếu).
# Tìm theo thứ tự: biến môi trường VSPACE_ANDROID_JAR, rồi ~/.cache/vspace/android-35.jar (scripts/verify_real.py --fetch tải về).
def real_android_jar():
    if "--stub" in sys.argv:
        return None
    for cand in (os.environ.get("VSPACE_ANDROID_JAR"), os.path.expanduser("~/.cache/vspace/android-35.jar")):
        if cand and os.path.isfile(cand):
            return cand
    return None


def javac_cmd():
    if shutil.which("javac"):
        return ["javac"]
    if shutil.which("java"):
        return ["java", "-m", "jdk.compiler/com.sun.tools.javac.Main"]
    return None


# ------------------------------------------------------------------ 1. stub từ spec
def parse_spec(path):
    blocks, cur = [], None
    for raw in open(path, encoding="utf-8").read().split("\n"):
        if raw.startswith("@@"):
            fq, decl = [x.strip() for x in raw[2:].split("|", 1)]
            cur = {"fq": fq, "decl": decl, "members": []}
            blocks.append(cur)
        elif cur is not None and raw.strip() and not raw.strip().startswith("#"):
            cur["members"].append(raw.rstrip())
    return blocks


NESTED_RE = re.compile(r"^\s*(?:(?:public|protected|private|static|final|abstract)\s+)*(class|interface|enum)\s+(\w+)")


def transform_members(simple, header_kind, members):
    out, stack = [], [(simple, header_kind)]
    for line in members:
        st = line.strip()
        m = NESTED_RE.match(st)
        if m and st.endswith("{") and "}" not in st:
            out.append(line)
            stack.append((m.group(2), m.group(1)))
            continue
        if st == "}":
            out.append(line)
            if len(stack) > 1:
                stack.pop()
            continue
        name, kind = stack[-1]
        is_method = (st.endswith(";") and "(" in st and "=" not in st and "{" not in st
                     and "abstract" not in st.split("(")[0].split() and not st.startswith("default"))
        if kind in ("interface", "@interface") or not is_method:
            out.append(line)
            continue
        ctor = re.match(r"^(?:public|protected|private)?\s*(\w+)\s*\(", st)
        if ctor and ctor.group(1) == name:
            out.append(line.rstrip()[:-1] + " {}")
        else:
            out.append(re.sub(r"^(\s*(?:(?:public|protected|private|static|final|synchronized)\s+)*)", r"\1native ", line, count=1))
    return out


def gen_stubs(blocks, outdir):
    pkgs = sorted({b["fq"].rpartition(".")[0] for b in blocks})
    for b in blocks:
        pkg, _, simple = b["fq"].rpartition(".")
        kind = "@interface" if "@interface" in b["decl"] else "interface" if re.search(r"\binterface\b", b["decl"]) else "class"
        body = "\n".join(transform_members(simple, kind, b["members"]))
        imports = "".join(f"import {p}.*;\n" for p in pkgs if p != pkg) + "import java.util.*;\nimport java.io.*;\n"
        d = os.path.join(outdir, *pkg.split("."))
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, simple + ".java"), "w", encoding="utf-8") as f:
            f.write(f"package {pkg};\n{imports}\n{b['decl']} {{\n{body}\n}}\n")


# ------------------------------------------------------------------ 2. R.java
def gen_r(res_dir, out_dir, pkg="dev.vspace.workspace"):
    import xml.etree.ElementTree as ET
    strings = [e.get("name") for e in ET.parse(os.path.join(res_dir, "values/strings.xml")).getroot().findall("string")]
    layouts, ids = [], set()
    for f in sorted(glob.glob(os.path.join(res_dir, "layout/*.xml"))):
        layouts.append(os.path.basename(f)[:-4])
        ids |= set(re.findall(r"@\+id/(\w+)", open(f, encoding="utf-8").read()))
    drawables = [os.path.basename(f)[:-4] for f in sorted(glob.glob(os.path.join(res_dir, "drawable/*.xml")))]
    n = [0x7f000000]

    def cls(name, items):
        lines = [f"    public static final class {name} {{"]
        for it in sorted(set(items)):
            n[0] += 1
            lines.append(f"        public static final int {it} = {n[0]};")
        lines.append("    }")
        return "\n".join(lines)

    d = os.path.join(out_dir, *pkg.split("."))
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "R.java"), "w", encoding="utf-8") as f:
        f.write(f"package {pkg};\npublic final class R {{\n" + "\n".join([
            cls("string", strings), cls("id", ids), cls("layout", layouts), cls("drawable", drawables)]) + "\n}\n")


# ------------------------------------------------------------------ 5. JUnit tối thiểu + runner
JUNIT_TEST = """package org.junit;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) @Target(ElementType.METHOD)
public @interface Test {}
"""
JUNIT_ASSERT = """package org.junit;
public class Assert {
    public static void assertTrue(boolean c) { if (!c) throw new AssertionError("expected true"); }
    public static void assertTrue(String m, boolean c) { if (!c) throw new AssertionError(m); }
    public static void assertFalse(boolean c) { if (c) throw new AssertionError("expected false"); }
    public static void assertFalse(String m, boolean c) { if (c) throw new AssertionError(m); }
    public static void assertEquals(long e, long a) { if (e != a) throw new AssertionError("expected " + e + " but was " + a); }
    public static void assertEquals(String m, long e, long a) { if (e != a) throw new AssertionError(m + ": expected " + e + " but was " + a); }
    public static void assertEquals(double e, double a, double delta) {
        if (!(Math.abs(e - a) <= delta)) throw new AssertionError("expected " + e + " but was " + a + " (delta " + delta + ")");
    }
    public static void assertEquals(String m, double e, double a, double delta) {
        if (!(Math.abs(e - a) <= delta)) throw new AssertionError(m + ": expected " + e + " but was " + a);
    }
    public static void assertEquals(Object e, Object a) {
        if (e == null ? a != null : !e.equals(a)) throw new AssertionError("expected <" + e + "> but was <" + a + ">");
    }
    public static void assertEquals(String m, Object e, Object a) {
        if (e == null ? a != null : !e.equals(a)) throw new AssertionError(m + ": expected <" + e + "> but was <" + a + ">");
    }
    public static void assertArrayEquals(byte[] e, byte[] a) {
        if (!java.util.Arrays.equals(e, a)) throw new AssertionError("expected <" + java.util.Arrays.toString(e) + "> but was <" + java.util.Arrays.toString(a) + ">");
    }
    public static void assertArrayEquals(String m, byte[] e, byte[] a) {
        if (!java.util.Arrays.equals(e, a)) throw new AssertionError(m + ": expected <" + java.util.Arrays.toString(e) + "> but was <" + java.util.Arrays.toString(a) + ">");
    }
}
"""
RUNNER = """import java.lang.reflect.*;
public class MiniRunner {
    public static void main(String[] args) throws Exception {
        int pass = 0, fail = 0;
        for (String cn : args) {
            Class<?> c = Class.forName(cn);
            for (Method m : c.getDeclaredMethods()) {
                if (m.getAnnotation(org.junit.Test.class) == null) continue;
                try {
                    Object o = c.getDeclaredConstructor().newInstance();
                    m.invoke(o);
                    pass++;
                } catch (InvocationTargetException e) {
                    fail++;
                    System.out.println("  FAIL " + c.getSimpleName() + "." + m.getName() + ": " + e.getCause());
                } catch (Throwable t) {
                    fail++;
                    System.out.println("  ERROR " + c.getSimpleName() + "." + m.getName() + ": " + t);
                }
            }
        }
        System.out.println("tests: " + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }
}
"""


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def run_javac(cmd, out, sources, classpath=None):
    listing = os.path.join(out + "-sources.txt")
    with open(listing, "w") as f:
        f.write("\n".join(sources))
    os.makedirs(out, exist_ok=True)
    args = cmd + ["-source", "17", "-target", "17", "-Xlint:-options", "-proc:none", "-Xmaxerrs", "5000", "-encoding", "UTF-8", "-d", out]
    if classpath:
        args += ["-cp", classpath]
    r = subprocess.run(args + ["@" + listing], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def main():
    keep = "--keep" in sys.argv
    jc = javac_cmd()
    if not jc:
        print("Không có java/javac: bỏ qua biên dịch thật.")
        return 0
    tmp = tempfile.mkdtemp(prefix="vspace-compile-")
    try:
        stubs, gen, mod = (os.path.join(tmp, x) for x in ("stubs", "gen", "mod"))
        blocks = parse_spec(SPEC)
        jar = real_android_jar()
        if jar:
            # Chỉ giữ phần lõi BlackBox giả; android.* lấy từ android.jar thật. androidx.* không có trong android.jar
            # (Google không công khai AndroidX qua mirror nào trong allowlist mạng) nên LUÔN cần stub thủ công.
            blocks = [b for b in blocks if b["fq"].startswith("top.niunaijun")]
        blocks += parse_spec(SPEC_ANDROIDX)
        print("  chế độ:", f"android.jar THẬT ({jar})" if jar else "stub viết tay (scripts/stubs/android_api.spec) — chạy verify_real.py --fetch để dùng SDK thật")
        gen_stubs(blocks, stubs)
        gen_r(os.path.join(ROOT, "workspace/src/main/res"), gen)
        shutil.copytree(os.path.join(ROOT, "workspace"), mod)
        r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts/gen_guest_hooks.py"), stubs, mod], capture_output=True, text=True)
        print("  gen_guest_hooks:", r.stdout.strip().splitlines()[0] if r.stdout.strip() else r.stderr[-200:])

        src = lambda base: glob.glob(os.path.join(base, "**/*.java"), recursive=True)
        main_srcs = src(stubs) + src(gen) + src(os.path.join(mod, "src/main/java"))
        out = os.path.join(tmp, "out")
        rc, log = run_javac(jc, out, main_srcs, classpath=jar)
        errs = [l for l in log.split("\n") if "error:" in l]
        print(f"  workspace: {len(src(os.path.join(mod, 'src/main/java')))} file(s) + {len(src(stubs))} stub(s) -> {'OK' if rc == 0 else str(len(errs)) + ' LỖI'}")
        if rc != 0:
            print(log[-6000:])
            return 1

        tg_srcs = src(stubs) + src(os.path.join(ROOT, "testguest/src/main/java"))
        rc, log = run_javac(jc, os.path.join(tmp, "tg-out"), tg_srcs, classpath=jar)
        print(f"  testguest: {'OK' if rc == 0 else 'LỖI'}")
        if rc != 0:
            print(log[-3000:])
            return 1

        junit = os.path.join(tmp, "junit")
        write(os.path.join(junit, "org/junit/Test.java"), JUNIT_TEST)
        write(os.path.join(junit, "org/junit/Assert.java"), JUNIT_ASSERT)
        write(os.path.join(junit, "MiniRunner.java"), RUNNER)
        test_srcs = src(junit) + src(os.path.join(ROOT, "workspace/src/test/java"))
        tout = os.path.join(tmp, "test-out")
        rc, log = run_javac(jc, tout, test_srcs, classpath=os.pathsep.join([out] + ([jar] if jar else [])))
        if rc != 0:
            print("  test compile: LỖI\n" + log[-4000:])
            return 1
        test_classes = [re.sub(r"[/\\]", ".", os.path.relpath(f, os.path.join(ROOT, "workspace/src/test/java"))[:-5])
                        for f in glob.glob(os.path.join(ROOT, "workspace/src/test/java/**/*Test.java"), recursive=True)]
        java = ["java"] if shutil.which("java") else None
        rr = subprocess.run(java + ["-cp", os.pathsep.join([out, tout] + ([jar] if jar else [])), "MiniRunner"] + test_classes, capture_output=True, text=True)
        print(rr.stdout.rstrip())
        if rr.returncode != 0:
            print(rr.stderr[-2000:])
            return 1
        # Kiểm API mới hơn minSdk 26 (cần android-26.jar thật; thiếu thì chỉ nhắc, không báo giả đạt)
        jar26 = os.path.expanduser("~/.cache/vspace/android-26.jar")
        if jar and os.path.isfile(jar26):
            ra = subprocess.run([sys.executable, os.path.join(ROOT, "scripts/api_audit.py"), out, jar26], capture_output=True, text=True)
            print("  api_audit (API > minSdk 26 phải có kiểm SDK_INT):", "ĐẠT" if ra.returncode == 0 else "LỖI")
            if ra.returncode != 0:
                print(ra.stdout[-2500:])
                return 1
        else:
            print("  api_audit: BỎ QUA (thiếu android-26.jar; tải từ Sable/android-platforms, xem scripts/api_audit.py)")
        return 0
    finally:
        if keep:
            print("giữ thư mục:", tmp)
        else:
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    rc = main()
    print("KẾT QUẢ BIÊN DỊCH:", "ĐẠT" if rc == 0 else "THẤT BẠI")
    sys.exit(rc)
