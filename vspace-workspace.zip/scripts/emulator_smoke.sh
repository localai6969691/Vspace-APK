#!/usr/bin/env bash
# Smoke test trên emulator: cài APK, mở màn hình chính, chờ, kiểm tiến trình còn sống và không có FATAL EXCEPTION của gói.
# Dùng trong CI (job emulator-smoke) hoặc chạy tay với emulator/điện thoại đang kết nối:  bash scripts/emulator_smoke.sh path/to.apk [gói]
# Ghi logcat vào emulator-logcat.txt. Thoát 1 nếu thất bại.
set -u
APK="${1:?cách dùng: emulator_smoke.sh duong-dan.apk [goi]}"
PKG="${2:-dev.vspace.workspace}"

adb wait-for-device
adb logcat -c || true
if ! adb install -r -t "$APK"; then
  echo "SMOKE FAIL: cài APK thất bại"
  exit 1
fi
adb shell pm grant "$PKG" android.permission.POST_NOTIFICATIONS 2>/dev/null || true
adb shell am start -W -n "$PKG/.MainActivity" || true
sleep 25

PID=$(adb shell pidof "$PKG" 2>/dev/null | tr -d '\r')
adb logcat -d > emulator-logcat.txt 2>/dev/null || true

if grep -A6 "FATAL EXCEPTION" emulator-logcat.txt | grep -q "$PKG"; then
  echo "SMOKE FAIL: có FATAL EXCEPTION của $PKG"
  grep -A12 "FATAL EXCEPTION" emulator-logcat.txt | head -n 40
  exit 1
fi
if [ -z "$PID" ]; then
  echo "SMOKE FAIL: tiến trình $PKG không còn chạy sau 25 giây"
  exit 1
fi
echo "SMOKE OK: $PKG đang chạy (pid $PID), không thấy FATAL EXCEPTION"
