#!/usr/bin/env python3
"""Chạy MỘT LỆNH trên máy Android thật (hoặc ngay trong điện thoại qua Termux) để làm P0-3 … P0-11, rồi ghi báo cáo.

  python3 scripts/device_suite.py --apk-dir ci-out [--minutes 10] [--serial S] [--out ket-qua]
  python3 scripts/device_suite.py --apk-dir ci-out --dry-run      # chỉ in kế hoạch, không đụng máy

Chuẩn bị (xem docs/DEVICE_GUIDE.md): bật Tùy chọn nhà phát triển + Gỡ lỗi USB (hoặc Gỡ lỗi không dây), kết nối adb, tắt khóa màn hình,
rút sạc nếu dùng adb không dây (số đo pin mới có nghĩa). `--apk-dir` là thư mục chứa APK tải từ CI (ci-out do scripts/ship.sh tạo).

Làm tự động: cài APK, miễn trừ pin, cấp quyền thông báo, đặt cờ ghim/giữ nền (cần bản Debug: dùng run-as), nhập testguest qua intent VIEW,
mở testguest qua ShortcutActivity, đo từng kịch bản bằng measure_background.py, chạy ScreenPower bằng quyền shell, thu thập chẩn đoán.
KHÔNG tự động được (app không mở cổng cho adb): chọn "Không gian 2" khi nhập APK, và bật chế độ Màn hình mờ/đen ở GameActivity.
Gặp chỗ đó script dừng và in đúng thao tác cần chạm; bỏ qua được bằng --no-manual.

Trạng thái: các hàm thuần có test (scripts/test_device_suite.py). Phần gọi adb CHƯA chạy được trên thiết bị trong sandbox.
"""
import argparse
import datetime
import glob
import importlib.util
import json
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
GUEST_PKG = "dev.vspace.testguest"
GUEST_ENTRY_EXTRA_PKG = "pkg"     # GameActivity.EXTRA_PKG
GUEST_ENTRY_EXTRA_USER = "user"   # GameActivity.EXTRA_USER


def load_mb():
    spec = importlib.util.spec_from_file_location("measure_background", os.path.join(HERE, "measure_background.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


# ------------------------------------------------------------------ hàm thuần (có test)

def first_abi(abilist):
    """ABI ưu tiên của máy từ ro.product.cpu.abilist ('arm64-v8a,armeabi-v7a,armeabi')."""
    for a in (abilist or "").replace(" ", "").split(","):
        if a in ("arm64-v8a", "armeabi-v7a"):
            return a
    return None


def workspace_pkg(abi):
    return "dev.vspace.workspace" + (".a32" if abi == "armeabi-v7a" else "")


def pick_apks(paths, abi):
    """Chọn APK workspace đúng ABI (ưu tiên Debug vì cần run-as) và APK testguest từ danh sách đường dẫn.
    Trả (workspace_apk, testguest_apk, ghi_chú) — thiếu thì None."""
    notes = []
    ws = [p for p in paths if os.path.basename(p).startswith("workspace-" + str(abi)) and p.endswith(".apk")]
    dbg = [p for p in ws if "debug" in os.path.basename(p).lower()]
    ws_apk = (dbg or ws or [None])[0]
    if ws_apk and not dbg:
        notes.append("chỉ có bản Release: không dùng được run-as nên không tự đặt cờ ghim được (làm tay trong Cài đặt)")
    tg = [p for p in paths if os.path.basename(p).lower().startswith("testguest") and p.endswith(".apk")]
    return ws_apk, (tg[0] if tg else None), notes


def patch_prefs_xml(xml, **flags):
    """Đặt các cờ boolean trong SharedPreferences XML (tạo mới nếu rỗng). flags: pin_processes=False, keep_alive=True…"""
    if not xml or "<map" not in xml:
        xml = "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>\n<map>\n</map>\n"
    for k, v in flags.items():
        val = "true" if v else "false"
        pat = re.compile(r'<boolean name="%s" value="(?:true|false)"\s*/>' % re.escape(k))
        new = '<boolean name="%s" value="%s" />' % (k, val)
        if pat.search(xml):
            xml = pat.sub(new, xml)
        else:
            xml = xml.replace("</map>", "    " + new + "\n</map>")
    return xml


def read_flag(xml, key):
    m = re.search(r'<boolean name="%s" value="(true|false)"' % re.escape(key), xml or "")
    return None if not m else m.group(1) == "true"


def scenarios(minutes, has_manual):
    """Danh sách kịch bản đo. screen: off = KEYCODE_SLEEP, keep = không đụng màn hình."""
    s = [
        {"id": "S1", "label": "Ghim TẮT, tắt màn hình thật", "pin": False, "screen": "off", "panel": False},
        {"id": "S2", "label": "Ghim BẬT, tắt màn hình thật", "pin": True, "screen": "off", "panel": False},
        {"id": "S3", "label": "Ghim BẬT, tắt PANEL bằng ScreenPower (máy vẫn thức)", "pin": True, "screen": "keep", "panel": True},
    ]
    if has_manual:
        s.append({"id": "S4", "label": "Ghim BẬT, chế độ Màn hình mờ/đen của app (bật tay)", "pin": True, "screen": "keep", "panel": False, "manual": True})
    for x in s:
        x["minutes"] = minutes
    return s


def report_markdown(info, results, extras):
    L = ["# Báo cáo đo trên máy thật", "",
         "| Mục | Giá trị |", "|---|---|"]
    for k in ("model", "brand", "android", "api", "abi", "display", "when"):
        L.append("| %s | %s |" % (k, info.get(k, "?")))
    L += ["", "## Kết quả từng kịch bản", ""]
    if not results:
        L.append("Chưa có kịch bản nào chạy xong (xem log).")
    for r in results:
        L.append("### %s — %s" % (r["id"], r["label"]))
        L.append("- Kết luận: **%s** — %s" % (r.get("verdict", "LỖI"), r.get("reason", r.get("error", ""))))
        if r.get("row"):
            L.append("")
            L.append(r["row"])
        L.append("")
    if extras:
        L += ["## Việc khác", ""] + ["- " + e for e in extras] + [""]
    L += ["---", "Gửi lại cho Claude: toàn bộ thư mục kết quả (nén zip) kèm file này."]
    return "\n".join(L)


# ------------------------------------------------------------------ gọi adb

class Dev:
    def __init__(self, serial, dry):
        self.serial, self.dry = serial, dry

    def adb(self, *args, timeout=120, input_text=None, check=False):
        cmd = ["adb"] + (["-s", self.serial] if self.serial else []) + list(args)
        if self.dry:
            print("  [dry] " + " ".join(cmd))
            return ""
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, input=input_text)
        except FileNotFoundError:
            sys.exit("Không thấy lệnh adb. Cài Android platform-tools và thêm vào PATH (xem docs/DEVICE_GUIDE.md).")
        except subprocess.TimeoutExpired:
            return ""
        if check and p.returncode != 0:
            raise RuntimeError("%s -> %s" % (" ".join(cmd), (p.stdout + p.stderr).strip()[-300:]))
        return p.stdout + (("\n" + p.stderr) if p.stderr and "Success" not in p.stdout else "")

    def sh(self, c, **kw):
        return self.adb("shell", c, **kw)

    def nap(self, sec):
        time.sleep(0 if self.dry else sec)

    def prop(self, k):
        return self.sh("getprop " + k).strip()


def say(msg):
    print(msg, flush=True)


def ask_manual(prompt, allow):
    if not allow or not sys.stdin.isatty():
        say("  [BỎ QUA bước tay] " + prompt)
        return False
    say("\n>>> CẦN THAO TÁC TAY: " + prompt)
    input("    Xong thì nhấn Enter (hoặc Ctrl+C để dừng)... ")
    return True


def wait_heartbeat(mb, d, seconds):
    end = time.time() + seconds
    while time.time() < end:
        if d.dry:
            return True
        hb = mb.parse_heartbeats(d.adb("logcat", "-d", "-s", mb.TAG + ":I"))
        if hb:
            return True
        time.sleep(4)
    return False


def launch_guest(d, wpkg, user=0):
    d.sh("am start -n %s/dev.vspace.workspace.ShortcutActivity --es %s %s --ei %s %d" % (
        wpkg, GUEST_ENTRY_EXTRA_PKG, GUEST_PKG, GUEST_ENTRY_EXTRA_USER, user))


def set_prefs(d, wpkg, **flags):
    """Sửa shared_prefs/vspace.xml bằng run-as (chỉ bản Debug). Trả True nếu đã đọc lại đúng giá trị."""
    d.sh("am force-stop " + wpkg)
    xml = d.sh("run-as %s cat shared_prefs/vspace.xml" % wpkg)
    if d.dry:
        return True
    if "not debuggable" in xml or xml.lstrip().startswith("run-as:"):
        return False   # bản Release hoặc không có quyền run-as
    new = patch_prefs_xml(xml if "<map" in xml else "", **flags)
    d.adb("shell", "run-as %s sh -c 'cat > shared_prefs/vspace.xml'" % wpkg, input_text=new)
    back = d.sh("run-as %s cat shared_prefs/vspace.xml" % wpkg)
    return all(read_flag(back, k) == v for k, v in flags.items())


def device_info(d, mb):
    api = d.prop("ro.build.version.sdk")
    abilist = d.prop("ro.product.cpu.abilist")
    return {"model": d.prop("ro.product.model"), "brand": d.prop("ro.product.brand"),
            "android": d.prop("ro.build.version.release"), "api": api, "abi": first_abi(abilist) or abilist,
            "display": "xem ảnh tấm nền (OLED/LCD) trong báo cáo tay", "when": datetime.datetime.now().strftime("%Y-%m-%d %H:%M")}


def run_scenario(mb, d, sc, wpkg, apk_for_sp, out_dir, can_prefs, allow_manual):
    res = {"id": sc["id"], "label": sc["label"]}
    say("\n=== %s: %s ===" % (sc["id"], sc["label"]))
    if sc.get("manual") and not ask_manual(
            "Mở GameActivity của testguest trong Workspace, bật chế độ 'Màn hình mờ' hoặc 'Màn hình đen', rồi quay lại đây", allow_manual):
        res["error"] = "bỏ qua (bước tay)"
        return res
    if can_prefs:
        ok = set_prefs(d, wpkg, pin_processes=sc["pin"], keep_alive=True)
        say("  cờ ghim=%s keep_alive=true -> %s" % (sc["pin"], "đã ghi và đọc lại đúng" if ok else "KHÔNG ghi được"))
        if not ok:
            can_prefs = False
    if not can_prefs and not sc.get("manual"):
        ask_manual("Trong Cài đặt của Workspace: bật 'Giữ nền', và %s 'Ghim tiến trình'" % ("BẬT" if sc["pin"] else "TẮT"), allow_manual)
    d.sh("logcat -c")
    d.sh("am start -n %s/dev.vspace.workspace.MainActivity" % wpkg)
    d.nap(6)
    launch_guest(d, wpkg, 0)
    if not wait_heartbeat(mb, d, 90):
        res["error"] = "không thấy nhịp tim testguest sau 90s: testguest chưa được nhập vào Không gian 1 hoặc không khởi động được"
        return res
    sp = None
    if sc["panel"]:
        secs = int(sc["minutes"] * 60 + 180)
        say("  tắt panel bằng ScreenPower %ds (quyền shell)" % secs)
        if not d.dry:
            sp = subprocess.Popen(["adb"] + (["-s", d.serial] if d.serial else []) + [
                "shell", "CLASSPATH=%s app_process / dev.vspace.workspace.ScreenPower off %d" % (apk_for_sp, secs)],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            d.nap(6)
    ns = argparse.Namespace(label=sc["label"], minutes=sc["minutes"], interval=60, screen=sc["screen"], serial=d.serial,
                            out=os.path.join(out_dir, sc["id"] + ".json"))
    if d.dry:
        say("  [dry] measure_background.cmd_run(%s)" % vars(ns))
        res["verdict"], res["reason"] = "DRY", "không chạy thật"
        return res
    try:
        mb.cmd_run(ns)
    except SystemExit as e:
        res["error"] = str(e.code)
    finally:
        if sp:
            try:
                sp.terminate()   # đóng stdin => ScreenPower tự bật lại panel; vẫn gọi 'on' rõ ràng cho chắc
                res["screenpower_log"] = (sp.communicate(timeout=10)[0] or "")[-400:]
            except Exception:
                pass
            d.sh("CLASSPATH=%s app_process / dev.vspace.workspace.ScreenPower on" % apk_for_sp)
            d.sh("input keyevent 224")
    jp = os.path.join(out_dir, sc["id"] + ".json")
    if os.path.isfile(jp):
        j = json.load(open(jp, encoding="utf-8"))
        res.update({"verdict": j["verdict"], "reason": j["reason"],
                    "row": mb.MD_HEADER + "\n" + mb.markdown_row(sc["label"], sc["minutes"], j["window"], j["verdict"], j["battery"][0],
                                                                 j["battery"][1], j["max_temp_deci"], j["adj_before"], j["adj_after"])})
    return res


def collect(d, wpkg, out_dir):
    files = {
        "logcat_testguest.txt": "logcat -d -s VSpaceTestGuest:I",
        "exit_info.txt": "dumpsys activity exit-info " + wpkg,
        "battery.txt": "dumpsys battery",
        "thermal.txt": "dumpsys thermalservice",
        "deviceidle_whitelist.txt": "dumpsys deviceidle whitelist",
        "power_wakefulness.txt": "dumpsys power",
        "processes.txt": "dumpsys activity processes",
        "meminfo.txt": "dumpsys meminfo " + wpkg,
        "props.txt": "getprop",
    }
    for name, cmd in files.items():
        txt = d.sh(cmd, timeout=90)
        if name == "power_wakefulness.txt":
            txt = "\n".join(l for l in txt.splitlines() if "Wakefulness" in l or "Display Power" in l)
        if not d.dry:
            open(os.path.join(out_dir, name), "w", encoding="utf-8").write(txt)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--apk-dir", required=True, help="thư mục chứa APK từ CI (tìm đệ quy)")
    ap.add_argument("--serial")
    ap.add_argument("--minutes", type=float, default=10, help="mỗi kịch bản (mặc định 10; chốt số liệu dùng 30)")
    ap.add_argument("--out", default="device-result")
    ap.add_argument("--no-manual", action="store_true", help="không dừng chờ thao tác tay (bỏ qua S4 và các bước tay)")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)

    mb = load_mb()
    d = Dev(a.serial, a.dry_run)
    os.makedirs(a.out, exist_ok=True)
    if not a.dry_run:
        mb.require_device(a.serial)
    info = device_info(d, mb) if not a.dry_run else {"model": "(dry)", "abi": "arm64-v8a", "api": "?"}
    abi = first_abi(info.get("abi")) or "arm64-v8a"
    wpkg = workspace_pkg(abi)
    paths = glob.glob(os.path.join(a.apk_dir, "**", "*.apk"), recursive=True)
    ws_apk, tg_apk, notes = pick_apks(paths, abi)
    say("Máy: %s %s | Android %s (API %s) | ABI %s" % (info.get("brand", ""), info.get("model"), info.get("android", "?"), info.get("api"), abi))
    for n in notes:
        say("  LƯU Ý: " + n)
    if not ws_apk or not tg_apk:
        sys.exit("Thiếu APK trong %s: workspace=%s testguest=%s (chạy scripts/ship.sh để CI build rồi tải về)" % (a.apk_dir, ws_apk, tg_apk))
    if info.get("abi") not in ("arm64-v8a", "armeabi-v7a") and not a.dry_run:
        say("  CẢNH BÁO: máy không phải ARM (%s): engine sẽ không chạy, kết quả vô nghĩa." % info.get("abi"))
    if not a.dry_run and mb.parse_battery(d.sh("dumpsys battery")).get("plugged"):
        say("  CẢNH BÁO: máy đang cắm sạc: số đo pin vô nghĩa. Dùng Gỡ lỗi không dây rồi rút sạc (xem docs/DEVICE_GUIDE.md).")

    # --- P0-3: cài + quyền
    say("\n[1/5] Cài APK và cấp quyền")
    for apk in (ws_apk,):
        out = d.adb("install", "-r", "-t", "-g", apk, timeout=300)
        if not a.dry_run and "Success" not in out:
            sys.exit("Cài workspace thất bại: " + out.strip()[-300:])
    d.sh("dumpsys deviceidle whitelist +" + wpkg)
    d.sh("pm grant %s android.permission.POST_NOTIFICATIONS" % wpkg)
    d.sh("appops set %s RUN_ANY_IN_BACKGROUND allow" % wpkg)
    d.sh("cmd appops set %s RUN_IN_BACKGROUND allow" % wpkg)

    # --- nhập testguest
    say("\n[2/5] Nhập testguest vào Workspace (Không gian 1) bằng intent VIEW")
    ext = "/sdcard/Android/data/%s/files" % wpkg
    d.sh("mkdir -p " + ext)
    d.adb("push", tg_apk, ext + "/testguest.apk")
    d.sh("am start -a android.intent.action.VIEW -d file://%s/testguest.apk -t application/vnd.android.package-archive -n %s/dev.vspace.workspace.MainActivity" % (ext, wpkg))
    d.nap(15)
    can_prefs = set_prefs(d, wpkg, keep_alive=True) if "debug" in os.path.basename(ws_apk).lower() else False
    d.sh("am start -n %s/dev.vspace.workspace.MainActivity" % wpkg)
    d.nap(5)
    launch_guest(d, wpkg, 0)
    if not wait_heartbeat(mb, d, 90):
        ask_manual("Trong Workspace bấm '+' và chọn testguest.apk (đã nằm ở %s), rồi mở testguest" % ext + "/testguest.apk", not a.no_manual)
        if not wait_heartbeat(mb, d, 60) and not a.dry_run:
            sys.exit("Vẫn không thấy nhịp tim testguest (logcat tag %s). Dừng: gửi thư mục %s và log cho Claude." % (mb.TAG, a.out))
    say("  testguest đang chạy, thấy nhịp tim.")

    # --- P0-6 cô lập: cần testguest ở cả hai không gian
    say("\n[3/5] Cô lập hai không gian (P0-6)")
    extras = []
    if ask_manual("Chuyển sang KHÔNG GIAN 2 trong Workspace, nhập lại testguest.apk vào đó và mở nó", not a.no_manual):
        mb.cmd_isolation(argparse.Namespace(serial=a.serial, wait=120))
        extras.append("P0-6: xem kết luận cô lập ở phần log phía trên (compare_idents)")
    else:
        extras.append("P0-6: chưa chạy (cần bước tay chọn Không gian 2): python3 scripts/measure_background.py isolation")

    # --- P0-4/5/7/11: các kịch bản
    say("\n[4/5] Đo %d kịch bản x %.0f phút" % (len(scenarios(a.minutes, not a.no_manual)), a.minutes))
    results = []
    sp_apk_remote = d.sh("pm path %s" % wpkg).replace("package:", "").strip().splitlines()[0] if not a.dry_run else "/data/app/base.apk"
    for sc in scenarios(a.minutes, not a.no_manual):
        results.append(run_scenario(mb, d, sc, wpkg, sp_apk_remote, a.out, can_prefs, not a.no_manual))
    d.sh("input keyevent 224")

    # --- P0-8: chẩn đoán
    say("\n[5/5] Thu thập chẩn đoán (exit-info, pin, nhiệt, ...)")
    collect(d, wpkg, a.out)
    extras.append("P0-8: xem exit_info.txt (tìm FREEZER / LOW_MEMORY / SIGNALED)")
    rep = report_markdown(info, results, extras)
    path = os.path.join(a.out, "REPORT.md")
    if not a.dry_run:
        open(path, "w", encoding="utf-8").write(rep)
    say("\n" + rep)
    say("\nĐã ghi " + path + " — nén cả thư mục %s gửi lại." % a.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
