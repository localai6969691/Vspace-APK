#!/usr/bin/env python3
"""Chạy MỘT LỆNH trên máy Android thật (hoặc ngay trong điện thoại qua Termux) để làm P0-3 … P0-11, rồi ghi báo cáo.

  python3 scripts/device_suite.py --apk-dir ci-out [--minutes 10] [--serial S] [--out ket-qua]
  python3 scripts/device_suite.py --apk-dir ci-out --dry-run      # chỉ in kế hoạch, không đụng máy

Chuẩn bị (xem docs/DEVICE_GUIDE.md): bật Tùy chọn nhà phát triển + Gỡ lỗi USB (hoặc Gỡ lỗi không dây), kết nối adb, tắt khóa màn hình,
rút sạc nếu dùng adb không dây (số đo pin mới có nghĩa). `--apk-dir` là thư mục chứa APK tải từ CI (ci-out do scripts/ship.sh tạo).

Làm tự động: cài APK, miễn trừ pin, cấp quyền thông báo, đặt cờ ghim/giữ nền (cần bản Debug: dùng run-as), nhập testguest qua intent VIEW,
mở testguest qua ShortcutActivity, đo từng kịch bản bằng measure_background.py, chạy ScreenPower bằng quyền shell, thu thập chẩn đoán.
KHÔNG tự động được (app không mở cổng cho adb): chọn "Không gian 2" khi nhập APK, và bật chế độ Màn hình mờ/đen ở GameActivity.
Gặp chỗ đó script dừng và in đúng thao tác cần chạm; bỏ qua được bằng --no-manual.

Trạng thái: các hàm thuần có test (scripts/test_device_suite.py). Phần gọi adb CHƯA chạy được trên thiết bị trong sandbox.
"""
import argparse
import datetime
import glob
import importlib.util
import json
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
GUEST_PKG = "dev.vspace.testguest"
GUEST_ENTRY_EXTRA_PKG = "pkg"     # GameActivity.EXTRA_PKG
GUEST_ENTRY_EXTRA_USER = "user"   # GameActivity.EXTRA_USER


def load_mb():
    spec = importlib.util.spec_from_file_location("measure_background", os.path.join(HERE, "measure_background.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


# ------------------------------------------------------------------ hàm thuần (có test)

SUPPORTED_ABIS = ("arm64-v8a", "armeabi-v7a", "x86_64")   # x86_64 = bản build THỬ cho emulator x86 có KVM (scripts/build_dobby.sh), không phát hành


def first_abi(abilist):
    """ABI đầu tiên của máy nằm trong danh sách ta build được (ro.product.cpu.abilist: 'arm64-v8a,armeabi-v7a,armeabi')."""
    for a in (abilist or "").replace(" ", "").split(","):
        if a in SUPPORTED_ABIS:
            return a
    return None


def choose_abi(abilist, paths):
    """ABI đầu tiên của máy MÀ có APK workspace tương ứng trong thư mục (emulator x86_64 chạy được cả arm64 qua dịch lệnh,
    nhưng nếu có APK x86_64 thì dùng nó vì engine chạy native, đáng tin hơn)."""
    for a in (abilist or "").replace(" ", "").split(","):
        if a in SUPPORTED_ABIS and pick_apks(paths, a)[0]:
            return a
    return None


def workspace_pkg(abi):
    return "dev.vspace.workspace" + (".a32" if abi == "armeabi-v7a" else "")


def pick_apks(paths, abi):
    """Chọn APK workspace đúng ABI (ưu tiên Debug vì cần run-as) và APK testguest từ danh sách đường dẫn.
    Trả (workspace_apk, testguest_apk, ghi_chú) — thiếu thì None."""
    notes = []
    ws = [p for p in paths if os.path.basename(p).startswith("workspace-" + str(abi)) and p.endswith(".apk")]
    dbg = [p for p in ws if "debug" in os.path.basename(p).lower()]
    ws_apk = (dbg or ws or [None])[0]
    if ws_apk and not dbg:
        notes.append("chỉ có bản Release: không dùng được run-as nên không tự đặt cờ ghim được (làm tay trong Cài đặt)")
    tg = [p for p in paths if os.path.basename(p).lower().startswith("testguest") and p.endswith(".apk")]
    return ws_apk, (tg[0] if tg else None), notes


def patch_prefs_xml(xml, **flags):
    """Đặt các cờ boolean trong SharedPreferences XML (tạo mới nếu rỗng). flags: pin_processes=False, keep_alive=True…"""
    if not xml or "<map" not in xml:
        xml = "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>\n<map>\n</map>\n"
    for k, v in flags.items():
        val = "true" if v else "false"
        pat = re.compile(r'<boolean name="%s" value="(?:true|false)"\s*/>' % re.escape(k))
        new = '<boolean name="%s" value="%s" />' % (k, val)
        if pat.search(xml):
            xml = pat.sub(new, xml)
        else:
            xml = xml.replace("</map>", "    " + new + "\n</map>")
    return xml


def read_flag(xml, key):
    m = re.search(r'<boolean name="%s" value="(true|false)"' % re.escape(key), xml or "")
    return None if not m else m.group(1) == "true"


def scenarios(minutes, has_manual):
    """Danh sách kịch bản đo. screen: off = KEYCODE_SLEEP, keep = không đụng màn hình."""
    s = [
        {"id": "S1", "label": "Ghim TẮT, tắt màn hình thật", "pin": False, "screen": "off", "panel": False},
        {"id": "S2", "label": "Ghim BẬT, tắt màn hình thật", "pin": True, "screen": "off", "panel": False},
        {"id": "S3", "label": "Ghim BẬT, tắt PANEL bằng ScreenPower (máy vẫn thức)", "pin": True, "screen": "keep", "panel": True},
    ]
    if has_manual:
        s.append({"id": "S4", "label": "Ghim BẬT, chế độ Màn hình mờ/đen của app (bật tay)", "pin": True, "screen": "keep", "panel": False, "manual": True})
    for x in s:
        x["minutes"] = minutes
    return s


def report_markdown(info, results, extras):
    L = ["# Báo cáo đo trên máy thật", "",
         "| Mục | Giá trị |", "|---|---|"]
    for k in ("model", "brand", "android", "api", "abi", "display", "when"):
        L.append("| %s | %s |" % (k, info.get(k, "?")))
    L += ["", "## Kết quả từng kịch bản", ""]
    if not results:
        L.append("Chưa có kịch bản nào chạy xong (xem log).")
    for r in results:
        L.append("### %s — %s" % (r["id"], r["label"]))
        L.append("- Kết luận: **%s** — %s" % (r.get("verdict", "LỖI"), r.get("reason", r.get("error", ""))))
        if r.get("row"):
            L.append("")
            L.append(r["row"])
        L.append("")
    if extras:
        L += ["## Việc khác", ""] + ["- " + e for e in extras] + [""]
    L += ["---", "Gửi lại cho Claude: toàn bộ thư mục kết quả (nén zip) kèm file này."]
    return "\n".join(L)


def parse_ui_nodes(xml):
    """Phân tích đầu ra `uiautomator dump`: danh sách node {text, rid, cls, pkg, bounds=(x1,y1,x2,y2)} (chỉ node có bounds hợp lệ)."""
    nodes = []
    for m in re.finditer(r"<node\b([^>]*?)/?>", xml or ""):
        attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', m.group(1)))
        b = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", attrs.get("bounds", ""))
        if not b:
            continue
        nodes.append({"text": attrs.get("text", ""), "rid": attrs.get("resource-id", ""), "cls": attrs.get("class", ""),
                      "pkg": attrs.get("package", ""), "bounds": tuple(int(x) for x in b.groups())})
    return nodes


def bounds_center(b):
    return (b[0] + b[2]) // 2, (b[1] + b[3]) // 2


def choose_dialog_tap(nodes, pkg, index=0):
    """Chọn điểm bấm để đi tiếp chuỗi hộp thoại nhập APK của Workspace (AlertDialog chuẩn): ưu tiên danh sách chọn không gian (mục
    thứ `index`+1: 0 = Không gian 1, resource-id android:id/text1), sau đó nút tích cực android:id/button1 (Cài / Tiếp tục / OK). Chỉ xét node của
    CHÍNH app (pkg) để không lỡ bấm hộp thoại hệ thống. Trả (x, y, mô tả) hoặc None nếu không có hộp thoại."""
    mine = [n for n in nodes if n["pkg"] == pkg]
    items = sorted((n for n in mine if n["rid"] == "android:id/text1"), key=lambda n: (n["bounds"][1], n["bounds"][0]))
    if items:
        i = min(index, len(items) - 1)   # index=0: Không gian 1; index=1: Không gian 2 (danh sách sắp theo toạ độ y)
        x, y = bounds_center(items[i]["bounds"])
        return x, y, "chọn mục %d của danh sách: %r" % (i + 1, items[i]["text"])
    for n in mine:
        if n["rid"] == "android:id/button1":
            x, y = bounds_center(n["bounds"])
            return x, y, "nút tích cực: %r" % n["text"]
    return None


def prefs_write_cmd(wpkg):
    """Lệnh ghi shared_prefs/vspace.xml bằng run-as. PHẢI tạo thư mục trước: nếu ghi cờ TRƯỚC lần chạy đầu của app (cần để bỏ màn
    thiết lập lần đầu che hộp thoại nhập APK) thì shared_prefs chưa tồn tại."""
    return "run-as %s sh -c 'mkdir -p shared_prefs && cat > shared_prefs/vspace.xml'" % wpkg


def summarize_ui(nodes, limit=10):
    """Tóm tắt một lần dump giao diện (để biết màn nào đang hiện khi không thấy hộp thoại): số node, các gói, vài chuỗi hiển thị đầu tiên."""
    pkgs = sorted({n["pkg"] for n in nodes if n["pkg"]})
    texts = [n["text"] for n in nodes if n["text"].strip()][:limit]
    return "UI dump: %d node, gói=%s, chữ=%s" % (len(nodes), ",".join(pkgs) or "(trống)", " | ".join(t[:30] for t in texts) or "(không có)")


def stop_markdown(info, msg):
    """REPORT.md khi script phải DỪNG sớm (ví dụ không thấy nhịp tim): để vẫn có kết quả đọc được thay vì không có gì."""
    return "\n".join(["# Báo cáo đo trên máy thật: DỪNG SỚM", "",
                      "Máy: %s %s, Android %s (API %s), ABI %s" % (info.get("brand", ""), info.get("model", "?"), info.get("android", "?"), info.get("api", "?"), info.get("abi", "?")),
                      "", "**Lý do dừng:** " + msg, "",
                      "Đã thu thập chẩn đoán (logcat_all.txt, logcat_testguest.txt, ps_vspace.txt, exit_info.txt...) cùng thư mục này.", ""])


# ------------------------------------------------------------------ gọi adb

class Dev:
    def __init__(self, serial, dry):
        self.serial, self.dry = serial, dry

    def adb(self, *args, timeout=120, input_text=None, check=False):
        cmd = ["adb"] + (["-s", self.serial] if self.serial else []) + list(args)
        if self.dry:
            print("  [dry] " + " ".join(cmd))
            return ""
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, input=input_text)
        except FileNotFoundError:
            sys.exit("Không thấy lệnh adb. Cài Android platform-tools và thêm vào PATH (xem docs/DEVICE_GUIDE.md).")
        except subprocess.TimeoutExpired:
            return ""
        if check and p.returncode != 0:
            raise RuntimeError("%s -> %s" % (" ".join(cmd), (p.stdout + p.stderr).strip()[-300:]))
        return p.stdout + (("\n" + p.stderr) if p.stderr and "Success" not in p.stdout else "")

    def sh(self, c, **kw):
        return self.adb("shell", c, **kw)

    def nap(self, sec):
        time.sleep(0 if self.dry else sec)

    def prop(self, k):
        return self.sh("getprop " + k).strip()


def say(msg):
    print(msg, flush=True)


def ask_manual(prompt, allow):
    if not allow or not sys.stdin.isatty():
        say("  [BỎ QUA bước tay] " + prompt)
        return False
    say("\n>>> CẦN THAO TÁC TAY: " + prompt)
    input("    Xong thì nhấn Enter (hoặc Ctrl+C để dừng)... ")
    return True


def wait_heartbeat(mb, d, seconds):
    end = time.time() + seconds
    while time.time() < end:
        if d.dry:
            return True
        hb = mb.parse_heartbeats(d.adb("logcat", "-d", "-s", mb.TAG + ":I"))
        if hb:
            return True
        time.sleep(4)
    return False


def launch_guest(d, wpkg, user=0):
    d.sh("am start -n %s/dev.vspace.workspace.ShortcutActivity --es %s %s --ei %s %d" % (
        wpkg, GUEST_ENTRY_EXTRA_PKG, GUEST_PKG, GUEST_ENTRY_EXTRA_USER, user))


def set_prefs(d, wpkg, **flags):
    """Sửa shared_prefs/vspace.xml bằng run-as (chỉ bản Debug). Trả True nếu đã đọc lại đúng giá trị."""
    d.sh("am force-stop " + wpkg)
    xml = d.sh("run-as %s cat shared_prefs/vspace.xml" % wpkg)
    if d.dry:
        return True
    if "not debuggable" in xml or xml.lstrip().startswith("run-as:"):
        return False   # bản Release hoặc không có quyền run-as
    new = patch_prefs_xml(xml if "<map" in xml else "", **flags)
    d.adb("shell", prefs_write_cmd(wpkg), input_text=new)
    back = d.sh("run-as %s cat shared_prefs/vspace.xml" % wpkg)
    return all(read_flag(back, k) == v for k, v in flags.items())


def ui_dump(d):
    """Lấy cây giao diện hiện tại (uiautomator có thể báo lỗi khi màn hình đang chuyển cảnh: thử lại tối đa 3 lần)."""
    for _ in range(3):
        out = d.adb("exec-out", "uiautomator", "dump", "/dev/tty", timeout=40)
        if "<hierarchy" in out:
            return out
        time.sleep(1.5)
    return ""


def drive_import_dialogs(d, wpkg, out_dir, seconds=75, space_index=0):
    """Tự bấm chuỗi hộp thoại nhập APK (xem trước -> chọn không gian -> xác nhận ghi đè). App cố ý KHÔNG mở cổng cài âm thầm cho adb
    (rủi ro bảo mật), nên script bấm giao diện như người dùng. Trả số lần đã bấm."""
    if d.dry:
        say("  [dry] tự bấm hộp thoại nhập APK")
        return 0
    taps, idle, end, back_sent, shown = 0, 0, time.time() + seconds, False, 0
    while time.time() < end:
        xml = ui_dump(d)
        nodes = parse_ui_nodes(xml)
        if shown < 3 and not taps:
            say("  " + summarize_ui(nodes))   # vào log/Annotations: biết màn nào đang hiện nếu không thấy hộp thoại
            shown += 1
        pick = choose_dialog_tap(nodes, wpkg, space_index)
        if pick:
            x, y, why = pick
            say("  bấm (%d,%d): %s" % (x, y, why))
            d.sh("input tap %d %d" % (x, y))
            taps += 1
            idle = 0
            time.sleep(2.5)
        else:
            idle += 1
            if taps and idle >= 2:     # đã bấm ít nhất 1 lần và 2 lần dump liên tiếp không còn hộp thoại => xong
                break
            if not taps and idle == 3 and not back_sent:
                # dự phòng: có màn khác (thiết lập lần đầu...) đang che hộp thoại của MainActivity => Back một lần để lộ ra
                say("  chưa thấy hộp thoại: gửi Back một lần (có thể màn thiết lập đang che)")
                d.sh("input keyevent 4")
                back_sent = True
            if not taps and idle >= 8:  # ~20-30 giây chưa thấy hộp thoại nào: intent VIEW không được app xử lý, đừng chờ hết giờ
                say("  không thấy hộp thoại nhập APK sau %d lần dump: bỏ qua" % idle)
                break
            time.sleep(2.5)
        open(os.path.join(out_dir, "ui_last.xml"), "w", encoding="utf-8").write(xml)
    return taps


def run_isolation(mb, d, wpkg, ext, out_dir):
    """P0-6 tự động: nhập testguest vào KHÔNG GIAN 2 (bấm mục thứ hai của danh sách), khởi chạy ở user 1, rồi so IDENT (ANDROID_ID, filesDir,
    token) với lần khởi chạy gần nhất ở Không gian 1. Chạy SAU các kịch bản đo để nhịp tim của hai guest không lẫn vào nhau."""
    res = {"ok": False}
    if d.dry:
        res["error"] = "dry-run"
        return res
    tag = mb.TAG + ":I"
    before = mb.parse_idents(d.adb("logcat", "-d", "-s", tag))
    if not before:
        res["error"] = "chưa có dòng ident của Không gian 1 trong logcat (testguest chưa in ident)"
        return res
    a = before[-1]
    d.sh("am start -a android.intent.action.VIEW -d file://%s/testguest.apk -t application/vnd.android.package-archive -n %s/dev.vspace.workspace.MainActivity" % (ext, wpkg))
    d.nap(4)
    taps = drive_import_dialogs(d, wpkg, out_dir, space_index=1)
    say("  nhập vào Không gian 2: đã bấm %d hộp thoại" % taps)
    d.nap(25)
    launch_guest(d, wpkg, 1)
    known = {i["pid"] for i in before}
    b, end = None, time.time() + 90
    while time.time() < end and not b:
        new = [i for i in mb.parse_idents(d.adb("logcat", "-d", "-s", tag)) if i["pid"] not in known]
        if new:
            b = new[-1]
            break
        time.sleep(4)
    if not b:
        res["error"] = "không thấy ident từ Không gian 2 sau 90 giây (đã bấm %d hộp thoại)" % taps
        return res
    r = mb.compare_idents(a, b)
    res.update({"ok": True, "a": a, "b": b, "result": r})
    with open(os.path.join(out_dir, "ISOLATION.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    return res


def isolation_lines(res):
    """Dòng tóm tắt đưa vào REPORT.md cho P0-6 (thuần, có test)."""
    if not res.get("ok"):
        return ["P0-6: KHÔNG chạy được tự động: %s (chạy tay: python3 scripts/measure_background.py isolation)" % res.get("error", "?")]
    r, a, b = res["result"], res["a"], res["b"]
    return ["P0-6: **%s** — %s" % (r["verdict"], r["reason"]),
            "  Không gian 1: uid=%s pid=%s androidId=%s filesDir=%s token=%s" % (a["uid"], a["pid"], a["android_id"], a["files_dir"], a["token"]),
            "  Không gian 2: uid=%s pid=%s androidId=%s filesDir=%s token=%s" % (b["uid"], b["pid"], b["android_id"], b["files_dir"], b["token"])]


def device_info(d, mb):
    api = d.prop("ro.build.version.sdk")
    abilist = d.prop("ro.product.cpu.abilist")
    return {"model": d.prop("ro.product.model"), "brand": d.prop("ro.product.brand"),
            "android": d.prop("ro.build.version.release"), "api": api, "abilist": abilist, "abi": first_abi(abilist) or abilist,
            "display": "xem ảnh tấm nền (OLED/LCD) trong báo cáo tay", "when": datetime.datetime.now().strftime("%Y-%m-%d %H:%M")}


def run_scenario(mb, d, sc, wpkg, apk_for_sp, out_dir, can_prefs, allow_manual):
    res = {"id": sc["id"], "label": sc["label"]}
    say("\n=== %s: %s ===" % (sc["id"], sc["label"]))
    if sc.get("manual") and not ask_manual(
            "Mở GameActivity của testguest trong Workspace, bật chế độ 'Màn hình mờ' hoặc 'Màn hình đen', rồi quay lại đây", allow_manual):
        res["error"] = "bỏ qua (bước tay)"
        return res
    if can_prefs:
        ok = set_prefs(d, wpkg, pin_processes=sc["pin"], keep_alive=True)
        say("  cờ ghim=%s keep_alive=true -> %s" % (sc["pin"], "đã ghi và đọc lại đúng" if ok else "KHÔNG ghi được"))
        if not ok:
            can_prefs = False
    if not can_prefs and not sc.get("manual"):
        ask_manual("Trong Cài đặt của Workspace: bật 'Giữ nền', và %s 'Ghim tiến trình'" % ("BẬT" if sc["pin"] else "TẮT"), allow_manual)
    d.sh("logcat -c")
    d.sh("am start -n %s/dev.vspace.workspace.MainActivity" % wpkg)
    d.nap(6)
    launch_guest(d, wpkg, 0)
    if not wait_heartbeat(mb, d, 90):
        res["error"] = "không thấy nhịp tim testguest sau 90s: testguest chưa được nhập vào Không gian 1 hoặc không khởi động được"
        return res
    sp = None
    if sc["panel"]:
        secs = int(sc["minutes"] * 60 + 180)
        say("  tắt panel bằng ScreenPower %ds (quyền shell)" % secs)
        if not d.dry:
            sp = subprocess.Popen(["adb"] + (["-s", d.serial] if d.serial else []) + [
                "shell", "CLASSPATH=%s app_process / dev.vspace.workspace.ScreenPower off %d" % (apk_for_sp, secs)],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            d.nap(6)
    ns = argparse.Namespace(label=sc["label"], minutes=sc["minutes"], interval=60, screen=sc["screen"], serial=d.serial,
                            out=os.path.join(out_dir, sc["id"] + ".json"))
    if d.dry:
        say("  [dry] measure_background.cmd_run(%s)" % vars(ns))
        res["verdict"], res["reason"] = "DRY", "không chạy thật"
        return res
    try:
        mb.cmd_run(ns)
    except SystemExit as e:
        res["error"] = str(e.code)
    finally:
        if sp:
            try:
                sp.terminate()   # đóng stdin => ScreenPower tự bật lại panel; vẫn gọi 'on' rõ ràng cho chắc
                res["screenpower_log"] = (sp.communicate(timeout=10)[0] or "")[-400:]
            except Exception:
                pass
            d.sh("CLASSPATH=%s app_process / dev.vspace.workspace.ScreenPower on" % apk_for_sp)
            d.sh("input keyevent 224")
    jp = os.path.join(out_dir, sc["id"] + ".json")
    if os.path.isfile(jp):
        j = json.load(open(jp, encoding="utf-8"))
        res.update({"verdict": j["verdict"], "reason": j["reason"],
                    "row": mb.MD_HEADER + "\n" + mb.markdown_row(sc["label"], sc["minutes"], j["window"], j["verdict"], j["battery"][0],
                                                                 j["battery"][1], j["max_temp_deci"], j["adj_before"], j["adj_after"])})
    return res


def collect(d, wpkg, out_dir):
    files = {
        "logcat_testguest.txt": "logcat -d -s VSpaceTestGuest:I",
        "logcat_all.txt": "logcat -d -t 4000",
        "vspace_app.log": "run-as %s cat files/vspace.log" % wpkg,
        "ps_vspace.txt": "ps -A",
        "exit_info.txt": "dumpsys activity exit-info " + wpkg,
        "battery.txt": "dumpsys battery",
        "thermal.txt": "dumpsys thermalservice",
        "deviceidle_whitelist.txt": "dumpsys deviceidle whitelist",
        "power_wakefulness.txt": "dumpsys power",
        "processes.txt": "dumpsys activity processes",
        "meminfo.txt": "dumpsys meminfo " + wpkg,
        "props.txt": "getprop",
    }
    for name, cmd in files.items():
        txt = d.sh(cmd, timeout=90)
        if name == "power_wakefulness.txt":
            txt = "\n".join(l for l in txt.splitlines() if "Wakefulness" in l or "Display Power" in l)
        if not d.dry:
            open(os.path.join(out_dir, name), "w", encoding="utf-8").write(txt)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--apk-dir", required=True, help="thư mục chứa APK từ CI (tìm đệ quy)")
    ap.add_argument("--serial")
    ap.add_argument("--minutes", type=float, default=10, help="mỗi kịch bản (mặc định 10; chốt số liệu dùng 30)")
    ap.add_argument("--out", default="device-result")
    ap.add_argument("--no-manual", action="store_true", help="không dừng chờ thao tác tay (bỏ qua S4 và các bước tay)")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)

    mb = load_mb()
    d = Dev(a.serial, a.dry_run)
    os.makedirs(a.out, exist_ok=True)
    if not a.dry_run:
        mb.require_device(a.serial)
    info = device_info(d, mb) if not a.dry_run else {"model": "(dry)", "abi": "arm64-v8a", "api": "?"}
    paths = glob.glob(os.path.join(a.apk_dir, "**", "*.apk"), recursive=True)
    abi = choose_abi(info.get("abilist") or info.get("abi"), paths) or first_abi(info.get("abi")) or "arm64-v8a"
    wpkg = workspace_pkg(abi)
    ws_apk, tg_apk, notes = pick_apks(paths, abi)
    say("Máy: %s %s | Android %s (API %s) | ABI %s" % (info.get("brand", ""), info.get("model"), info.get("android", "?"), info.get("api"), abi))
    for n in notes:
        say("  LƯU Ý: " + n)
    if not ws_apk or not tg_apk:
        sys.exit("Thiếu APK trong %s: workspace=%s testguest=%s (chạy scripts/ship.sh để CI build rồi tải về)" % (a.apk_dir, ws_apk, tg_apk))
    if abi == "x86_64" and not a.dry_run:
        say("  LƯU Ý: đang chạy bản x86_64 THỬ NGHIỆM (Dobby tự build, emulator): đủ để kiểm engine/giữ nền/cô lập, KHÔNG thay cho đo pin/nhiệt/OEM trên máy ARM thật.")
    elif abi not in SUPPORTED_ABIS and not a.dry_run:
        say("  CẢNH BÁO: ABI máy (%s) không có bản build: engine sẽ không chạy." % info.get("abi"))
    if not a.dry_run and mb.parse_battery(d.sh("dumpsys battery")).get("plugged"):
        say("  CẢNH BÁO: máy đang cắm sạc: số đo pin vô nghĩa. Dùng Gỡ lỗi không dây rồi rút sạc (xem docs/DEVICE_GUIDE.md).")

    # --- P0-3: cài + quyền
    say("\n[1/5] Cài APK và cấp quyền")
    for apk in (ws_apk,):
        out = d.adb("install", "-r", "-t", "-g", apk, timeout=300)
        if not a.dry_run and "Success" not in out:
            sys.exit("Cài workspace thất bại: " + out.strip()[-300:])
    d.sh("dumpsys deviceidle whitelist +" + wpkg)
    d.sh("pm grant %s android.permission.POST_NOTIFICATIONS" % wpkg)
    d.sh("appops set %s RUN_ANY_IN_BACKGROUND allow" % wpkg)
    d.sh("cmd appops set %s RUN_IN_BACKGROUND allow" % wpkg)

    # --- nhập testguest
    say("\n[2/5] Nhập testguest vào Workspace (Không gian 1) bằng intent VIEW")
    ext = "/sdcard/Android/data/%s/files" % wpkg
    d.sh("mkdir -p " + ext)
    d.adb("push", tg_apk, ext + "/testguest.apk")
    # Lần chạy đầu MainActivity mở SetupActivity phía trên (setup_seen chưa đặt) và hộp thoại xem trước bị che: đặt cờ TRƯỚC khi gửi intent.
    can_prefs = set_prefs(d, wpkg, keep_alive=True, setup_seen=True) if "debug" in os.path.basename(ws_apk).lower() else False
    d.sh("am start -a android.intent.action.VIEW -d file://%s/testguest.apk -t application/vnd.android.package-archive -n %s/dev.vspace.workspace.MainActivity" % (ext, wpkg))
    d.nap(4)
    taps = drive_import_dialogs(d, wpkg, a.out)
    say("  đã bấm %d hộp thoại; chờ cài đặt hoàn tất" % taps)
    d.nap(25)
    d.sh("am start -n %s/dev.vspace.workspace.MainActivity" % wpkg)
    d.nap(5)
    launch_guest(d, wpkg, 0)
    if not wait_heartbeat(mb, d, 90):
        ask_manual("Trong Workspace bấm '+' và chọn testguest.apk (đã nằm ở %s), rồi mở testguest" % ext + "/testguest.apk", not a.no_manual)
        if not wait_heartbeat(mb, d, 60) and not a.dry_run:
            msg = "Vẫn không thấy nhịp tim testguest (logcat tag %s)." % mb.TAG
            collect(d, wpkg, a.out)   # vẫn thu chẩn đoán để biết vì sao (crash native? nhập APK lỗi?)
            open(os.path.join(a.out, "REPORT.md"), "w", encoding="utf-8").write(stop_markdown(info, msg))
            sys.exit(msg + " Dừng: gửi thư mục %s và log cho Claude." % a.out)
    say("  testguest đang chạy, thấy nhịp tim.")

    extras = []

    # --- P0-4/5/7/11: các kịch bản
    say("\n[4/5] Đo %d kịch bản x %.0f phút" % (len(scenarios(a.minutes, not a.no_manual)), a.minutes))
    results = []
    sp_apk_remote = d.sh("pm path %s" % wpkg).replace("package:", "").strip().splitlines()[0] if not a.dry_run else "/data/app/base.apk"
    for sc in scenarios(a.minutes, not a.no_manual):
        results.append(run_scenario(mb, d, sc, wpkg, sp_apk_remote, a.out, can_prefs, not a.no_manual))
    d.sh("input keyevent 224")

    # --- P0-6: cô lập hai không gian (tự nhập vào Không gian 2 bằng cách bấm hộp thoại)
    say("\n[5/5] Cô lập hai không gian (P0-6) và thu thập chẩn đoán")
    iso = run_isolation(mb, d, wpkg, ext, a.out)
    extras.extend(isolation_lines(iso))

    # --- P0-8: chẩn đoán
    collect(d, wpkg, a.out)
    extras.append("P0-8: xem exit_info.txt (tìm FREEZER / LOW_MEMORY / SIGNALED)")
    rep = report_markdown(info, results, extras)
    path = os.path.join(a.out, "REPORT.md")
    if not a.dry_run:
        open(path, "w", encoding="utf-8").write(rep)
    say("\n" + rep)
    say("\nĐã ghi " + path + " — nén cả thư mục %s gửi lại." % a.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
