#!/usr/bin/env python3
"""Kiểm tra tĩnh cho dự án (không cần Android SDK/javac). Chạy trong CI trước khi build và chạy tay được:

    python3 scripts/check.py

Bắt các lỗi từng xảy ra thật: tên bước YAML có ': ', chuỗi có '%' trần, thiếu khóa chuỗi, sai số tham số khi gọi
giữa các lớp, id layout không tồn tại, ngoặc lệch, component khai trong manifest nhưng không có file, bảng Markdown vỡ.
Đây KHÔNG thay thế biên dịch thật: chỉ là lưới an toàn để lỗi hiện ra sớm.
"""
import glob, os, re, subprocess, sys, tempfile, shutil
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
FAILS = []


def fail(msg):
    FAILS.append(msg)
    print("  FAIL", msg)


def section(t):
    print("==", t)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


MAIN_J = "workspace/src/main/java/dev/vspace/workspace/"
RES = "workspace/src/main/res/"

# ---------------------------------------------------------------- helpers: Java text
def strip_java(s):
    # MỘT lượt quét trái→phải cho chuỗi và ký tự: nếu quét riêng thì '"' (ký tự dấu nháy kép) bị ghép nhầm với chuỗi phía sau.
    s = re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])\'', lambda m: '""' if m.group(0)[0] == '"' else "\'\'", s)
    s = re.sub(r"/\*.*?\*/", "", s, flags=re.S)
    s = re.sub(r"//[^\n]*", "", s)
    return s


def split_args(arg_text):
    """Tách tham số ở mức ngoài cùng (bỏ qua nội dung trong () {} [] )."""
    depth, cur, parts = 0, [], []
    for ch in arg_text:
        if ch in "({[":
            depth += 1
        elif ch in ")}]":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append("".join(cur)); cur = []
        else:
            cur.append(ch)
    last = "".join(cur).strip()
    if last or parts:
        parts.append(last)
    return [p for p in parts if p.strip()]


def balanced_call_args(src, open_idx):
    """src[open_idx] == '(' → trả về (nội dung trong ngoặc, chỉ số ngoặc đóng) hoặc None."""
    depth = 0
    for i in range(open_idx, len(src)):
        c = src[i]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return src[open_idx + 1:i], i
    return None


def param_count(params):
    params = params.strip()
    if not params:
        return 0
    depth, n = 0, 1
    for ch in params:
        if ch in "<(": depth += 1
        elif ch in ">)": depth -= 1
        elif ch == "," and depth == 0: n += 1
    return n


DEF_RE = re.compile(
    r"(?:^|\n)[ \t]*(?:@\w+(?:\([^)]*\))?\s+)*(?:(?:public|private|protected|static|final|synchronized|abstract)\s+)*"
    r"(?:<[^>]+>\s+)?(?:[\w.<>\[\], ?]+?\s+)?(\w+)\s*\(([^()]*)\)\s*(?:throws\s+[\w., ]+)?\s*[{;]")
KEYWORDS = {"if", "for", "while", "switch", "catch", "return", "new", "synchronized", "else", "try", "do", "super", "this"}


def method_arities(src):
    out = {}
    for m in DEF_RE.finditer(src):
        name = m.group(1)
        if name in KEYWORDS:
            continue
        out.setdefault(name, set()).add(param_count(m.group(2)))
    return out


# ---------------------------------------------------------------- 1. XML
section("XML")
xml_files = glob.glob("workspace/src/main/**/*.xml", recursive=True) + glob.glob("testguest/src/main/**/*.xml", recursive=True)
for f in xml_files:
    try:
        ET.parse(f)
    except Exception as e:
        fail(f"{f}: {e}")
print(f"  {len(xml_files)} files parsed")

# ---------------------------------------------------------------- 2. strings
section("strings (vi/en)")


def load_strings(p):
    return {e.get("name"): "".join(e.itertext()) for e in ET.parse(p).getroot().findall("string")}


vi, en = load_strings(RES + "values/strings.xml"), load_strings(RES + "values-en/strings.xml")
java_files = {os.path.basename(f)[:-5]: read(f) for f in glob.glob(MAIN_J + "*.java")}
all_java = "\n".join(java_files.values())
layout_xml = "".join(read(f) for f in glob.glob(RES + "layout/*.xml") + glob.glob(RES + "xml/*.xml")) + read("workspace/src/main/AndroidManifest.xml")
used = (set(re.findall(r"R\.string\.(\w+)", all_java)) | set(re.findall(r"@string/(\w+)", layout_xml))) - {"ok", "cancel"}
miss = sorted(used - set(vi))
if miss: fail(f"chuỗi thiếu trong values/: {miss}")
miss_en = sorted(set(vi) - set(en) - {"app_name"})
if miss_en: fail(f"chuỗi thiếu trong values-en/: {miss_en}")
extra_en = sorted(set(en) - set(vi))
if extra_en: fail(f"khóa chỉ có ở values-en/: {extra_en}")
spec = lambda s: sorted(re.findall(r"%(\d+)\$[\d.]*[sdf]", s))
for k in en:
    if k in vi and spec(vi[k]) != spec(en[k]):
        fail(f"định dạng %n$ khác nhau ở '{k}': {spec(vi[k])} vs {spec(en[k])}")
for name, d in (("vi", vi), ("en", en)):
    for k, v in d.items():
        if "%" in re.sub(r"%\d+\$[\d.]*[sdf]|%%", "", v):
            fail(f"{name}.{k}: có '%' trần (aapt có thể hiểu nhầm là định dạng)")
raw = read(RES + "values/strings.xml") + read(RES + "values-en/strings.xml")
for m in re.finditer(r"<string[^>]*>([^<]*)</string>", raw):
    if re.search(r"(?<!\\)'", m.group(1)):
        fail("dấu nháy đơn chưa escape: " + m.group(1)[:50])
unused = sorted(set(vi) - used)
print(f"  vi={len(vi)} en={len(en)}; dùng {len(used)}; không dùng: {unused or 'không'}")

# ---------------------------------------------------------------- 3. ids per activity
section("layout ids")
for name, src in java_files.items():
    layouts = set(re.findall(r"setContentView\(R\.layout\.(\w+)\)", src)) | set(re.findall(r"inflate\(R\.layout\.(\w+)", src)) | set(re.findall(r"new RemoteViews\([^,]+,\s*R\.layout\.(\w+)", src))
    need = set(re.findall(r"(?<![\w.])R\.id\.(\w+)", src))
    if not need:
        continue
    have = set()
    for lay in layouts:
        p = RES + f"layout/{lay}.xml"
        if os.path.exists(p):
            have |= set(re.findall(r"@\+id/(\w+)", read(p)))
        else:
            fail(f"{name}: layout {lay}.xml không tồn tại")
    if need - have:
        fail(f"{name}: id không có trong layout của nó: {sorted(need - have)}")
print("  checked")

# ---------------------------------------------------------------- 4. braces
section("ngoặc cân bằng")
src_files = glob.glob(MAIN_J + "*.java") + glob.glob("workspace/src/test/java/**/*.java", recursive=True) + glob.glob("testguest/src/main/java/**/*.java", recursive=True)
for f in sorted(src_files):
    t = strip_java(read(f))
    if not all(t.count(a) == t.count(b) for a, b in ("{}", "()", "[]")):
        fail("ngoặc lệch: " + f)
print(f"  {len(src_files)} files")

# ---------------------------------------------------------------- 5. cross-class references + arity
section("tham chiếu chéo giữa lớp (tồn tại + số tham số)")
all_src = {f: strip_java(read(f)) for f in src_files}
proj = {n: strip_java(s) for n, s in java_files.items()}
nested = set()
for s in all_src.values():
    nested |= set(re.findall(r"\b(?:class|interface|enum)\s+(\w+)", s))
arity = {c: method_arities(s) for c, s in proj.items()}
fields = {}
for c, s in proj.items():
    fields[c] = set(re.findall(r"\b(\w+)\s*(?:=[^=;]|;)", s))
ctor_arity = {}
for c, s in proj.items():
    ctor_arity[c] = {param_count(m.group(1)) for m in re.finditer(r"(?:^|\n)[ \t]*(?:public |private |protected )?" + c + r"\s*\(([^()]*)\)\s*\{", s)}
    # constructors of nested classes
    for n in re.findall(r"\b(?:static\s+)?(?:final\s+)?class\s+(\w+)", s):
        ctor_arity.setdefault(n, set()).update(
            param_count(m.group(1)) for m in re.finditer(r"(?:^|\n)[ \t]*(?:public |private |protected )?" + n + r"\s*\(([^()]*)\)\s*\{", s))
checked_calls = 0
for caller, s in all_src.items():
    cname = os.path.basename(caller)[:-5]
    for cls in proj:
        for m in re.finditer(r"\b" + cls + r"\.(\w+)\b", s):
            member = m.group(1)
            if member in ("class", "this", "super") or member in nested:   # Outer.this / Outer.super là cú pháp hợp lệ trong lớp lồng/ẩn danh
                continue
            after = m.end()
            is_call = after < len(s) and s[after] == "("
            if is_call:
                ba = balanced_call_args(s, after)
                if ba is None:
                    continue
                n_args = len(split_args(ba[0]))
                ar = arity[cls].get(member)
                checked_calls += 1
                if ar is None:
                    fail(f"{cname}: {cls}.{member}() không tồn tại")
                elif n_args not in ar:
                    fail(f"{cname}: {cls}.{member}() gọi {n_args} tham số, định nghĩa có {sorted(ar)}")
            elif member not in fields[cls] and member not in arity[cls]:
                fail(f"{cname}: {cls}.{member} không tồn tại")
        # new Cls(...)
        for m in re.finditer(r"\bnew\s+" + cls + r"\s*\(", s):
            ba = balanced_call_args(s, m.end() - 1)
            if ba is None or not ctor_arity.get(cls):
                continue
            n_args = len(split_args(ba[0]))
            checked_calls += 1
            if n_args not in ctor_arity[cls]:
                fail(f"{cname}: new {cls}() {n_args} tham số, constructor có {sorted(ctor_arity[cls])}")
# nested classes constructors used from other files (e.g. new GuestApp(...) inside MainActivity)
for caller, s in all_src.items():
    cname = os.path.basename(caller)[:-5]
    for n, ars in ctor_arity.items():
        if n in proj or not ars:
            continue
        for m in re.finditer(r"\bnew\s+(?:\w+\.)?" + n + r"\s*\(", s):
            ba = balanced_call_args(s, m.end() - 1)
            if ba is None:
                continue
            k = len(split_args(ba[0]))
            checked_calls += 1
            if k not in ars:
                fail(f"{cname}: new {n}() {k} tham số, constructor có {sorted(ars)}")
# gm.xxx / GameModeController.get(..).xxx (thành viên instance)
gm_members = set(arity["GameModeController"]) | fields["GameModeController"]
for caller, s in all_src.items():
    cname = os.path.basename(caller)[:-5]
    for m in re.finditer(r"GameModeController\.get\([^)]*\)\.(\w+)|\bgm\.(\w+)", s):
        member = m.group(1) or m.group(2)
        checked_calls += 1
        if member not in gm_members:
            fail(f"{cname}: GameModeController.{member} không tồn tại")
print(f"  {checked_calls} tham chiếu đã kiểm")

# ---------------------------------------------------------------- 6. manifest
section("manifest")
man = read("workspace/src/main/AndroidManifest.xml")
for comp in re.findall(r'<(?:activity|service|receiver|provider)[^>]*android:name="\.(\w+)"', man) + ["SpaceApp"]:
    if comp not in java_files:
        fail(f"manifest khai .{comp} nhưng không có file Java")
for perm in ("SYSTEM_ALERT_WINDOW", "FOREGROUND_SERVICE_SPECIAL_USE", "POST_NOTIFICATIONS", "SCHEDULE_EXACT_ALARM", "WAKE_LOCK"):
    if perm not in man:
        fail("manifest thiếu quyền " + perm)
if "dataSync" in man:
    fail("manifest không được dùng foregroundServiceType dataSync (xem tài liệu F-2)")
print("  components + permissions")

# ---------------------------------------------------------------- 7. workflow
section("workflow")
try:
    import yaml
    wf = yaml.safe_load(read(".github/workflows/build.yml"))
    n = 0
    for jname, job in wf["jobs"].items():
        for st in job.get("steps", []):
            if st.get("run"):
                with tempfile.NamedTemporaryFile("w", suffix=".sh", delete=False) as t:
                    t.write(st["run"])
                if subprocess.run(["bash", "-n", t.name]).returncode:
                    fail(f"bash -n lỗi ở bước '{st.get('name')}' của job {jname}")
                os.unlink(t.name)
                n += 1
    print(f"  YAML hợp lệ; {n} bước run: qua bash -n")
except ImportError:
    print("  (bỏ qua: chưa cài pyyaml)")
except Exception as e:
    fail(f"workflow YAML lỗi: {e}")
for sh in glob.glob("scripts/*.sh"):
    if subprocess.run(["bash", "-n", sh]).returncode:
        fail("bash -n lỗi: " + sh)
# network_security_config phải ép HTTPS đúng các miền mà UpdateChecker được phép gọi
_uc = read("workspace/src/main/java/dev/vspace/workspace/UpdateChecker.java")
_nsc = read("workspace/src/main/res/xml/network_security_config.xml")
for _host in ("github.com", "api.github.com", "githubusercontent.com"):
    if _host not in _uc:
        fail(f"UpdateChecker không còn nhắc miền {_host} nhưng network_security_config vẫn khai: đồng bộ lại")
    if f">{_host}<" not in _nsc:
        fail(f"network_security_config thiếu miền {_host} của UpdateChecker")
_pin = subprocess.run([sys.executable, "scripts/pin_actions.py", "--check"], capture_output=True, text=True)
if _pin.returncode:
    fail("có GitHub Action chưa ghim SHA (chuỗi cung ứng): " + _pin.stdout.strip()[-300:] + " — chạy: python3 scripts/pin_actions.py --apply")
else:
    print("  " + _pin.stdout.strip())

# ---------------------------------------------------------------- 8. overlay dry-run
section("overlay dry-run")
tmp = tempfile.mkdtemp()
try:
    core = os.path.join(tmp, "core")
    os.makedirs(core + "/Bcore/src/main/java/com/fork/engine/cfg")
    open(core + "/settings.gradle", "w").write("rootProject.name='NB'\ninclude ':app', ':Bcore'\n")
    open(core + "/Bcore/src/main/java/com/fork/engine/BlackBoxCore.java", "w").write("package com.fork.engine;\npublic class BlackBoxCore {}\n")
    open(core + "/Bcore/src/main/java/com/fork/engine/cfg/ClientConfiguration.java", "w").write("package com.fork.engine.cfg;\npublic abstract class ClientConfiguration {}\n")
    for _ in range(2):  # chạy 2 lần: phải idempotent
        r = subprocess.run(["bash", "scripts/overlay.sh", core], capture_output=True, text=True)
        if r.returncode:
            fail("overlay.sh lỗi: " + r.stderr[-200:])
    st = read(core + "/settings.gradle")
    for mod in ("workspace", "testguest"):
        if st.count(f'include(":{mod}")') != 1:
            fail(f"overlay: include {mod} xuất hiện {st.count(chr(34) + ':' + mod)} lần (phải đúng 1)")
    eng = read(core + "/workspace/src/main/java/dev/vspace/workspace/Engine.java")
    if "import com.fork.engine.BlackBoxCore;" not in eng or "import com.fork.engine.cfg.ClientConfiguration;" not in eng:
        fail("overlay: import không được sửa theo package thật của core")
    print("  idempotent; import tự sửa; include đúng 1 lần mỗi module")
finally:
    shutil.rmtree(tmp, ignore_errors=True)

# ---------------------------------------------------------------- 8b. bộ sinh mã hook
section("bộ sinh mã gen_guest_hooks (4 kiểu core giả)")
r = subprocess.run([sys.executable, "scripts/test_gen_guest_hooks.py"], capture_output=True, text=True)
if r.returncode:
    fail("test_gen_guest_hooks.py thất bại:\n" + r.stdout[-600:] + r.stderr[-300:])
else:
    print("  " + r.stdout.strip().splitlines()[-1])

# ---------------------------------------------------------------- 8c. biên dịch thật + chạy test đơn vị
section("biên dịch thật bằng javac (stub Android) + test đơn vị")
import shutil as _sh
if _sh.which("java") or _sh.which("javac"):
    r = subprocess.run([sys.executable, "scripts/compile_check.py"], capture_output=True, text=True)
    print("\n".join("  " + l for l in r.stdout.strip().splitlines()[-6:]))
    if r.returncode:
        fail("compile_check.py thất bại (xem lỗi ở trên; chạy riêng: python3 scripts/compile_check.py)")
else:
    print("  (bỏ qua: không có java/javac)")

# ---------------------------------------------------------------- 8a. cú pháp bash của scripts/*.sh
section("cú pháp scripts/*.sh (bash -n)")
for f in sorted(glob.glob("scripts/*.sh")):
    r = subprocess.run(["bash", "-n", f], capture_output=True, text=True)
    if r.returncode:
        fail(f + ": " + r.stderr.strip())
    else:
        print("  " + f + ": ok")

# ---------------------------------------------------------------- 8b. công cụ đo bằng adb
section("công cụ đo (scripts/measure_background.py)")
r = subprocess.run([sys.executable, "scripts/test_measure_background.py"], capture_output=True, text=True)
tail = (r.stderr or r.stdout).strip().splitlines()
print("\n".join("  " + l for l in tail[-3:]))
if r.returncode:
    fail("test_measure_background.py thất bại (chạy riêng: python3 scripts/test_measure_background.py)")
r = subprocess.run([sys.executable, "scripts/test_device_suite.py"], capture_output=True, text=True)
print("  device_suite: " + (r.stderr or r.stdout).strip().splitlines()[-1])
if r.returncode:
    fail("test_device_suite.py thất bại (chạy riêng: python3 scripts/test_device_suite.py)")

# ---------------------------------------------------------------- 9. docs tables
section("tài liệu: bảng Markdown")
for md in ("docs/PROJECT_HANDOFF.md", "README.md"):
    if not os.path.exists(md):
        continue
    cur, bad = None, 0
    for i, line in enumerate(read(md).split("\n"), 1):
        if line.startswith("|"):
            n = len(re.findall(r"(?<!\\)\|", line))
            if cur is None: cur = n
            elif n != cur: bad += 1; fail(f"{md}:{i}: số cột bảng lệch ({n} vs {cur})")
        else:
            cur = None
    print(f"  {md}: {'ok' if not bad else str(bad) + ' hàng lệch'}")

print()
print("KẾT QUẢ:", "TẤT CẢ ĐẠT" if not FAILS else f"{len(FAILS)} LỖI")
sys.exit(1 if FAILS else 0)
