#!/usr/bin/env bash
# Chạy một lệnh KHÔNG làm đỏ job, nhưng đưa kết quả (đạt/hỏng + dòng quan trọng) ra Annotations công khai.
#   bash scripts/ci_soft.sh "Tiêu đề" <lệnh> [đối số...]
# Vì sao: bước test/lint Gradle đang để continue-on-error (P1-16) nên trang lượt chạy chỉ hiện "xanh", không cho biết
# test/lint có đạt hay không; log đầy đủ cần đăng nhập. Script này biến kết quả thành Annotation đọc được không cần đăng nhập,
# để quyết định bỏ continue-on-error dựa trên số liệu thật. Mã thoát luôn là 0.
set -u
TITLE="${1:?usage: ci_soft.sh <tiêu đề> <lệnh...>}"
shift
HERE="$(cd "$(dirname "$0")" && pwd)"
LOG="$(mktemp "${RUNNER_TEMP:-/tmp}/ci_soft.XXXXXX")"
set -o pipefail
"$@" 2>&1 | tee "$LOG"
RC="${PIPESTATUS[0]}"
if [ "$RC" -eq 0 ]; then
  python3 "$HERE/ci_annotate.py" notice "$TITLE - DAT" "$LOG" --tail 8
else
  python3 "$HERE/ci_annotate.py" warning "$TITLE - HONG (ma thoat $RC)" "$LOG" \
    --grep 'FAILED|Lint found|error:|Error|What went wrong|tests completed|Execution failed' --tail 16
fi
exit 0
