#!/usr/bin/env bash
# Chạy trong emulator-runner (job emulator-smoke): 3 kiểm tra ĐỘC LẬP, không dừng ở lỗi đầu tiên (lỗi smoke không che kết quả kiểm cài đặt),
# mỗi kiểm tra phát Annotation (cả khi đạt) để đọc được kết quả mà không cần đăng nhập xem log.
#   bash scripts/emulator_ci.sh <apk-workspace> <thu-muc-fixture>
set -u
APK="${1:?usage: emulator_ci.sh <apk> <fixtures>}"
FIX="${2:?usage: emulator_ci.sh <apk> <fixtures>}"
HERE="$(cd "$(dirname "$0")" && pwd)"
FAILS=0
check() {   # tên, tệp ghi kết quả, lệnh...
  local name="$1" out="$2" rc
  shift 2
  "$@" > "$out" 2>&1
  rc=$?
  cat "$out"
  if [ "$rc" -ne 0 ]; then
    FAILS=$((FAILS + 1))
    python3 "$HERE/ci_annotate.py" error "$name (mã thoát $rc)" "$out" --grep 'FAIL|SMOKE|SCREENPOWER|INSTALL|Exception|error' --tail 14
  else
    python3 "$HERE/ci_annotate.py" notice "$name đạt" "$out" --tail 8
  fi
  return "$rc"
}
check "install-check" install-check.txt bash "$HERE/emulator_install_check.sh" "$FIX"
check "screenpower-check" screenpower-check.txt bash "$HERE/emulator_screenpower_check.sh" "$APK"
if ! check "smoke" smoke.txt bash "$HERE/emulator_smoke.sh" "$APK"; then
  # app mở được rồi tắt: đưa dấu vết lỗi từ logcat ra Annotations để biết vì sao (crash Java, lỗi nạp .so, tín hiệu native...)
  if [ -f emulator-logcat.txt ]; then
    python3 "$HERE/ci_annotate.py" warning "logcat: dấu vết lỗi của app" emulator-logcat.txt \
      --grep 'FATAL EXCEPTION|AndroidRuntime|UnsatisfiedLinkError|dlopen failed|SIGSEGV|SIGABRT|Abort message|Fatal signal|libblackbox|VSpace.*(Exception|failed|error)' --tail 22
  fi
fi
if [ "$FAILS" -ne 0 ]; then
  echo "emulator_ci: $FAILS kiểm tra lỗi"
  exit 1
fi
echo "emulator_ci: tất cả đạt"
