#!/usr/bin/env python3
"""Vá Dobby 223aabc (bản mà lõi dùng) để biên dịch được với NDK mới (đã gặp ở CI lượt #12, NDK 29).

Lỗi: external/logging/logging.c đặt `#include <android/log.h>` BÊN TRONG thân hàm. android/log.h của NDK mới có hàm `static inline`
(dòng 174), mà định nghĩa hàm không được phép nằm trong hàm khác => "error: function definition is not allowed here".
NDK 2021 chưa có hàm inline nên Dobby chạy được lúc đó. Cách vá: đưa #include lên phạm vi tệp; giữ nguyên hành vi.
  python3 scripts/patch_dobby.py <thu-muc-ma-nguon-dobby>
"""
import os
import sys

HEAD = '#include "logging/logging.h"\n'
FILE_INC = '#if defined(__ANDROID__)\n#include <android/log.h>\n#endif\n'
INNER = '#define ANDROID_LOG_TAG "Dobby"\n#include <android/log.h>\n'
INNER_FIXED = '#define ANDROID_LOG_TAG "Dobby"\n'


def patch(src):
    """Trả về nội dung đã vá; chạy lại trên bản đã vá thì không đổi; không đúng dạng đã biết thì báo lỗi rõ."""
    if FILE_INC in src and INNER not in src:
        return src
    if INNER not in src or HEAD not in src:
        raise SystemExit("ERROR: external/logging/logging.c không còn đúng dạng của Dobby 223aabc (đã đổi SHA?)")
    return src.replace(INNER, INNER_FIXED, 1).replace(HEAD, HEAD + FILE_INC, 1)


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else sys.exit("usage: patch_dobby.py <dobby-src>")
    p = os.path.join(root, "external/logging/logging.c")
    s = open(p, encoding="utf-8").read()
    new = patch(s)
    if new != s:
        open(p, "w", encoding="utf-8").write(new)
        print("Đã vá external/logging/logging.c (include android/log.h lên phạm vi tệp)")
    else:
        print("logging.c đã được vá sẵn")


if __name__ == "__main__":
    main()
