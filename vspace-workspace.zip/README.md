# VSpace Workspace

Ứng dụng "không gian ảo" cho Android: cài APK khác vào bên trong, chạy chúng **cô lập**, và có
chế độ **giữ app ảo chạy nền khi tắt màn hình** (kể cả app không được thiết kế để chạy nền).

- Lõi ảo hóa: [ALEX5402/NewBlackbox](https://github.com/ALEX5402/NewBlackbox) (Apache-2.0, Android 5–15, không cần root)
- Phần của repo này: giao diện quản lý app, foreground service giữ nền, ghim tiến trình app ảo,
  trợ giúp miễn trừ pin / tự khởi động theo hãng, và workflow GitHub Actions để build APK.

> **Tiếp tục dự án / bàn giao:** đọc [`docs/PROJECT_HANDOFF.md`](docs/PROJECT_HANDOFF.md) — trạng thái thật, việc tồn đọng có ưu tiên,
> kỹ thuật đã loại, kế hoạch kiểm chứng trên máy. **Hiện chưa có bản build/chạy thử nào** (chi tiết ở tài liệu đó).
> Trong app có nút **Chẩn đoán** để lấy báo cáo đo thật (importance từng tiến trình app ảo, API thật của core).

## Chế độ game (mới)

Game chạy logic theo khung hình nên **tắt màn hình thật là game đứng dù tiến trình còn sống**. Vì vậy có hai chế độ cho từng game
(menu giữ lâu trên app → *Chế độ game…*):

- **Màn hình đen**: phủ overlay đen + giữ màn hình bật (cần quyền *Hiển thị trên các ứng dụng khác*). Game vẫn nhận VSync nên vẫn chạy logic.
  Panel OLED tiết kiệm rõ; GPU/CPU vẫn chạy nên vẫn tốn pin và nóng máy. Thoát: chạm 3 lần góc trên-phải, hoặc nút trong thông báo.
- **Tắt màn hình thật**: chỉ giữ tiến trình (hợp app có kết nối hoặc game tính phía server).

Kèm theo: tự dừng theo giờ/pin/nhiệt, tắt tiếng có khôi phục, phát hiện game đứng (CPU ≈ 0), cảnh báo tiến trình bị kill, báo cáo phiên,
hẹn giờ hằng ngày, watchdog, 3 "không gian" để chơi nhiều tài khoản, cảnh báo trước khi cài game có anti-cheat.
Workspace **không thêm** tính năng che giấu môi trường ảo hay giả mạo ID thiết bị (và sẽ không thêm: đó là lách kiểm soát của game/ngân hàng). **Nhưng lõi NewBlackbox mà Workspace dùng đã tự giả mạo thuộc tính thiết bị** (model/fingerprint/serial "Pixel 6", cờ qemu) cho mọi app ảo ngay khi nạp thư viện native — đọc từ source thật, xem `PROJECT_HANDOFF.md` mục O-11. Mặc định giữ nguyên hành vi của lõi; muốn gỡ: chạy workflow với `strip_core_spoof` = true (hoặc `VSPACE_STRIP_CORE_SPOOF=1 bash scripts/overlay.sh <core>`).

App thử `testguest` (artifact `testguest.apk` trong CI) giả lập game theo khung hình để **đo** thay vì đoán: xem `docs/PROJECT_HANDOFF.md` mục 16.

## Kiểm tra và công cụ

- `python3 scripts/compile_check.py`: biên dịch THẬT toàn bộ mã Java bằng `javac` với stub Android (không cần Android SDK) và chạy test đơn vị.
- `python3 scripts/check.py`: kiểm tĩnh toàn dự án (kèm biên dịch ở trên) (XML, chuỗi vi/en, id layout, số tham số mọi lời gọi giữa các lớp, manifest, workflow, overlay). Chạy trong CI trước khi build.
- `python3 scripts/apk_report.py <apk>`: dung lượng + kiểm thư viện native có căn 16 KB không.
- Trong app: **Chẩn đoán** (importance, CPU, lý do tiến trình thoát, vị trí dữ liệu engine) → **Chia sẻ** để gửi kèm nhật ký.
- Test đơn vị: `./gradlew :workspace:testDebugUnitTest`.
- Mở APK từ trình quản lý file, hoặc chọn nhiều APK cùng lúc, đều cài vào workspace được; mỗi lần cài có hộp xem trước chữ ký/quyền.

## Mới: hook app ảo, chế độ mờ, PiP, sao lưu

- Lõi có `AppLifecycleCallback`; `scripts/gen_guest_hooks.py` đọc source thật của lõi lúc build để sinh lớp callback tương ứng, nên biết chính xác game nào chạy ở tiến trình `:pN` nào.
- **Màn hình mờ**: giữ màn hình bật + độ sáng thấp nhất ngay trên cửa sổ game, **không cần quyền overlay**.
- **PiP** (thử nghiệm): thu nhỏ game vào cửa sổ nổi.
- **Sao lưu/khôi phục dữ liệu game** + tự sao lưu ra thư mục bạn chọn. Dữ liệu app ảo nằm ở `<dữ liệu app>/blackbox` (anh em với thư mục cache, **không** nằm trong cache — đọc từ source thật ở phiên 5), nên "Xóa bộ nhớ đệm" không xóa nó, nhưng **"Xóa dữ liệu" của Workspace thì xóa sạch** mọi app ảo.

## Tắt hẳn panel mà game vẫn chạy (nâng cao)

Game dừng khi máy NGỦ, nhưng vẫn chạy nếu chỉ tắt PANEL còn Android thức (kỹ thuật `scrcpy --turn-screen-off`). `ScreenPower` làm việc đó và chạy bằng quyền shell:
trong hồ sơ game bấm **"Tắt hẳn panel màn hình"** để lấy đúng lệnh ADB cho APK của bạn (cần Gỡ lỗi không dây hoặc USB). Nên chọn chế độ "Màn hình mờ" trước. Chưa kiểm chứng trên máy thật.

## Phiên 4: kiểm tra máy, hướng dẫn hãng, thống kê, widget, công cụ đo

Tất cả mới chỉ biên dịch được và có test hàm thuần; **chưa chạy trên máy thật** (chi tiết và giả định ở `docs/PROJECT_HANDOFF.md` mục 18).

- **Kiểm tra trước khi chạy nền**: trước khi bắt đầu phiên game, app cảnh báo nếu chưa miễn trừ pin, nhóm chờ (App Standby) quá thấp, Tiết kiệm dữ liệu đang bật, máy nóng, RAM thấp, pin sắp tới ngưỡng, thiếu quyền overlay/thông báo. Chỉ cảnh báo, bạn quyết định.
- **Hướng dẫn theo hãng** (Xiaomi, Huawei/Honor, Oppo/Realme, OnePlus, Vivo, Samsung, Asus, Nokia, Meizu) và nhắc cấp lại miễn trừ pin sau khi hệ thống cập nhật.
- **Thống kê từng game**: thời gian chạy nền, **pin tụt mỗi giờ thật**, nhiệt cao nhất, số lần bị dừng/tự mở lại. Nhắc khi một phiên chạy hơn 12 giờ.
- **Tinh chỉnh trong game** (đều tắt/bật được): nâng ưu tiên luồng game, gợi ý 30 Hz cho cả Surface của game, giảm độ phân giải render (thử nghiệm), ghim chọn lọc theo game, tự mở lại game khi tiến trình biến mất.
- **Tài nguyên**: RAM (PSS) và CPU từng tiến trình, gắn với game nào. Widget màn hình chính cho trạng thái chạy nền. Màn hình Cài đặt (nhật ký, kiểm máy, hướng dẫn hãng). Danh sách có sắp xếp, lọc "đang chạy".
- **Cập nhật app ảo giữ dữ liệu**: sao lưu trước, cài đè, nếu dữ liệu mất thì tự khôi phục.
- **Gói XAPK/APKS**: nếu gói có split (`config.*`, `split_*`), app ghép thành một APK bằng APKEditor 1.4.9 (CI tải và kiểm sha256) **rồi ký lại bằng khóa riêng sinh trên máy** (`ApkSigner`, chữ ký APK Scheme v2). Bước ký là bắt buộc: lõi gọi `collectCertificates()` khi cài nên APK ghép chưa ký bị từ chối (đọc từ source thật, phiên 7). Chuỗi ghép + ký đã được `apksigner` AOSP thật xác minh trên JVM; **chưa chạy trên máy thật**. Gói có OBB thì chép vào thư mục OBB ảo sau khi cài (đích đã đọc từ source thật ở phiên 5).
- **Emulator trong CI**: job `emulator-smoke` (cài APK arm64 trên emulator x86_64 API 30, mở, chờ, kiểm không crash) chỉ mang tính tham khảo vì cần lớp dịch ARM; lõi không có ABI x86 nên không có chặng x86. Chạy tay: `bash scripts/emulator_smoke.sh duong-dan.apk`.
- **Đo thay vì đoán**: `python3 scripts/measure_background.py run --label ... --minutes 30` (cần adb + testguest đang mở) cho kết luận RUNS / FRAME-LOOP-STOPPED / FROZEN / KILLED; `... isolation` kiểm hai không gian có dùng chung dữ liệu không; `... analyze log.txt` phân tích log có sẵn.
- **Gỡ có hoàn tác / thùng rác**: gỡ app hoặc xóa dữ liệu thì Workspace tạo bản sao an toàn (dữ liệu dưới 1,5 GB; giữ tối đa 3 bản / 14 ngày) và hiện thanh *Hoàn tác*; khôi phục sau từ Cài đặt → Thùng rác.
- **Chi tiết + Quyền từng app**: cho biết quyền nhạy cảm nào đã cấp / xin được ngay / *không xin được vì Workspace không khai báo*. Android 11+: nếu app cần bộ nhớ chung mà thiếu "Truy cập mọi tệp", hỏi trước khi mở (lõi chỉ ghi cảnh báo rồi vẫn mở).
- **Không gian ảo**: cài/gỡ Google services vào từng không gian (lõi *sao chép* gói Google đã cài trên máy, không tải gì; chưa kiểm chứng) và xóa cả không gian.
- **Cập nhật trong app**: nút *Kiểm tra cập nhật* hỏi GitHub Releases của chính kho này (build truyền `-PupdateRepo=owner/repo`; trống thì tính năng tắt). Chỉ HTTPS, chỉ host GitHub, kiểm sha256 trước khi cài; tự kiểm mỗi ngày là tùy chọn **mặc định tắt**; không gửi bất cứ dữ liệu người dùng nào.
- **Kiểm chứng bằng công cụ thật**: `python3 scripts/verify_real.py --fetch` (javac với `android.jar` API 35 + source thật của lõi, `aapt`, `apksigner`, APKEditor, `actionlint`).
- **Danh sách app ảo bằng RecyclerView + vuốt để thao tác** (phiên 8): vuốt phải = mở app, vuốt trái = menu (như chạm giữ). AndroidX không tải được vào sandbox để biên dịch thử (mọi mirror tìm được đều ngoài allowlist mạng) nên phần này được kiểm bằng stub thủ công đối chiếu tài liệu chính thức (`scripts/stubs/androidx_api.spec`, có kiểm đột biến) — xem `docs/PROJECT_HANDOFF.md` mục 20. **Chưa nhìn bằng mắt trên máy thật.**
- **Mã hóa file sao lưu khi xuất ra ngoài** (phiên 8): khi sao lưu qua *Sao lưu* (không phải Thùng rác, vẫn nằm trong máy), Workspace hỏi có mã hóa bằng khóa riêng trong AndroidKeyStore không — chỉ máy này mở lại được. Giải quyết đúng một vấn đề: file rời khỏi bộ nhớ riêng của app thì ai có file cũng đọc được dữ liệu guest bên trong; **không** phải là cách ly giữa các app ảo (vẫn chung UID host, xem O-11/phiên 7).

## Cấu trúc

```
.github/workflows/build.yml   CI: clone NewBlackbox, ghép module, build APK 64-bit + 32-bit
scripts/overlay.sh            chép module vào repo lõi, đăng ký settings.gradle, tự sửa import
workspace/                    module Android (Java, không phụ thuộc thư viện ngoài ngoài lõi)
testguest/                    app thử giả lập game theo khung hình (đo chế độ chạy nền)
  └─ src/main/java/dev/vspace/workspace/
       SpaceApp          khởi tạo engine (chạy ở cả tiến trình chính lẫn :pN)
       Engine            lớp bọc DUY NHẤT gọi vào BlackBox
       MainActivity      thêm APK / nhân bản app đã cài / mở / dừng / gỡ
       KeepAliveService  foreground service + wakelock + wifilock
       ProcessPinner     bind vào tiến trình :pN của app ảo để không bị coi là "cached"
       Diagnostics       báo cáo chẩn đoán để kiểm chứng trên máy thật
       GameModeController/GameOverlay/GameActivity/Scheduler/CpuSampler/Notifier  chế độ game
       ApkImporter/RiskList  kiểm tra + xem trước APK trước khi cài, cảnh báo anti-cheat
       LogBuffer/ExitReasons/ShareProvider  nhật ký, lý do tiến trình thoát, chia sẻ báo cáo
       SetupActivity/ShortcutActivity  thiết lập lần đầu, phím tắt
       PowerHelper       xin miễn trừ pin, mở trang tự khởi động Xiaomi/Oppo/Vivo/Huawei/Samsung...
       BootReceiver      bật lại giữ nền sau khi khởi động máy
       Preflight/OemGuide/SessionStats/GuestMonitor/UpdateKeeper  kiểm máy, hướng dẫn hãng, thống kê, tài nguyên, cập nhật giữ dữ liệu
       DisplayTuning/ThreadBoost/AppSort/StatusWidget/SettingsActivity  tần số quét/độ phân giải, ưu tiên luồng, sắp xếp, widget, cài đặt
scripts/measure_background.py   đo giữ nền bằng adb (run / analyze / isolation), có test
```

## Build trên GitHub

1. Tạo repo mới, đẩy toàn bộ thư mục này lên nhánh `main`.
2. Vào tab **Actions** → workflow *Build VSpace Workspace* tự chạy (hoặc bấm *Run workflow*).
3. Tải APK ở mục **Artifacts**: `workspace-arm64-v8a-Debug` (đa số máy hiện nay) và
   `workspace-armeabi-v7a-Debug` (bản 32-bit, dùng khi app muốn cài chỉ có lib armv7).
4. Đẩy tag `v1.1.0` để tự tạo GitHub Release (bản Release, kèm ghi chú tự sinh) và APK. `versionCode` lấy từ số lần chạy CI.
5. **Ký phát hành thật (khuyến nghị trước khi đưa cho người khác):** tạo keystore rồi đặt 4 GitHub Secrets `VSPACE_KEYSTORE_BASE64` (`base64 -w0 release.jks`), `VSPACE_KEYSTORE_PASSWORD`, `VSPACE_KEY_ALIAS`, `VSPACE_KEY_PASSWORD`. Thiếu secrets thì APK vẫn ký bằng debug key (CI sẽ cảnh báo): chỉ để cài thử, không phát hành. Giữ keystore cẩn thận: mất khóa là không cập nhật đè được.

Tuỳ chọn khi *Run workflow*: `core_ref` (ghim commit của NewBlackbox; mặc định đã ghim `89b59836c6…`, SHA đã đọc source), `strip_core_spoof` (gỡ `VirtualSpoof.cpp`/`AntiDetection.cpp` khỏi lõi, O-11).

**APKEditor (ghép split):** workflow tải đúng `V1.4.9` và kiểm sha256 `a9cd40df818845456be6d696de6110c89edf4b0a0580cb83438ed6b25a366e67` (đã đối chiếu độc lập ở phiên 5 và 7). Muốn đổi phiên bản, sửa `APKEDITOR_URL`/`APKEDITOR_SHA256` trong `.github/workflows/build.yml` và chạy lại `scripts/verify_real.py`.
Build local: clone NewBlackbox, `bash scripts/overlay.sh <core> workspace`, rồi
`cd <core> && ./gradlew :workspace:assembleDebug -Pabi=arm64-v8a -PupdateRepo=owner/repo` (**JDK 21** — lõi biên dịch ở Java 21, JDK 17 sẽ vỡ; SDK 35; NDK 29.0.13846066 do AGP tự tải).

> `targetSdk` mặc định là 28 vì BlackBox khuyến nghị để tương thích tốt nhất. Đổi bằng `-PtargetSdk=34`
> (khi đó cần cấp quyền thông báo, và hệ thống áp quy tắc foreground-service nghiêm hơn).

## Cách giữ app chạy nền hoạt động

App ảo chạy trong tiến trình `:p0…:p49` của chính app này (chung UID). Khi tắt màn hình, activity của app ảo
bị stop và tiến trình của nó trở thành "cached" → bị kill sớm nhất, hoặc bị đóng băng (Android 11+).
Workspace xử lý theo 4 lớp:

1. **Foreground service** có thông báo cố định → cả UID không bị coi là idle/background.
2. **PARTIAL_WAKE_LOCK + WifiLock** → CPU và Wi-Fi không ngủ khi tắt màn hình (tự gia hạn 5 phút/lần).
3. **ProcessPinner** → mỗi 15 giây quét các tiến trình `:pN` đang chạy và bind (`BIND_IMPORTANT`) vào service stub
   của nó từ tiến trình foreground → các tiến trình app ảo được nâng mức ưu tiên, không còn là cached.
4. **Miễn trừ tối ưu pin + tự khởi động** (nút trong app) → thoát Doze/App Standby và bộ diệt app của hãng.

Thứ tự khuyến nghị lần đầu: bật công tắc "Giữ app chạy nền" → *Cho phép* ở hộp thoại pin → bấm *Tự khởi động*
và đặt pin "Không hạn chế" → mở app ảo cần chạy.

## Giới hạn (nói thẳng)

- **App ảo vẫn bị `onPause/onStop` khi tắt màn hình.** Chúng ta giữ *tiến trình* sống, không ép code của app ảo chạy.
  App tự dừng việc trong `onStop` (trình phát video, game…) sẽ vẫn tạm dừng. App có service/thread/socket
  (chat, tải xuống, bot, VPN…) thì tiếp tục chạy.
- Một số ROM (Xiaomi/Huawei/Oppo/Vivo) vẫn kill mạnh tay bất chấp mọi cách; cần bật hết tuỳ chọn của hãng và khoá app ở màn hình đa nhiệm.
- Sau khi khởi động lại máy, app ảo **không tự mở** (Android chặn mở activity từ nền). Dịch vụ giữ nền tự bật, bạn mở lại app ảo 1 lần.
- Gói split/XAPK/APKS được ghép thành 1 APK và ký lại bằng khóa riêng của máy: chữ ký **khác bản gốc**, nên app tự kiểm chữ ký, đăng nhập Google, Maps, Billing, Firebase sẽ không chạy. App dùng anti-tamper, DRM hoặc đăng nhập ngân hàng thường không chạy được trong môi trường ảo.
- Foreground service + wakelock làm tốn pin hơn bình thường.
- Mọi app ảo dùng chung quyền của host: thêm quyền cần thiết vào `AndroidManifest.xml` và cấp qua nút *Quyền*.

## Nếu CI báo lỗi

| Lỗi | Cách xử lý |
|---|---|
| `Cannot find symbol` ở `Engine.java` | Fork core đổi tên hàm. Sửa trong `Engine.java` (file duy nhất gọi vào core), xem `BlackBoxCore.java` của core. |
| `Không tìm thấy module lõi ':Bcore'` | Xem `settings.gradle` của core, sửa tên module trong `workspace/build.gradle`. |
| NDK / CMake không tìm thấy | Mở `Bcore/build.gradle` xem `ndkVersion`, đổi số trong bước *Install NDK* của workflow. |
| Manifest merger conflict | Thêm thuộc tính bị báo vào `tools:replace` của thẻ `<application>`. |
| APK 32-bit crash khi mở | Core có thể không build lib armv7 ở bản bạn ghim; chỉ dùng APK arm64. |

## Giấy phép

Phần mã của repo này: chọn giấy phép tuỳ bạn (thêm file `LICENSE`).
NewBlackbox theo Apache-2.0; hãy giữ nguyên thông báo bản quyền của họ khi phân phối APK.


## Công cụ kiểm chứng cần mạng GitHub (phiên 11)
- `python3 scripts/verify_real.py --fetch`: javac/aapt/apksigner/APKEditor/actionlint thật + kiểm O-17 trên lõi thật.
- `python3 scripts/net_check.py`: chạy `UpdateChecker` thật với GitHub thật (không nằm trong CI).
- `python3 scripts/pin_actions.py --check|--apply|--verify`: ghim GitHub Action theo SHA.
- Công tắc build: `strip_core_spoof` (O-11), `harden_exports` (O-17, mặc định tắt, chưa thử máy thật).
- `bash scripts/ship.sh <owner/repo> [--harden] [--strip-spoof]`: đẩy mã lên GitHub, chạy CI build APK thật + emulator-smoke, tải kết quả về `ci-out/` (cần `gh auth login`).
- `scripts/emulator_install_check.sh` và `scripts/emulator_screenpower_check.sh`: kiểm bằng emulator trong CI (job `emulator-smoke`, API 30 và 34); chưa chạy lần nào.
- `python3 scripts/device_suite.py --apk-dir ci-out`: chạy P0-3…P0-11 trên điện thoại thật bằng một lệnh, ghi `REPORT.md` (hướng dẫn: `docs/DEVICE_GUIDE.md`).
- `scripts/build_dobby.sh <core> x86_64` + `VSPACE_X86_64=1` + job CI `x86-engine-test`: build engine x86_64 (thử nghiệm) để chạy `device_suite.py` trên emulator có KVM; xem handoff mục 23.9.
- `scripts/ci_run.sh`, `scripts/ci_annotate.py`, `scripts/emulator_ci.sh`: đưa lý do lỗi của CI ra Annotations (công khai, đọc được không cần đăng nhập).
