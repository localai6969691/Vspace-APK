<!--
Trước khi mở PR, chạy ở máy bạn (không cần Android SDK cho 2 lệnh đầu):
  python3 scripts/check.py           # kiểm tĩnh + biên dịch thật (android.jar) + test JVM + api_audit
  python3 scripts/verify_real.py     # aapt/apksigner/APKEditor/actionlint (cần apt install aapt apksigner shellcheck)
Dán kết quả 2 lệnh đó vào mục "Đã kiểm" bên dưới — PR không chạy lại 2 lệnh này tự động (job `checks` của CI thì có).
-->

## Làm gì, vì sao

<!-- 1-3 câu. Nếu sửa lỗi: lỗi là gì, do đâu. Nếu thêm tính năng: liên kết tới mục nào trong docs/PROJECT_HANDOFF.md
     (P0-x / P1-x / O-x) nếu có, vì mọi tính năng mới nên có chỗ đứng trong tài liệu đó. -->

## Mức kiểm chứng (xem chú giải [V]/[S]/[?] ở đầu docs/PROJECT_HANDOFF.md)

- [ ] **[V]** Đã chạy thật bằng công cụ thật trong PR này (`verify_real.py`, test JVM, hoặc cài trên thiết bị — ghi rõ cái nào)
- [ ] **[S]** Chỉ đọc source/so khớp chữ ký, chưa chạy
- [ ] **[?]** Giả định chưa kiểm chứng — PHẢI ghi thành dòng `G-xx` mới trong `docs/PROJECT_HANDOFF.md` nếu PR được merge

## Đã kiểm

```
(dán output của check.py)
```

```
(dán output của verify_real.py, hoặc ghi "bỏ qua vì <lý do>" — KHÔNG để trống nếu PR đụng tới
 .github/workflows, build.gradle, AndroidManifest.xml, hoặc bất kỳ file res/)
```

## Có cần cập nhật `docs/PROJECT_HANDOFF.md` không?

- [ ] Không cần (không đổi hành vi, không phải tính năng mới, không phải phát hiện mới về lõi)
- [ ] Có, đã cập nhật: mục nào — <!-- ví dụ: "P1-9, đổi từ [?] sang [V]" -->

## Việc KHÔNG làm trong PR này (nếu có)

<!-- Nếu PR này cố ý không làm một phần của yêu cầu ban đầu, ghi lý do ở đây — đừng để người review phải đoán.
     Nếu lý do là "lách cơ chế chống gian lận/bảo mật" (giả mạo ID, che overlay...) thì đó là quyết định không đổi,
     không phải việc cần bàn thêm — xem AGENTS.md #9. -->
