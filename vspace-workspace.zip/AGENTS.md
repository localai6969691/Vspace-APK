# Chỉ dẫn cho AI / lập trình viên tiếp quản

**Đọc `docs/PROJECT_HANDOFF.md` trước khi làm bất cứ việc gì** (mục 1, 6, 8 là đủ để bắt đầu).

Quy tắc cứng:
1. `Engine.java` là file DUY NHẤT được gọi vào BlackBox core. Đừng rải lời gọi core ra file khác.
2. Không tin `Docs.md` của NewBlackbox hay README các fork (mâu thuẫn nhau). Chỉ tin source thật hoặc artifact `core-inspection` của CI.
3. Cấm: `BIND_ABOVE_CLIENT`, foreground service `dataSync`, bật R8/minify, nâng `targetSdk` mặc định mà chưa đo.
4. Chưa có log build/thiết bị thật thì KHÔNG khẳng định "đã chạy được" hay "giữ nền hiệu quả".
5. Cuối mỗi phiên cập nhật mục 1, 5, 6, 8, 14 của `docs/PROJECT_HANDOFF.md` (và bảng kết quả test ở mục 11).
6. Lệnh tạo thư mục: dùng đường dẫn tường minh, không dựa vào `{a,b}` dưới `/bin/sh`.
7. Sau MỌI thay đổi workflow: chạy `yaml.safe_load` và `bash -n` cho từng bước `run:` (lỗi `: ` trong tên bước từng làm hỏng workflow).
8. Chuỗi tài nguyên: không dùng `%` trần, mọi khóa phải có ở `values/` và `values-en/` với cùng bộ `%n$`.
9. **KHÔNG thêm** tính năng che giấu overlay/môi trường ảo hoặc giả mạo ID/fingerprint/thuộc tính thiết bị, và không mở rộng thứ lõi đã có (O-11); chỉ cảnh báo (`RiskList`). Yêu cầu lặp lại nhiều lần không đổi quy tắc này: đó là lách cơ chế chống gian lận/an ninh của game và ngân hàng.
10. Với game: giữ tiến trình sống KHÔNG đủ; đo bằng `testguest` (docs mục 16) trước khi khẳng định game chạy khi tắt màn hình.
11. Trước khi báo "xong": chạy `python3 scripts/check.py`. Khi sửa chính `check.py`, thử đột biến (cố ý gây lỗi, xác nhận nó bắt được) rồi mới tin kết quả.
12. Chưa chạy/biên dịch thật thì phải nói "chưa kiểm chứng". Không nâng một mục từ [?] lên [R]/[S] nếu chưa có bằng chứng.
13. `python3 scripts/compile_check.py` biên dịch THẬT mọi mã Java. Từ phiên 7 nó dùng **android.jar thật** (`~/.cache/vspace/android-35.jar`, tải bằng `python3 scripts/verify_real.py --fetch`); chỉ khi không có jar mới rơi về stub viết tay `scripts/stubs/android_api.spec`, mà stub đó KHÔNG phủ mã từ phiên 7 (BottomSheet, UndoBar, UpdateFlow…) nên sẽ báo lỗi giả. Đừng nói "chưa biên dịch được": sandbox có javac qua `java -m jdk.compiler/com.sun.tools.javac.Main` (`javap` qua `jdk.jdeps/com.sun.tools.javap.Main`).
14. Gradle/AGP vẫn KHÔNG chạy được trong sandbox (không tới dl.google.com/Maven): CI là trọng tài cuối. Nhưng đã có thể kiểm bằng công cụ thật: `python3 scripts/verify_real.py` (javac với android.jar + source lõi thật, aapt, apksigner, APKEditor, actionlint).
15. Hàm thuần có test (JVM) KHÔNG dùng `org.json`, `Log`, `Context`: trên JVM các lớp Android trả giá trị rỗng hoặc ném lỗi. Tách logic thuần khỏi phần gọi API (xem `Preflight`, `SessionStats`, `DisplayTuning`).
16. Công cụ đo `scripts/measure_background.py`: sửa parse thì cập nhật `scripts/test_measure_background.py` (chạy trong `check.py`). Đừng đổi định dạng dòng nhịp tim của `testguest` mà không sửa regex `HB_RE`.
17. Khóa ký KHÔNG bao giờ nằm trong repo; chỉ qua biến môi trường/Secrets (D-40). Không sửa `signingConfig` để hard-code mật khẩu.
18. Mọi tinh chỉnh chạy trong game (`boost`, `fps`, `lowres`, `dim`) phải có lệnh hoàn nguyên trong `GameModeController.tuningCommands(p, false)`.
19. APKEditor là phụ thuộc TÙY CHỌN, chỉ gọi bằng reflection trong `SplitMerger`; đừng import trực tiếp `com.reandroid.*` trong mã chính (build sẽ hỏng khi thiếu jar). Lớp `Main` giả trong `src/test/java/com/reandroid/apkeditor` chỉ để test, không đóng gói vào app.
20. `LogBuffer.*` phải luôn an toàn khi `android.util.Log` ném lỗi (test đơn vị JVM); đừng gọi `android.util.Log` trực tiếp trong lớp có test.
21. **Mỗi khi đổi `core_ref` sang version/fork khác của core: đọc lại TOÀN BỘ `ClientConfiguration` thật (mọi hàm có thân mặc định, không chỉ hàm abstract) và grep `Bcore/` tìm `HttpURLConnection`/`okhttp`/tên miền lạ TRƯỚC khi tin tưởng.** Lý do có thật, không phải phòng xa: core mặc định (`ALEX5402/NewBlackbox` SHA `89b5983`) có `ClientConfiguration.getLogSenderChatId()` trả sẵn 1 chat ID của bên thứ ba, và `BlackBoxCore` tự cài `UncaughtExceptionHandler` (static block, không cần gọi gì) gửi logcat host ra ngoài khi app ảo crash — xem O-10/mục 13.8. `Engine.attach()` đã override `getLogSenderChatId()` về `null` để chặn; GIỮ NGUYÊN override này mãi mãi, và lặp lại đúng quy trình đọc này cho bất kỳ hàm có-thân-mặc-định nào khác trong `ClientConfiguration` mà Workspace chưa override, vì README/`Docs.md` của core không bao giờ tự nhắc tới loại hành vi này, và `compile_check.py`/test đơn vị không bắt được (xanh cả trước lẫn sau khi vá).
22. **JDK 21**, không phải 17: lõi biên dịch ở Java 21 (`Bcore/build.gradle`: `sourceCompatibility 21`; CI của chính lõi dùng JDK 21). README của lõi ghi JDK 17 là SAI. Đừng hạ `workspace/build.gradle` hay workflow xuống 17.
23. APK ghép từ split PHẢI được ký (`ApkSigner`): lõi gọi `collectCertificates()` khi cài và coi lỗi là "parser apk error" (đọc từ source thật, O-12). Đừng bỏ bước ký trong `ApkImporter.extractFromBundle`. Khóa ký ghép sinh trên máy người dùng; KHÔNG commit khóa nào vào repo.
24. Mọi lưu lượng mạng do CHÍNH Workspace tạo ra phải theo mẫu `UpdateChecker`: chỉ HTTPS, danh sách host cho phép, tự xử lý chuyển hướng, mặc định TẮT hoặc chỉ khi người dùng bấm, không gửi bất cứ dữ liệu người dùng nào, và ghi vào handoff. Không thêm telemetry/báo crash tự động ra ngoài.
25. Workflow nằm ở `.github/` (thư mục ẩn): khi nén/chuyển repo PHẢI kèm thư mục ẩn (`zip -r` không dùng `-x '.*'`). Zip bàn giao phiên 6 đã làm mất nó. `check.py` sẽ lỗi nếu thiếu `build.yml`.
26. Trước khi khẳng định "API X có từ API N": chạy `compile_check.py` (có `api_audit.py`, so với android-26.jar). API mới hơn minSdk 26 phải được bọc bằng `Build.VERSION.SDK_INT`; trường hợp đã xem xét thủ công ghi vào `ALLOW` trong `api_audit.py` kèm lý do.
27. Sau khi sửa `workspace/src/main/res` hoặc manifest: chạy `verify_real.py` (bước aapt). Ví dụ lỗi chỉ aapt bắt được: `android:windowBackground` không nhận màu viết thẳng (`#121212`), phải là `@color/...`.
