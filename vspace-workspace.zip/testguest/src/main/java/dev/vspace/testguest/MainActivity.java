package dev.vspace.testguest;

import android.app.Activity;
import android.app.Application;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Choreographer;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/**
 * Mô phỏng hai kiểu "game":
 *  - game client-side: logic cộng dồn trong Choreographer.FrameCallback (chỉ chạy khi có VSync, tức khi activity hiển thị);
 *  - game server-side/ứng dụng có kết nối: một luồng nền đếm mỗi giây, không phụ thuộc màn hình.
 * Mọi mốc được ghi vào Logcat (tag VSpaceTestGuest) và filesDir/heartbeat.log.
 *
 * Cách đọc kết quả sau một thời gian tắt màn hình:
 *   wall ≈ worker, game << wall  => tiến trình sống nhưng logic theo khung hình đã đứng (cần chế độ "Màn hình đen").
 *   wall ≈ worker ≈ game         => cả hai chạy bình thường.
 *   worker << wall               => tiến trình bị đóng băng/CPU bị tước.
 */
public class MainActivity extends Activity implements Choreographer.FrameCallback {
    private static final String TAG = "VSpaceTestGuest";

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat fmt = new SimpleDateFormat("HH:mm:ss", Locale.US);

    private TextView tv;
    private File logFile;
    private long startReal;
    private long frames;
    private long gameMs;
    private long lastFrameNs;
    private volatile long workerTicks;
    private volatile boolean running = true;
    private int resumes;
    private int pauses;
    private long pausedAt;
    private long pausedTotalMs;

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            tv.setText(render());
            ui.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        tv = new TextView(this);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(12);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        tv.setPadding(pad, pad, pad, pad);
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        setContentView(sv);

        startReal = SystemClock.elapsedRealtime();
        logFile = new File(getFilesDir(), "heartbeat.log");
        logLine("create");
        logIdent();

        Thread w = new Thread(new Runnable() {
            @Override
            public void run() {
                long next = SystemClock.elapsedRealtime() + 1000;
                while (running) {
                    try {
                        Thread.sleep(Math.max(1, next - SystemClock.elapsedRealtime()));
                    } catch (InterruptedException e) {
                        return;
                    }
                    next += 1000;
                    workerTicks++;
                    if (workerTicks % 10 == 0) logLine("worker");
                }
            }
        }, "vspace-worker");
        w.setDaemon(true);
        w.start();

        Choreographer.getInstance().postFrameCallback(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumes++;
        if (pausedAt > 0) {
            pausedTotalMs += SystemClock.elapsedRealtime() - pausedAt;
            pausedAt = 0;
        }
        logLine("resume");
        ui.post(refresh);
    }

    @Override
    protected void onPause() {
        pauses++;
        pausedAt = SystemClock.elapsedRealtime();
        logLine("pause");
        ui.removeCallbacks(refresh);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        running = false;
        Choreographer.getInstance().removeFrameCallback(this);
        super.onDestroy();
    }

    /** "Game loop" theo khung hình: mỗi VSync cộng dt (chặn tối đa 100 ms như phần lớn game engine). */
    @Override
    public void doFrame(long frameTimeNanos) {
        frames++;
        if (lastFrameNs != 0) {
            long dtMs = (frameTimeNanos - lastFrameNs) / 1_000_000L;
            gameMs += Math.min(dtMs, 100);
        }
        lastFrameNs = frameTimeNanos;
        if (frames % 600 == 0) logLine("frames");
        Choreographer.getInstance().postFrameCallback(this);
    }

    private String render() {
        long now = SystemClock.elapsedRealtime();
        double wall = (now - startReal) / 1000.0;
        double game = gameMs / 1000.0;
        long paused = pausedTotalMs + (pausedAt > 0 ? now - pausedAt : 0);
        String proc = Build.VERSION.SDK_INT >= 28 ? Application.getProcessName() : "?";
        String fingerprint = Build.FINGERPRINT;
        StringBuilder sb = new StringBuilder();
        sb.append("VSpace TestGuest\n");
        sb.append(String.format(Locale.US, "uid=%d pid=%d%nprocess=%s%n", Process.myUid(), Process.myPid(), proc));
        sb.append("androidId=").append(Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID)).append('\n');
        sb.append("fingerprint=").append(fingerprint).append('\n');
        sb.append("filesDir=").append(getFilesDir()).append("\n\n");
        sb.append(String.format(Locale.US, "wall (dong ho that)      : %9.1f s%n", wall));
        sb.append(String.format(Locale.US, "worker (thread 1 Hz)     : %9d tick%n", workerTicks));
        sb.append(String.format(Locale.US, "game (theo khung hinh)   : %9.1f s%n", game));
        sb.append(String.format(Locale.US, "frames                   : %9d%n", frames));
        sb.append(String.format(Locale.US, "chenh lech wall - game   : %9.1f s%n%n", wall - game));
        sb.append(String.format(Locale.US, "resume x%d, pause x%d, tong thoi gian pause %.1f s%n%n",
                resumes, pauses, paused / 1000.0));
        sb.append("Doc ket qua:\n");
        sb.append(" wall ~ worker, game << wall => tien trinh song nhung logic khung hinh dung\n");
        sb.append(" worker << wall              => tien trinh bi dong bang / het CPU\n");
        sb.append(" tat ca ~ bang nhau          => chay binh thuong\n");
        sb.append("Log: logcat -s VSpaceTestGuest  hoac file heartbeat.log\n");
        return sb.toString();
    }

    /**
     * Dòng định danh để script đo (scripts/measure_background.py isolation) so sánh hai không gian:
     * cùng filesDir/token nghĩa là dữ liệu bị DÙNG CHUNG (engine không cô lập). token là chuỗi ngẫu nhiên tạo lần đầu trong filesDir.
     * Dòng này chỉ thêm định danh, không đổi định dạng dòng nhịp tim.
     */
    private void logIdent() {
        String token = "?";
        try {
            File f = new File(getFilesDir(), "token.txt");
            if (f.isFile()) {
                try (BufferedReader r = new BufferedReader(new FileReader(f))) {
                    token = r.readLine();
                }
            } else {
                token = UUID.randomUUID().toString();
                try (FileWriter fw = new FileWriter(f)) {
                    fw.write(token + "\n");
                }
            }
        } catch (Exception ignored) {
        }
        Log.i(TAG, "ident uid=" + Process.myUid() + " pid=" + Process.myPid()
                + " androidId=" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID)
                + " filesDir=" + getFilesDir() + " token=" + token);
    }

    private synchronized void logLine(String src) {
        long wall = (SystemClock.elapsedRealtime() - startReal) / 1000;
        String line = fmt.format(new Date()) + " " + src + " wall=" + wall + "s game=" + (gameMs / 1000)
                + "s worker=" + workerTicks + " frames=" + frames;
        Log.i(TAG, line);
        try (FileWriter fw = new FileWriter(logFile, true)) {
            fw.write(line + "\n");
        } catch (Exception ignored) {
        }
    }
}
