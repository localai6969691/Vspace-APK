# Chạy kiểm tra trên điện thoại thật (không phải tự code gì)

Mục tiêu: một lệnh làm P0-3 … P0-11 và ra file `REPORT.md` để gửi lại. Cần **một điện thoại Android ARM** (hầu hết máy từ 2016 trở đi).
Script `scripts/device_suite.py` tự cài, tự cấp quyền, tự đo; chỗ nào app không cho điều khiển từ `adb` thì nó dừng và nói đúng thao tác cần chạm.

## Bước 0a — Đưa mã lên GitHub (làm TRƯỚC, nếu repo chưa có thư mục scripts/ workspace/ testguest/)
GitHub không tự giải nén zip. Nếu CI báo `scripts/verify_real.py: No such file` nghĩa là bạn đã upload file `.zip` thay vì nội dung bên trong. Ba cách sửa:

**Cách 1 — chỉ cần trình duyệt (điện thoại hay máy tính đều được), dùng workflow giải nén có sẵn**
1. Trong repo: *Add file → Create new file*, đặt tên đúng `.github/workflows/unpack.yml`, dán nội dung file `unpack.yml` đi kèm, *Commit changes*.
2. *Add file → Upload files*, upload `vspace-workspace-s11.zip` vào **gốc** repo (một file duy nhất), *Commit*.
3. Tab *Actions* → chọn **Giải nén zip vào repo** → *Run workflow*. Chờ xanh: repo sẽ có `scripts/`, `workspace/`, `testguest/`… và file zip bị xóa.
4. GitHub không cho workflow tự sửa thư mục `.github/workflows`, nên workflow mới nằm ở `NEW_build.yml`. Làm tiếp: mở `.github/workflows/build.yml` cũ → biểu tượng thùng rác → *Commit*. Mở `NEW_build.yml` → biểu tượng bút chì → ở ô tên file sửa thành `.github/workflows/build.yml` → *Commit*. CI tự chạy.

**Cách 2 — có `git` (máy tính hoặc Termux)**
```
unzip vspace-workspace-s11.zip -d vspace && cd vspace
git init -b main && git add -A && git commit -m "VSpace workspace"
git remote add origin https://github.com/<ban>/<repo>.git
git push -f origin main        # đăng nhập bằng token cá nhân (Settings → Developer settings → Personal access tokens, quyền repo + workflow)
```

**Cách 3 — có GitHub CLI:** `bash scripts/ship.sh <ban>/<repo> --force` (tự đẩy, chạy CI, tải kết quả).

## Bước 0 — Lấy APK từ CI
```
gh auth login
bash scripts/ship.sh <chu-so-huu>/<ten-repo>      # đẩy mã, CI build, tải APK về ./ci-out
```
Cần APK **Debug** (có `Debug` trong tên) để script đặt được cờ "ghim" bằng `run-as`. Bản Release vẫn chạy nhưng bạn phải bật/tắt "Ghim tiến trình" bằng tay.

## Bước 1 — Chuẩn bị điện thoại (làm một lần, ~3 phút)
1. Cài đặt → Giới thiệu điện thoại → bấm 7 lần **Số hiệu bản dựng** → bật **Tùy chọn nhà phát triển**.
2. Bật **Gỡ lỗi USB** (cách A) hoặc **Gỡ lỗi không dây** (cách B / C).
3. **Tắt khóa màn hình** (Không có / Vuốt) trong thời gian đo; để máy ở chế độ không sạc nếu có thể (số đo pin mới có nghĩa).
4. Tắt "Tiết kiệm pin". Đặt "Tự động tắt màn hình" 30 giây hoặc dài hơn đều được.

## Cách A — Có máy tính, cắm cáp USB (dễ nhất)
```
# Cài adb: https://developer.android.com/tools/releases/platform-tools  (giải nén, thêm vào PATH)
adb devices                                       # phải thấy máy, bấm "Cho phép" trên điện thoại
python3 scripts/device_suite.py --apk-dir ci-out --minutes 10
```
Cắm cáp thì máy báo "đang sạc": script sẽ cảnh báo và số đo pin không đáng tin; phần giữ nền/đóng băng vẫn đo đúng.
Muốn có số pin đúng: dùng cách B.

## Cách B — Có máy tính, Gỡ lỗi không dây (rút được sạc)
Điện thoại: Tùy chọn nhà phát triển → **Gỡ lỗi không dây** → "Ghép nối thiết bị bằng mã ghép nối" (ghi IP:cổng và mã).
```
adb pair <IP>:<cổng-ghép-nối>        # nhập mã 6 số
adb connect <IP>:<cổng-gỡ-lỗi>        # cổng hiển thị ở màn Gỡ lỗi không dây
python3 scripts/device_suite.py --apk-dir ci-out --minutes 10
```

## Cách C — KHÔNG có máy tính: chạy ngay trong điện thoại (Termux)
1. Cài **Termux** từ F-Droid (bản Play Store đã cũ). Mở Termux:
```
pkg update && pkg install -y python git android-tools
termux-setup-storage
```
2. Chép `vspace-workspace-s11.zip` và thư mục `ci-out` vào bộ nhớ máy, giải nén vào `~/vspace` (hoặc `git clone` repo của bạn rồi lấy APK từ trang Actions).
3. Bật **Gỡ lỗi không dây** như cách B, rồi trong Termux:
```
adb pair localhost:<cổng-ghép-nối>
adb connect localhost:<cổng-gỡ-lỗi>
cd ~/vspace && python3 scripts/device_suite.py --apk-dir ci-out --minutes 10
```
(Termux và màn hình chia đôi: giữ Termux ở cửa sổ nổi hoặc dùng "Gỡ lỗi không dây" khi tắt màn hình đo thì adb không dây vẫn giữ kết nối trên đa số máy; nếu mất kết nối, chạy lại bằng `--minutes` ngắn hơn.)

## Script làm gì (theo thứ tự)
1. **Cài** workspace (đúng ABI) + miễn trừ pin + quyền thông báo (P0-3).
2. **Nhập testguest** bằng intent VIEW vào Không gian 1 rồi **mở** nó, đợi nhịp tim trong logcat.
3. **P0-6** cô lập hai không gian: *cần 1 thao tác tay* (chọn Không gian 2 và nhập lại testguest). Script nhắc đúng chỗ.
4. **Đo 3 kịch bản** (mặc định 10 phút mỗi cái; số liệu chốt dùng `--minutes 30`):
   - S1 ghim TẮT + tắt màn hình thật; S2 ghim BẬT + tắt màn hình thật (P0-4/P0-5: ProcessPinner có tác dụng không);
   - S3 ghim BẬT + tắt panel bằng **ScreenPower** (quyền shell, P0-11), máy vẫn thức;
   - S4 *(tay, bỏ qua được bằng `--no-manual`)* chế độ Màn hình mờ/đen trong app (P0-7).
5. **Thu thập chẩn đoán** (P0-8): lý do tiến trình thoát (FREEZER/LOW_MEMORY…), pin, nhiệt, danh sách miễn trừ, wakefulness.
6. Ghi `device-result/REPORT.md` + toàn bộ log. **Nén thư mục `device-result` gửi lại cho Claude**, không cần tự đọc.

## Nếu script dừng
| Thông báo | Cách xử lý |
|---|---|
| "Không thấy nhịp tim testguest" | Mở Workspace, bấm "+", chọn `testguest.apk` (script đã chép sẵn vào `Android/data/dev.vspace.workspace/files/`), mở testguest, chạy lại |
| "KHÔNG ghi được" cờ ghim | Đang dùng bản Release: vào Cài đặt của app bật/tắt "Ghim tiến trình" theo nhắc |
| "máy không phải ARM" | Đây là emulator x86: engine không chạy, dùng máy ARM |
| adb mất kết nối khi tắt màn hình | Dùng cáp USB (cách A), hoặc rút `--minutes` |

Không có máy ARM? Xem mục thuê thiết bị đám mây (Firebase Test Lab) trong `PROJECT_HANDOFF.md` §23.7.
