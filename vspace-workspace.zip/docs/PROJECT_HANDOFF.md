# VSpace Workspace — Tài liệu bàn giao kỹ thuật

> **Cập nhật lần cuối:** 2026-11-16 (phiên 10: audit "chưa nối dây"; hầu hết ĐÃ nối đúng, 2 lỗ hổng thật được vá; xem mục **22**). **Quy tắc:** cuối MỖI phiên làm việc, cập nhật mục **1, 5, 6, 8, 14**. Phiên 4 xem mục **18** (18.5 là phần tra cứu bổ sung).
> **Cách đọc nhanh (2 phút):** mục 1 → mục 6 (việc tiếp theo) → mục 8 (đừng lặp lại sai lầm). Các mục còn lại là tra cứu.

**Chú giải mức xác thực (dùng xuyên suốt tài liệu):**

| Ký hiệu | Nghĩa |
|---|---|
| **[R]** | Có nguồn tài liệu/tra cứu hỗ trợ (URL ở mục 13). Chưa chắc đúng với *đúng thiết bị của bạn*. |
| **[S]** | Đã kiểm tra tĩnh trong sandbox (parse XML/YAML, `bash -n`, chạy thử `overlay.sh` trên core giả, cân bằng ngoặc). **Chưa phải biên dịch thật.** |
| **[V]** | **Đã kiểm chứng bằng công cụ THẬT trong sandbox** (phiên 7): `android.jar` thật, source thật của lõi, `aapt`, `apksigner`, APKEditor, `actionlint` (mục 19). Mạnh hơn [S]; **vẫn chưa phải chạy trên thiết bị** và chưa phải Gradle/AGP. |
| **[?]** | **CHƯA kiểm chứng.** Cần CI chạy thật hoặc thiết bị thật. Là giả thuyết, không phải sự thật. |
| **[✗]** | Đã thử hoặc đã loại. Đừng làm lại (xem mục 8). |
| **[D]** | Quyết định thiết kế đã chốt (xem mục 3). |

---

## 1. Tóm tắt trạng thái

| Hạng mục | Trạng thái |
|---|---|
| Mục tiêu | App Android "không gian ảo": cài APK khác vào trong, app đó chạy nền khi tắt màn hình; mã nguồn build ra APK trên GitHub |
| Code | Viết xong (module `workspace` = 54 lớp Java + 82 test đơn vị (JVM, phiên 7) + 22 test Python cho công cụ đo + module thử `testguest`, manifest, layout vi/en + theme sáng/tối/động, workflow, script). **Đã biên dịch bằng `javac` thật với stub Android, nhưng CHƯA build bằng Android SDK thật.** |
| CI | Workflow **dựng lại ở phiên 7** (bản cũ mất khỏi zip) bám workflow thật của lõi, JDK 21; YAML + `bash -n` + `actionlint` **[V]**, **chưa chạy lần nào [?]** |
| Chạy trên máy | **Chưa từng cài/chạy trên thiết bị nào [?]** |
| Hiệu quả giữ nền | Cơ chế 4 lớp có cơ sở lý thuyết **[R]**, **hiệu quả thực tế chưa đo [?]** |
| Chế độ game (phiên 3) | Viết xong: overlay đen giữ màn hình bật, hồ sơ từng game, tự dừng theo giờ/pin/nhiệt, phát hiện game đứng (CPU), báo cáo phiên, hẹn giờ, watchdog, đa không gian. **Chưa chạy lần nào [?]**; đo bằng `testguest` (mục 16) |
| Phát hiện quan trọng | Với game chạy theo khung hình, **giữ tiến trình sống KHÔNG đủ**: tắt màn hình thật thì hết VSync, logic đứng (mục 16) |
| Lưới an toàn | `scripts/check.py` (kiểm tĩnh, chạy trong CI trước khi build) đã qua **thử đột biến 12/12**; kiểm cả số tham số mọi lời gọi giữa các lớp. **Không thay thế biên dịch thật.** |
| Biên dịch trong sandbox | `scripts/compile_check.py`: 31 file `workspace` + `testguest` qua **javac thật** với stub Android (spec ở `scripts/stubs/`), **58 test đơn vị chạy thật, đạt hết (phiên 4)**; thử đột biến 8/8 bắt được. Phát hiện cuối đợt 3: sandbox **có** javac (qua `java -m jdk.compiler/…`), các đợt trước báo "không có javac" là sai (E-10) |
| Phát hiện từ nghiên cứu lõi (đợt 3, qua tài liệu dẫn từ source) | *Đã bị SỬA ở phiên 5 bằng cách đọc source thật, xem hàng dưới* |
| **Phiên 5 — đọc trực tiếp source thật qua mạng (không cần thiết bị/SDK)** | Clone thật `ALEX5402/NewBlackbox` (SHA `89b5983`) và chạy thật `overlay.sh`/`gen_guest_hooks.py` trên đó. Sửa 1 claim SAI: gốc dữ liệu ảo là **anh em của cache** (`cacheDir.getParent()/blackbox`), KHÔNG nằm trong cache — "Xóa bộ nhớ đệm" KHÔNG xóa app ảo (O-9 đã sửa). Xác nhận: `stopPackage`/`installPackageAsUser`(trả `InstallResult{success,msg}`, không phải `boolean`)/`uninstallPackageAsUser`/`uninstallPackage`/`createUser`/`getUsers` có thật; **`BActivityManager.killAppByPkg` KHÔNG tồn tại** (bỏ khỏi `Engine.java`); `AppLifecycleCallback` là **class cụ thể 15 phương thức** (không phải interface 3 hàm như đoán) — `gen_guest_hooks.py` chạy thật trên core thật ra đúng, `extends` đúng, không cần sửa code sinh. ABI thật trong `build.gradle` của core: **chỉ `arm64-v8a` + `armeabi-v7a`, KHÔNG có `x86`** (README của core quảng cáo sai có x86 — sửa P1-4). `:p0..:p49` (50 slot) dùng **CHUNG cho mọi không gian/game cùng lúc**, không phải 50 riêng mỗi không gian (ảnh hưởng P0-6). OBB map đúng theo `BEnvironment.getExternalObbDir` (gốc NGOÀI khác gốc trong) — đã sửa `ObbImporter` (giải G-31). `ANDROID_ID` trả nguyên giá trị HOST cho mọi không gian (không có cách ly) — ghi làm CẢNH BÁO, không giả mạo. Không tìm thấy lớp proxy Keystore nào trong core → alias keystore giữa các guest nhiều khả năng không cách ly. Tải + tính sha256 thật của `APKEditor` V1.4.9 (`a9cd40df81…`), dùng `javap` xác nhận `Main.execute(String[])` tách khỏi `main()` — khớp giả định của `SplitMerger` (giải một phần G-30). Repo core: 419★/232 fork/22 issue mở (API GitHub bị rate-limit trong sandbox nên không đọc được nội dung từng issue — E-4 vẫn mở phần đó), push cuối 2026-07-19, Apache-2.0. **Đã sửa code theo các xác nhận trên, chạy lại `compile_check.py`/`check.py`: biên dịch thật + 58 test đơn vị đạt, mọi kiểm tĩnh đạt.** Chi tiết đầy đủ ở mục 13.7. **Làm** ( người dùng yêu cầu lại ở phiên này): tính năng che giấu overlay `ANDROID_ID`/fingerprint. |
| **Phiên 6 — PHÁT HIỆN NGHIÊM TRỌNG: lõi tự rò rỉ logcat host ra bên thứ ba khi crash, đã vá** | Đọc tiếp `BlackBoxCore.java`/`ClientConfiguration.java`/`LogSender.java` thật: lõi cài `UncaughtExceptionHandler` TỰ ĐỘNG (static block, không cần Workspace gọi gì) gửi logcat host + info thiết bị tới `https://logs-sender-api.vercel.app/api/<chatId>/upload` (chatId mặc định hardcode `-1003719573856`, do tác giả core kiểm soát) mỗi khi app ảo crash — xem O-10 (mục 12) để biết chi tiết đầy đủ. **Đã vá**: `Engine.attach()` override `getLogSenderChatId()` về `null` → chặn hoàn toàn trước khi tạo file/chạy logcat/gọi mạng. Nhân tiện đọc thêm `BlackBoxCore`/`BPackageManagerService`/`ClientConfiguration` đầy đủ, xác nhận thêm: `clearPackage(String,int)` (xóa dữ liệu riêng 1 guest, có thật — trước đó ghi [?] là sai), `deleteUser(int)` (xóa cả 1 không gian), `isSupportGms()/isInstallGms()/installGms()/uninstallGms()` (lõi có cơ chế cài GMS thật cho không gian ảo — đổi khung "scope_no" cho FCM/Google services từ "gần như không thể" sang "có cơ chế, chưa kiểm chứng trên máy"), `hasAllFilesAccess()/requestAllFilesAccess()` (luồng xin quyền lưu trữ có sẵn, chưa được Workspace dùng), `isHideRoot()/isDisableFlagSecure()` (mặc định `false`, Workspace không bật — xác nhận KHÔNG đang dùng tính năng ẩn/né nào của lõi). Chạy lại `compile_check.py`/`check.py`: biên dịch qua, 58 test đạt; chạy lại `overlay.sh` trên core thật xác nhận override biên dịch đúng với class thật. Chi tiết ở mục 13.8 |
| **Phiên 7 — kiểm chứng bằng công cụ thật + làm nốt phần làm được** | Sandbox có mạng tới GitHub/Ubuntu (không tới Google/Maven): tải `android.jar` API 26/28/35 thật, clone lõi ở SHA `89b5983`, cài `aapt`/`apksigner`. **Kết quả [V]:** toàn bộ mã biên dịch với `android.jar` + source lõi thật (có kiểm đột biến), tài nguyên+manifest qua `aapt` thật (bắt 1 lỗi build thật: `windowBackground` màu thẳng), workflow qua `actionlint`, chuỗi ghép split→ký→`apksigner`. **Lỗi thật tìm ra:** workflow `.github/` MẤT khỏi zip (dựng lại); JDK phải là **21** (README/handoff ghi 17, sai); APK ghép chưa ký bị lõi **từ chối** (O-12) → viết `ApkSigner` (v2) được `apksigner` AOSP xác minh. **Phát hiện về lõi:** O-11 (lõi tự giả mạo thuộc tính thiết bị toàn tiến trình; có công tắc gỡ). **Tính năng mới:** cập nhật trong app (mạng, mặc định tắt), thùng rác + Hoàn tác, Chi tiết/Quyền, gợi ý "Truy cập mọi tệp", Google services/xóa không gian, bottom sheet. 82 test JVM đạt. **Vẫn chưa: Gradle/AGP, thiết bị thật, P0-1…P0-11.** Chi tiết mục 19 |
| Tắt hẳn panel (đợt 4) | Nghiên cứu cho thấy kỹ thuật `scrcpy --turn-screen-off` (hàm ẩn `SurfaceControl.setDisplayPowerMode`) giữ Android thức nên **game vẫn chạy khi panel tắt** (cộng đồng đã dùng cho bot game). Đã cài `ScreenPower` chạy từ chính APK bằng quyền shell (ADB); **chưa thử trên máy thật** (G-18). `cmd display power-off` KHÔNG tương đương |
| Công cụ thu bằng chứng | Chẩn đoán (importance, CPU, **lý do tiến trình thoát gồm FREEZER**, vị trí dữ liệu engine), nhật ký vòng + chia sẻ báo cáo 1 chạm, `testguest`, `apk_report.py` (16 KB) |
| Phiên 4 (2026-11-13) | Làm nốt các việc dang dở trong phạm vi làm được **không cần máy thật**: kiểm tra trước chạy nền, hướng dẫn theo hãng + nhắc OTA, thống kê/pin mỗi giờ từng game, ghim chọn lọc, tăng ưu tiên luồng game, giảm tần số quét/độ phân giải, tự mở lại game, RAM/CPU từng tiến trình, widget, cài đặt/nhật ký, cập nhật giữ dữ liệu, công cụ đo bằng adb, ký phát hành tùy chọn. **Tất cả chưa chạy trên máy thật [?]**; chi tiết mục 18 |
| Phiên 4b (tra cứu bổ sung) | Tra cứu rồi làm: ghép split APK (APKEditor tùy chọn), chép OBB từ XAPK, job emulator x86; kết quả tra cứu về virtual display và ABI của lõi (mục 18.5). 58 test đơn vị. **Từ chối** phần né phát hiện của anti-cheat (mục 18.5). Trạng thái như phiên 4: biên dịch được + test thuần, chưa chạy máy thật [?] |
| Công cụ đo bằng adb | `scripts/measure_background.py` (`run` / `analyze` / `isolation`): tự đo testguest khi tắt màn hình, đọc pin/nhiệt/mức ưu tiên `:pN`, kết luận RUNS / FRAME-LOOP-STOPPED / FROZEN / KILLED, kiểm hai không gian có dùng chung dữ liệu không. Phần phán quyết và parse **[S]** (22 test); phần gọi adb thử bằng adb giả, **chưa chạy trên thiết bị thật [?]** |
| Blocker số 1 | Vẫn chưa có build bằng Android SDK/Gradle thật và chưa chạy trên thiết bị nào — sandbox này có mạng tới GitHub nhưng KHÔNG tới `dl.google.com`/Android SDK nên không tự chạy Gradle được. Phần "tên hàm lõi chưa xác nhận" đã giải ở phiên 5 (đọc source thật, xem hàng trên); rủi ro còn lại là stub cho **API Android chuẩn** (Context/Intent/…) vẫn viết theo trí nhớ, chỉ Android SDK thật mới bắt hết được |
| **Việc tiếp theo số 1** | Đẩy lên GitHub, chạy Actions (build Android SDK thật) — đọc `core-inspection` giờ chỉ còn giá trị ĐỐI CHIẾU với phiên 5, không còn là nguồn duy nhất; P0-3 (cài máy thật) mới là việc còn thiếu nhất (mục 6, P0-1/P0-3) |

**Sự thật cần nhớ:** *chưa có kỹ thuật nào được chứng minh trên thiết bị.* Mục 7 là "kỹ thuật có cơ sở", không phải "kỹ thuật đã thành công".

---

## 2. Yêu cầu của người dùng và tiêu chí nghiệm thu

**Yêu cầu gốc (phiên 1, nguyên văn rút gọn):** viết chương trình dạng *workspace* trên Android; cài được APK khác vào trong; *đặc biệt* các APK cài trong đó chạy được nền dù không được thiết kế để chạy nền, tắt màn hình vẫn chạy; ở dạng **source code build APK trên GitHub**.

**Yêu cầu bổ sung (phiên 2):** tra cứu cách khắc phục giới hạn và phần chưa kiểm chứng; trả lời app trong không gian ảo có chạy bình thường như bên ngoài không và có bị giới hạn quyền không; viết tài liệu kỹ thuật (tiến độ, việc phải làm theo yêu cầu, đã xong, tồn đọng, kỹ thuật thành công/thất bại/không hiệu quả) để lần sau **chỉ cần đọc tài liệu này, không cần đọc lại cả phiên chat**, và để bên khác nhận việc không phải làm lại từ đầu hay đoán mò.

**Yêu cầu bổ sung (phiên 3):** thêm các tính năng trong bản đánh giá bên ngoài (DeepSeek, file PDF người dùng gửi), **đặc biệt các tính năng để chạy game**; người dùng xác nhận ứng dụng cần "chạy nền cho game". Cách xử lý từng đề xuất ở mục 17.

| ID | Tiêu chí nghiệm thu | Trạng thái |
|---|---|---|
| AC-1 | Là app Android dạng workspace, có UI quản lý | Code xong **[S]**; chưa chạy **[?]** |
| AC-2 | Cài được APK khác vào trong (từ file và từ app đã cài) | Code xong **[S]**; chưa thử **[?]** |
| AC-3 | App bên trong chạy nền khi tắt màn hình, kể cả app không thiết kế chạy nền | Cơ chế xong; hiệu quả **[?]**; **giới hạn cố hữu: chỉ giữ tiến trình sống, không ép code app chạy** (mục 9) |
| AC-4 | Mã nguồn trên GitHub, build APK tự động | Workflow xong **[S]**; chưa chạy **[?]** |
| AC-5 | Tra cứu cách khắc phục giới hạn / phần chưa kiểm chứng | **Xong** (mục 7–10); phần kiểm chứng chuyển thành test plan (mục 11) |
| AC-6 | Trả lời: app ảo có chạy như ngoài không, giới hạn quyền | **Xong** (mục 9–10) |
| AC-7 | Tài liệu bàn giao đủ để tiếp tục không cần chat | Tài liệu này |
| AC-8 | Game chạy theo khung hình vẫn chạy logic khi người dùng không nhìn màn hình | Chế độ "Màn hình đen" viết xong; **chưa đo [?]** (P0-7, mục 16.5) |
| AC-9 | Chơi nhiều tài khoản cùng một game (nhiều không gian) | UI + `Engine` hỗ trợ 3 không gian; **cô lập dữ liệu giữa các không gian chưa kiểm chứng [?]** (P0-6) |
| AC-10 | Có công cụ đo thay vì đoán | `testguest` (giả lập game) + màn hình Chẩn đoán (importance, CPU) xong; chưa chạy **[?]** |
| AC-11 | Không mất dữ liệu game (sao lưu/khôi phục, tự sao lưu ra thư mục ngoài cache) | Code xong theo bố cục đã xác nhận; **chưa chạy thật [?]** (P0-9) |

---

## 3. Kiến trúc và quyết định thiết kế

```
REPO NÀY (GitHub)                          GITHUB ACTIONS (mỗi ABI: arm64-v8a, armeabi-v7a)
 ├ workspace/   module Java          ─►    1. checkout repo này + ALEX5402/NewBlackbox → core/
 ├ scripts/overlay.sh                      2. overlay.sh: chép workspace/ vào core/, include(":workspace"),
 ├ .github/workflows/build.yml                tự sửa import BlackBoxCore/ClientConfiguration theo package thật
 └ docs/PROJECT_HANDOFF.md                 3. inspect: xuất API/manifest của core → artifact "core-inspection"
                                           4. ./gradlew :workspace:assembleDebug -Pabi=<abi>  → APK

TRÊN MÁY — toàn bộ nằm dưới MỘT UID (dev.vspace.workspace)
┌─ Tiến trình chính ───────────────────────────────────────────────────────────────┐
│ MainActivity · KeepAliveService (foreground + WakeLock + WifiLock)               │
│ ProcessPinner ──bindService(BIND_AUTO_CREATE|BIND_IMPORTANT)──┐ · BootReceiver   │
└───────────────────────────────────────────────────────────────┼──────────────────┘
┌─ Tiến trình :p0 … :p49 (stub của core) ◄──────────────────────┘ ─────────────────┐
│ chứa app ảo (guest). SpaceApp.attachBaseContext/onCreate chạy cả ở đây          │
└──────────────────────────────────────────────────────────────────────────────────┘
```

| ID | Quyết định | Lý do | Đánh đổi |
|---|---|---|---|
| D-01 | Dùng **NewBlackbox** làm lõi, không tự viết engine | Engine ảo hóa = hàng chục nghìn dòng hook hệ thống. Apache-2.0, nhận hỗ trợ Android 5–14+ **[R]** | Phụ thuộc repo ~470★/58 commit; có bản "enhanced" thương mại, repo công khai có thể tụt hậu **[R]** |
| D-02 | **Overlay** module vào bản clone của core (không submodule, không AAR) | AAR qua `fileTree` mất dependency bắc cầu; `include` từ repo ngoài phụ thuộc cấu hình root. Overlay dùng nguyên root build của core nên plugin/repo khớp | `overlay.sh` phải khớp cấu trúc core (đã kiểm: core có `Bcore/`, `app/`, `settings.gradle` Groovy **[R]**) |
| D-03 | Module viết **Java thuần**, widget framework, không Kotlin/AppCompat | Không phụ thuộc plugin Kotlin hay thư viện nào của core | UI đơn sơ |
| D-04 | `Engine.java` là **điểm duy nhất** chạm core | Core đổi API → sửa một file. Gọi trực tiếp chỉ các hàm có trong README; xác minh kết quả bằng `getInstalledApplications`; hàm không chắc dùng reflection | Mất kiểm tra lúc biên dịch với các hàm reflection |
| D-05 | `targetSdk` mặc định **28** (đổi bằng `-PtargetSdk=`) | README BlackBox khuyên ≤28 để tương thích **[R]**. Android 14–17 vẫn cài được vì ngưỡng chặn hiện là 24 **[R]** | Cảnh báo "built for older Android"; không lên Play; có thể bị nâng ngưỡng sau này |
| D-06 | Foreground service type **`specialUse`** | `dataSync` bị giới hạn 6h/24h và bị chặn khởi động lúc boot trên Android 15 **[R]**; `specialUse` không nằm trong danh sách bị chặn lúc boot **[R]** | Không đưa lên Play được; cần khai `PROPERTY_SPECIAL_USE_FGS_SUBTYPE` |
| D-07 | Giữ tiến trình guest bằng **bind từ tiến trình foreground vào stub service của `:pN`** | AOSP: tiến trình bị bind không thể thành cached trước client; cached bị đóng băng sau 10 giây **[R]** | Giả định stub service chấp nhận bind (onBind null vẫn tính?) **[?]** |
| D-08 | **Không** bật R8/minify; `release` ký bằng debug key | Engine dùng reflection nặng, R8 sẽ làm vỡ | APK to hơn, chưa có key phát hành |
| D-09 | `useLegacyPackaging = true` (giải nén `.so`) | Engine native cần đường dẫn `.so` thật **[?]** | APK lớn hơn |
| D-10 | Có màn hình **Chẩn đoán** (sao chép báo cáo) | Biến các mục **[?]** thành số đo được trên máy thật; báo cáo dán thẳng vào chat/issue | — |
| D-11 | UI tiếng Việt, một Activity, ListView | Người dùng nói tiếng Việt; tối thiểu hóa phụ thuộc | Chưa i18n |
| D-12 | Lõi tính năng game = **overlay đen + `FLAG_KEEP_SCREEN_ON`** (chế độ B), không chỉ giữ tiến trình | Game chạy logic trong vòng lặp khung hình; tắt màn hình thật thì hết VSync | Màn hình thật vẫn bật: GPU/CPU vẫn chạy, chỉ tiết kiệm phần panel (rõ nhất trên OLED) |
| D-13 | Overlay do **tiến trình chính** vẽ (`TYPE_APPLICATION_OVERLAY`, cần quyền "hiển thị trên ứng dụng khác"); không hook activity của guest | Không phụ thuộc cơ chế vòng đời của engine; độ sáng theo **cửa sổ** nên hệ thống tự khôi phục khi overlay biến mất, kể cả khi tiến trình chết | Một số game/anti-cheat phát hiện cửa sổ overlay (D-14) |
| D-14 | Overlay hiển thị bình thường, **không che giấu**; có cảnh báo trước khi cài/chạy game thuộc danh sách có anti-cheat (`RiskList`) | Không hỗ trợ né kiểm soát chống gian lận; người dùng tự chịu rủi ro khóa tài khoản | Người dùng có thể thấy cảnh báo là phiền |
| D-15 | "Không gian" = `userId` 0..2 của engine để chơi nhiều tài khoản; `Engine` tự thử `createUser` bằng reflection | Cách nhanh nhất cho đa tài khoản mà engine hỗ trợ sẵn | Engine có cô lập dữ liệu giữa các userId không là **[?]** (P0-6); **không** giả mạo ID/fingerprint |
| D-16 | Watchdog dùng alarm **không chính xác** (10 phút, `setAndAllowWhileIdle`); lịch game dùng alarm chính xác có fallback khi thiếu quyền | Watchdog không cần độ chính xác nên khỏi xin `SCHEDULE_EXACT_ALARM` | Doze giãn alarm; vẫn có thể trễ |
| D-17 | Module `testguest` mô phỏng game (bộ đếm theo `Choreographer` + luồng 1 Hz độc lập) | Biến AC-3/AC-8 thành số đo (mục 16.5) | Chỉ mô phỏng, không thay thế test game thật |
| D-18 | Âm lượng media: lưu mức gốc rồi tắt tiếng, khôi phục khi dừng / boot / dựng lại dịch vụ | Tiến trình có thể bị kill giữa phiên; không được để máy câm vĩnh viễn | Ghi `SharedPreferences` đồng bộ (`commit`) |
| D-19 | Nhật ký vòng tự viết (`LogBuffer`, 256 KB, có crash handler); chỉ **tiến trình chính** ghi file | Người dùng xuất báo lỗi không cần adb; tránh nhiều tiến trình ghi chung một file | Crash native không bắt được (D-21) |
| D-20 | Chia sẻ báo cáo bằng `ShareProvider` tự viết, không dùng FileProvider/androidx | Không thêm phụ thuộc vào build của core | Phải tự chặn path traversal (đã chặn) |
| D-21 | Dùng `ApplicationExitInfo` (Android 11+) thay vì Breakpad để biết vì sao tiến trình chết | Có sẵn trong hệ thống, cho biết **FREEZER / LOW_MEMORY / SIGNALED**; không cần mã native | Chỉ từ Android 11; không có stack native |
| D-22 | Xem trước APK trước khi cài: tên, phiên bản, chữ ký SHA-256, quyền nhạy cảm, thành phần hệ thống có thể không chạy | Người dùng quyết định có thông tin; công bố giới hạn ngay lúc cài | Chỉ là thông tin, không chặn cài |
| D-23 | `ShortcutActivity` để `exported=true` | Launcher cần gọi được; chỉ mở app đã cài trong không gian ảo nên rủi ro thấp (app khác chỉ có thể yêu cầu mở một app ảo đã cài) | Ghi nhận rủi ro thấp |
| D-24 | CI: job `checks` (check.py) **chặn** build; unit test / lint / apk_report dùng `continue-on-error` | Chưa biết build có xanh không; bật bắt buộc sau lần xanh đầu (P1-16) | Test có thể đỏ mà không ai để ý nếu không đọc artifact `reports` |
| D-25 | **Không** làm sao lưu/khôi phục dữ liệu guest ở giai đoạn này | Chưa biết engine lưu dữ liệu ở đâu; ghi đè thư mục đoán mò có thể làm hỏng dữ liệu | Thay bằng: Chẩn đoán "vị trí dữ liệu" + xuất file APK (P1-10) |
| D-26 | Hook app ảo bằng `AppLifecycleCallback` của lõi; lớp callback **sinh từ source thật của lõi lúc build** (`scripts/gen_guest_hooks.py`) | Tài liệu các fork mâu thuẫn (interface hay abstract class, chữ ký). Sinh mã thích ứng; không tìm thấy thì sinh bản stub, build vẫn qua, tính năng tự tắt | Phụ thuộc cấu trúc source của lõi; đã thử 4 kiểu core giả |
| D-27 | Kênh IPC giữa tiến trình chính và `:pN` dùng **LocalSocket trừu tượng** + kiểm UID peer (SO_PEERCRED) | Engine hook ActivityManager trong tiến trình app ảo nên broadcast/ContentProvider có thể bị chuyển vào "hệ thống ảo"; socket không đi qua đường đó | Cần kiểm trên máy thật (P0-9) |
| D-28 | Thêm chế độ **Màn hình mờ** (`MODE_DIM`): giữ màn hình bật + độ sáng thấp nhất trên chính cửa sổ game, qua hook | Không cần quyền overlay (Android 15 có thể coi là "cài đặt bị hạn chế"); là phương án khác khi overlay không cấp được | Panel vẫn hiện game nên tiết kiệm pin ít hơn chế độ màn hình đen |
| D-29 | PiP thử nghiệm: script merge `supportsPictureInPicture` vào mọi `ProxyActivity` của lõi + lệnh `pip` chạy trong tiến trình app ảo | Hệ thống kiểm PiP theo manifest của proxy, không theo app ảo; chỉ activity trong tiến trình app ảo mới gọi được `enterPictureInPictureMode` | Chưa biết game có tiếp tục chạy khi vào PiP (G-13) |
| D-30 | Sao lưu/khôi phục: zip (meta → apk → data → ext), giải nén ra thư mục tạm rồi mới tráo, **giữ bản an toàn** dữ liệu cũ, chặn zip-slip/zip-bomb, tự sao lưu ra thư mục SAF và xoay vòng 3 bản | Dữ liệu nằm trong cache nên sao lưu ngoài là biện pháp bảo vệ chính | Phải dừng game trước; tự sao lưu chỉ chạy khi phiên kết thúc tự động |
| D-31 | Ghim cả tiến trình **`:daemon`** của engine | Nó chứa dịch vụ hệ thống ảo: chết hoặc bị đóng băng thì mọi app ảo mất dịch vụ | Giả định bind được vào `DaemonService` **[?]** |
| D-32 | Kiểm biên dịch bằng stub Android + `javac` + runner mini (`compile_check.py`); chữ ký stub phải đúng Android thật | Biến "chưa biên dịch" thành "biên dịch được với stub" trong sandbox không có SDK | Stub sai có thể che lỗi hoặc báo lỗi giả; CI vẫn cần build thật |
| D-33 | **Tắt hẳn panel** bằng `ScreenPower` (chạy bằng `app_process` với quyền shell, dùng thẳng APK làm classpath, không dựng jar riêng); app chỉ hiển thị lệnh để người dùng chạy qua ADB | Là cách duy nhất đã được cộng đồng kiểm chứng để game vẫn vẽ khi panel tắt mà không cần root; app thường không có quyền gọi `SurfaceControl.setDisplayPowerMode` | Cần ADB (máy tính hoặc Termux + Gỡ lỗi không dây); Android 14+ cần nhánh `DisplayControl` + `loadLibrary0` chưa thử trên máy thật |
| D-34 | Theme `android:Theme.DeviceDefault.DayNight` cho Android 10+ (qua `values-v29` và `values-night-v29`) thay cho việc thêm Material/AndroidX | Có sẵn dark theme tự động và màu động (Material You, Android 12+) mà không thêm phụ thuộc vào build của lõi | Giao diện vẫn là widget framework, chưa có RecyclerView/Material component |
| D-35 | `Preflight` chỉ CẢNH BÁO trước khi vào chế độ game (pin, nhóm chờ, tiết kiệm dữ liệu, nhiệt, RAM, overlay, thông báo), người dùng quyết định; phần đánh giá là hàm thuần tách khỏi phần đọc API | Tech.txt: "không kiểm thì mạng chết âm thầm"; hàm thuần test được | Thêm một hộp thoại trước khi bắt đầu |
| D-36 | Ghim chọn lọc theo game dùng **pid** từ sổ IPC (`GuestRegistry.get(pid)`), không dùng `Info.proc` | `proc` là tên tiến trình ảo của guest, không phải `:pN` của host | Game chưa kết nối IPC vẫn bị ghim (an toàn) |
| D-37 | Tinh chỉnh bên trong game (boost luồng, `fps`, `lowres`, `dim`) đi qua IPC, mỗi lệnh có lệnh hoàn nguyên; danh sách lệnh sinh bằng hàm thuần `tuningCommands` | Chỉ tác động cửa sổ/luồng của chính tiến trình app ảo; dễ test | Hiệu quả phụ thuộc game (G-21..G-23) |
| D-38 | Cập nhật đè giữ dữ liệu bằng **sao lưu preupdate + so dung lượng + tự khôi phục** (`UpdateKeeper`), không dựa việc engine tự giữ dữ liệu | Không biết engine ghi đè có xóa dữ liệu không (G-17) | Cần dư dung lượng 1,2× dữ liệu; thiếu thì bỏ qua sao lưu và báo |
| D-39 | `SessionStats` lưu dạng văn bản `k=v;k=v` một dòng/phiên, không dùng `org.json` | Lớp được test trên JVM, nơi `org.json` của android.jar trả giá trị rỗng | Không đọc bằng công cụ JSON |
| D-40 | Ký phát hành bằng khóa lấy từ biến môi trường/GitHub Secrets (`VSPACE_KEYSTORE_FILE`, `_PASSWORD`, `VSPACE_KEY_ALIAS`, `_KEY_PASSWORD`); thiếu thì vẫn debug key; `versionCode` = số lần chạy CI | Không lưu khóa trong repo; cập nhật đè cần `versionCode` tăng đơn điệu | Gradle/CI chưa chạy thật [?]; tag `v*` build Release |
| D-41 | Công cụ đo adb tách phần phán quyết thuần (test được) khỏi phần gọi adb; testguest thêm dòng `ident` (androidId, filesDir, token) | Biến [?] thành số đo mà không phải đọc log bằng mắt | Định dạng `dumpsys` đổi theo bản Android (G-29) |
| D-42 | Ghép split APK bằng **APKEditor (REAndroid, Apache-2.0) gọi qua reflection** (`com.reandroid.apkeditor.Main.execute`), jar TÙY CHỌN do CI tải vào `workspace/libs/` | Build vẫn xanh khi thiếu jar; không buộc phụ thuộc cứng vào thư viện chưa thử trên máy; kiểm bằng file đầu ra thay vì mã trả về | APK ghép chưa ký (G-30); ghép app lớn tốn RAM/thời gian; CI cần mạng + `gh` |
| D-43 | OBB: chép từ mục `Android/obb/<gói>/*.obb` của XAPK vào thư mục OBB ảo `storage/emulated/<không gian>/Android/obb/<gói>/` (anh em của thư mục data lõi dùng) | Cấu trúc XAPK đã xác nhận qua tài liệu; không có tài liệu nói lõi map OBB | Đường dẫn đích chỉ là giả định (G-31); OBB nằm trong cache có thể bị xóa |

---

## 4. Bản đồ file

| Đường dẫn | Vai trò | Ghi chú |
|---|---|---|
| `workspace/build.gradle` | Module app; tham số `-Pabi`, `-PtargetSdk`; tìm `:Bcore`/`:bcore` | Hậu tố `.a32` cho bản armv7 |
| `workspace/src/main/AndroidManifest.xml` | Quyền (guest dùng quyền host), service `specialUse`, receiver boot | `tools:replace` chống xung đột manifest với core |
| `.../SpaceApp.java` | `Engine.attach` + `Engine.create` ở **mọi** tiến trình | Bắt buộc theo README core |
| `.../Engine.java` | Lớp bọc duy nhất vào core; `launch()` xử lý trả `Intent` hoặc `boolean`; `apiSurface()` | Import được `overlay.sh` tự sửa |
| `.../MainActivity.java` | UI: thêm APK (SAF), nhân bản app đã cài, mở/dừng/gỡ, công tắc giữ nền, Chẩn đoán | Cài APK qua file tạm trong `cacheDir/import`, xóa ngay sau khi cài |
| `.../KeepAliveService.java` | FGS + `PARTIAL_WAKE_LOCK` (gia hạn 5 phút/lần) + `WifiLock` | `START_STICKY`; nút Dừng trong thông báo |
| `.../ProcessPinner.java` | Quét tiến trình `:pN` mỗi 15 giây, bind vào stub service | **Không dùng `BIND_ABOVE_CLIENT`** (mục 8) |
| `.../Diagnostics.java` | Báo cáo: thiết bị, trạng thái giữ nền, **importance của từng `:pN`**, stub phát hiện, API thật của core | Dùng cho test plan mục 11 |
| `.../PowerHelper.java` | Xin miễn trừ pin; mở trang tự khởi động Xiaomi/Huawei/Oppo/Vivo/Samsung/OnePlus/Asus/Letv/Nokia | Danh sách component lấy từ kinh nghiệm cộng đồng **[R]**, chưa thử trên máy |
| `.../BootReceiver.java`, `Prefs.java` | Bật lại dịch vụ sau boot; lưu cấu hình | — |
| `scripts/overlay.sh` | Ghép module vào core + sửa import | Idempotent **[S]** |
| `.github/workflows/build.yml` | Build ma trận 2 ABI, inspect core, upload artifact, release theo tag `v*` | `CORE_REF` mặc định `main` → **cần ghim SHA** (P1-1) |
| `AGENTS.md`, `CLAUDE.md` | Chỉ dẫn cho AI/dev tiếp quản | Trỏ về tài liệu này |
| `.../GameModeController.java` | Máy trạng thái phiên game: overlay, mute, tick 30 giây (hết giờ/pin/nhiệt/đứng hình), báo cáo, lưu & khôi phục phiên | **Chưa chạy [?]** |
| `.../GameOverlay.java` | View đen; chạm 1 lần = hiện thông tin 3 giây; chạm 3 lần góc trên-phải = thoát | Không dùng `NOT_TOUCHABLE` |
| `.../GameActivity.java`, `GameProfile.java` | Màn hình hồ sơ từng game (chế độ, giờ, pin, nhiệt, mute, 30 Hz, hẹn giờ) + lưu cấu hình | Mở từ menu giữ lâu trong danh sách |
| `.../Notifier.java` | Thông báo foreground (đổi nội dung khi đang chơi) + cảnh báo kênh riêng | `FOREGROUND_SERVICE_IMMEDIATE` từ API 31 |
| `.../Scheduler.java`, `AlarmReceiver.java` | Lịch hằng ngày + watchdog 10 phút | Mở game tự động chỉ là cố gắng tối đa (F-4) |
| `.../CpuSampler.java` | Đọc `/proc/<pid>/stat` để đo CPU từng tiến trình `:pN` | Cùng UID nên đọc được **[?]** |
| `.../ApkImporter.java` | Sao chép APK, nhận XAPK/APKS có 1 APK gốc, kiểm ABI 32/64 và dung lượng | Không ghép split (F-15) |
| `.../RiskList.java` | Danh sách THAM KHẢO game có anti-cheat + hộp thoại xác nhận | Có thể sai/thiếu |
| `testguest/` | App thử (giả lập game) build trong CI, artifact `testguest.apk` | Cài vào workspace để đo (mục 16.6) |
| `workspace/src/main/res/values-en`, `values-night` | Tiếng Anh + giao diện tối | Chuỗi kiểm bằng script (đủ khóa, đúng định dạng `%n$`) |
| `.../LogBuffer.java`, `ExitReasons.java` | Nhật ký vòng + crash handler; lý do tiến trình thoát (`ApplicationExitInfo`), ghi vào nhật ký lúc khởi động | Tất cả `Log.x` đã đi qua `LogBuffer` |
| `.../ShareProvider.java` | ContentProvider chia sẻ báo cáo (`cache/share`, chỉ đọc) | Authority `<applicationId>.share` |
| `.../SetupActivity.java` | Thiết lập lần đầu (thông báo, pin, overlay, autostart) + tuyên bố phạm vi | Tự mở lần đầu; nút "Thiết lập & giới hạn" |
| `.../ShortcutActivity.java` | Phím tắt ngoài màn hình chính mở app ảo | D-23 |
| `workspace/src/test/java/.../PureLogicTest.java` | Test đơn vị các hàm thuần (lịch, parse `/proc`, ABI, RiskList, định dạng…) | Chạy bằng `:workspace:testDebugUnitTest` |
| `scripts/check.py` | Kiểm tĩnh: XML, chuỗi vi/en, id, ngoặc, tham chiếu chéo + số tham số, manifest, workflow, overlay dry-run, bảng tài liệu | Chạy tay và trong job `checks` |
| `scripts/apk_report.py` | Dung lượng APK + kiểm căn lề 16 KB của `.so` 64-bit | Đã thử trên ELF thật; cảnh báo, không chặn |
| `scripts/compile_check.py`, `scripts/stubs/android_api.spec` | Sinh stub Android + lõi giả + `R.java`, chạy `gen_guest_hooks.py`, biên dịch bằng `javac`, chạy test bằng runner mini | Cần JDK (kể cả JDK rút gọn có `jdk.compiler`) |
| `.../ScreenPower.java` | Tắt/bật panel màn hình bằng quyền shell (`app_process`), có 2 nhánh: Android ≤13 `SurfaceControl`, Android 14+ `DisplayControl` + `loadLibrary0`; tự bật lại khi hết giờ/mất adb | Chạy bằng ADB, KHÔNG chạy trong app; hàm thuần có test |
| `workspace/src/main/res/values-v29`, `values-night-v29` | Theme DayNight của hệ thống (D-34) | Android 10+ |
| `scripts/gen_guest_hooks.py`, `scripts/test_gen_guest_hooks.py` | Sinh `GuestGenerated.java` từ source lõi; chèn `ProxyActivity` PiP vào manifest; bài thử 4 kiểu lõi | Bản trong repo là stub (`AVAILABLE=false`) |
| `.../GuestHooks.java`, `IpcClient.java` | Chạy TRONG tiến trình app ảo: theo dõi activity, lệnh `dim`/`pip`, báo về tiến trình chính | D-26, D-27 |
| `.../IpcServer.java`, `GuestRegistry.java` | Máy chủ LocalSocket + sổ đăng ký pid → (gói, không gian, activity) | Nhờ đó biết game nào ở `:pN` nào |
| `.../GuestBackup.java`, `TraceText.java` | Sao lưu/khôi phục/tự sao lưu; trích chữ từ tombstone | D-30 |
| `.../Preflight.java` | Kiểm tra máy trước chạy nền: `evaluate(Snapshot)` thuần + `snapshot(Context)` đọc API + hộp thoại xác nhận | D-35; có test |
| `.../OemGuide.java` | Họ ROM theo hãng, hướng dẫn từng hãng, trang dontkillmyapp, phát hiện mất miễn trừ pin sau OTA | Nội dung bước là [R] |
| `.../SessionStats.java` | Lịch sử phiên từng game, pin tụt mỗi giờ, tổng hợp | D-39 |
| `.../GuestMonitor.java` | RAM (PSS) + CPU từng tiến trình, gắn với game qua pid | Pin theo tiến trình không đọc được, dùng CPU thay thế |
| `.../DisplayTuning.java` | Chọn `Display.Mode` tần số thấp, tính kích thước render giảm | G-22..G-24 |
| `.../ThreadBoost.java` | Nâng ưu tiên luồng chính + luồng render theo tên (chạy trong tiến trình app ảo) | G-21 |
| `.../UpdateKeeper.java` | Cập nhật đè giữ dữ liệu (sao lưu preupdate, kiểm, khôi phục) | D-38 |
| `.../StatusWidget.java`, `res/xml/widget_info.xml`, `res/layout/widget_status.xml` | Widget trạng thái chạy nền + nút thoát game | G-28 |
| `.../SettingsActivity.java`, `res/layout/activity_settings.xml` | Cài đặt: nhắc 12 giờ/OTA, kiểm máy, hướng dẫn hãng, xem/chia sẻ nhật ký, xóa thống kê, giới thiệu + thay đổi | — |
| `.../AppSort.java` | Thứ tự sắp xếp danh sách (tên / không gian / đang chạy trước) | Hàm thuần |
| `scripts/measure_background.py`, `scripts/test_measure_background.py` | Công cụ đo bằng adb + 22 test (chạy trong `check.py`) | D-41 |

---

## 5. Đã hoàn thành

| # | Hạng mục | Bằng chứng |
|---|---|---|
| 1 | Toàn bộ mã module `workspace` (9 lớp Java, manifest, 2 layout, drawable, strings) | **[S]** XML hợp lệ; ngoặc cân bằng; không thiếu string/id; đủ 9 lớp |
| 2 | Cài APK từ file + nhân bản app đã cài + mở/dừng/gỡ | Code xong; **[?]** chạy thật |
| 3 | Foreground service + WakeLock + WifiLock + `specialUse` đúng cho Android 14+ | Code xong; chọn type dựa trên **[R]** |
| 4 | ProcessPinner | Code xong; cơ sở lý thuyết **[R]**; hiệu quả **[?]** |
| 5 | Miễn trừ pin + trang tự khởi động theo hãng | Code xong; **[?]** trên máy thật |
| 6 | `launch()` chịu được cả hai kiểu trả về của `launchApk` | Phát hiện từ tra cứu: README các fork mâu thuẫn **[R]** |
| 7 | Màn hình Chẩn đoán (importance `:pN`, API thật, stub) | Code xong; chưa chạy **[?]** |
| 8 | Workflow CI (ma trận 2 ABI, inspect, release theo tag) | **[S]** YAML + `bash -n` từng bước |
| 9 | `overlay.sh` tự sửa import theo package thật | **[S]** chạy thử trên core giả, chạy 2 lần vẫn đúng |
| 10 | Tra cứu giới hạn nền tảng/quyền/tương thích | Mục 7–10, nguồn ở mục 13 |
| 11 | Chế độ game: overlay đen, hồ sơ từng game, tự dừng (giờ/pin/nhiệt), mute có khôi phục, phát hiện đứng hình (CPU), cảnh báo tiến trình chết, báo cáo phiên, khôi phục phiên khi dịch vụ dựng lại | Code xong; **[S]** cross-check mọi lời gọi giữa các lớp; **[?]** chạy thật |
| 12 | Hẹn giờ hằng ngày + watchdog dựng lại dịch vụ | Code xong; **[?]** |
| 13 | Nhiều không gian (3 userId) để chơi nhiều tài khoản | Code xong; **[?]** cô lập dữ liệu |
| 14 | Luồng cài an toàn hơn: kiểm ABI 32/64, dung lượng, nhận XAPK 1 APK, thanh tiến trình, chọn không gian, cảnh báo anti-cheat | Code xong; **[?]** |
| 15 | UX: tìm kiếm, giao diện tối, tiếng Anh, thanh trạng thái game ở màn hình chính | **[S]** XML hợp lệ, chuỗi vi/en đồng bộ |
| 16 | Chẩn đoán chạy nền thread (không chặn UI), thêm CPU/pin/nhiệt/thermal/lịch | Code xong; **[?]** |
| 17 | `testguest` + CI build và xuất artifact | **[S]** YAML; **[?]** build |
| 18 | Kiểm tĩnh mở rộng: XML, chuỗi 2 ngôn ngữ, id layout, ngoặc, tham chiếu chéo giữa lớp, manifest, overlay dry-run 2 module; **bắt và sửa 2 lỗi thật** (dấu `:` trong tên bước YAML; `%` trần trong chuỗi) | Chạy trong sandbox |
| 19 | Nhật ký vòng + crash handler + `ExitReasons` + chia sẻ báo cáo qua `ShareProvider` | Code xong; **[?]** chạy thật |
| 20 | Xem trước APK (chữ ký SHA-256, quyền nhạy cảm, thành phần hệ thống), cảnh báo ghi đè/hạ phiên bản, cài hàng loạt, nhận APK từ trình quản lý file (VIEW/SEND) | Code xong; **[?]** |
| 21 | Đổi tên app ảo, phím tắt ngoài màn hình chính, xuất file APK | Code xong; **[?]** |
| 22 | Màn hình thiết lập lần đầu + tuyên bố phạm vi trong app | Code xong; **[S]** layout/chuỗi |
| 23 | Chẩn đoán thêm: lý do tiến trình thoát, vị trí dữ liệu engine, 15 dòng nhật ký cuối | Code xong; **[?]** |
| 24 | Test đơn vị (21 test, chạy thật bằng runner mini) cho hàm thuần; cấu hình Gradle `testOptions` | Viết xong; **chưa chạy [?]** |
| 25 | CI: job `checks` chặn build; unit test, lint, `apk_report`, artifact `reports` | **[S]** YAML + `bash -n` |
| 26 | `check.py` được kiểm bằng **thử đột biến**: 12 lỗi cố ý (sai số tham số, hàm không tồn tại, thiếu chuỗi, `%` trần, id sai, ngoặc lệch, YAML hỏng, component ma, lệch `%n$`, `dataSync`) đều bị bắt | Chạy trong sandbox |
| 27 | `apk_report.py` thử trên ELF thật (4 KB, vá 16 KB, 32-bit) | Chạy trong sandbox |
| 28 | **Biên dịch thật** toàn bộ mã bằng `javac` + stub; 19 test đơn vị chạy thật và đạt; đột biến 8/8 bị bắt | Chạy trong sandbox (không phải Android SDK) |
| 29 | Hook app ảo qua `AppLifecycleCallback` (mã sinh thích ứng) + kênh IPC LocalSocket + sổ đăng ký pid → game | Code xong, biên dịch được; **[?]** chạy thật |
| 30 | Chế độ Màn hình mờ (không cần overlay) và lệnh PiP thử nghiệm | Code xong; **[?]** |
| 31 | Sao lưu/khôi phục dữ liệu game theo bố cục đã xác nhận + tự sao lưu ra SAF + khôi phục từ file (kể cả máy mới nếu có kèm APK) | Code xong; hàm thuần có test; **[?]** chạy thật |
| 32 | Ghim thêm `:daemon`; `Engine.stop` giết thẳng pid đã biết khi lõi không có hàm dừng | Code xong; **[?]** |
| 33 | Lưu trace ANR (văn bản) và tombstone crash native (protobuf, trích chữ) từ `ApplicationExitInfo`, đưa vào báo cáo chia sẻ | Code xong; **[?]** |
| 34 | Giao diện: thẻ bo góc, nút chính màu nhấn (style Material của framework, không thêm thư viện) | **[S]** XML hợp lệ |
| 35 | Nghiên cứu: màn hình ảo (VirtualDisplay) không khả thi cho trường hợp này (F-20); Material/AndroidX hoãn có lý do (F-19) | Mục 8 |
| 36 | `ScreenPower` + màn hình hướng dẫn trong hồ sơ game (lệnh ADB cho đúng đường dẫn APK, sao lưu lệnh, mở Tùy chọn nhà phát triển) | Code xong, biên dịch được, hàm thuần có test; **chưa chạy trên máy thật [?]** |
| 37 | Theme tự sáng/tối + màu động cho Android 10+ không thêm thư viện | **[S]** XML hợp lệ |
| 38 | Test đơn vị tăng lên 21, tất cả chạy thật và đạt | Chạy trong sandbox |
| 39 | Phiên 4: `Preflight`, `OemGuide` (+ nhắc OTA), `SessionStats`, `GuestMonitor`, `UpdateKeeper`, `StatusWidget`, `SettingsActivity`, `DisplayTuning`, `ThreadBoost`, `AppSort` | Biên dịch được bằng javac + stub; hàm thuần có test; **chưa chạy máy thật [?]** |
| 40 | Phiên 4: ghim chọn lọc theo game, tự mở lại game, nhắc phiên > 12 giờ, `onTrimMemory`, dự phòng khi Android chặn FGS từ nền, sắp xếp/lọc danh sách + trạng thái đang chạy, StrictMode bản debug | Như trên |
| 41 | Phiên 4: test đơn vị tăng lên **45**; thử đột biến 7/7 bắt được (một đột biến sống sót lúc đầu → thêm test ngưỡng nhóm chờ → bắt được) | Chạy trong sandbox |
| 42 | Phiên 4: `measure_background.py` + 22 test Python; testguest ghi dòng `ident`; chạy thử `run`/`isolation` bằng adb giả | Sandbox không có thiết bị |
| 43 | Phiên 4: `build.gradle` nhận `-PversionCode/-PversionName` + khóa ký tùy chọn; CI nạp khóa từ Secrets, xác minh chữ ký/ABI, cảnh báo debug key, ghi chú phát hành tự động | **[S]** YAML + `bash -n`; Gradle/CI chưa chạy [?] |
| 44 | Phiên 7: `ApkSigner` (APK Scheme v2, Java thuần) + tích hợp vào ghép split; `apksigner` thật xác minh | **[V]**; **[?]** `PackageParser` thật |
| 45 | Phiên 7: `UpdateChecker`/`UpdateFlow`/`MiniJson` (cập nhật trong app, mặc định tắt, HTTPS + allowlist + sha256) | **[V]** biên dịch + 10 test; **[?]** đường mạng thật |
| 46 | Phiên 7: `TrashBin` + `UndoBar` + `BottomSheet` + Chi tiết/Quyền (`PermissionBridge`) + gợi ý "Truy cập mọi tệp" (`StorageAccess`) + Google services/xóa không gian + `Engine.clearData/deleteSpace/gms*` | **[V]** biên dịch; **[?]** giao diện/chạy |
| 47 | Phiên 7: dựng lại workflow (JDK 21, bỏ chặng x86), `verify_real.py`, `api_audit.py`, `compile_check.py` dùng `android.jar` thật, `LICENSE`/`NOTICE`, công tắc O-11 | **[V]** `actionlint`, `aapt`, javac với lõi thật |

---

## 6. Tồn đọng (backlog có ưu tiên)

> Mỗi việc có **tiêu chí xong** để không phải đoán.

### P0 — Chặn mọi thứ khác (làm theo thứ tự)

| ID | Việc | Tiêu chí xong | Gợi ý |
|---|---|---|---|
| P0-1 | Đẩy repo lên GitHub, chạy workflow lần đầu | Cả 2 leg (arm64, arm32) build xanh **hoặc** biết chính xác lỗi | Bảng xử lý lỗi ở README; lỗi hay gặp: import/hàm không tồn tại (sửa `Engine.java`), tên module lõi, NDK/CMake, manifest merger (thêm vào `tools:replace`) |
| P0-2 | ~~Đọc artifact `core-inspection`~~ **Làm xong theo cách khác ở phiên 5**: clone thẳng source thật (mạng tới GitHub có sẵn trong sandbox) thay vì chờ artifact CI — đáng tin hơn vì là nguồn gốc, không phải bản trích xuất. Bảng mục 13.2/13.7 đã điền xong với cột "Xác nhận từ source", `Engine.java` đã sửa khớp. **Còn thiếu**: artifact CI (nếu P0-1 chạy) vẫn nên đối chiếu 1 lần cho chắc, vì core có thể đổi giữa lúc đọc (phiên 5, 2026-11-14) và lúc build thật | Bảng 13.2 điền xong; phiên 7 xác nhận HEAD vẫn là SHA `89b5983` (không trôi) | Xem mục 13.7, 19 |
| P0-3 | Cài APK arm64 lên **1 máy thật**, thêm 1 app thử, mở được | Ghi kết quả vào bảng mục 14 | Bắt đầu với Pixel/ROM gần AOSP trước, Xiaomi/Samsung sau |
| P0-4 | Đo ProcessPinner | Bảng A/B: importance `:pN` sau 15 phút tắt màn hình, **ghim BẬT vs TẮT** | Dùng nút Chẩn đoán + lệnh mục 11. Nếu ghim BẬT vẫn `CACHED` → ProcessPinner vô hiệu, xem phương án ở mục 8 |
| P0-5 | **Chạy** app thử `testguest` (đã viết, CI build ra `testguest.apk`): cài vào workspace, theo dõi bộ đếm wall/worker/game | Có số đo tắt màn hình 30 phút ở mục 16.5 | Cài vào Không gian 1 trước |
| P0-6 | Kiểm tra **cô lập giữa các không gian**: cài `testguest` ở Không gian 1 và 2, so `androidId`, `filesDir`, `heartbeat.log` | Hai không gian có dữ liệu riêng; ghi kết quả vào mục 11 | Nếu trùng → không quảng cáo "đa tài khoản" |
| P0-7 | Đo **chế độ game**: `testguest` × (ghim tắt / ghim bật / màn hình đen) × 30 phút, đọc wall/worker/game + CPU `:pN` + pin + nhiệt, ≥ 1 máy OLED và 1 máy LCD | Bảng mục 16.5 đầy đủ | Nếu game vẫn đứng khi màn hình đen → xem 16.4 |
| P0-8 | Chạy **Chẩn đoán** sau một đêm có game chạy: đọc mục "Lý do tiến trình thoát" (tìm **FREEZER**, LOW_MEMORY, SIGNALED) và "Vị trí dữ liệu" | Dán kết quả vào mục 11 và 13; xác nhận hoặc bác giả thuyết đóng băng/OEM kill | Đây là bằng chứng trực tiếp nhất cho AC-3 |
| P0-9 | Thử **hook + IPC + sao lưu** trên máy thật: Chẩn đoán phải liệt kê game ở mục "App ao dang ket noi IPC"; sao lưu rồi khôi phục một game; thử Màn hình mờ | Bảng kết quả mục 11 (V–Y); `GuestGenerated.AVAILABLE=true` | Nếu mục IPC trống: đọc `inspect/` của CI, kiểm `AppLifecycleCallback` thật |
| P0-10 | ~~Xác minh stub Android~~ **Làm xong phần xác minh chữ ký ở phiên 7 [V]:** mã biên dịch sạch với `android.jar` API 35 thật và với source lõi thật; `compile_check.py` nay dùng `android.jar` thật (stub chỉ còn là phương án dự phòng, đã lạc hậu so với mã phiên 7). **Còn lại:** Gradle/AGP thật (CI) | CI build xanh | `python3 scripts/verify_real.py --fetch` |
| P0-11 | **Thử `ScreenPower`** trên ≥ 2 máy (một Android ≤13, một Android 14+): chạy lệnh TẮT, mở `testguest`, đo wall/worker/game sau 30 phút | Bảng: panel tắt + chế độ "Màn hình mờ" → game ≈ wall | Nếu Android 14+ lỗi: thử `LD_PRELOAD` (danh sách trong G-18) hoặc `service call SurfaceFlinger 20000 i64 <id> i32 0` (Qualcomm) |

### P1 — Sau khi P0 xong

| ID | Việc | Tiêu chí xong |
|---|---|---|
| P1-1 | ~~Ghim `CORE_REF` bằng SHA~~ **Xong ở phiên 5**: `.github/workflows/build.yml` mặc định dùng `89b59836c66f173756a4ae258cf379a957649820` (đọc trực tiếp, không qua summary CI vì CI chưa chạy lần nào); `workflow_dispatch` vẫn cho đổi tay. Áp dụng luôn cho phụ thuộc `APKEditor` (V1.4.9, sha256 `a9cd40df81…`, xem mục 13.7) | Build tái lập được, không vỡ khi core đổi — **còn treo**: chỉ tái lập được phần "nguồn", chưa ai build thật bằng Gradle để xác nhận reproducible toàn phần |
| P1-2 | ~~Xác nhận `stopPackage` / `uninstallPackageAsUser` có thật~~ **Xong ở phiên 5**: cả hai có thật (đọc source, không phải suy luận); `stopPackage` gọi thẳng `BProcessManagerService.killPackageAsUser`. `BActivityManager.killAppByPkg` (phương án dự phòng cũ) **xác nhận KHÔNG tồn tại**, đã bỏ khỏi `Engine.stop()` | Nút "Dừng" thực sự tắt tiến trình — **còn treo**: hành vi THẬT (tiến trình có chết hẳn không, hay chỉ đổi trạng thái) chỉ máy thật mới trả lời được |
| P1-3 | Kiểm cách core xử lý `requestPermissions` của guest; bổ sung luồng cấp quyền nếu cần. **Đọc một phần ở phiên 5**: `IPermissionManagerProxy` làm quyền của guest LUÔN được coi là đã cấp (không hiện hộp thoại thật cho guest); quyền nguy hiểm (camera/mic/vị trí) chỉ hoạt động nếu **host** (Workspace) đã tự xin quyền đó trước — không có cầu nối "guest xin → hộp thoại hệ thống hiện ra" | Guest xin CAMERA/LOCATION → hộp thoại hiện đúng, quyền được cấp cho host — **còn treo**: hành vi thật khi host CHƯA có quyền (guest có tự crash, hay coi như từ chối vĩnh viễn?) cần máy thật |
| P1-4 | ~~Kiểm core có build `.so` armv7 không~~ **Xác nhận bằng SOURCE THẬT ở phiên 5** (mạnh hơn [R] trước đó dựa README): `Bcore/build.gradle` và `app/build.gradle` chỉ có `abiFilters 'arm64-v8a', 'armeabi-v7a'` — **README của core quảng cáo sai** là có hỗ trợ `x86` (không có trong build.gradle thật, không tin README phần này nữa); giữ leg `armeabi-v7a` là đúng | Có `.so` armv7 trong APK 32-bit |
| P1-5 | Kiểm thông báo của guest (hiện không, kênh thông báo, trên Android 13+) | Guest đẩy được notification |
| P1-6 | Thử FCM cho một app dùng push thật | Ghi rõ có/không (xem mục 9) |
| P1-7 | Thử trên Android 14, 15, 16, 17 | Bảng mục 14 đủ các hàng |
| P1-8 | **PiP**: code xong (manifest proxy + lệnh `pip`), cần thử game thật xem còn chạy khi vào PiP không | Ghi rõ chạy/không với ≥ 3 game (G-13) |
| P1-9 | ~~Xem **quyền + chữ ký** trước khi cài~~ **Code xong (phiên 3, đợt 2)** | Cần thử trên máy thật (mục 11-Q) |
| P1-10 | **Sao lưu/khôi phục** dữ liệu guest: **code xong (D-30)** | Backup rồi restore sang máy khác chạy được (P0-9) |
| P1-11 | ~~Crash handler + ring buffer log + xuất báo cáo~~ **Code xong** (không dùng FileProvider, D-20) | Cần thử trên máy thật (mục 11-T) |
| P1-12 | Hạ tầng test: **đã có** biên dịch thật bằng stub, 19 test chạy thật, `check.py`, lint/size/16KB trong CI. **Còn thiếu**: instrumentation, emulator trong CI, build bằng Android SDK thật | Bật bắt buộc test/lint sau khi CI xanh (P1-16) |
| P1-13 | Native: kiểm căn 16 KB (`apk_report.py`), `ExitReasons` + lưu tombstone/ANR **đã có**; chưa có Breakpad (không cần nếu tombstone đọc được) | Chạy trên máy 16 KB thật; xem `crash/native-*.txt` có nội dung không |
| P1-14 | Nền UI: **đã có** thiết lập lần đầu, tìm kiếm, theme tối, i18n; **chưa có** Material/RecyclerView/ViewModel/edge-to-edge | Cân nhắc rủi ro phụ thuộc vào build của core |
| P1-15 | Cô lập từng guest thật sự (keystore alias, WebView dir, provider authority, clipboard): đọc source core rồi lập bảng "engine đã/chưa xử lý". **Xong phần đọc source ở phiên 5 + 9**: ContentProvider authority **CÓ** cách ly cấu trúc (mỗi :pN một authority riêng); WebView dir **CÓ, đã đọc hết** (mục 21.1) — `BActivityThread` gọi `WebView.setDataDirectorySuffix(userId:pkg:processName)` KHÔNG ĐIỀU KIỆN cho mọi guest trên Android 9+ (API 28+, tức hầu hết thiết bị minSdk 26 của dự án này); Keystore **KHÔNG** thấy lớp proxy nào (rủi ro thật, không phải suy luận, xác nhận lại ở phiên 9); `ANDROID_ID` **KHÔNG** cách ly (trả nguyên giá trị host). **Phát hiện mới phiên 9 (O-16)**: cùng lúc với việc cách ly WebView dir đúng, core lại ÉP BẬT `setAllowFileAccessFromFileURLs`/`setAllowUniversalAccessFromFileURLs` cho MỌI WebView của MỌI guest — xem 21.2 | Bảng đầy đủ ở mục 13.7 + 21 — còn treo: Android 8/8.1 (API 26/27, dưới ngưỡng `>= P` của core) KHÔNG được cách ly WebView dir; keystore alias collision và hành vi thật trên máy vẫn cần P0-6 |
| P1-16 | Sau khi CI xanh lần đầu: bỏ `continue-on-error` của unit test và lint; chốt `APK_BUDGET_MB` theo kích thước thật | CI đỏ khi test/lint hỏng |
| P1-20 | Cài một **XAPK/APKS có split thật** (nhỏ) trên máy thật; kiểm app mở được, chữ ký ghép được `PackageParser` chấp nhận (G-33/G-34) | Mở được, hoặc biết chính xác lỗi (bắt đầu bằng app nhỏ, không phải game 2 GB) |
| P1-21 | Chạy workflow với `strip_core_spoof=true` rồi cài thử (G-36); quyết định giữ/gỡ O-11 theo mục tiêu sản phẩm | NDK build xong; có quyết định ghi vào mục 12 (quyết định là của chủ dự án) |
| P1-22 | Tạo release thử trên kho thật và bấm *Kiểm tra cập nhật* (G-37) | Tải về, sha256 khớp, trình cài mở (cần tag `v*` + secrets ký thật, P1-19) |
| P1-17 | Thiết kế sao lưu/khôi phục dữ liệu dựa trên "vị trí dữ liệu" thực đo được | Backup rồi restore sang máy khác chạy được |
| P1-18 | **Thử các tính năng phiên 4 trên máy thật** (G-20…G-29, mục 18.2): Preflight, nhóm chờ, boost luồng, `fps`/`lowres`, tự mở lại, widget, cập nhật giữ dữ liệu | Mỗi giả thuyết G-xx ghi rõ đúng/sai vào mục 18.2 |
| P1-19 | **Đặt secrets khóa ký** (`VSPACE_KEYSTORE_BASE64`, `_PASSWORD`, `VSPACE_KEY_ALIAS`, `_KEY_PASSWORD`) rồi đẩy tag `v*` | APK phát hành không còn ký debug key (CI hết cảnh báo) |
| P1-23 | **OBB**: `ObbImporter` chép OBB từ XAPK. **Đích đã sửa đúng theo source thật ở phiên 5** (G-31 giải xong phần đường dẫn): gốc là `context.getExternalFilesDir("blackbox")` (gốc NGOÀI, khác gốc nội bộ của `GuestBackup`) + `storage/emulated/<không gian>/Android/obb/<gói>/`, đọc từ `BEnvironment.getExternalObbDir`/`getExternalUserDir` thật, không còn là đoán | Một game có OBB chạy được sau khi cài từ XAPK — còn treo: core có THẬT SỰ đọc OBB từ đó khi game chạy hay không, chỉ máy thật mới xác nhận |

### P2 — Độ bền nền

- Watchdog `AlarmManager.setExactAndAllowWhileIdle` để dựng lại service nếu bị kill; receiver `CONNECTIVITY` để kiểm tra sức khỏe sau khi có mạng lại. **[R]** (kinh nghiệm cộng đồng; chưa thử)
- ~~Phát hiện Samsung "sleeping apps"~~ **Hướng dẫn riêng cho Samsung đã có (`OemGuide`, phiên 4)**; việc phát hiện tự động không có API công khai nên không làm.
- ~~Màn hình hướng dẫn theo hãng + nhắc khóa thẻ đa nhiệm~~ **Code xong (phiên 4, `OemGuide`)**, nội dung bước là [R].
- ~~Phát hiện miễn trừ pin bị reset sau OTA~~ **Code xong (phiên 4, `OemGuide.checkOta`)**: so `Build.FINGERPRINT` lúc còn miễn trừ với hiện tại.
- ~~Chọn app nào cần ghim~~ **Code xong (phiên 4, D-36)**: công tắc "Ghim tiến trình" trong hồ sơ từng game.
- ~~Theo dõi RAM/pin từng guest~~ **RAM + CPU đã có (`GuestMonitor`)**; pin theo tiến trình không đọc được nên dùng CPU thay thế, kèm pin tụt mỗi giờ theo phiên (`SessionStats`).
- Một chạm không cần PC: tích hợp **Shizuku** hoặc tự cài ADB-client nội bộ (libadb-android) để chạy `ScreenPower` ngay từ app; cần cân nhắc phụ thuộc và độ phức tạp ghép nối.
- **Vá lõi** để khởi chạy app ảo trên `VirtualDisplay` (thêm hàm `launchOnDisplay(pkg, userId, displayId)` truyền `ActivityOptions`); chỉ làm khi đã fork lõi (F-20).

### P3 — Dài hạn / chiến lược

- Chế độ thay thế **work profile** (kiểu Shelter/Island) cho app cần tương thích 100% (mục 9).
- Nâng `targetSdk` khi core hỗ trợ; i18n; Material UI; khóa key phát hành; test tự động.
- Đánh giá engine khác nếu NewBlackbox không đạt (mục 12).

---

## 7. Kỹ thuật có cơ sở (chưa phải "đã thành công trên máy")

| ID | Kỹ thuật | Cơ sở | Mức |
|---|---|---|---|
| T-1 | Tiến trình bị bind (có `BIND_AUTO_CREATE`) luôn quan trọng ít nhất bằng tiến trình client; không vào cached trước client | Tài liệu Android về vòng đời tiến trình; tài liệu AOSP về cached apps freezer | **[R]** |
| T-2 | Tiến trình cached bị **đóng băng sau 10 giây** (Android 11 QPR3+); cách xử lý do chính AOSP nêu: đưa tiến trình lên trạng thái không-cached (ví dụ bound foreground service) | AOSP cached-apps-freezer | **[R]** |
| T-3 | Dùng `specialUse` để khởi động FGS từ `BOOT_COMPLETED` trên Android 15 (các type bị chặn: dataSync, camera, mediaPlayback, phoneCall, mediaProjection, microphone) | Android 15 behavior changes | **[R]** |
| T-4 | Android 17: tương tác âm thanh nền cần Activity hiển thị **hoặc** FGS không phải `SHORT_SERVICE`; FGS của ta thỏa điều kiện cơ bản | Android 17 background audio hardening | **[R]** |
| T-5 | `targetSdk` 28 cài được trên Android 14–17 (ngưỡng chặn 23→24, giữ nguyên ở 16 và 17) | bayton.org ma trận minimum targetSdk | **[R]** |
| T-6 | APK **bên trong** không gian ảo không đi qua PackageManager nên **không dính** chặn `INSTALL_FAILED_DEPRECATED_SDK_VERSION` | Suy luận từ kiến trúc | **[?]** |
| T-7 | Miễn trừ tối ưu pin + autostart + khóa đa nhiệm là điều kiện cần trên Xiaomi/Oppo/Vivo/Huawei/Samsung | dontkillmyapp.com và nhiều bài thực nghiệm | **[R]**, nhưng *vẫn có máy kill dù đã làm hết* |
| T-8 | Tiến trình `:pN` do AMS quản lý (khai trong manifest) nên **không phải phantom process**; giới hạn phantom (32, toàn hệ thống) chỉ áp cho tiến trình con fork/exec | Tài liệu phantom process | **[R]** (không ảnh hưởng ta, trừ guest tự fork tiến trình con) |
| T-9 | Tự dò package thật của `BlackBoxCore`/`ClientConfiguration` bằng script thay vì hardcode | Dry-run | **[S]** |
| T-10 | Xác minh cài đặt bằng danh sách `getInstalledApplications` thay vì dựa vào giá trị trả về (vì kiểu trả về mâu thuẫn giữa các tài liệu) | Phát hiện mâu thuẫn ở mục 13 | **[S]** (logic); **[?]** (chạy) |

---

## 8. Kỹ thuật lỗi / thất bại / không hiệu quả / bị loại — ĐỪNG LẶP LẠI

### 8.1 Đã loại sau khi tra cứu

| ID | Kỹ thuật | Vì sao loại | Nguồn |
|---|---|---|---|
| F-1 | Bind với cờ **`BIND_ABOVE_CLIENT`** để "ghim mạnh hơn" | Trên Android 14/15 nó kẹp oom_adj của **chính client** về 900 (cached) khi client không ở foreground, kể cả khi client có FGS → host bị **đóng băng**, thông báo vẫn hiện nhưng tiến trình không làm gì | nextcloud/Android-SingleSignOn #1081 |
| F-2 | FGS type **`dataSync`** | 6 giờ/24 giờ rồi bị hệ thống gọi `onTimeout`, không đáp ứng thì crash; bị chặn khởi động từ boot | Android 15 behavior changes |
| F-3 | Dựa vào quyền **`SYSTEM_ALERT_WINDOW`** để mở activity/FGS từ nền | Với app target Android 15 miễn trừ này hẹp lại: phải *đang có cửa sổ overlay hiển thị* | Android 15 behavior changes |
| F-4 | Tự mở lại activity của guest từ service nền sau khi guest chết | Bị chặn bởi Background Activity Launch (Android 10+, Android 17 mở rộng sang `IntentSender`). Thay bằng: thông báo nhắc người dùng | Android 17 behavior changes |
| F-5 | **Tin `Docs.md` của NewBlackbox** và README các fork | Mâu thuẫn nội bộ: `InstallResult` vs `boolean`, `launchApk` trả `boolean` vs `Intent`, `getInstalledApps` vs `getInstalledApplications`, `uninstallPackage` vs `uninstallPackageAsUser`, ghi "Android 8.0+, root recommended" trong khi README nói "không cần root"; giọng văn giống tài liệu sinh tự động. **Chỉ tin source thật** | Đối chiếu trực tiếp |
| F-6 | Chỉ dùng WakeLock/Handler để giữ nền | Vô tác dụng nếu app chưa được miễn trừ pin (Doze bỏ qua), và không ngăn được OEM kill | dontkillmyapp |
| F-7 | Tích hợp core bằng AAR (`fileTree`) | Mất dependency bắc cầu của core; build vỡ khó đoán | Suy luận, README core chỉ đưa ví dụ tối thiểu |
| F-8 | Bật R8/minify cho bản release | Engine ảo hóa dựa vào reflection | Suy luận; chưa thử |
| F-9 | Mặc định `targetSdk ≥ 34` | BlackBox khuyên ≤28; target cao bật thêm ràng buộc FGS type, thông báo, bộ nhớ ngoài | README core |
| F-11 | Điều chỉnh độ sáng bằng `Settings.System` hoặc `SCREEN_BRIGHT_WAKE_LOCK` | Để lại màn hình tối nếu tiến trình chết; wake lock loại này đã deprecated. Dùng độ sáng theo cửa sổ + `FLAG_KEEP_SCREEN_ON` | Tài liệu Android |
| F-12 | `FLAG_NOT_TOUCHABLE` cho overlay | Chạm xuyên xuống game, người dùng vô tình bấm trong túi | Thiết kế |
| F-13 | Bắt vòng đời activity guest bằng `registerActivityLifecycleCallbacks` của `SpaceApp` | Guest có `Application` riêng nên callback của host không nhận. **ĐÃ GIẢI QUYẾT bằng `AppLifecycleCallback` của lõi (D-26): đăng ký trên Application THẬT của app ảo** | Nghiên cứu đợt 3 |
| F-14 | Alarm chính xác cho watchdog | Cần quyền `SCHEDULE_EXACT_ALARM` khi target cao mà không cần độ chính xác | D-16 |
| F-15 | Ghép split APK / chép OBB từ XAPK | **Đã làm (phiên 4b):** ghép bằng APKEditor tùy chọn qua reflection (D-42, `SplitMerger`), chép OBB (D-43, `ObbImporter`). Còn [?]: jar chạy trên Android, engine nhận APK ghép chưa ký (G-30), đường dẫn OBB (G-31) | Mục 18.5; chưa chạy máy thật |
| F-16 | `FileProvider`/androidx để chia sẻ file | Thêm phụ thuộc vào build của core mà không cần: `ShareProvider` ~90 dòng đủ dùng (D-20) | Thiết kế |
| F-17 | Breakpad/mã native để bắt crash native | Thay bằng `ApplicationExitInfo.getTraceInputStream()` (tombstone protobuf từ Android 12; trace văn bản cho ANR). Đã cài (D-21, mục 33) | Tài liệu `ApplicationExitInfo` |
| F-18 | Sao lưu dữ liệu guest bằng cách nén thư mục đoán | **Đã làm đúng cách (D-30)** sau khi xác nhận bố cục thư mục từ tài liệu kiến trúc của lõi (DeepWiki) | Nghiên cứu đợt 3 |
| F-19 | Viết lại UI sang Material/RecyclerView/ViewModel ngay | Không thể thử UI trong sandbox; rủi ro phụ thuộc lớn hơn lợi ích. **Phương án khác đã làm:** theme DeviceDefault.DayNight (D-34) cho dark tự động + màu động | Hoãn (P1-14) |
| F-20 | Chạy game trên **VirtualDisplay** do app tạo để màn hình thật tắt mà game vẫn render | Về nguyên tắc AOSP cho app chạy activity **của chính nó** trên màn hình ảo **do nó tạo**. Nhưng engine khởi chạy app ảo qua máy chủ (`DaemonService`) rồi thay `ComponentName` bằng activity proxy `P0…P49`, nên phía app không gắn được `ActivityOptions` (launchApk trả boolean, tự khởi chạy); Android không cho chuyển task đang chạy sang màn hình khác; màn hình ảo không có cách tương tác để đăng nhập. **Chỉ khả thi nếu vá lõi** (backlog P2). Phương án thay thế đã làm: `ScreenPower` (D-33) | AOSP activity-launch policy + kiến trúc proxy của lõi | **Tra cứu bổ sung (phiên 4b):** thử nghiệm trên Android 15 thật do người khác công bố cho thấy app thường không gắn được `ActivityOptions.setLaunchDisplayId` lên màn hình ảo do chính nó tạo (SecurityException), và màn hình ảo PUBLIC cần token MediaProjection hoặc quyền hệ thống; các công cụ thật dùng một tiến trình quyền shell (adb/app_process, kiểu Shizuku) để tạo và khởi chạy. Vẫn P3: cần helper quyền shell + vá lõi để chọn displayId.
| F-21 | `cmd display power-off` để tắt panel | **KHÔNG dùng được cho mục tiêu này**: đi qua đường yêu cầu nguồn điện màn hình nên Android thôi coi màn hình là bật (scrcpy từ chối cách này, issue #5530 theo một dự án bot game). Cách đúng là hàm ẩn `SurfaceControl.setDisplayPowerMode` như scrcpy; đã cài trong `ScreenPower` (D-33) | scrcpy, dự án bot game |
| F-22 | IPC giữa tiến trình chính và `:pN` bằng broadcast hoặc ContentProvider | Engine hook ActivityManager trong tiến trình app ảo, có thể chuyển hướng vào hệ thống ảo; dùng LocalSocket (D-27) | Suy luận kiến trúc; chưa kiểm |
| F-23 | `Window.setFrameRate(30, FIXED_SOURCE)` như tech.txt mô tả | Không có hàm này trên `Window`. Có `Surface.setFrameRate` (API 30, cần có `Surface`) và `LayoutParams.preferredRefreshRate`/`preferredDisplayModeId`. Đã dùng hai cách đó (`GuestHooks.applySurfaceTuning`, `DisplayTuning`) | Tra cứu API; G-22, G-24 |
| F-24 | Hook `Display.getRefreshRate()` trả 60 cho game trong khi cửa sổ chạy 30 Hz | Cần hook trong tiến trình app ảo (vá lõi/native), không làm được từ Java phía app; có thể làm vật lý game sai nhịp. Để P2 khi đã fork lõi | tech.txt; chưa làm |
| F-25 | Phát hiện LCD hay OLED bằng heuristic để ước lượng pin | Không có API công khai đáng tin. Thay bằng **đo pin tụt mỗi giờ thật** từng phiên (`SessionStats`) | Phiên 4 |
| F-27 | Hộp thoại "phiên trước bị ngắt do Buộc dừng, có tiếp tục không" | Thừa và gây nhầm: khi mở lại app, `Prefs.keepAlive` còn bật nên `startKeepAlive` → `resumeIfNeeded` khôi phục phiên tự động. Chỉ cần giải thích trong tuyên bố phạm vi (đã thêm) | Đọc luồng `MainActivity.onResume` |
| F-28 | `android:enableOnBackInvokedCallback` (predictive back) | Dự án target 28; chưa kiểm hiệu quả; thêm thuộc tính mới vào manifest mà không build thật là rủi ro không cần thiết | Hoãn |
| F-29 | Ghép split APK thành một APK | ~~Không làm~~ **Làm được nhờ APKEditor (Apache-2.0, lệnh `m`), đã chạy trên Android trong AntiSplit-M**; tích hợp tùy chọn (jar do CI tải). APKEditor không ký lại APK (G-30) | Tra cứu mục 18.5; D-42 |
| F-30 | Job emulator trong CI | ~~Hoãn~~ **Đã thêm (phiên 4b):** chặng `x86` + job `emulator-smoke` (cài, mở, chờ 25 giây, kiểm không crash). Lõi có ABI `x86` nên không cần `x86_64`; emulator x86_64 chạy được app 32-bit x86. **Chưa chạy trên CI thật [?]** (G-32) | `scripts/emulator_smoke.sh`, `build.yml` |

### 8.2 Đã gặp trong phiên làm việc (lỗi quy trình)

| ID | Sự cố | Cách tránh |
|---|---|---|
| E-1 | `mkdir -p a/{b,c}` chạy dưới `/bin/sh` **không** khai triển ngoặc nhọn → tạo thư mục tên chữ `{.github`; các `cat > file` sau đó âm thầm thất bại | Dùng đường dẫn tường minh, hoặc `bash -c`. Luôn `find . -type d` kiểm tra sau khi tạo cây |
| E-9 | **Zip bàn giao phiên 6 thiếu `.github/`** (thư mục ẩn không được nén) ⇒ mất workflow; `check.py` báo thiếu `build.yml` | Nén bằng cách bao gồm thư mục ẩn; sau khi giải nén chạy `python3 scripts/check.py` |
| E-10 | README/handoff ghi **JDK 17** nhưng lõi biên dịch Java 21 (`Bcore/build.gradle`); đã tin README của lõi thay vì đọc `build.gradle` | Chỉ tin `build.gradle`/CI của lõi (AGENTS #22) |
| E-11 | `android:windowBackground` đặt bằng màu thẳng `#121212` ở `values-night` — `check.py`/stub KHÔNG bắt được, chỉ `aapt` thật bắt | Chạy `verify_real.py` sau khi sửa res (AGENTS #27) |
| E-12 | Stub Android viết tay và `check.py` cùng tin nhầm: bản stub không phủ API mới nên báo lỗi giả; ngược lại stub sai chữ ký thì báo đạt giả | Dùng `android.jar` thật (AGENTS #13) |
| E-13 | Bước CI `unittest discover` do tôi viết nhầm: `test_gen_guest_hooks.py` là script, không phải unittest ⇒ sẽ đỏ trên CI. Bắt được vì chạy thử lệnh đó trong sandbox trước khi tin | Chạy thử MỌI lệnh của workflow ở máy (hoặc `check.py` đã làm hộ) |
| E-2 | `web_fetch` bị chặn (`ROBOTS_DISALLOWED`) trên trang `tree/` của GitHub, trong khi trang `blob/` đọc được | Không đọc được mã nguồn `Bcore` qua công cụ. **Giải pháp bền vững: artifact `core-inspection` của CI** |
| E-3 | Tham số giới hạn token của `web_fetch` **không** cắt đầu ra; fetch README của fork trả về cả nghìn dòng | Tránh fetch README dài; ưu tiên `web_search` để lấy đoạn |
| E-4 | Công cụ tìm kiếm không trả về trang Issues của NewBlackbox | **[ĐÃ LÀM phiên 11]** Đọc được tab Issues bằng HTML `github.com` (API bị rate-limit nhưng trang HTML vẫn tải được bằng curl) — kết quả ở mục 23.2 |
| E-5 | (SỬA ở đợt 3) Trước đây ghi "sandbox không có `javac`" là **sai**: `which javac` rỗng nhưng JDK rút gọn có module `jdk.compiler` | Kiểm bằng `java --list-modules \| grep compiler` rồi chạy `java -m jdk.compiler/com.sun.tools.javac.Main`; xem `compile_check.py` |
| E-6 | Tên bước workflow có `: ` ("app thử: mô phỏng…") làm YAML hỏng, GitHub sẽ từ chối cả workflow | **Luôn** chạy `yaml.safe_load` + `bash -n` từng bước `run:` sau khi sửa workflow |
| E-7 | `cut -c` cắt giữa ký tự UTF-8 → công cụ trả lỗi "không phải UTF-8" | In đoạn cắt bằng Python, không dùng `cut -c` với tiếng Việt |
| E-8 | Chuỗi tài nguyên chứa `%` trần ("pin ≤ (%, 0 = tắt)") có thể bị aapt hiểu là định dạng | Diễn đạt không dùng `%`; script kiểm tra mọi chuỗi |
| E-9 | Bộ kiểm tra qua ngay lần đầu có thể là bộ kiểm tra yếu | Phải **thử đột biến** (cố ý gây lỗi, xác nhận bị bắt). Đã làm 12/12 cho `check.py` (Quy tắc mới trong `AGENTS.md`) |
| E-10 | Báo "chưa biên dịch được" qua nhiều phiên trong khi công cụ có sẵn → người dùng bị trì hoãn việc cần làm | Khi thấy công cụ "không có", **thử các đường khác** (`java -m`, `python -m`, `find`) trước khi kết luận; ghi bằng chứng vào tài liệu |
| E-11 | Stub Android viết theo trí nhớ có thể sai chữ ký (ví dụ: lúc đầu `Uri` chưa là `Parcelable`, `Cursor` chưa là `Closeable`, thiếu `android.R`) | Mỗi lần dùng API Android mới phải thêm/kiểm stub; lỗi lạ ở stub khác lỗi ở mã dự án; CI build thật là trọng tài cuối |

### 8.3 Giả thuyết còn treo (không phải thất bại, nhưng đừng coi là đúng)

- ProcessPinner làm `:pN` thoát khỏi `CACHED` **[?]** → đo ở P0-4.
- Stub service `ProxyService$Pn` chấp nhận bind mà không làm guest crash **[?]**.
- `launchApk` thật sự mở được app ảo trên host target 28 **[?]**.
- Danh sách component OEM trong `PowerHelper` còn đúng trên ROM hiện hành **[?]**.
- Đặt `useLegacyPackaging` là cần/đủ cho engine native **[?]**.

---

## 9. App cài trong không gian ảo có chạy bình thường như cài ngoài không?

**Trả lời ngắn: không hoàn toàn.** App chạy *trong tiến trình của host dưới UID của host*, được engine "đánh lừa" rằng nó đã được cài. Phần lớn app thuần client chạy được; app dựa vào thành phần hệ thống, bảo mật cao, hoặc dịch vụ Google thì không đáng kỳ vọng.

> **Với game: xem mục 16.** App chat có socket/thread tự chạy nên giữ tiến trình là đủ; game chạy logic trong vòng lặp khung hình sẽ đứng khi tắt màn hình thật dù tiến trình còn sống.

| Nhóm | Dự kiến | Lý do / ghi chú | Mức |
|---|---|---|---|
| App thuần client: chat qua socket/websocket, công cụ, trình đọc, game offline, bot, tải xuống | **Chạy được**, và là nhóm hưởng lợi nhất từ giữ nền | Có service/thread/socket nên tiến trình có việc để làm khi tắt màn hình | **[?]** |
| **Push FCM** | **Rủi ro cao** | Cần Google Play Services nhận diện *package của guest*. VirtualApp quảng cáo "Google services" như tính năng của **bản thương mại**; người dùng Parallel Space thường báo push lỗi. `Docs.md` của core tuyên bố có "mock GMS" nhưng đó là tài liệu không đáng tin (F-5). **Cách né:** app dùng websocket/polling, giữ nền để socket sống | **[R]** + **[?]** |
| Camera, mic, vị trí, bộ nhớ | Chạy **nếu** quyền được khai trong manifest host và cấp cho host | Mục 10 | **[?]** |
| Phát âm thanh nền | Chạy nếu có FGS (ta có) | Android 17 yêu cầu FGS không phải `SHORT_SERVICE` | **[R]** |
| WebView/trình duyệt, đăng nhập Google, WorkManager/JobScheduler | Core tuyên bố hỗ trợ | Chỉ có trong `Docs.md` (F-5) | **[?]** |
| **Ngân hàng, ví, Play Integrity/SafetyNet, chống root/chống ảo hóa** | **Thường từ chối chạy** | SDK như Appdome phát hiện "second space/parallel app" và chặn | **[R]** |
| App khai cờ `REQUIRE_SECURE_ENV` | **Không chạy** | Parallel Space cũng đã ngừng hỗ trợ nhóm này | **[R]** |
| Thành phần cần **đăng ký với PackageManager thật**: AccessibilityService, NotificationListener, VpnService, DeviceAdmin, InputMethod, Wallpaper, AppWidget, NFC HCE, vai trò mặc định SMS/Dialer, deep link/share target từ bên ngoài, broadcast hệ thống (BOOT/SMS_RECEIVED…) | **Nhìn chung không chạy** | Hệ thống không biết guest tồn tại nên không bind/gửi tới nó; engine có thể giả lập một số thứ nhưng chưa xác nhận | Suy luận kiến trúc **[?]** |
| APK dạng split / XAPK / APKS | **Không cài được** | Engine nhận APK đơn; Shelter (work profile) cũng gặp khó với split | **[R]** (Shelter) |
| App chỉ có lib 32-bit khi host chạy 64-bit (và ngược lại) | Không chạy → dùng APK host đúng ABI | README core: "dự án phân biệt 32/64-bit" | **[R]** |
| App tự **fork tiến trình con** (exec) | Có thể bị giết khi vượt 32 phantom process toàn hệ thống (Android 12+) | Mục T-8 | **[R]** |
| Khởi động lại máy | Guest **không tự mở lại**; dịch vụ giữ nền tự bật, người dùng mở lại guest 1 lần | Hành vi chung của mọi app ảo; background-activity-launch chặn tự mở | **[R]** |
| Pin/RAM | Tốn hơn chạy ngoài (thêm engine, FGS, wakelock) | — | **[R]** |

**Lựa chọn thay thế khi cần tương thích thật:** *work profile* (Shelter/Island): app được cài thật, có UID riêng, thành phần hệ thống hoạt động. Đánh đổi: chỉ **1** work profile, cần quyền profile owner/device admin, ROM như MIUI có thể lỗi nặng, vẫn bị OEM kill. *Private Space* (Android 15+) khóa → app bị đóng băng. **[R]**

---

## 10. Giới hạn về quyền khi chạy bên trong

| # | Sự thật | Hệ quả thực tế | Mức |
|---|---|---|---|
| 1 | Guest chạy dưới **UID của host** → quyền thật = quyền host được cấp | Quyền guest cần phải **được khai trong `AndroidManifest.xml` của host** (đã khai sẵn INTERNET, CAMERA, RECORD_AUDIO, LOCATION, STORAGE…; thiếu quyền nào thì thêm) | Kiến trúc **[?]** |
| 2 | Quyền runtime được cấp **cho host** | Dùng nút "Quyền" (mở trang thông tin app) để cấp; không có cách cấp riêng cho từng guest ở mức hệ điều hành | **[?]** |
| 3 | Mọi guest thấy cùng một tập quyền | **Không** có cô lập quyền giữa các guest với nhau | Kiến trúc |
| 4 | Core có thể có hàm kiểu `setAppPermission` | Chỉ thấy trong `Docs.md` (F-5) → **không dùng cho tới khi xác nhận** | **[?]** |
| 5 | Quyền đặc quyền (SMS mặc định, readlogs, install packages…) | Host không thể có → guest cần chúng sẽ không chạy | Chung |
| 6 | **Android 15 Enhanced Confirmation Mode**: app cài ngoài Play bị hạn chế quyền nhạy cảm (Accessibility, Notification Listener…) | Host của ta (sideload) sẽ gặp; guest cần các quyền đó càng không chạy | **[R]** |
| 7 | `POST_NOTIFICATIONS` (Android 13+) thuộc về host | Thông báo của guest hiển thị như của host; với `targetSdk 28` hệ thống tự hỏi khi tạo channel đầu tiên | **[R]** + **[?]** |
| 8 | `QUERY_ALL_PACKAGES`, `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`, FGS `specialUse` | Chính sách Google Play **không** cho phép dễ dàng → dự án chỉ phù hợp **sideload** | Chung |
| 9 | `targetSdk 28` | Đổi ngữ nghĩa quyền/lưu trữ/FGS so với target cao; đổi `-PtargetSdk=34` thì phải xử lý FGS type, quyền thông báo | **[R]** |

---

## 11. Kế hoạch kiểm chứng trên thiết bị (biến **[?]** thành số đo)

Chuẩn bị: cài APK, bật "Giữ app chạy nền" + "Ghim tiến trình", chọn **Cho phép** ở hộp thoại pin, mở app thử (P0-5). Log tag: `VSpaceEngine`, `VSpacePinner`, `VSpaceKeepAlive`, `VSpaceBoot`.

| Test | Cách làm | Kết quả mong đợi | Nếu sai |
|---|---|---|---|
| **A. Cài/mở** | Thêm APK → bấm mở. `adb logcat -s VSpaceEngine` | App ảo hiện lên | Đọc stacktrace; xem `Engine.apiSurface` trong Chẩn đoán; sửa `Engine.java` |
| **B. Ghim hiệu quả** | Mở app thử → tắt màn hình 15 phút → mở Chẩn đoán → đọc importance `:pN` | `FOREGROUND_SERVICE` hoặc `SERVICE` (≤300) | `CACHED` (400) ⇒ ghim vô hiệu → kiểm stub có bind được không; xem log `VSpacePinner` |
| **B2. Đối chứng** | Lặp B nhưng tắt công tắc "Ghim tiến trình" | Dự kiến `CACHED` | Nếu vẫn ≤300 thì ghim không cần thiết; ghi nhận |
| **C. Đóng băng** | `adb shell dumpsys activity \| grep -i "Apps frozen"` (cách do AOSP nêu) và `adb shell dumpsys activity processes \| grep ":p"` | `:pN` của guest không nằm trong danh sách frozen | — |
| **D. Doze** | `adb shell dumpsys deviceidle force-idle`; theo dõi heartbeat; kiểm `adb shell dumpsys deviceidle whitelist` có package host (lệnh chuẩn AOSP, chưa chạy ở phiên này) | Heartbeat không đứt khi đã miễn trừ pin | Xem P2 (watchdog, nhắc miễn trừ) |
| **E. Heartbeat 30 phút** | App thử ghi dấu thời gian mỗi 10 giây; tắt màn hình 30 phút | Không có khoảng trống > 30 giây | Ghi lại hãng/ROM/phiên bản vào bảng dưới |
| **F. Quyền** | Guest xin CAMERA/LOCATION | Hộp thoại hiện; quyền cấp cho host | P1-3 |
| **G. Thông báo** | Guest đẩy notification | Hiện lên | P1-5 |
| **H. FCM** | Cài app dùng push thật, chờ tin khi tắt màn hình | Nhận được hoặc xác nhận không | P1-6 |
| **I. Khởi động lại** | Reboot | Dịch vụ giữ nền tự bật (thấy thông báo) | Kiểm `BootReceiver` / autostart OEM |
| **J. Android 15+ test cờ** | `adb shell am compat enable FGS_BOOT_COMPLETED_RESTRICTIONS <pkg>` rồi broadcast `BOOT_COMPLETED` | Dịch vụ `specialUse` vẫn khởi động | Đổi type |
| **K. Chế độ game 30 phút** | Cài `testguest`, bật chế độ "Màn hình đen", chờ 30 phút, thoát, đọc bộ đếm | wall ≈ worker ≈ game; CPU `:pN` > 1% | Xem 16.4 (kiểm cờ giữ màn hình, độ sáng, game pause khi mất focus) |
| **L. Đối chứng tắt màn hình thật** | Chế độ "Tắt màn hình thật", 30 phút | worker ≈ wall nhưng game << wall (xác nhận giả thuyết cốt lõi) | Nếu game ≈ wall thì chế độ B không cần cho máy đó |
| **M. Cô lập không gian** | `testguest` ở Không gian 1 và 2: so androidId/filesDir | Khác nhau | P0-6 |
| **N. Cảnh báo** | Kill một tiến trình `:pN` giữa phiên; ép CPU ≈ 0 | Thông báo "tiến trình bị dừng" / "game có vẻ đứng" | Kiểm `ProcessPinner.died`, `CpuSampler` |
| **O. Lịch** | Đặt hẹn giờ +2 phút | Phiên tự bắt đầu; ghi nhận game có tự mở hay không | Ghi rõ vào mục 16.4 |
| **P. Khôi phục** | Kill tiến trình chính giữa phiên | Dịch vụ dựng lại, overlay hiện lại, âm lượng đúng | Kiểm `resumeIfNeeded`, `vol_restore` |
| **Q. Xem trước APK** | Chọn APK thật có quyền camera/vị trí; chọn APK có AccessibilityService | Hiện tên, phiên bản, SHA-256, danh sách quyền nhạy cảm, cảnh báo thành phần hệ thống | Kiểm `ApkImporter.fillDetails` |
| **R. Hàng loạt + mở từ ngoài** | Chọn 3 APK cùng lúc; mở APK từ trình quản lý file và chọn Workspace | Một hộp xác nhận chung, một lần chọn không gian; "Đã cài X/3" | Kiểm `importUris`, intent-filter |
| **S. Phím tắt, đổi tên, xuất APK** | Menu giữ lâu: Đổi tên, Tạo phím tắt, Xuất file APK | Tên mới hiện ở danh sách; phím tắt mở đúng app; file APK xuất cài lại được | Ghi nhận launcher không hỗ trợ ghim |
| **T. Chia sẻ báo cáo** | Chẩn đoán → Chia sẻ → gửi vào email/Drive | File `.txt` đọc được, có nhật ký cuối | Kiểm `ShareProvider` (authority, grant URI) |
| **U. Lý do tiến trình thoát** | Sau một đêm, mở Chẩn đoán | Có các dòng `ApplicationExitInfo`; ghi lại có FREEZER/LOW_MEMORY/SIGNALED không | Android < 11 sẽ báo cần Android 11 |
| **V. Sao lưu/khôi phục** | Menu app → Sao lưu (kèm/không kèm APK); đổi dữ liệu trong game; Khôi phục; mở lại game | Dữ liệu quay về lúc sao lưu; thư mục `files/safety/` giữ bản cũ | Kiểm `GuestBackup.locate` (xem mục "Vi tri du lieu" của Chẩn đoán) |
| **W. Tự sao lưu** | Chọn thư mục sao lưu; bật "Tự sao lưu" trong hồ sơ game; để phiên tự kết thúc bằng giờ | Có file `vspace-<pkg>-u<n>-<giờ>.zip` trong thư mục; chỉ giữ 3 bản gần nhất; game đã bị dừng | Kiểm quyền SAF bền (`takePersistableUriPermission`) |
| **X. Hook + IPC** | Mở một game, vào Chẩn đoán | Mục "App ao dang ket noi IPC" liệt kê pid → gói → activity; `GuestGenerated: co` | Đọc `inspect/BlackBoxCore-public-methods.txt` và `AppLifecycleCallback` thật |
| **Y. Màn hình mờ + PiP** | Hồ sơ game chọn "Màn hình mờ", bắt đầu; thử nút PiP | Độ sáng xuống thấp nhất trong game, màn hình không tắt; PiP trả `ok` hoặc lý do ở Chẩn đoán | Ghi vào G-13, G-14 |
| **Z. Cache bị xóa** | (Chỉ thử trên máy thử) Xóa bộ nhớ đệm của Workspace, RỒI mở lại app ảo | Kỳ vọng mới sau phiên 5 (nguồn thật, O-9 đã sửa): app ảo **vẫn còn** vì dữ liệu không nằm trong cache; nếu kết quả thật lại MẤT dữ liệu thì phát hiện phiên 5 sai, cần đọc lại `BEnvironment` | Thử thêm "Xóa dữ liệu"/gỡ cài đặt Workspace để xác nhận ĐÓ mới là thao tác phá dữ liệu |
| **AA. Tắt hẳn panel** | Chọn "Màn hình mờ", bắt đầu; chạy lệnh TẮT của `ScreenPower` qua ADB; để 30 phút; đọc bộ đếm `testguest` | Panel tối hẳn, wall ≈ worker ≈ game; bấm nút nguồn hoặc lệnh BẬT bật lại | Ghi lỗi in ra của `ScreenPower` (cách 1/cách 2) vào G-18 |
| **Z1. Preflight** | Bật Wi-Fi/Tiết kiệm dữ liệu, bỏ miễn trừ pin, rồi bấm "Bắt đầu" ở hồ sơ game; hoặc Cài đặt → "Kiểm tra máy" | Hộp thoại liệt kê đúng từng vấn đề (G-20) | Dán báo cáo Chẩn đoán mục "Preflight" |
| **Z2. Đo tự động** | `python3 scripts/measure_background.py run --label ... --minutes 30` với testguest đang mở | Bảng Markdown + kết luận (RUNS/FRAME-LOOP-STOPPED/FROZEN/KILLED) | Nếu parse rỗng: gửi đầu ra `dumpsys` (G-29) |
| **Z3. Cô lập** | `python3 scripts/measure_background.py isolation` rồi mở testguest ở Không gian 1 và 2 | `ISOLATED` hoặc biết rõ `SHARED-DATA`/`SAME-ID` | Nếu `SHARED-DATA`: không quảng cáo đa tài khoản |
| **Z4. Boost luồng** | Chẩn đoán sau 2 phút chế độ game: dòng "nang uu tien luong" | Số luồng ≥ 1 (G-21) | Tắt tùy chọn "Nâng ưu tiên luồng" và so wall/worker/game |
| **Z5. fps/độ phân giải** | Bật "30 Hz" và/hoặc "giảm độ phân giải" trong chế độ mờ/đen với một game Unity | Game vẫn vẽ đúng; CPU/GPU giảm (G-22, G-23) | Tắt tùy chọn; ghi game nào lỗi |
| **Z6. Cập nhật giữ dữ liệu** | Cài app có dữ liệu, tạo dữ liệu, cài đè bản mới | Dữ liệu còn; nếu engine xóa thì toast "đã khôi phục" (G-27) | Giữ `filesDir/preupdate/*.zip` và gửi log `VSpaceUpdate` |
| **Z7. Tự mở lại + 12 giờ** | Bật "Tự mở lại game", kill tiến trình game bằng `adb shell am kill`; chờ ≤ 1 phút | Game mở lại, thông báo (G-25) | Xem log `GameMode`; thử chế độ Màn hình đen |
| **Z8. Widget** | Thêm widget "Workspace: trạng thái" ra màn hình chính, bắt đầu/thoát phiên | Chữ đổi theo trạng thái, nút Thoát chạy (G-28) | Xem log `VSpaceWidget` |

**Kết quả test (điền khi có):**

| Ngày | Máy / ROM / Android | Test | Kết quả | Ghi chú |
|---|---|---|---|---|
| — | — | — | — | Chưa có dữ liệu thật |

---

## 12. Quyết định mở & rủi ro

| ID | Vấn đề | Lựa chọn | Khuyến nghị tạm thời |
|---|---|---|---|
| O-1 | Phụ thuộc NewBlackbox: một người duy trì, nhiều fork; repo công khai có thể tụt hậu bản thương mại **[R]** | Giữ / chuyển engine / tự fork | Giữ, **ghim SHA**, tự fork khi cần sửa |
| O-2 | `targetSdk` 28 vs 34 | 28 (tương thích engine) / 34 (tương lai) | 28 tới khi P0 xong, đo cả hai |
| O-3 | Hỗ trợ 32-bit | Giữ leg armv7 / bỏ | Quyết ở P1-4 |
| O-4 | Phân phối | Sideload / Play | Chỉ sideload (mục 10 #8) |
| O-5 | Android 16/17 | Hook native/hidden API có thể vỡ; **không có nguồn nào xác nhận NewBlackbox chạy ổn trên 16/17** | Test ở P1-7; có thể phải chờ bản vá core |
| O-6 | Thiết bị 16KB page size (Android 15+) | `.so` của guest chưa căn 16KB có thể lỗi | Suy luận; kiểm ở P1-7 |
| O-7 | Pháp lý/đạo đức | Chỉ dùng cho app của chính bạn/được phép; ảo hóa để qua mặt kiểm soát bảo mật là vi phạm điều khoản nhiều dịch vụ | Ghi rõ trong README khi công khai |
| O-8 | Giấy phép | **[ĐÃ LÀM phiên 7, hoàn tất phiên 11]** `LICENSE` (Apache-2.0) + `NOTICE`. Phiên 11 đối chiếu giấy phép thật của Dobby (Apache-2.0), xDL (MIT), FreeReflection (**MIT**, bản NOTICE cũ ghi nhầm Apache-2.0), toml4j (MIT, POM Maven Central; kho nay là `mwanji/toml4j`). MIT yêu cầu đính kèm dòng bản quyền + nội dung cấp phép trong bản phân phối: còn cần trang "Giấy phép nguồn mở" trong sản phẩm khi phát hành | Chủ dự án có quyền đổi giấy phép cho mã của mình |
| O-9 | **[ĐÃ SỬA ở phiên 5, đọc source thật]** Dữ liệu app ảo KHÔNG nằm trong cache — nó là thư mục anh em của cache (`cacheDir.getParent()/blackbox`, tức `/data/data/<host_pkg>/blackbox`). "Xóa bộ nhớ đệm" KHÔNG xóa app ảo. Rủi ro thật còn lại: gỡ cài đặt Workspace hoặc bấm "Xóa dữ liệu" (xóa cả `/data/data/<host_pkg>`) vẫn mất hết, và đổi máy cũng mất | Đã sửa cảnh báo trong app cho đúng (không còn nói "cache"); vẫn giữ tự sao lưu vì lý do "gỡ cài đặt/đổi máy" | Không cần vá lõi đổi sang `filesDir` nữa — đây chưa bao giờ là vấn đề thật, chỉ là đọc nhầm tài liệu ở đợt 3 |
| **O-10 [MỨC NGHIÊM TRỌNG — đã vá, phiên 6, đọc source thật]** | **Lõi tự gửi logcat của HOST (toàn bộ, không riêng app nào) + thông tin thiết bị ra MỘT MÁY CHỦ CỦA BÊN THỨ BA mỗi khi app ảo crash, mặc định, không cần Workspace bật gì.** Cơ chế thật, đọc từng dòng: `BlackBoxCore` có khối `static{}` tự chạy `SimpleCrashFix.installSimpleFix()` ngay khi lớp được nạp (không cần gọi gì) → cài `UncaughtExceptionHandler` bắt nhiều loại crash (NullContext/GMS/WebView/Attribution/SocialMedia/uncaught) → mỗi loại tự gọi `BlackBoxCore.sendLogs(...)` → hàm này đọc `ClientConfiguration.getLogSenderChatId()`; nếu Workspace KHÔNG override, giá trị MẶC ĐỊNH của `ClientConfiguration` (abstract, không phải Workspace viết) là chuỗi hardcode `"-1003719573856"` → tạo file tạm, đổ `logcat -d -v threadtime` (toàn bộ log của tiến trình host, có thể lẫn dữ liệu của MỌI app ảo đang chạy) + info thiết bị vào file → `LogSender.send()` POST file đó (multipart/form-data) tới `https://logs-sender-api.vercel.app/api/<chatId>/upload` — một endpoint do tác giả core (không phải Workspace, không phải Anthropic) kiểm soát, không hề nhắc tới trong README công khai của core. Người dùng chỉ thấy 1 thông báo hệ thống mơ hồ "BlackBox Log Upload Success/Failed" sau đó, không có xin phép trước | **Đã vá ở `Engine.attach()`** (phiên 6): override `getLogSenderChatId()` trả `null` trong `ClientConfiguration` ẩn danh mà Workspace tạo — `sendLogs()` có `if (chatId == null \|\| chatId.isEmpty()) return;` ngay dòng đầu nên trở thành no-op hoàn toàn (không tạo file tạm, không chạy `logcat`, không gọi mạng). Đã grep toàn bộ `Bcore` tìm `HttpURLConnection`/`vercel`/`telegram`: chỉ có đúng 1 đường duy nhất (`LogSender.java`), không có đường rò rỉ nào khác đã tìm thấy | **Không phải lỗi của Workspace — là hành vi mặc định của phụ thuộc bên thứ ba.** Bắt buộc giữ override này vĩnh viễn; nếu sau này đổi `core_ref` sang fork/bản khác, PHẢI kiểm tra lại y hệt cách này (đọc `ClientConfiguration` thật + grep `sendLogs`/`HttpURLConnection`) trước khi tin tưởng, vì đây là loại lỗi mà README/tài liệu KHÔNG BAO GIỜ tự nói ra |
| O-13 | Hook app ảo phụ thuộc `AppLifecycleCallback` của lõi và mã sinh tự động | Giữ / vá lõi | Bản stub tự tắt tính năng nếu không đọc được; kiểm ở P0-9 |
| **O-11 [MỨC NGHIÊM TRỌNG — phát hiện phiên 7, đọc source thật; có công tắc]** | **Lõi tự giả mạo danh tính thiết bị cho MỌI tiến trình nạp thư viện native, độc lập với `ClientConfiguration`:** `Utils/VirtualSpoof.cpp` có `__attribute__((constructor))` hook `__system_property_get` (Dobby) rồi trả `ro.product.model`="Pixel 6", brand `google`, fingerprint `google/oriole/...:12/...`, `ro.build.version.release`=12, serial giả, `ro.kernel.qemu`=0… cho cả host lẫn app ảo. `Utils/AntiDetection.cpp` cũng có constructor nhưng CHỈ ghi log (không cài hook thật). README công khai của lõi tự ghi "Device Spoofing" là tính năng. Hệ quả: (1) docs cũ nói "Workspace không giả mạo" chỉ đúng ở mức mã của Workspace — đã sửa README; (2) app ảo luôn thấy máy giả, nên số liệu thiết bị trong Chẩn đoán đọc qua `SystemProperties` có thể là giá trị giả (đọc `Build.*` tĩnh thì không); (3) với game có anti-cheat, việc này là hành vi mà người dùng KHÔNG chủ động bật | Giữ mặc định / gỡ | Mặc định GIỮ nguyên hành vi lõi (Workspace không tự đổi hành vi mặc định của phụ thuộc). Công tắc: workflow `strip_core_spoof=true` hoặc `VSPACE_STRIP_CORE_SPOOF=1 bash scripts/overlay.sh <core>` gỡ 2 dòng khỏi `Android.mk` (đã chạy thử trên lõi thật, danh sách nguồn vẫn hợp lệ; **chưa build NDK** [?]). Workspace KHÔNG mở rộng việc giả mạo |
| **O-12 [đọc source thật, phiên 7]** | `BPackageManagerService.parserApk` gọi `PackageParserCompat.collectCertificates(p, true)` rồi coi mọi lỗi là `parser apk error` ⇒ **APK không có chữ ký bị lõi từ chối** (G-30 đã có đáp án). APK ghép bằng APKEditor không có chữ ký | — | Đã viết `ApkSigner` (v2, Java thuần, khóa sinh trên máy). Từ Android 11, app `targetSdk>=30` đòi tối thiểu scheme v2 nên v1 không đủ. Chữ ký KHÁC bản gốc ⇒ app tự kiểm chữ ký/Google Sign-In/Maps/Billing không chạy |

---

## 13. Sổ tra cứu

### 13.1 Thông số core (đã đọc từ trang repo vào 2026-11-06; cột cuối sửa ở phiên 5 bằng source thật, 2026-11-14)

| Mục | Giá trị | Phiên 5 |
|---|---|---|
| Repo | `ALEX5402/NewBlackbox` — Apache-2.0, ≈469★, 270 fork, 58 commit, ≈24 issue mở | Đọc lại: 419★/232 fork/22 issue mở, push cuối 2026-07-19 (số liệu dao động theo nguồn/thời điểm, không phải dấu hiệu lỗi) |
| Cấu trúc gốc | `.github/ Bcore/ app/ assets/ black-reflection/ compiler/ gradle/`, `settings.gradle` (Groovy), `build.gradle`, `gradle.properties`, `gradlew` | Khớp — đã `git clone` và thấy đúng cấu trúc này |
| Yêu cầu build | JDK 17, Android SDK 34+, **NDK 29.0.13846066** | Khớp (README) |
| Hỗ trợ (theo README) | Android 5.0 → 14.0+, ARM64/ARMv7/x86; "32-bit và 64-bit" | **README nói SAI phần x86**: `Bcore/build.gradle` và `app/build.gradle` thật chỉ khai `abiFilters 'arm64-v8a', 'armeabi-v7a'`, không có `x86`/`x86_64` (xem P1-4) |
| Khuyến nghị | `targetSdkVersion ≤ 28` để tương thích tốt hơn | chưa đọc lại field này trong build.gradle thật, giữ như cũ |
| Native/hook | Dobby, xDL; reflection: BlackReflection, FreeReflection | khớp (README credits) |
| Bản "enhanced" | Fork `sujiw/NewBlackbox` ghi mã nguồn bản nâng cấp bán theo giấy phép thương mại; AAR phát qua Telegram → repo công khai có thể thiếu fix | chưa đọc lại, giữ như cũ |
| Tính năng README tự quảng cáo | — | README liệt kê **"Device Spoofing: Modify device information"** và **"Fake Location: Spoof GPS coordinates"** như tính năng CÓ SẴN của lõi (khớp với thư mục `fake/service`, `view.fake.FakeManagerActivity` trong sample app của core). Đây là tính năng của BÊN THỨ BA đi kèm phụ thuộc — Workspace không bật, không gọi tới, và không xây thêm tính năng che giấu/giả mạo nào khác (AGENTS.md mục 9). Ghi vào RiskList (O-7) để minh bạch, không phải để dùng |

### 13.2 API BlackBoxCore: xác nhận vs. tuyên bố (cột "Mức" đã cập nhật ở phiên 5 bằng cách đọc trực tiếp source thật, SHA `89b59836c66f173756a4ae258cf379a957649820` — mạnh hơn "tài liệu dẫn từ source" vì là chính source, không qua trung gian)

| Hàm | Nguồn | Mức | Cách `Engine.java` xử lý |
|---|---|---|---|
| `doAttachBaseContext(Context, ClientConfiguration)` + `getHostPackageName()` | README core, nhiều bản sao | **[R] xác nhận bằng source thật** | Gọi trực tiếp |
| `doCreate()` | README | **[R] xác nhận bằng source thật** | Trực tiếp |
| `installPackageAsUser(File, int)`, `installPackageAsUser(String, int)` | README | **[R] xác nhận bằng source thật — trả `InstallResult{boolean success, String packageName, String msg}`, KHÔNG phải `boolean`** | Trực tiếp; từ phiên 5 ĐỌC kết quả bằng reflection field-access (`readInstallResult`) để lấy `msg` thật khi cài lỗi, không chỉ đoán qua `isInstalled()` nữa |
| `installPackageAsUser(Uri, int)` | chỉ `Docs.md` | **[?] vẫn chưa xác nhận** (không thấy overload này khi đọc source) | Không dùng |
| `launchApk(String, int)` | README | **[R] xác nhận bằng source thật — trả `boolean`. KHÔNG có overload trả `Intent` ở core này** | Reflection; nhánh xử lý `Intent` giữ lại phòng fork khác, nhưng ở core SHA `89b5983` nhánh đó không bao giờ chạy |
| `getInstalledApplications(int, int)`, `getInstalledPackages(int, int)`, `getUsers()` | README | **[R] xác nhận bằng source thật** | `getInstalledApplications` trực tiếp |
| `uninstallPackageAsUser(String, int)`, `uninstallPackage(String)` | DeepWiki + README fork | **[R] xác nhận bằng source thật — cả 2 overload đều có** | Reflection (giữ nguyên theo D-04, dù đã xác nhận, để không vỡ nếu người dùng trỏ `core_ref` sang fork khác) |
| `stopPackage(String, int)` | không tài liệu nào (đợt 3) | **[R] xác nhận bằng source thật — gọi thẳng `BProcessManagerService.killPackageAsUser(pkg, userId)`, có tác dụng thật, không phải no-op** | Reflection (giữ nguyên theo D-04) |
| `BActivityManager.killAppByPkg` | giả định đợt 3 (theo DeepWiki) | **[R] xác nhận KHÔNG TỒN TẠI** — đã grep toàn bộ `public` method của `BActivityManagerService`, không có | **Đã bỏ khỏi `Engine.stop()`** ở phiên 5 (trước đó gọi thử bằng reflection, luôn fail âm thầm) |
| `isPackageInstalled`, `isAppInstalled`, `getInstalledApps`, `startVirtualProcess`, `setAppPermission`, `clearAppData`… | chỉ `Docs.md`/fork | **[?] chưa grep lại cụ thể từng tên này** — nhiều khả năng vẫn không tồn tại (không thấy khi đọc `BlackBoxCore.java`/`BPackageManagerService.java`/`BProcessManagerService.java` cho các việc liên quan) | Không dùng |
| `createUser(int)` | không tài liệu nào | **[R] xác nhận bằng source thật — trả `BUserInfo`** | Reflection (bỏ qua nếu thiếu) trước khi cài vào userId > 0 |
| `AppLifecycleCallback` | đợt 3 đoán là `interface` 3 hàm | **[R] xác nhận là CLASS cụ thể, 15 phương thức ghi đè được** (`extends Application.ActivityLifecycleCallbacks`), xem mục 13.7 | `gen_guest_hooks.py` đã **chạy thật** trên core thật ở phiên 5, tự dò đúng `class`→`extends`, không cần sửa |

> P0-2 coi như xong bằng cách đọc source thật thay vì chờ artifact CI (xem mục 13.7). Artifact `core-inspection` (nếu P0-1 chạy) vẫn nên đối chiếu 1 lần cho chắc vì core công khai có thể đổi giữa lúc đọc (2026-11-14) và lúc ai đó thật sự build.

### 13.3 Lệnh hay dùng

```bash
# Build tay (cần JDK17, SDK35, NDK theo core)
git clone https://github.com/ALEX5402/NewBlackbox core && bash scripts/overlay.sh core workspace
(cd core && ./gradlew :workspace:assembleDebug -Pabi=arm64-v8a)
# Log
adb logcat -s VSpaceEngine VSpacePinner VSpaceKeepAlive VSpaceBoot
# Trạng thái tiến trình/đóng băng
adb shell dumpsys activity processes | grep -A2 ":p"
adb shell dumpsys activity | grep -i "Apps frozen"
```

### 13.4 Nguồn tham khảo

- NewBlackbox: https://github.com/ALEX5402/NewBlackbox · https://github.com/ALEX5402/NewBlackbox/blob/main/Docs.md · bản sao README API: https://github.com/CKAndroidProject/NewBlackbox · fork "enhanced": https://github.com/sujiw/NewBlackbox
- Cached apps freezer (AOSP): https://source.android.com/docs/core/perf/cached-apps-freezer
- Vòng đời tiến trình: https://developer.android.com/guide/components/activities/process-lifecycle · Service bindings: https://developer.android.com/topic/performance/memory/guide/service-bindings
- Lỗi `BIND_ABOVE_CLIENT`: https://github.com/nextcloud/Android-SingleSignOn/issues/1081
- Android 15 FGS: https://developer.android.com/about/versions/15/behavior-changes-15
- Android 17: https://developer.android.com/about/versions/17/behavior-changes-17 · https://developer.android.com/about/versions/17/changes/bg-audio
- Ngưỡng targetSdk khi cài: https://bayton.org/android/android-minimum-targetsdk-matrix/
- OEM kill: https://dontkillmyapp.com/xiaomi · https://dev.to/stoyan_minchev/what-android-oems-do-to-background-apps-and-the-11-layers-i-built-to-survive-it-28bb
- Phantom process: https://github.com/agnostic-apollo/Android-Docs/blob/master/en/docs/apps/processes/phantom-cached-and-empty-processes.md
- Work profile thay thế: https://github.com/loco-chen/Shelter
- Giới hạn app ảo: https://www.appbrain.com/app/parallel-space-app-cloning/com.lbe.parallel.intl · https://github.com/DualVectorFoil/VirtualApp · https://www.appdome.com/how-to/mobile-fraud-prevention-detection/know-your-customer-checks/block-secondary-space-in-android-apps/
- Enhanced Confirmation Mode: https://blog-api.testapp.io/enable-unknown-sources-on-android-a-complete-how-to-guide


### 13.5 Phát hiện từ nghiên cứu lõi (đợt 3; nguồn: DeepWiki của ALEX5402/NewBlackbox, dẫn từ source; log issue FBlackBox/BlackBox)

| Mục | Giá trị | Mức |
|---|---|---|
| Gốc dữ liệu ảo | `<cacheDir của host>/blackbox` | tài liệu dẫn từ source; Chẩn đoán in đường dẫn thực |
| Dữ liệu app | `<gốc>/data/user/<userId>/<pkg>` | như trên |
| Dữ liệu ngoài | `<gốc>/storage/emulated/<userId>/Android/data/<pkg>` | như trên |
| APK | `<gốc>/data/app/<pkg>/base.apk` | như trên |
| Cấu hình hệ thống ảo | `<gốc>/system` (user.conf, uid.conf, package.conf) | như trên |
| Mô hình tiến trình | `:p0…:p49` (app ảo) + `:daemon` (dịch vụ hệ thống ảo) | tài liệu dẫn từ source |
| Slot proxy | 50 slot, mỗi slot có activity proxy (3 loại), service proxy, job service proxy (`BIND_JOB_SERVICE`) và ContentProvider `${applicationId}.proxy_content_provider_N` | tài liệu dẫn từ source |
| Luồng khởi chạy | client → `BActivityManager` → máy chủ (`DaemonService`) thay `ComponentName` bằng proxy → `ProxyActivity.onCreate` khôi phục activity gốc | tài liệu dẫn từ source |
| IPC của lõi | `SystemCallProvider` (một ContentProvider) làm cầu IPC | tài liệu dẫn từ source |
| API xác nhận | `uninstallPackageAsUser`, `addAppLifecycleCallback`, `getBActivityManager()`, `getUsers()` → `List<BUserInfo>` | tài liệu dẫn từ source (số dòng) |
| Callback vòng đời | `beforeCreateApplication`, `beforeApplicationOnCreate`, `afterApplicationOnCreate` | log thật trong issue của BlackBox |
| Đã xác nhận ở phiên 5 (mục 13.7) | kiểu (`interface`/`class`) và chữ ký chính xác của `AppLifecycleCallback` (= class, 15 hàm); `stopPackage` (có thật); `killAppByPkg` (KHÔNG có thật); `createUser` (có thật, trả `BUserInfo`) | → mã sinh thích ứng đã chạy thật và đúng; reflection + fallback giết pid vẫn giữ làm lưới an toàn (D-04) |
| Không dùng | `Docs.md` của lõi (F-5) | mâu thuẫn nội bộ |


### 13.6 Phát hiện về tắt panel (đợt 4; nguồn: scrcpy, issue #3927, dự án bot game pogo-utils)

| Mục | Giá trị | Mức |
|---|---|---|
| Hàm tắt panel | `SurfaceControl.setDisplayPowerMode(IBinder token, int mode)`; mode 0 = OFF, 2 = NORMAL | scrcpy |
| Điều kiện | Quyền shell (`app_process` chạy bằng `adb shell`); app thường không gọi được | scrcpy |
| Tác dụng | Panel tắt nhưng Android vẫn "Awake" nên game vẫn vẽ; máy NGỦ thì game thôi vẽ | dự án bot game |
| Android 14+ | `getPhysicalDisplayIds/Token` chuyển sang `com.android.server.display.DisplayControl` trong `services.jar`, cần nạp `libandroid_servers.so` | issue scrcpy #3927 |
| Đã thấy chạy | Pixel 7, Xiaomi 13T Pro, Xiaomi 14 (bằng `LD_PRELOAD`); scrcpy sửa bằng `ClassLoaderFactory` + `Runtime.loadLibrary0` | issue scrcpy #3927 |
| Không dùng | `cmd display power-off`: Android thôi coi màn hình là bật | dự án bot game |
| Lối thay thế | `service call SurfaceFlinger 20000 i64 <id> i32 0` (thiết bị Qualcomm) | issue scrcpy #3927 |

### 13.7 Phiên 5 — đọc trực tiếp source thật của core qua mạng (2026-11-14, không có thiết bị/Android SDK, có mạng tới GitHub)

Sandbox phiên này có mạng tới `github.com`/`codeload.github.com`/`raw.githubusercontent.com` (không có tới `dl.google.com`/Android SDK/Maven Google) — nên `git clone` thẳng `ALEX5402/NewBlackbox` được, SHA `89b59836c66f173756a4ae258cf379a957649820` (lúc clone, 2026-11-14). Đây là nguồn ĐÁNG TIN HƠN "tài liệu dẫn từ source"/DeepWiki ở mục 13.5 (đợt 3) vì là chính source, không qua trung gian tóm tắt. Theo AGENTS.md mục 2 ("chỉ tin source thật hoặc artifact core-inspection"), các dòng dưới đây được coi là mức [R] cao nhất hiện có, không phải [?].

**A. Mô hình tiến trình — đếm thật từ `Bcore/src/main/AndroidManifest.xml`:**

| Thành phần | Số lượng | Ghi chú |
|---|---|---|
| `ProxyActivity$P0..P49` | 50 | tiến trình `:p0..:p49` |
| `TransparentProxyActivity$P0..P49` | 50 | cùng dải `:pN` |
| `ProxyPendingActivity$P0..P49` | 50 | cùng dải `:pN` |
| `ProxyService$P0..P49` | 50 | **service thật có thể bind** — xác nhận đúng giả định D-07 của ProcessPinner |
| `ProxyContentProvider$P0..P49` | 50 | mỗi slot `:pN` một authority provider riêng |
| `ProxyJobService$P0..P49` | 50 | JobScheduler của guest ĐƯỢC virtualize qua đây (không phải "chưa xử lý" như lo ngại trước đó) |
| `DaemonService` + `DaemonService$DaemonInnerService` | 1+1 | process `:black` (giá trị thật của `@string/black_box_service_name`, không phải `:daemon` như đợt 3 đoán — **sửa nhỏ so với 13.5**) |
| `SystemCallProvider` | 1 | cùng process `:black` |

`BProcessManagerService.getUsingBPidL()` (đọc trực tiếp): chọn slot trống đầu tiên trong `0..ProxyManifest.FREE_COUNT` (`FREE_COUNT = 50`, hằng số thật) theo tiến trình **đang chạy thật** (không gán theo userId) → **50 slot dùng CHUNG cho MỌI không gian/game cùng lúc**, không phải 50 riêng mỗi không gian. 20 guest đang chạy đồng thời ở 3 không gian là đã dùng 60/50 → tràn. Vì bộ cấp phát luôn tránh trùng slot cho các tiến trình đang sống, **không có 2 guest nào đang chạy cùng lúc bị trùng authority `ProxyContentProvider`** — lo ngại "va chạm authority giữa 2 guest" ở câu hỏi trước coi như được loại trừ về mặt CẤU TRÚC (hành vi thật vẫn cần máy để xác nhận).

**B. Vị trí dữ liệu — đọc `BEnvironment.java` thật (sửa 1 claim sai ở mục 13.5/O-9):**

| Mục | Công thức thật | Khác gì so với đợt 3 |
|---|---|---|
| Gốc nội bộ | `context.getCacheDir().getParent() + "/blackbox"` = `/data/data/<host_pkg>/blackbox` | Đợt 3 ghi `<cacheDir>/blackbox` (NẰM TRONG cache) — **sai**; thật ra là ANH EM của cache |
| Gốc ngoài | `context.getExternalFilesDir("blackbox")` | Đợt 3 không phân biệt gốc ngoài với gốc trong — **đã sửa `ObbImporter`/`GuestBackup.ext`** |
| Dữ liệu app | `<gốc nội bộ>/data/user/<userId>/<pkg>` | khớp đợt 3 |
| Dữ liệu ngoài (Android/data ảo) | `<gốc ngoài>/storage/emulated/<userId>/Android/data/<pkg>` | đợt 3 ghi nhầm dùng chung gốc nội bộ |
| OBB ảo | `<gốc ngoài>/storage/emulated/<userId>/Android/obb/<pkg>` (`getExternalObbDir`/`getExternalUserDir`) | G-31 coi như giải xong phần đường dẫn |
| APK đã cài | `<gốc nội bộ>/data/app/<pkg>/base.apk` | khớp đợt 3 |

Hệ quả thật: "Xóa bộ nhớ đệm" KHÔNG xóa app ảo (sửa cảnh báo trong `strings.xml`, `GuestBackup.describeLayout`). Chỉ gỡ cài đặt Workspace hoặc "Xóa dữ liệu" (xóa cả `/data/data/<host_pkg>`) mới xóa.

**C. Cô lập giữa các guest — đọc `fake/service/*.java`, chưa đầy đủ (chỉ phần có thời gian đọc):**

| Cơ chế | Có lớp xử lý trong core? | Ý nghĩa |
|---|---|---|
| ContentProvider authority | Có (`ProxyContentProvider$Pn`, mục A) | Cách ly theo CẤU TRÚC giữa các tiến trình đang chạy đồng thời |
| WebView data dir | Có (`WebViewFactoryProxy`, `WebViewProxy`, `IWebViewUpdateServiceProxy`) | Tồn tại cơ chế; **chưa đọc đủ sâu** để biết có namespace theo userId/pkg hay không — để [?] |
| `ANDROID_ID` | Có hook (`AndroidIdProxy`) nhưng **KHÔNG cách ly**: trả nguyên `Settings.Secure.ANDROID_ID` thật của host cho mọi không gian trừ khi giá trị đó rỗng/`"0"` (khi đó mới sinh số ngẫu nhiên, và sinh lại MỖI LẦN gọi — không lưu, có thể là điểm bất ổn chứ không hẳn là "tính năng") | Rủi ro đa tài khoản game là CÓ THẬT, không chỉ suy luận — ghi vào RiskList/`scope_no` để cảnh báo, KHÔNG giả mạo (cấm theo AGENTS.md mục 9) |
| Keystore alias | **Không tìm thấy lớp proxy nào** khi grep `KeyStore`/`Keystore` toàn bộ core | Guest dùng sinh trắc học/chữ ký riêng nhiều khả năng KHÔNG cách ly giữa các không gian — rủi ro thật, chưa có cách giảm nhẹ nào được code |
| Quyền nguy hiểm (camera/mic/vị trí) | `IPermissionManagerProxy` làm quyền guest LUÔN "đã cấp" ở tầng check nội bộ | KHÔNG có cầu nối "guest xin → hộp thoại hệ thống hiện cho host". Quyền chỉ thật sự có nếu HOST đã tự xin trước (P1-3) |

**D. Kiểm thử thật đã chạy trong sandbox này (không cần Android SDK/thiết bị):**

- `gen_guest_hooks.py /home/claude/core workspace` chạy thật trên core thật → tự dò đúng `AppLifecycleCallback` là `class` (không phải `interface`), sinh `GuestGenerated` với đủ 15 hàm `void`, `register=addAppLifecycleCallback` đúng; tự tìm đúng 100 activity proxy để tiêm `resizeableActivity`/PiP. **Không cần sửa gì** — mã sinh thích ứng viết từ trước đã đúng ngay cả với phát hiện "là class, không phải interface" ở trên.
- `overlay.sh /tmp/overlay_real workspace` chạy thật trên core thật → import `BlackBoxCore`/`ClientConfiguration` khớp đúng gói thật ngay (không cần viết lại), copy module, `settings.gradle` thêm đúng 1 lần `:workspace` + `:testguest`. Hoàn tất không lỗi.
- `scripts/compile_check.py` và `scripts/check.py` chạy lại sau mọi sửa đổi ở phiên 5: biên dịch javac thật qua stub Android đã cập nhật (`InstallResult`, `Context.getExternalFilesDir`), 58 test đơn vị đạt, mọi kiểm tĩnh (XML, manifest, workflow YAML+bash -n, tham chiếu chéo, README bảng Markdown…) đạt.
- **Vẫn KHÔNG làm được trong sandbox này**: build Gradle thật (cần `dl.google.com`/Android Gradle Plugin, không nằm trong domain cho phép), cài/chạy trên thiết bị thật. Đây là ranh giới thật của "mạng đã mở" — mạng tới GitHub giúp đọc source thật, không giúp build Android thật.

**E. Phụ thuộc `APKEditor` (G-30/D-42) — tải jar thật, không chỉ đọc tài liệu:**

Tải `REAndroid/APKEditor` tag `V1.4.9` 2 lần độc lập, sha256 khớp cả 2 lần: `a9cd40df818845456be6d696de6110c89edf4b0a0580cb83438ed6b25a366e67`. Dùng `javap` (qua `java -m jdk.jdeps/com.sun.tools.javap.Main`) đọc `com/reandroid/apkeditor/Main.class`: có cả `public static void main(String[])` và **`public static int execute(String[])`** tách riêng — khớp đúng giả định mà `SplitMerger.java` đã viết từ trước (gọi `execute` qua reflection để tránh `System.exit`). Gợi ý đặt `APKEDITOR_TAG=V1.4.9`, `APKEDITOR_SHA256=a9cd40df818845456be6d696de6110c89edf4b0a0580cb83438ed6b25a366e67` làm repository variables (đã ghi vào README). Vẫn KHÔNG kiểm chứng được: jar chạy trên máy Android thật (không có thiết bị), và engine có chịu được APK ghép chưa ký hay không.

**F. Làm (nhắc lại vì phiên này bị yêu cầu lại):**  thêm tính năng che giấu overlay , giả mạo `ANDROID_ID`/fingerprint để né ban đa tài khoản — đúng AGENTS.md mục 9. Phát hiện ở mục C (ANDROID_ID không cách ly, keystore không cách ly) được ghi lại CHỈ để cảnh báo người dùng (RiskList, `scope_no`), không phải để khai thác.

---

### 13.8 Phiên 6 — rò rỉ logcat ra bên thứ ba (O-10) + API facade đầy đủ của `BlackBoxCore`

**A. Cơ chế rò rỉ, đọc từng bước từ source thật (SHA `89b5983`):**

1. `BlackBoxCore.java` dòng ~85-89: khối `static{}` của lớp gọi `SimpleCrashFix.installSimpleFix()` — chạy ngay khi JVM nạp lớp `BlackBoxCore`, **không cần Workspace/Engine.java gọi bất kỳ hàm nào**. `installSystemHooks()` cũng gọi lại hàm này (phòng hờ).
2. `SimpleCrashFix.java` cài `Thread.setDefaultUncaughtExceptionHandler` + vài chỗ bắt lỗi theo tên (NullContext/GMS/WebView/Attribution/SocialMedia) → mỗi nhánh gọi `BlackBoxCore.get().sendLogs("...", async/sync)`.
3. `BlackBoxCore.sendLogs(caption, async, listener)` đọc `mClientConfiguration.getLogSenderChatId()`. `mClientConfiguration` chính là đối tượng `ClientConfiguration` mà **Workspace tự đưa vào** qua `doAttachBaseContext(base, new ClientConfiguration(){...})` trong `Engine.attach()`.
4. `ClientConfiguration` (abstract, `top/niunaijun/blackbox/app/configuration/ClientConfiguration.java`) có `getLogSenderChatId()` **không phải abstract** — có thân hàm mặc định `return "-1003719573856";`. Trước phiên 6, Workspace chỉ override `getHostPackageName()` (bắt buộc vì abstract), **không override `getLogSenderChatId()`** → giá trị mặc định này được dùng y nguyên.
5. Với `chatId` khác rỗng, `sendLogs` tạo file tạm trong `cacheDir`, ghi header (caption + info thiết bị từ `getDeviceInfoString()`) rồi `exec("logcat -d -v threadtime")` đổ toàn bộ logcat hiện có của tiến trình host vào file đó — **logcat không phân biệt theo app, nên có thể lẫn dòng log của mọi app ảo khác đang/đã chạy trong cùng tiến trình hoặc tiến trình con**.
6. `LogSender.send(chatId, file, caption)` (`top/niunaijun/blackbox/utils/LogSender.java`) POST file đó (multipart/form-data, không xác thực, không mã hóa riêng ngoài HTTPS) tới `String.format("https://logs-sender-api.vercel.app/api/%s/upload", chatId)`.
7. Sau đó hiện 1 `Notification`/`Toast` mơ hồ "BlackBox Log Upload Success" hoặc "...Failed" — không giải thích đã gửi gì, gửi đi đâu.

**Đã grep toàn bộ `Bcore/` tìm `HttpURLConnection`, `vercel`, `telegram`, `okhttp3`:** chỉ `LogSender.java` khớp (và `ShellUtils.java` khớp nhầm vì cùng dùng `DataOutputStream` cho việc hoàn toàn khác — chạy lệnh shell `su`/`sh`, không phải mạng). Không tìm thấy đường rò rỉ nào khác trong thời gian đọc được ở phiên này — nhưng đây KHÔNG phải bảo đảm tuyệt đối (core còn hàng chục nghìn dòng chưa đọc hết).

**B. Bản vá (đã làm, xem `Engine.attach()`):** override `getLogSenderChatId()` trả `null` trong `ClientConfiguration` mà Workspace tạo. `sendLogs()` có dòng chặn đầu tiên `if (chatId == null || chatId.isEmpty()) return;` nên toàn bộ bước 5-7 ở trên không bao giờ chạy nữa — không tạo file, không gọi `logcat`, không có request mạng nào. Đã xác nhận override này biên dịch đúng cả với stub (`android_api.spec` đã thêm `getLogSenderChatId()`) lẫn với **class thật** của core (chạy lại `overlay.sh` trên bản clone thật, xem log `grep getLogSenderChatId`).

**C. Vì sao đây không phải lỗi của Workspace nhưng vẫn là trách nhiệm của Workspace:** README công khai của `ALEX5402/NewBlackbox` không hề nhắc tới `sendLogs`/`LogSender`/endpoint này — một người dùng engine bình thường (đọc README, không đọc hết `Bcore/src`) sẽ không biết tính năng này tồn tại. Đây đúng là rủi ro "core từ bên thứ ba, không audit" mà O-1 đã cảnh báo từ đầu dự án, giờ có bằng chứng cụ thể. Bài học rút ra cho AGENTS.md: **mọi lần đổi `core_ref` sang version/fork khác đều phải lặp lại đúng quy trình đọc này** (`ClientConfiguration` thật + grep `HttpURLConnection`/`sendLogs`/tên miền lạ) trước khi tin, vì không có cách nào suy luận được việc này từ README hay từ hành vi biên dịch/test đơn vị (biên dịch/test vẫn xanh kể cả KHI CHƯA vá — đây là loại lỗi logic/thiết kế javac không bắt được).

**D. API facade đầy đủ của `BlackBoxCore`, đọc trực tiếp (bổ sung mục 13.2), các hàm đáng chú ý thêm:**

| Hàm | Xác nhận | Ý nghĩa cho backlog |
|---|---|---|
| `clearPackage(String, int)` | [R] có thật, gọi trực tiếp được | Giải quyết "xóa dữ liệu riêng từng guest" (nêu ở câu hỏi UI/UX trước đó, mục P1 "Trung bình") — chưa có UI gọi tới, có thể thêm |
| `deleteUser(int)` | [R] có thật | "Xóa cả 1 không gian" — chưa có UI gọi tới |
| `isInstalled(String, int)` | [R] có thật — tên đúng là `isInstalled`, không phải `isPackageInstalled`/`isAppInstalled` như [?] cũ đoán | `Engine.isInstalled()` nên ưu tiên tên này khi thử reflection |
| `installPackageAsUser(Uri, int)` | [R] có thật, trả `InstallResult` | `ApkImporter` hiện copy Uri→File trước khi cài; vẫn đúng/an toàn, không bắt buộc đổi |
| `isSupportGms()`, `isInstallGms(int)`, `installGms(int)`, `uninstallGms(int)` | [R] có thật | Lõi CÓ cơ chế cài GMS cho từng không gian — đổi `scope_no` cho Google Sign-In/Maps/Firebase từ "hầu như không thể" sang "có cơ chế ở lõi, CHƯA kiểm chứng trên máy" (vẫn không hứa chạy được, chỉ sửa lý do) |
| `hasAllFilesAccess()`, `requestAllFilesAccess(Activity)`, `handleAllFilesAccessResult(int)` | [R] có thật | Luồng xin quyền lưu trữ đầy đủ có sẵn ở lõi, Workspace hiện CHƯA gọi — liên quan trực tiếp tới độ tin cậy của tính năng OBB/split-APK (P1-20/G-30/G-31): nếu core cần quyền này để đọc/ghi OBB mà Workspace chưa xin, OBB có thể fail âm thầm. Nên thêm vào luồng cài trước khi dùng OBB — CHƯA LÀM ở phiên này (để lại cho phiên sau) |
| `isHideRoot()`, `isDisableFlagSecure()` | [R] có thật, mặc định `false` ở cả lõi lẫn `ClientConfiguration` | Workspace KHÔNG override hai hàm này → giữ nguyên `false` → không ẩn root, không tắt `FLAG_SECURE` cho guest. Ghi lại để xác nhận Workspace không (và sẽ không) dùng các cờ này cho mục đích né phát hiện |
| `requestInstallPackage(File, int)` trên `ClientConfiguration` | [R] có thật, mặc định `false` | Là một **hook callback** lõi gọi NGƯỢC vào app (không phải hàm app gọi lõi) để hỏi "có cho cài file này không" — khác với `BlackBoxCore.installPackageAsUser`. Workspace chưa override (giữ mặc định `false` = từ chối) — cần xác nhận hành vi thật trên máy trước khi coi đây là đang chặn cài đặt hay không liên quan tới luồng cài hiện tại |
| `getBUid()`, `getCallingBUid()`, `getUid()`, `getHostUid()` | [R] có thật, chưa đọc kỹ ý nghĩa từng hàm | Có khái niệm UID ảo nội bộ tách biệt UID hệ điều hành thật — liên quan gián tiếp tới lo ngại `Binder.getCallingUid()` nêu ở câu hỏi game trước đó, nhưng CHƯA đọc đủ sâu để kết luận; để [?] |

---

## 14. Nhật ký phiên

| Phiên | Ngày | Làm gì | Kết quả |
|---|---|---|---|
| 1 | 2026-11-06 | Chọn NewBlackbox làm lõi; viết module `workspace`, workflow, `overlay.sh`, README | Zip dự án; kiểm tĩnh XML/YAML/shell/overlay; **chưa biên dịch** |
| 2 | 2026-11-06 | Tra cứu: freezer/bind, FGS Android 15/17, ngưỡng targetSdk, OEM, phantom process, giới hạn app ảo, work profile; đọc `Docs.md` của core. Sửa `launch()`, thêm Chẩn đoán + inspect CI, viết tài liệu này | Phát hiện mâu thuẫn tài liệu core (F-5); loại `BIND_ABOVE_CLIENT`/`dataSync`; chuyển phần "chưa kiểm chứng" thành test plan |
| 3 | 2026-11-07 | Đọc bản đánh giá DeepSeek (PDF); phân loại đề xuất; thêm tính năng game, hẹn giờ, watchdog, đa không gian, kiểm ABI/dung lượng, tìm kiếm, i18n vi/en, theme tối, `testguest`; kiểm tĩnh mở rộng | Bắt và sửa 2 lỗi thật (YAML, `%`); cố ý **không** làm né anti-cheat; vẫn **chưa biên dịch/chạy** |
| 3b | 2026-11-07 | Làm tiếp backlog: nhật ký + crash + chia sẻ báo cáo, `ExitReasons`, xem trước APK, cài hàng loạt, nhận APK từ ngoài, thiết lập lần đầu, đổi tên/phím tắt/xuất APK, test đơn vị, `check.py` + `apk_report.py`, CI mở rộng | `check.py` qua thử đột biến 12/12; `apk_report.py` thử trên ELF thật; **không** làm sao lưu dữ liệu/PiP/Material (có lý do); vẫn **chưa biên dịch/chạy** |
| 3c | 2026-11-07 | Nghiên cứu lõi (bố cục dữ liệu, `:daemon`, `AppLifecycleCallback`), tombstone/ANR, VirtualDisplay; thêm hook + IPC + chế độ mờ + PiP + sao lưu/khôi phục/tự sao lưu + ghim `:daemon`; **dựng stub Android và biên dịch thật bằng javac**; sửa 6 lỗi stub; thử đột biến 8/8 | Mã biên dịch được, 19 test chạy thật đạt; phát hiện sai lầm "không có javac" (E-10); vẫn **chưa build bằng Android SDK thật** |
| 3d | 2026-11-07 | Nghiên cứu hướng "không làm": tắt panel kiểu scrcpy, VirtualDisplay (đọc kiến trúc proxy của lõi), Material. Cài `ScreenPower` + hướng dẫn trong app + theme DayNight; thêm 2 test | Biên dịch được, 21 test đạt; VirtualDisplay vẫn cần vá lõi (F-20); `ScreenPower` chưa thử máy thật (G-18) |
| 4 | 2026-11-13 | Đọc kỹ tài liệu + mã + PDF + tech.txt; làm nốt phần làm được không cần máy thật (mục 18): Preflight, OemGuide/OTA, SessionStats, GuestMonitor, ghim chọn lọc, boost luồng, `fps`/`lowres`, tự mở lại, nhắc 12 giờ, onTrimMemory, widget, Cài đặt/nhật ký, UpdateKeeper, sắp xếp/lọc; `measure_background.py`; ký phát hành tùy chọn + CI; 24 test đơn vị mới, 22 test Python | Biên dịch được, 45 test đạt, đột biến 7/7 bắt được; **vẫn chưa build Gradle/chạy máy thật** |
| 5 | 2026-11-14 | Sandbox lần này có mạng tới GitHub (không tới Android SDK/Google Maven): `git clone` thật `ALEX5402/NewBlackbox` (SHA `89b5983`) thay cho chờ artifact `core-inspection` (P0-2 coi như xong theo cách khác, xem mục 13.7); sửa 1 bug thật tìm được (gốc dữ liệu ảo không nằm trong cache — O-9), sửa `GuestBackup`/`ObbImporter`/cảnh báo strings; nâng `Engine.java` theo API xác nhận thật (`InstallResult`, bỏ `killAppByPkg` không tồn tại); chạy THẬT `gen_guest_hooks.py` và `overlay.sh` trên core thật (cả 2 qua, không cần sửa); pin `CORE_REF` theo SHA (P1-1); tải + tính sha256 thật jar `APKEditor` V1.4.9, xác nhận `execute()` bằng `javap` (G-30 một phần); cập nhật stub `android_api.spec` cho khớp. **Từ chối** yêu cầu thêm tính năng che giấu overlay/giả mạo ID (đúng AGENTS.md mục 9, đã từ chối từ phiên 3) | Biên dịch thật qua `compile_check.py` + 58 test đơn vị đạt, `check.py` đạt toàn bộ; nhiều mục [?] trong mục 13.2/13.5 chuyển thành [R]; **vẫn chưa build Gradle thật/chạy máy thật nào** |
| 6 | 2026-11-14 | Đọc tiếp `BlackBoxCore.java`/`ClientConfiguration.java` đầy đủ (không chỉ phần Engine.java chạm tới). **Phát hiện O-10 (mức nghiêm trọng)**: lõi tự động gửi logcat host + info thiết bị tới `logs-sender-api.vercel.app` (bên thứ ba) mỗi khi app ảo crash, mặc định bật sẵn, không cần Workspace làm gì — xem mục 13.8 để biết cơ chế đầy đủ. **Đã vá ngay** bằng 1 dòng override `getLogSenderChatId()` → `null` trong `Engine.attach()`. Nhân đó đọc thêm API facade đầy đủ của `BlackBoxCore`, xác nhận thêm `clearPackage`/`deleteUser`/`isInstalled`/GMS-install/storage-permission-flow có thật (mục 13.8.D) | `compile_check.py`/`check.py` chạy lại sau vá: biên dịch qua, 58 test đạt; chạy lại `overlay.sh` trên core thật xác nhận override hợp lệ với class thật, không chỉ với stub |
| 7 | 2026-11-15 | Đọc kỹ handoff + PDF + tech.txt, rồi dùng mạng (GitHub, Ubuntu) để kiểm chứng bằng công cụ thật: `android.jar` API 26/28/35, source lõi ở `89b5983`, `aapt`, `apksigner`, APKEditor, `actionlint`. Dựng lại workflow (JDK 21). Sửa lỗi build thật (`windowBackground`), lỗi CI, README sai. Phát hiện O-11, O-12. Viết `ApkSigner`, `UpdateChecker`/`UpdateFlow`, `TrashBin`/`UndoBar`/`BottomSheet`, `PermissionBridge`/`StorageAccess`, mở rộng `Engine` | 82 test JVM đạt (từ 58); `verify_real.py` 5/5 [V]; `check.py` tất cả đạt; **chưa Gradle, chưa thiết bị** |
| 8 | 2026-11-16 | Người dùng yêu cầu tìm phương án khác cho 3 việc đã ghi "cố ý không làm" ở phiên 7 (Material/RecyclerView, vuốt để thao tác, mã hóa). Giữ nguyên từ chối việc thứ 4 (giả mạo ID/che overlay — không phải giới hạn kỹ thuật, là quyết định không đổi). Tra cứu: không tải được artifact AndroidX thật vào sandbox (mọi mirror — Google Maven, CERN Nexus, jitpack — đều ngoài allowlist mạng); thay bằng stub thủ công đối chiếu tài liệu chính thức. Viết `GuestAdapter`/`GuestSwipeCallback` (RecyclerView + ItemTouchHelper thật, phụ thuộc thêm vào `build.gradle`), `BackupCrypto` (AES-GCM, khóa AndroidKeyStore, cho file sao lưu xuất ra ngoài) | 92 test JVM đạt (từ 82); `verify_real.py` 5/5 [V] (đã cập nhật để dựng stub androidx vào đường biên dịch với lõi thật); `check.py` tất cả đạt; mutation test bắt được lỗi ở cả stub mới và `BackupCrypto` |
| 9 | 2026-11-16 | Người dùng nói "Tiếp"; không có việc cụ thể mới nên tự tìm trong backlog: sửa lỗi đánh trùng số `P1-20`; đọc sâu `WebViewFactoryProxy`/`WebViewProxy`/`BActivityThread` để giải quyết phần "còn treo" của P1-15 | Tìm ra O-16 (WebView bị ép bật 2 cờ nguy hiểm) — phát hiện mới bằng đọc source thật, không phải máy thật |
| 10 | 2026-11-16 | Người dùng yêu cầu rà "chưa nối dây / việc dang dở / kỹ thuật trong PDF chưa làm". Audit có hệ thống: class ít tham chiếu nhất, mọi nút/checkbox trong layout có listener, mọi chuỗi có nơi dùng, `GuestHooks`/crash handler/`Scheduler`↔`AlarmReceiver`/`autoRestart`/widget/accessibility (contentDescription)/RTL đều ĐÃ nối đúng (âm tính có giá trị — xác nhận lại, không phải chưa kiểm). 2 lỗ hổng thật tìm được: không có `.gitignore` trong repo; không có PR/issue template (mục "Developer experience" từ PDF gốc, chưa ai làm) | Thêm `.gitignore`, `.github/PULL_REQUEST_TEMPLATE.md`, `.github/ISSUE_TEMPLATE/{bug_report,feature_request,config}.yml`. Cố ý KHÔNG thêm: `proguard-rules.pro` (mâu thuẫn D-08 — đã quyết không bật R8), `lint.xml`/CONTRIBUTING.md (gated sau P1-16 / đã có AGENTS.md) |
| 11 | 2026-11-18 | Làm nốt phần làm được bằng mạng GitHub: kiểm `UpdateChecker` thật với mạng thật, đọc 22 issue của lõi (E-4), O-17 (siết 300 stub exported), ghim 16 Action theo SHA, sửa NOTICE (FreeReflection là MIT), P1-24 (cảnh báo giới hạn lõi trong app) | `verify_real.py` 6/6, `check.py` đạt (92 test JVM). Mạng chỉ tới GitHub (Google/Maven/Gradle bị chặn) nên vẫn không build Gradle; chi tiết mục 23 |

**Việc đầu tiên của phiên 11:** (1) P0-1: đẩy lên GitHub, chạy Actions (workflow đã dựng lại, mục 19), đọc log; cần đặt secrets ký (P1-19) và biến `updateRepo` đã tự điền bằng `github.repository`; (2) P0-3…P0-11 trên máy thật; (3) nếu P0-1 đỏ vì Gradle: sửa theo log, đừng đoán. Mọi mục [V] ở mục 19 là bằng chứng offline, KHÔNG thay cho hai việc này.

---

## 15. Hướng dẫn bàn giao

**Cho người/AI tiếp quản, theo thứ tự:**
1. Đọc mục 1, 6, 8 (≈5 phút).
2. Chạy P0-1 (đẩy lên GitHub → Actions). Không sửa gì trước khi có log build thật.
3. Tải artifact `core-inspection`, đối chiếu mục 13.2, chỉnh `Engine.java` (chỉ file này chạm core).
4. Cài APK lên máy thật, mở **Chẩn đoán**, dán báo cáo vào mục 14.
5. Mỗi thay đổi: cập nhật mục 5/6/8/14.

**Câu mở đầu gợi ý cho phiên chat mới:**
> Đọc `docs/PROJECT_HANDOFF.md` (đính kèm). Tiếp tục từ mục 6, việc P0 đầu tiên chưa xong. Đây là log/báo cáo mới: …

**Không làm:** dùng `BIND_ABOVE_CLIENT`; dùng FGS `dataSync`; tin `Docs.md` của core; bật R8; giả định đã "chạy được" khi chưa có log thật; khẳng định cơ chế giữ nền hiệu quả trước khi có bảng A/B ở P0-4.


---

## 16. Chế độ game (phiên 3)

### 16.1 Vấn đề cốt lõi: tiến trình sống ≠ game đang chạy

- Đa số game (Unity, Unreal, Cocos, native) chạy logic **trong vòng lặp khung hình** (`Update()`, `Choreographer`). Tắt màn hình thật → activity bị pause, không còn VSync → logic đứng. Giữ tiến trình ra khỏi nhóm CACHED (P0-4) **không** sửa được việc này. *(Nhận định từ bản đánh giá bên ngoài + hiểu biết về Android; chưa đo — dùng `testguest` ở 16.5.)*
- App chat/bot/tải xuống có socket hoặc thread độc lập nên không bị ảnh hưởng. Đó là lý do có **hai chế độ**.

### 16.2 Các chế độ

| Chế độ | Cơ chế | Hợp với | Đánh đổi | Trạng thái |
|---|---|---|---|---|
| A. Tắt màn hình thật (`MODE_SAVER`) | FGS + WakeLock + WifiLock + ghim `:pN` | App có kết nối, game tính phía server | Game theo khung hình sẽ đứng; có cảnh báo CPU ≈ 0 | Code xong **[?]** |
| B. Màn hình đen (`MODE_FAKE_OFF`) | Overlay đen + `FLAG_KEEP_SCREEN_ON`, độ sáng thấp nhất theo cửa sổ, gợi ý 30 Hz | Game theo khung hình, AFK/auto-battle | Panel vẫn bật; GPU/CPU vẫn chạy → vẫn tốn pin/nóng; tiết kiệm rõ nhất trên OLED | Code xong **[?]** |
| C. PiP | Đưa activity game vào cửa sổ nhỏ | Game idle | Cần guest cùng chịu vào PiP; nhiều game pause khi mất focus | **Chưa làm** (P1-8) |
| D. Virtual display + MediaProjection | Render ngoài màn hình | Tắt màn hình thật mà game vẫn chạy | Cần người dùng đồng ý mỗi phiên, FGS `mediaProjection`, GPU path khác | **Chưa làm** (P3) |

### 16.3 Cách chế độ B hoạt động (lớp nào làm gì)

1. `GameActivity` lưu `GameProfile`, gọi `GameModeController.start(...)` rồi mở game bằng `Engine.launch`.
2. `GameModeController.begin`: bật `keepAlive`, khởi động `KeepAliveService`, tắt tiếng (lưu mức gốc vào `vol_restore`), đăng ký nhận `SCREEN_OFF`, lưu phiên vào `Prefs`.
3. Sau `delaySec` (mặc định 20 giây, để người chơi kịp vào game) `showOverlay()` thêm `GameOverlay` bằng `WindowManager` (`TYPE_APPLICATION_OVERLAY`, `PixelFormat.OPAQUE`, `NOT_FOCUSABLE | KEEP_SCREEN_ON | LAYOUT_IN_SCREEN | LAYOUT_NO_LIMITS`, `screenBrightness = BRIGHTNESS_OVERRIDE_OFF`, `preferredRefreshRate = 30`).
4. Mỗi 30 giây `onTick`: hết giờ → dừng; pin ≤ ngưỡng và không cắm sạc → dừng; thermal ≥ SEVERE (API 29+) → dừng; CPU `:pN` < 0,5% hai lần liên tiếp → cảnh báo "game có vẻ đứng"; overlay mất → dựng lại; cập nhật thông báo.
5. Lối thoát: (a) chạm 3 lần góc trên-phải trong 1,5 giây; (b) nút trong thông báo; (c) nút trên màn hình chính; (d) tự dừng theo điều kiện ở bước 4. Chạm 1 lần chỉ hiện thông tin 3 giây.
6. `stop()`: gỡ overlay, khôi phục âm lượng, tạo **báo cáo phiên** (thời gian, pin đầu/cuối, nhiệt cao nhất, MB mạng theo UID, số lần tiến trình chết, số lần nghi đứng, số lần màn hình bị tắt thật, lý do dừng), lưu vào `last_report`, đẩy thông báo.
7. Khôi phục: nếu dịch vụ bị kill rồi dựng lại, `resumeIfNeeded()` đọc phiên đã lưu và dựng lại overlay; sau reboot `BootReceiver` xóa phiên và trả âm lượng.
8. Hẹn giờ: `Scheduler` đặt alarm bắt đầu hằng ngày; kết thúc theo giờ đặt; cố gắng mở game (có thể bị Android chặn, nên có thông báo nhắc).
9. Watchdog: alarm 10 phút dựng lại dịch vụ nếu `keepAlive` bật mà dịch vụ không chạy.

### 16.4 Giả định và rủi ro CHƯA kiểm chứng

| ID | Giả định | Nếu sai thì |
|---|---|---|
| G-1 | `FLAG_KEEP_SCREEN_ON` trên cửa sổ overlay giữ màn hình bật | Thêm `WakeLock` màn hình không khả thi (deprecated) → chuyển sang activity trong suốt của chính app |
| G-2 | `screenBrightness` của cửa sổ overlay áp dụng được trên ROM đó | Một số OEM bỏ qua; chấp nhận độ sáng bình thường, vẫn đen trên OLED |
| G-3 | Overlay không focus nên game giữ focus và **không** gọi pause | Nếu game pause khi bị che → chế độ B vô dụng với game đó; ghi vào danh sách tương thích |
| G-4 | `preferredRefreshRate = 30` có hiệu lực | Game có thể bỏ phiếu cao hơn; chỉ là gợi ý |
| G-5 | Quyền overlay cấp được cho app cài ngoài Play (Android 15 có thể coi là "cài đặt bị hạn chế") | UI đã có hướng dẫn "Cho phép cài đặt bị hạn chế" |
| G-6 | Đọc `/proc/<pid>/stat` của `:pN` được (cùng UID/domain) | `CpuSampler` trả "không đọc được", mất tính năng phát hiện đứng hình |
| G-7 | Alarm hẹn giờ + khởi động FGS/overlay từ nền được phép (target 28 không bị ràng buộc FGS-từ-nền của Android 12+; suy luận từ tài liệu: các hạn chế này gắn với targetSdk) | Phiên theo lịch không bắt đầu; thông báo nhắc người dùng |
| G-8 | Mở game tự động từ nền | Thường bị chặn; chỉ là cố gắng tối đa |
| G-9 | Các không gian (userId > 0) tạo được và cô lập dữ liệu | **Không quảng cáo đa tài khoản** (P0-6) |
| G-10 | `TrafficStats.getUidRxBytes` theo UID đủ cho báo cáo mạng | Chỉ là ước lượng tổng cho cả workspace |
| G-11 | Overlay có thể bị một số game/anti-cheat phát hiện | **Đã cảnh báo; không né** (D-14, F-10) |
| G-12 | Bấm nút nguồn → màn hình tắt thật → game đứng | Chỉ cảnh báo; không chặn được |
| G-13 | Game tiếp tục chạy khi vào PiP; thiết bị hỗ trợ PiP | Ghi vào danh sách tương thích; PiP không dùng cho game đó |
| G-14 | Hook áp độ sáng/giữ màn hình lên cửa sổ game và game không tự đặt lại | Dùng chế độ "Màn hình đen" thay thế |
| G-15 | `AppLifecycleCallback` được gọi trong `:pN` đúng lúc và mã sinh khớp lõi thật | Đọc `inspect/` của CI, chỉnh `gen_guest_hooks.py`; tính năng hook tự tắt nhưng game vẫn chạy |
| G-16 | Socket UNIX trừu tượng dùng được giữa các tiến trình của app (đã kiểm UID peer) | Chuyển sang ContentProvider (lõi dùng `SystemCallProvider` cho IPC nên đường này chắc chắn đi được) |
| G-17 | Bố cục thư mục dữ liệu đúng như tài liệu lõi (`<cache>/blackbox/data/user/<u>/<pkg>`) | `GuestBackup.locate` có fallback dò tìm; Chẩn đoán in đường dẫn thực |
| G-18 | `ScreenPower` chạy được trên máy thật: Android ≤13 qua `SurfaceControl`, Android 14+ qua `DisplayControl` + `loadLibrary0` | Thử `LD_PRELOAD` các thư viện: `/apex/com.android.adbd/lib64/libadb_pairing_server.so`, `libadb_pairing_connection.so`, `/apex/com.android.os.statsd/lib64/libstatspull.so`, `libstatssocket.so`, `/apex/com.android.runtime/lib64/bionic/libdl_android.so`, `/apex/com.android.i18n/lib64/libandroidicu.so`, `/system/lib64/libandroid_servers.so` cùng `CLASSPATH=<apk>:/system/framework/services.jar`; hoặc `service call SurfaceFlinger 20000 i64 <id> i32 0` (Qualcomm; id lấy từ `dumpsys SurfaceFlinger --displays`) |
| G-19 | Panel tắt + `FLAG_KEEP_SCREEN_ON` trên cửa sổ game (chế độ mờ) giữ Android không ngủ và game tiếp tục vẽ | Đo bằng `testguest` (mục 11-AA); nếu máy vẫn ngủ thì đặt thời gian chờ màn hình dài hơn |

### 16.5 Cách đo (thay cho "tin")

Bộ đếm của `testguest`: **wall** (đồng hồ thật), **worker** (luồng 1 Hz, độc lập màn hình), **game** (cộng dồn trong `Choreographer`, chỉ tăng khi có VSync). Chạy mỗi cấu hình 30 phút, ghi vào bảng:

| Cấu hình | Mong đợi nếu giả thuyết đúng | wall | worker | game | CPU `:pN` | Pin | Nhiệt |
|---|---|---|---|---|---|---|---|
| Ghim TẮT, tắt màn hình thật | worker có thể tụt (CACHED), game đứng | — | — | — | — | — | — |
| Ghim BẬT, tắt màn hình thật (chế độ A) | worker ≈ wall, **game đứng** | — | — | — | — | — | — |
| Chế độ B (màn hình đen) | wall ≈ worker ≈ game | — | — | — | — | — | — |

Kết luận cần có: (1) ghim có tác dụng không (importance + worker); (2) game theo khung hình có thật sự đứng ở chế độ A không; (3) chế độ B có cứu được không; (4) chênh lệch pin giữa A và B trên OLED/LCD.

### 16.6 Quy trình thử bằng `testguest`

1. Tải artifact `testguest.apk` (job arm64 của workflow). Trong workspace: *Thêm APK* → chọn file → chọn Không gian 1.
2. Mở app, chụp lại `androidId`, `filesDir`. Cài thêm vào Không gian 2 và so sánh (P0-6).
3. Menu giữ lâu → *Chế độ game…* → chọn cấu hình → *Bắt đầu*. Chờ 30 phút.
4. Thoát, mở lại `testguest`, đọc bộ đếm; mở *Chẩn đoán* để lấy importance/CPU; lấy `heartbeat.log` (`logcat -s VSpaceTestGuest`).
5. Dán kết quả vào bảng 16.5 và mục 11.


### 16.7 Cập nhật đợt 3: chế độ mờ, hook, PiP, sao lưu

| Chủ đề | Thiết kế | Giả định chưa kiểm |
|---|---|---|
| Màn hình mờ (`MODE_DIM`) | Hook trong tiến trình app ảo đặt `FLAG_KEEP_SCREEN_ON` + `screenBrightness = 0` trên cửa sổ activity đang hiển thị; áp lại mỗi lần resume; khôi phục giá trị gốc khi thoát | G-14: hook hoạt động và game không tự đổi lại độ sáng |
| Hook | `GuestCallback` (sinh từ source lõi) → `GuestHooks.onEvent` → đăng ký `ActivityLifecycleCallbacks` trên Application thật của app ảo + mở `IpcClient` | G-15: `AppLifecycleCallback` được gọi trong tiến trình `:pN` đúng lúc |
| IPC | Tiến trình chính mở `LocalServerSocket("vspace-ipc-<host>")`; app ảo kết nối, gửi `hello` (pid, gói, không gian), nhận lệnh `dim`/`pip`; kiểm UID peer | G-16: socket trừu tượng dùng được giữa các tiến trình của app |
| PiP | Manifest: mọi `ProxyActivity` có `supportsPictureInPicture`; lệnh `pip` gọi `enterPictureInPictureMode` trên activity đang hiển thị | G-13: game tiếp tục chạy khi vào PiP; thiết bị hỗ trợ PiP |
| Sao lưu | Xem D-30; game được dừng bằng `Engine.stop` (hàm lõi → `killAppByPkg` → giết pid từ sổ IPC) và chờ `waitUntilGone` | G-17: bố cục thư mục đúng như tài liệu lõi (Chẩn đoán in đường dẫn thực) |
| Chính xác hơn khi phát hiện đứng | Biết pid của đúng game nên đo CPU của game đó thay vì tiến trình bận nhất | Phụ thuộc G-15 |

---

## 17. Đối chiếu bản đánh giá bên ngoài (DeepSeek, file PDF người dùng gửi)

Người dùng làm rõ phạm vi là **kỹ thuật, UI, UX Android**, nên phần pháp lý/kinh doanh/thanh toán không xử lý (chỉ ghi lại nếu sau này bán). Dưới đây là trạng thái từng nhóm đề xuất.

### 17.1 Đã làm trong phiên 3 (code xong, chưa chạy)

| Đề xuất | Cách làm | Mục |
|---|---|---|
| Phân tích "giữ nền cho game" (process sống ≠ game chạy) | Chế độ A/B, `GameModeController`, `GameOverlay` | 16 |
| Overlay đen + khóa chạm + 2 lối thoát | Chạm 3 lần góc phải-trên + nút thông báo + nút màn hình chính | 16.3 |
| Tự thoát theo pin/nhiệt/giờ; báo cáo phiên | `onTick`, `buildReport` | 16.3 |
| Tắt tiếng có khôi phục an toàn | `muteMusic`/`restoreVolume`, `vol_restore` | D-18 |
| Gợi ý giảm tần số quét | `preferredRefreshRate = 30` (chỉ là gợi ý, G-4) | 16.4 |
| Hồ sơ từng game, hẹn giờ | `GameProfile`, `GameActivity`, `Scheduler` | 16 |
| Phát hiện game đứng; cảnh báo tiến trình chết | `CpuSampler`, `ProcessPinner.died` | 16.3 |
| Watchdog dựng lại dịch vụ | `AlarmReceiver` + `Scheduler.armWatchdog` | D-16 |
| Đa tài khoản (không gian) | `Engine` theo `userId`, chọn không gian khi cài | D-15 |
| Báo lỗi cài đặt rõ (ABI 32/64, dung lượng, split, APK hỏng) + tiến trình | `ApkImporter`, `ProgressBar` | 5 |
| Nhận XAPK/APKS có 1 APK gốc | `ApkImporter.extractSingleApk` | F-15 |
| Cảnh báo game có anti-cheat trước khi cài/chạy | `RiskList.confirm` | D-14 |
| Tìm kiếm danh sách, giao diện tối, tiếng Anh, trạng thái game ở màn hình chính | `MainActivity`, `values-night`, `values-en` | 5 |
| Chẩn đoán đo CPU/pin/nhiệt, không chặn UI | `Diagnostics`, `CpuSampler.measureAll` | 5 |
| Kênh thông báo riêng cho cảnh báo; `FOREGROUND_SERVICE_IMMEDIATE` | `Notifier` | 4 |
| App thử để đo (đề xuất P0-5/P0-6/P0-7 của họ) | `testguest` | D-17 |
| Crash handler, ring buffer log, xuất báo cáo | `LogBuffer`, `ShareProvider`, nút Chia sẻ | D-19, D-20 |
| Xem quyền + chữ ký trước khi cài; công bố thành phần không chạy được | `ApkImporter.fillDetails`, hộp xác nhận | D-22 |
| Cài hàng loạt; nhận APK qua share/VIEW; cảnh báo ghi đè/hạ phiên bản | `importUris`, intent-filter, `checkOverwriteThenInstall` | 5 |
| Đổi tên, phím tắt launcher, xuất APK | menu app, `ShortcutActivity` | D-23 |
| Onboarding + tuyên bố phạm vi trong app | `SetupActivity` | 5 |
| Test đơn vị, lint, ngân sách APK, kiểm 16 KB | `PureLogicTest`, CI, `apk_report.py` | D-24 |
| Thay Breakpad bằng lý do thoát tiến trình | `ExitReasons` | D-21 |
| Sao lưu/khôi phục dữ liệu, tự sao lưu ra thư mục ngoài | `GuestBackup`, SAF | D-30 |
| Hook vòng đời app ảo; sổ pid → game | `GuestHooks`, `IpcServer`, `GuestRegistry` | D-26, D-27 |
| Chế độ không cần quyền overlay; PiP | `MODE_DIM`, lệnh `pip` | D-28, D-29 |
| Biên dịch và test thật trong sandbox | `compile_check.py` | D-32 |
| Tắt hẳn panel mà game vẫn chạy | `ScreenPower` + hướng dẫn trong hồ sơ game (cần ADB) | D-33 |
| Dark theme tự động / màu động mà không thêm thư viện | `values-v29`, `values-night-v29` | D-34 |

### 17.2 Chưa làm (đã ghi backlog)

Còn lại sau phiên 4b: virtual display (F-20: cần helper quyền shell + vá lõi); Material/RecyclerView/ViewModel (F-19: viết lại UI mù có rủi ro vỡ màn hình duy nhất đang chạy được; AndroidX chắc chắn có trong repo lõi nên về phụ thuộc không phải trở ngại); hook `Display.getRefreshRate` (F-24, cần vá lõi); cô lập từng guest ở mức engine (P1-15, cần đọc lõi). Đã làm trong phiên 4/4b: cập nhật giữ dữ liệu, widget, hạ độ phân giải, ghim chọn lọc, RAM/CPU từng guest, Cài đặt, ghép split APK (tùy chọn), chép OBB, job emulator (mục 18). **Không làm vì không có API tin cậy:** phát hiện LCD/OLED (F-25). **Không làm vì mục đích là né kiểm soát của bên khác:** F-26 và việc giả mạo/ẩn danh tính thiết bị để né anti-cheat (mục 18.5).

### 17.3 Cố ý KHÔNG làm

| Đề xuất | Lý do |
|---|---|
| Vẽ overlay trong task của host / cách khác để anti-cheat không phát hiện | Là né kiểm soát chống gian lận (F-10, D-14) |
| Giả mạo ANDROID_ID, fingerprint để tránh bị ban khi đa tài khoản | Cùng lý do; chỉ **đo** và báo cáo ID khác nhau hay không (P0-6) |
| Tự động bấm/anti-idle (nhập liệu giả) | Ngoài phạm vi, rủi ro vi phạm điều khoản game |
| Pháp lý, thanh toán, license key, chống sao chép | Người dùng đã giới hạn câu hỏi ở kỹ thuật/UI/UX |

### 17.4 Điểm bản đánh giá bên ngoài chưa chính xác hoặc chưa tính tới

- Nhiều mục "bắt buộc" (predictive back, edge-to-edge bắt buộc, quyền báo thức chính xác, hạn chế FGS khi boot) **chỉ áp với `targetSdk` cao**. Dự án đang target 28 nên chúng chưa phát sinh, nhưng sẽ phát sinh nếu nâng `-PtargetSdk` (D-05).
- Đánh giá coi "overlay đen làm màn hình tắt" là tiết kiệm pin; thực tế **GPU/CPU vẫn chạy** (đã ghi ở 16.2, 16.4).
- Một số khẳng định về hành vi engine (provider authority, keystore alias, WebView dir, `Binder.getCallingUid()`, 50 stub `:pN`) là **suy luận chung về app ảo hóa, chưa kiểm với NewBlackbox**; phải kiểm bằng P0-2/P1-15 trước khi coi là thật.

---

## 18. Phiên 4: làm nốt phần làm được không cần máy thật

Phạm vi: đọc kỹ tài liệu + mã + PDF (bản đánh giá DeepSeek) + `tech.txt`, rồi làm hết những gì **làm được và kiểm được trong sandbox** (biên dịch bằng `javac` + stub, test đơn vị, công cụ đo). **Không có thiết bị, Android SDK, Gradle hay mạng**, nên mọi thứ dưới đây là **[S] biên dịch được + hàm thuần có test**, còn hành vi trên máy là **[?]**.

### 18.1 Đối chiếu từng kỹ thuật trong PDF và `tech.txt`

| Kỹ thuật (nguồn) | Trạng thái | Ở đâu |
|---|---|---|
| Kiểm `isIgnoringBatteryOptimizations` + `getAppStandbyBucket` trước khi vào chế độ (tech.txt, "3 thứ bắt buộc") | Code xong, chỉ cảnh báo | `Preflight` (D-35) |
| Tiết kiệm dữ liệu, nhiệt, pin sắp tới ngưỡng, RAM thấp, ngủ đông/thu hồi quyền, overlay/thông báo bị tắt (PDF) | Code xong | `Preflight` |
| `setFrameRate(30)` giảm tải GPU (tech.txt) | Làm bằng `Surface.setFrameRate` trong game + `preferredDisplayModeId` ở overlay; `Window.setFrameRate` **không tồn tại** (F-23) | `GuestHooks.applySurfaceTuning`, `DisplayTuning` |
| `THREAD_PRIORITY_DISPLAY` cho luồng render (tech.txt) | Code xong, chạy trong tiến trình app ảo; không đổi được uclamp (không có API công khai) | `ThreadBoost` (D-37) |
| Hook `Display.getRefreshRate()` trả 60 (tech.txt) | **Không làm**, cần vá lõi (F-24) | — |
| Virtual display + MediaProjection; hook VSync/`eglSwapBuffers` (tech.txt) | **Không làm** (tech.txt tự xếp P3/nghiên cứu; F-20) | — |
| "Vẽ overlay trong task của host" để tránh bị phát hiện (tech.txt) | **Cố ý không làm** (F-26) | — |
| Hạ độ phân giải render (PDF) | Thử nghiệm, tắt mặc định (G-23) | `GuestHooks`, `DisplayTuning.scaledSize` |
| Phát hiện LCD/OLED (PDF) | **Không làm**; thay bằng đo pin tụt mỗi giờ thật (F-25) | `SessionStats` |
| Hướng dẫn theo hãng, khóa thẻ đa nhiệm, Samsung ngủ ứng dụng (PDF) | Code xong; nội dung bước là [R] | `OemGuide` |
| Miễn trừ pin bị mất sau OTA (PDF) | Code xong | `OemGuide.checkOta` |
| Nhắc khi phiên chạy > 12 giờ; báo cáo sau phiên có pin tụt/giờ, số lần dừng, tự mở lại, thiếu RAM (PDF) | Code xong | `GameModeController`, `SessionStats` |
| Thống kê từng game; hồ sơ từng game (boost, giảm độ phân giải, tự mở lại, ghim) (PDF) | Code xong | `SessionStats`, `GameProfile`, `GameActivity` |
| Tự mở lại game khi tiến trình biến mất (PDF) | Code xong, **phụ thuộc hook IPC** (G-25) | `GameModeController.checkGuestGone` |
| `onTrimMemory`/LMK; giới hạn địa chỉ 32-bit (PDF) | Đếm sự kiện + cảnh báo; cảnh báo 32-bit trong Preflight | `SpaceApp`, `GameModeController.onTrimMemory` |
| FGS bị Android chặn khởi động từ nền: dự phòng (PDF) | Code xong: thông báo thay vì im lặng | `GameModeController.begin`, `AlarmReceiver` |
| StrictMode bản debug (PDF) | Code xong, chỉ ghi log | `SpaceApp` |
| RAM/CPU từng guest; ghim chọn lọc theo guest (PDF) | Code xong | `GuestMonitor`, `ProcessPinner.shouldPin` (D-36) |
| Widget; màn hình Cài đặt; xem/chia sẻ nhật ký; giới thiệu + thay đổi (PDF) | Code xong | `StatusWidget`, `SettingsActivity` |
| Sắp xếp/lọc, trạng thái "đang chạy", `contentDescription` (PDF) | Code xong; **chưa có** vuốt-để-thao-tác, Snackbar hoàn tác, bottom sheet (framework không có sẵn, F-19) | `MainActivity`, `AppSort` |
| Cập nhật guest giữ dữ liệu (PDF) | Code xong | `UpdateKeeper` (D-38) |
| Khóa ký thật, `versionCode` tăng, `apksigner verify`, ghi chú phát hành (PDF) | Code xong; **cần đặt secrets** (P1-19) | `build.gradle`, `build.yml` (D-40) |
| Instrumentation/emulator trong CI (PDF) | **Chưa** (F-30); thay bằng công cụ đo adb | `measure_background.py` |
| ANDROID_ID/fingerprint khác nhau giữa guest (PDF) | **Chỉ đo, không giả mạo** (mục 17.3) | testguest `ident` + `measure_background.py isolation` |
| Play Protect không quét app ảo, Buộc dừng, vuốt khỏi đa nhiệm, OBB, Widevine, Google Sign-In/Maps/Billing/Firebase (PDF, "hết chưa") | Đã đưa vào tuyên bố phạm vi trong app; OBB còn là P1-20 | `strings.xml` (`scope_no`, `scope_maybe`) |
| Ghép split APK; Material/RecyclerView/ViewModel; virtual display | **Chưa làm** (F-29, F-19, F-20) | — |

### 18.2 Giả định mới chưa kiểm chứng

| ID | Giả định | Cách kiểm | Nếu sai |
|---|---|---|---|
| G-20 | `UsageStatsManager.getAppStandbyBucket()` đọc được cho chính gói của app không cần quyền, và trả đúng trên mọi ROM | Z1: so với `dumpsys usagestats` | Bỏ cảnh báo nhóm chờ trên ROM đó |
| G-21 | `Process.setThreadPriority` mức âm đưa luồng ra khỏi nhóm nền; `ThreadBoost` tìm đúng luồng render theo tên | Z4 + `measure_background.py` có/không bật boost | Tắt mặc định, hoặc bỏ |
| G-22 | `Surface.setFrameRate` trên Surface của SurfaceView làm game giảm tải GPU (game có thể tự đặt lại) | Z5: CPU/GPU, pin | Bỏ lệnh `fps` |
| G-23 | `setFixedSize` giảm độ phân giải mà game vẫn vẽ đúng, không crash | Z5 với ≥ 3 game Unity/Unreal/Cocos | Giữ tắt mặc định, ghi danh sách game lỗi |
| G-24 | ROM tôn trọng `preferredDisplayModeId` cho cửa sổ overlay | Z5: `dumpsys display` hoặc đo pin | Chỉ còn gợi ý `preferredRefreshRate` |
| G-25 | Tự mở lại game từ nền được Android cho phép khi overlay đang hiển thị (miễn trừ khởi chạy nền), và hook đã báo game kết nối IPC | Z7 | Chỉ báo thông báo, không tự mở |
| G-26 | `ActivityManager.getProcessMemoryInfo` đọc được PSS các tiến trình cùng UID; pid khớp sổ IPC | Mở "Tài nguyên" khi game chạy | Hiện `?` (đã xử lý) |
| G-27 | Engine ghi đè không giữ dữ liệu → `UpdateKeeper` phát hiện (so dung lượng) và khôi phục đúng; `GuestBackup.locate` đúng vị trí | Z6 | Xem log `VSpaceUpdate`; giữ file preupdate |
| G-28 | Widget `RemoteViews` hiển thị đúng; nút Thoát (`PendingIntent.getService`) chạy khi đang có FGS | Z8 | Dùng `getForegroundService` hoặc bỏ nút |
| G-29 | Định dạng `dumpsys activity processes` / `dumpsys battery` khớp bộ parse của `measure_background.py` trên Android của bạn | Chạy `run` 1 phút, xem có dòng "ưu tiên :pN" | Parse trả rỗng (đã không báo sai); gửi mẫu để sửa regex |
| G-30 | Jar APKEditor chạy được trên Android (dex hóa, không dùng API thiếu) và lõi chấp nhận APK ghép **chưa ký** | Cài một XAPK split thật (có `config.*` + `split_*`) | Ký lại bằng thư viện ký chạy được trên Android (AntiSplit-M dùng bản port apksig của MuntashirAkon); hoặc bỏ tính năng |
| G-31 | Lõi đọc OBB từ `storage/emulated/<không gian>/Android/obb/<gói>/` dưới gốc ảo | Cài XAPK có OBB, mở game; so với `core-inspection`/P0-2 | Sửa `BundlePlan.obbDirRel` theo đường dẫn lõi thật |
| G-32 | Job `emulator-smoke` chạy được trên runner (KVM, API 30, `arch: x86_64` chạy APK ABI `x86`) | Xem log job lần chạy đầu | Chỉnh `api-level`/`arch`; job đã `continue-on-error` nên không chặn gì |

### 18.3 Cách dùng công cụ đo (máy tính có adb + điện thoại bật gỡ lỗi USB)

```
# 1. Cài workspace + testguest, thêm testguest vào Workspace, MỞ nó (để có nhịp tim trong logcat)
# 2. Tắt màn hình thật 30 phút (ghim bật/tắt tùy công tắc trong app):
python3 scripts/measure_background.py run --label "ghim-bat-tat-man-hinh" --minutes 30 --screen off --out kq1.json
# 3. Hoặc chế độ game: bật "Màn hình đen" trong app rồi:
python3 scripts/measure_background.py run --label "game-man-hinh-den" --minutes 30 --screen keep
# 4. Cô lập giữa hai không gian:
python3 scripts/measure_background.py isolation
# 5. Có sẵn log: adb logcat -d -s VSpaceTestGuest:I > log.txt ; python3 scripts/measure_background.py analyze log.txt
```

Kết quả dán vào bảng mục 16.5; mã kết luận: **RUNS** (logic game vẫn tiến), **FRAME-LOOP-STOPPED** (tiến trình sống nhưng vòng lặp khung hình dừng), **FROZEN** (hết CPU/đóng băng), **KILLED** (khởi động lại), **PARTIAL**, **NO-DATA**.

### 18.4 Những gì làm trong sandbox không thay được

- Chưa có build Gradle thật: stub Android (đã thêm khoảng 30 chữ ký trong phiên này) viết theo hiểu biết API, có thể lệch bản thật (P0-10).
- Không có đo nào về giữ nền, pin, nhiệt, tần số quét, độ phân giải: mọi con số thuộc P0-4/5/7 và P1-18 vẫn **trống**.
- Không thể chứng minh các tinh chỉnh trong game (boost luồng, `fps`, `lowres`) có lợi: chúng đều tắt/bật được và hoàn nguyên được để đo A/B.
- Bài học quy trình: thử đột biến phát hiện một test thiếu (ngưỡng nhóm chờ RARE); đã bổ sung và đột biến bị bắt. `check.py` cũng được mở rộng (đọc `res/xml`, nhận layout của `RemoteViews`) và đã chứng minh bắt được lỗi id widget thiếu.

### 18.5 Tra cứu bổ sung (phiên 4b): kết quả và những gì đã làm theo đó

Người dùng yêu cầu tra cứu và làm nốt các mục "chưa làm" / "cố ý không làm". Kết quả:

| Chủ đề | Điều tra cứu được (nguồn) | Việc đã làm |
|---|---|---|
| Ghép split APK | APKEditor của REAndroid (Apache-2.0) có lệnh `m` ghép thư mục/XAPK/APKS/APKM thành APK đơn; tài liệu nêu cách nhúng bằng `com.reandroid.apkeditor.Main.execute(String[])` (không gọi `System.exit`). AntiSplit-M (fork Apache-2.0, ~3,4 nghìn sao) chạy trên Android bằng chính mã đó; nhắc rằng APK ghép phải được ký mới cài được bằng trình cài đặt hệ thống. ARSCLib (nền của APKEditor) có trên Maven Central (`io.github.reandroid:ARSCLib`) | `SplitMerger` (reflection, tùy chọn), CI tải jar (`APKEDITOR_TAG`/`APKEDITOR_SHA256` để ghim), `ApkImporter` tự ghép khi gói có split |
| OBB | Cấu trúc XAPK: APK + `Android/obb/<gói>/*.obb` + `manifest.json`. Không có tài liệu nào nói NewBlackbox map đường dẫn OBB | `BundlePlan`, `ObbImporter`, xem trước số tệp/MB, chép sau khi cài; đích là giả định (G-31) |
| ABI của lõi | README và DeepWiki của NewBlackbox: ARMv7a, ARM64-v8a, x86 (không nêu x86_64); app mẫu của lõi dùng AndroidX (lifecycle, work-runtime...) và cấu hình kho Maven tập trung trong `settings.gradle` | Giữ leg armv7 (P1-4 [R]); thêm chặng x86 + `emulator-smoke` (F-30) |
| Virtual display | Thử nghiệm Android 15 thật do người khác công bố: app thường không gắn được `setLaunchDisplayId` lên màn hình ảo do chính nó tạo (SecurityException), màn hình ảo PUBLIC cần token MediaProjection; các công cụ thật dùng tiến trình quyền shell | Không làm (F-20 cập nhật): cần helper quyền shell + vá lõi |
| Material/RecyclerView | Lõi dùng AndroidX nên phụ thuộc không phải rào cản; rào cản là phải chuyển theme sang Material và viết lại danh sách + menu ngữ cảnh mà không build/chạy được | Không làm (F-19), nêu rõ lý do |

** người dùng đề nghị bỏ quy tắc để làm các tính năng (che overlay khỏi bị phát hiện, giả mạo/ẩn danh tính thiết bị hoặc môi trường ảo). Việc này nhằm vô hiệu hóa cơ chế bảo vệ của bên thứ ba và thường dùng để gian lận trong game trực tuyến, nên không được thêm vào dự án. Cái thay thế hợp lệ cho nhu cầu thật: (1) đo xem engine có cô lập dữ liệu giữa hai không gian không (`measure_background.py isolation`) và nói thật kết quả; (2) với đa tài khoản, dùng cơ chế chính thống của Android (hồ sơ công việc/người dùng phụ, Island/Shelter) hoặc tính năng đa tài khoản/AFK mà nhà phát hành game cho phép; (3) giữ cảnh báo anti-cheat trước khi cài (`RiskList`) và tuyên bố phạm vi trong app.

---

## 19. Phiên 7: kiểm chứng bằng công cụ thật và làm nốt phần làm được

### 19.1 Điều kiện sandbox (đã đo, không đoán)

Cho phép: `github.com`, `codeload`/`raw`/`release-assets.githubusercontent.com`, `archive.ubuntu.com` (apt), npm/PyPI/crates/conda.
**Không** có: `dl.google.com`, `maven.google.com`, `repo1.maven.org`, `services.gradle.org` ⇒ **Gradle/AGP vẫn không chạy được** (P0-1 vẫn là việc của CI). `api.github.com` bị giới hạn lượt (60/giờ chia sẻ IP, đã chạm trần) ⇒ không đọc được nội dung Issues của lõi (E-4 vẫn mở; nguồn tổng hợp công khai ghi 22 issue mở, lần push cuối 2026-07-19 khớp SHA đã ghim, không trôi).

### 19.2 Bằng chứng mới (mức [V]) — chạy lại bằng `python3 scripts/verify_real.py --fetch`

| # | Kiểm chứng | Công cụ thật | Kết quả |
|---|---|---|---|
| 1 | Toàn bộ `workspace` + hook sinh tự động biên dịch với **source thật của lõi (SHA `89b5983`) và `android.jar` API 35** | `javac`, `overlay.sh` chạy trên lõi thật | 0 lỗi trong mã dự án; **đột biến** (gọi hàm lõi không tồn tại) bị bắt đúng chỗ ⇒ phép kiểm không mù. Bỏ qua có chủ ý 1191 lỗi nằm trong lõi (thiếu AIDL/`BR*` sinh tự động, androidx) |
| 2 | Tài nguyên + manifest | `aapt` thật + `android.jar` API 28 (phần mới hơn 28 loại ra có chủ ý: `values-v29`, `foregroundServiceType`) | Đạt sau khi sửa 1 lỗi thật (E-11) |
| 3 | Chữ ký APK v2 do `ApkSigner` sinh | **`apksigner` AOSP** | `Verified using v2 scheme: true`; APK lớn nhiều đoạn 1 MiB; ký lại APK đã ký; **ca âm**: sửa 1 byte ⇒ bị từ chối (`CHUNKED_SHA256 digest mismatch`) |
| 4 | Chuỗi ghép split → ký | APKEditor 1.4.9 thật (sha256 `a9cd40df…` khớp giá trị ghim) + bộ split do `aapt` tạo (base + hdpi + xhdpi) | Ghép đủ 3 mật độ, ký, `apksigner` v2 = true, `aapt dump badging` đọc được gói |
| 5 | Workflow | `actionlint` v1.7.7 (+ `shellcheck`) | 0 cảnh báo |
| 6 | API mới hơn minSdk 26 phải có kiểm `SDK_INT` | `javap` + `android-26.jar` thật (`scripts/api_audit.py`, chạy trong `compile_check.py`) | 3 phương thức `ExitReasons` (API 30) đã được bảo vệ ở hàm vào (dòng 56, 130) ⇒ ghi vào `ALLOW` kèm lý do; 0 mục chưa bảo vệ |

**Giới hạn của [V]:** `apksigner` xác minh bằng cùng thuật toán v2 mà hệ thống dùng, nhưng **`PackageParser` thật trên Android chưa từng chấp nhận APK này**; chưa Gradle/AGP; chưa chạy trên thiết bị.

### 19.3 Phát hiện về lõi (đọc source thật, SHA `89b5983`)

| Điều | Kết luận |
|---|---|
| **O-11** `VirtualSpoof.cpp` | Xem mục 12. Công tắc gỡ: `strip_core_spoof` / `VSPACE_STRIP_CORE_SPOOF=1`. Mặc định giữ nguyên hành vi lõi |
| **O-12** cài APK không chữ ký | Bị từ chối (`collectCertificates`). Đã có `ApkSigner` |
| UID ảo | `Os.getuid()` và `Binder.getCallingUid()` (hook native `BinderHook.cpp`) trả **appId ảo riêng theo gói** (`BPackageManagerService.getAppId`), nên kiểm `callingUid == myUid` giữa hai app ảo KHÔNG còn qua sai. **Nhưng UID thật của kernel vẫn là của host**: không có cách ly tệp/SELinux; app ảo A vẫn đọc được tệp của B nếu biết đường dẫn (đo ở P0-6) |
| Gate quyền lưu trữ | `BlackBoxCore.launchApk` (Android 11+, thiếu `MANAGE_EXTERNAL_STORAGE`) chỉ ghi cảnh báo rồi **vẫn mở** vì `AppLifecycleCallback.onStoragePermissionNeeded` mặc định trả `false`. Bộ sinh hook của Workspace chỉ override hàm `void` nên không chạm hàm này ⇒ Workspace tự hỏi người dùng trước khi mở (`MainActivity.openGuest`, `StorageAccess`) |
| Google services (`GmsCore`) | Chỉ **sao chép** các gói Google đã cài trên máy (`installPackageAsUser(String)`), không tải gì từ mạng. Đã nối UI (Cài đặt → Không gian ảo). **Chưa kiểm chứng** FCM/đăng nhập Google trên máy thật (P1-6) |
| API mới dùng | `clearPackage(String,int)`, `deleteUser(int)`, `isSupportGms()`, `isInstallGms(int)`, `installGms(int)`, `uninstallGms(int)`: chữ ký đã được `javac` xác nhận trên source thật; đã thêm vào spec của stub |
| ABI | `Bcore/build.gradle` `abiFilters 'arm64-v8a','armeabi-v7a'` và `Application.mk` — **không có x86** (chặng `x86` ở F-30 là sai, đã bỏ) |
| Java/Gradle | `Bcore` `sourceCompatibility 21`, CI lõi dùng JDK 21, AGP 8.13.2, Gradle 8.14.5, compileSdk 35, NDK 29.0.13846066 (E-10) |

### 19.4 Mã mới (đều biên dịch với `android.jar` thật; logic thuần có test JVM)

| Lớp | Việc | Test |
|---|---|---|
| `ApkSigner` | Ký APK Scheme v2, Java thuần, khóa RSA 2048 sinh trên máy (chứng chỉ tự ký dựng tay bằng DER), lưu `files/merge-signer/` | `ApkSignerTest` (8) + `apksigner` thật |
| `MiniJson`, `UpdateChecker` | Phân tích Releases JSON, so sánh phiên bản, chọn APK theo ABI, tải có kiểm host/HTTPS/sha256 | `UpdateCheckerTest` (10) |
| `UpdateFlow` + Cài đặt | Nút *Kiểm tra cập nhật*, tùy chọn tự kiểm (mặc định TẮT), hộp thoại, tải, mở trình cài; thanh nhắc ở màn hình chính | giao diện chưa chạy [?]; phần mạng không test được trong sandbox |
| `TrashBin`, `UndoBar` | Bản sao an toàn trước khi gỡ / xóa dữ liệu (≤1,5 GB; giữ 3 bản / 14 ngày), thanh *Hoàn tác* 12 giây, khôi phục từ Cài đặt → Thùng rác | `PermissionBridgeTest` (kế hoạch dọn) |
| `BottomSheet` | Menu từng app dạng bảng đáy (framework, không thêm thư viện) | — |
| `PermissionBridge` | Phân loại quyền nhạy cảm: đã cấp / xin được / **không xin được vì Workspace không khai báo** | `PermissionBridgeTest` (6) |
| `StorageAccess` | Gợi ý \"Truy cập mọi tệp\" Android 11+ trước khi mở app cần bộ nhớ chung | — |
| `Engine` | `clearData`, `deleteSpace`, `gmsSupported/Installed`, `installGms`, `uninstallGms` | — |
| Hạ tầng | `verify_real.py`, `api_audit.py`, `compile_check.py` dùng `android.jar` thật, workflow dựng lại, `LICENSE`, `NOTICE`, công tắc O-11 | — |

Quyền manifest mới: `REQUEST_INSTALL_PACKAGES` (đưa APK cập nhật đã kiểm sha256 cho trình cài; người dùng vẫn phải bấm), `MANAGE_EXTERNAL_STORAGE`. Vì app ảo dùng quyền của host nên hai quyền này cũng nằm trong tay app ảo (chúng vẫn bị hệ thống chặn bằng hộp thoại/cài đặt do người dùng bật).

### 19.5 Cố ý KHÔNG làm, và vì sao

| Việc | Lý do |
|---|---|
| Che overlay/giả mạo ID, fingerprint, thuộc tính thiết bị; mở rộng thứ lõi đã giả mạo | Vô hiệu hóa cơ chế chống gian lận/an ninh của bên thứ ba. Bị yêu cầu nhiều lần nhưng không đổi quyết định (AGENTS #9). Phần lõi tự có đã được **minh bạch hóa + có công tắc gỡ** (O-11) |
| Gửi báo crash/telemetry tự động ra ngoài | Lõi từng rò dữ liệu ra bên thứ ba (O-10); báo lỗi vẫn là xuất/chia sẻ tệp thủ công (AGENTS #24) |
| Chuyển sang AppCompat/Material/RecyclerView/ViewModel | Phụ thuộc đã có trong đồ thị build (lõi dùng), nhưng **không có AndroidX trong sandbox** để biên dịch/kiểm; viết lại màn hình duy nhất đang chạy được mà không biên dịch, không chạy là rủi ro lớn hơn lợi ích. Đã đạt phần lớn mục đích UX bằng thành phần framework (bottom sheet, thanh hoàn tác, theme DayNight) |
| Vuốt-để-thao-tác trên danh sách | Xung đột cử chỉ với chạm/chạm giữ hiện có; không thể thử bằng cảm ứng thật; bottom sheet thay thế |
| Màn hình ảo + MediaProjection (hướng 2 trong `tech.txt`), hook `getRefreshRate` | Cần vá lõi + thiết bị; mục 18.5 đã ghi rào cản (SecurityException `setLaunchDisplayId`) |
| Instrumentation test (`androidTest`) | Cần `androidx.test` (không có trong sandbox); job `emulator-smoke` là phương án tạm |
| Mã hóa dữ liệu app ảo | Cùng UID kernel của host ⇒ mã hóa trong cùng tiến trình không đem lại cách ly thật; ghi vào giới hạn thay vì tạo cảm giác an toàn giả |

### 19.6 Giả định mới CHƯA kiểm chứng

| ID | Giả định | Cách kiểm |
|---|---|---|
| G-33 | `PackageParser` trên Android thật chấp nhận APK ghép + ký v2 của `ApkSigner` (đã qua `apksigner`, chưa qua `PackageParser`) | Cài một XAPK có split trên máy thật (P0-3) |
| G-34 | Ghép bằng APKEditor giữ được `classes*.dex`, thư viện native và `resources.arsc` đúng với app thật (mới thử với bộ split mẫu chỉ có tài nguyên) | Thử XAPK thật nhỏ |
| G-35 | `installGms` chạy được trên máy có GMS và FCM hoạt động trong không gian đó | P1-6 |
| G-36 | `VSPACE_STRIP_CORE_SPOOF=1` vẫn build NDK xong (đã kiểm: danh sách nguồn hợp lệ; chưa chạy `ndk-build`) | CI với `strip_core_spoof=true` |
| G-37 | Đường mạng của `UpdateChecker` (api.github.com → chuyển hướng → tải → sha256) chạy đúng thật; mới test phần thuần + từ chối HTTP/host lạ | Tạo release thử trên kho thật, bấm nút |
| G-38 | `emulator-smoke` với APK arm64 trên emulator x86_64 API 30 (lớp dịch ARM) mở được UI | Xem log job lần đầu |
| G-39 | Menu bottom sheet/thanh hoàn tác hiển thị đúng ở chế độ sáng/tối, cạnh tai thỏ, bàn phím | Nhìn bằng mắt trên máy |

### 19.7 Cách chạy lại mọi thứ

```bash
python3 scripts/verify_real.py --fetch   # tải android.jar 26/28/35, lõi ở SHA ghim, APKEditor, actionlint; cần: git, java, aapt, apksigner, shellcheck (apt)
python3 scripts/check.py                 # kiểm tĩnh + compile_check (android.jar thật) + test JVM + api_audit
```

Thiếu công cụ thì bước tương ứng ghi `BỎ QUA` (không tính là đạt).

---

## 20. Phiên 8: tìm phương án khác cho những việc "cố ý không làm"

Phiên 7 liệt kê 4 việc không làm. Phiên 8 tách lại: **1 việc là quyết định, không phải giới hạn kỹ thuật** (giữ
nguyên); **3 việc còn lại tra cứu ra được cách làm thật**, không chỉ là ghi chú cho tương lai.

### 20.0 Giữ nguyên: không giả mạo ID / che overlay khỏi bị phát hiện

Đây không phải "chưa tìm ra cách" — mục đích của nó là lách cơ chế chống gian lận/bảo mật của game và ngân hàng
(AGENTS #9). Được hỏi lại ở phiên này dưới dạng chung "tìm phương án khác giải quyết vấn đề"; không đổi quyết định
vì được hỏi nhiều lần không phải lý do để đổi. O-11 (lõi tự làm việc này) vẫn chỉ minh bạch hóa + có công tắc gỡ,
không mở rộng.

### 20.1 Giới hạn mạng thật đã kiểm (không đoán)

Tìm artifact AndroidX thật (để biên dịch thử trong sandbox) tại: Google Maven (`dl.google.com`/`maven.google.com`),
CERN Nexus public mirror (`nexus.web.cern.ch` — có thật, có đủ `androidx.appcompat`/`material`), jitpack. **Cả ba
đều ngoài allowlist mạng của `bash_tool`** (chỉ có `github.com` và vài domain gói ngôn ngữ khác) nên không tải
được, kể cả khi biết chính xác URL. Đây là giới hạn sandbox, không phải chưa tìm ra nguồn.

### 20.2 RecyclerView + vuốt để thao tác — làm thật, không chỉ AppCompat/Material

**Phát hiện quan trọng đổi kế hoạch:** `AppCompatActivity`/theme `Theme.MaterialComponents` không cần thiết cho
RecyclerView — `RecyclerView` là `ViewGroup` bình thường, chạy được trên `Activity` + theme framework hiện tại
(đã xác nhận qua tài liệu chính thức). Vì vậy phiên này **chỉ** thêm RecyclerView (đổi được, rủi ro thấp, không
đụng base class của 9 Activity khác), **chưa** đổi sang AppCompatActivity/Material theme (việc đó vẫn cần làm
riêng, xem 20.5) — tránh rủi ro lớn khi không có máy để nhìn bằng mắt.

- `GuestAdapter extends RecyclerView.Adapter<VH>` thay `AppAdapter extends BaseAdapter`: ViewHolder thật (đỡ
  `findViewById` lặp mỗi lần cuộn), vẫn đọc trực tiếp `shown` như cũ (chưa chuyển sang `DiffUtil`/`ListAdapter` —
  G-41, để giảm rủi ro khi chưa nhìn được animation trên máy thật).
- `GuestSwipeCallback extends ItemTouchHelper.SimpleCallback`: vuốt phải = mở app, vuốt trái = menu (bottom
  sheet, như chạm giữ). `onSwiped` không xóa hàng — chỉ kích hoạt hành động rồi `notifyItemChanged` để hàng tự
  "nhảy" về chỗ cũ. `onChildDraw` vẽ nền màu + chữ "Mở"/"Menu" bằng `Canvas`/`Paint` thuần (không cần icon mới).
- `ListView.setEmptyView()` không có trên RecyclerView (G-40) → chuyển sang bật/tắt `View.GONE/VISIBLE` thủ công
  trong `applyFilter()`.
- `build.gradle` thêm `implementation 'androidx.recyclerview:recyclerview:1.1.0'`: **phải khai riêng** dù
  `Bcore` đã dùng `appcompat`/`material` — vì `Bcore/build.gradle` khai bằng `implementation` (không transitive),
  `workspace` không tự thấy được. `settings.gradle` gốc đã có `google()`/`mavenCentral()` nên khi CI thật chạy
  (có mạng tới Google Maven), dependency này resolve bình thường — **chỉ không resolve được TRONG SANDBOX**.

**Stub thủ công** (`scripts/stubs/androidx_api.spec`, mới): chỉ stub đúng phần `androidx.recyclerview.widget.*`
mà `GuestAdapter`/`GuestSwipeCallback` gọi tới (không thêm bề mặt thừa) — `RecyclerView`+`Adapter`+`ViewHolder`+
`LayoutManager`, `LinearLayoutManager`, `ItemTouchHelper`+`Callback`+`SimpleCallback`. Mỗi chữ ký đối chiếu với
developer.android.com (đã search, không đoán — ví dụ `getAdapterPosition()` chưa deprecated ở bản 1.1.0 đã ghim,
`SimpleCallback(int,int)`, `onChildDraw(Canvas,RecyclerView,ViewHolder,float,float,int,boolean)`). **Giá trị các
hằng số** (`LEFT`/`RIGHT`/`ACTION_STATE_*`) KHÔNG cần khớp tuyệt đối bản thật: stub không bao giờ được build CI
dùng tới (CI thật kéo androidx thật từ Maven), chỉ để `javac` chạy qua trong sandbox — nên sai giá trị hằng số
không gây hậu quả khi build thật, chỉ sai *chữ ký* (tên hàm/số-kiểu tham số/kiểu trả về) mới gây hậu quả, và đó là
phần đã đối chiếu kỹ.

Hai lần chạy `javac` khác nhau trong dự án đều cần stub này: `compile_check.py` (biên dịch với core giả) và
`verify_real.py` bước 1 (biên dịch với **source core thật**) — ban đầu quên nối vào bước 2, bị bắt ngay bởi chính
`verify_real.py` báo LỖI (`package androidx.recyclerview.widget does not exist`); đã sửa, xem 20.4.

Kiểm đột biến riêng cho stub mới: gọi một hàm không tồn tại của `GuestAdapter` → `compile_check.py` báo lỗi đúng
dòng → phục hồi → đạt lại. Mutation test cho thấy stub không "cho qua vô điều kiện".

**Mức kiểm chứng:** biên dịch sạch với stub đối chiếu tài liệu (mạnh hơn đoán, nhưng KHÔNG mạnh bằng [V] của mục
19 vì không phải android.jar/core thật) → gắn nhãn **[S2]**. Chưa chạy, chưa nhìn bằng mắt trên máy thật (G-39,
G-42, G-43).

### 20.3 Mã hóa — tìm đúng vấn đề để giải quyết, không lặp lại vấn đề cũ

Phiên 7 từ chối "mã hóa dữ liệu app ảo trong máy" vì guest/host chung UID kernel → mã hóa tại chỗ không tạo cách
ly thật, chỉ tạo cảm giác an toàn giả. **Lý do đó vẫn đúng và không đổi.** Nhưng đó không phải vấn đề duy nhất có
thể gọi là "mã hóa dữ liệu": có một vấn đề KHÁC, thật, và giải quyết được — file sao lưu MỘT KHI đã rời khỏi bộ
nhớ riêng của app (xuất qua Storage Access Framework ở `doBackup`, người dùng tự chọn nơi lưu) thì bất cứ app nào
đọc được bộ nhớ dùng chung, hoặc dịch vụ đồng bộ đám mây, đều đọc được dữ liệu riêng của app ảo bên trong (mật
khẩu đã lưu, token, ảnh…) — đây KHÔNG liên quan gì đến việc guest/host chung UID, vì file đã rời máy.

`BackupCrypto` (mới): AES-256-GCM, khóa sinh một lần trong `AndroidKeyStore` (không xuất ra được dạng byte, không
gắn sinh trắc học để khôi phục không cần mở khóa). Định dạng file: magic 8 byte (không bao giờ trùng 4 byte đầu
thật của ZIP là `PK\3\4`) + độ dài IV + IV + bản mã GCM. `wrapDecrypt` tự nhận ra file có mã hóa hay không (so
magic) nên khôi phục file cũ (trước khi có tính năng này) vẫn chạy, không hỏi gì thêm.

**Đánh đổi phải nói thật với người dùng trước khi bật** (đã viết thành hộp thoại, không giấu trong cài đặt):
khóa gắn với CÀI ĐẶT ứng dụng trên CHÍNH máy này — gỡ cài đặt hoặc đổi máy thì file đã mã hóa theo cách này KHÔNG
THỂ mở lại, kể cả bởi chính Workspace. Vì đánh đổi này đáng kể và sao lưu không phải thao tác làm nhiều lần, chọn
hỏi lại mỗi lần (dialog) thay vì một công tắc chung dễ quên.

**Test trên JVM:** `android.security.keystore.*`/`KeyStore.getInstance("AndroidKeyStore")` không chạy được trên
JVM thường (provider chỉ có trên Android thật) — tách `wrapEncrypt`/`wrapDecrypt` thành bản nhận thẳng `SecretKey`
(dùng nội bộ bởi bản không tham số gọi `AndroidKeyStore`) để test được bằng khóa AES thường của `javax.crypto`.
10 test: khứ hồi (rỗng, nhỏ, lớn nhiều khối cipher), sai khóa bị từ chối, sửa 1 byte đuôi (thẻ xác thực GCM) bị từ
chối NGAY CẢ VỚI ĐÚNG KHÓA, file cũ không mã hóa (kể cả ngắn hơn độ dài magic) đi qua nguyên vẹn. Hành vi
`CipherInputStream` khi thẻ xác thực sai (có ném lỗi đúng cách hay không — đây từng là lỗi lịch sử của một số
bản JDK) **đã chạy thật trên OpenJDK 21 trong sandbox, không suy đoán**: ném lỗi đúng, `isKeyOrIntegrityFailure`
nhận ra qua `AEADBadTagException`/`BadPaddingException` trong chuỗi `getCause()`.

**Mức kiểm chứng:** [V] cho định dạng file + logic mã hóa/giải mã (chạy thật trên JVM, kể cả ca lỗi). **[?]** cho
`AndroidKeyStore` thật trên Android (provider không có trên JVM) và cho UI (hộp thoại, 3 điểm gọi trong
`MainActivity` đã nối nhưng chưa chạy) — G-44.

### 20.4 Lỗi quy trình phát hiện ở phiên này

| # | Lỗi | Sửa |
|---|---|---|
| E-14 | Thêm `androidx_api.spec` vào `compile_check.py` nhưng QUÊN thêm vào đường biên dịch thứ hai của `verify_real.py` (biên dịch với source lõi thật) — `verify_real.py` tự bắt được (`package ... does not exist`), không phải tôi tự phát hiện trước | Luôn chạy LẠI `verify_real.py` sau khi thêm API mới cần stub, không chỉ `compile_check.py` |
| E-15 | `org.junit.Assert` giả của dự án thiếu `assertArrayEquals` — viết test trước, mới phát hiện khi chạy thật | Thêm vào `compile_check.py` (2 overload, giống phong cách các `assertEquals` khác đã có) |

### 20.5 Còn lại cho AppCompat/Material/ViewModel (ghi lại đường đi, chưa làm)

Nếu sau này muốn đổi thật sang Material (không chỉ RecyclerView): (1) thêm `androidx.appcompat:appcompat:1.2.0`
và `com.google.android.material:material:1.3.0` vào `workspace/build.gradle` (đã biết core dùng cùng bản, không
xung đột); (2) đổi TỪNG Activity một sang `AppCompatActivity`, build + cài thử trên máy TRƯỚC KHI đổi activity
tiếp theo (không đổi cả 10 cái cùng lúc — không có máy để phát hiện activity nào vỡ); (3) thêm stub
`androidx.appcompat.app.AppCompatActivity` (tối thiểu: `extends android.app.Activity`, không cần mô phỏng
`FragmentActivity` thật) vào `androidx_api.spec` theo đúng kỹ thuật ở mục 20.2; (4) đổi theme sang
`Theme.MaterialComponents.DayNight.NoActionBar` — core đã phụ thuộc Material nên không cần thêm gì khác. Việc
đáng làm trước: đã có `G-33` (cài XAPK thật) ở backlog — nên làm cùng đợt với việc này vì cả hai đều cần máy thật.

### 20.6 Giả định mới CHƯA kiểm chứng

| ID | Giả định | Cách kiểm |
|---|---|---|
| G-40 | Ẩn/hiện `emptyView` thủ công trong `applyFilter()` hoạt động đúng như `ListView.setEmptyView()` cũ (không nhấp nháy khi lọc nhanh) | Nhìn bằng mắt trên máy |
| G-41 | `notifyDataSetChanged()` (không dùng `DiffUtil`) đủ mượt cho danh sách thực tế (vài chục app); nếu giật/nhấp nháy khi danh sách dài thì cần chuyển sang `DiffUtil` | Nhìn bằng mắt với ~30-50 app ảo |
| G-42 | Vuốt không xung đột với cuộn dọc của chính RecyclerView (`ItemTouchHelper` tự xử lý việc này trong androidx thật, nhưng chưa nhìn bằng mắt) | Thử trên máy cảm ứng thật |
| G-43 | `androidx.recyclerview:recyclerview:1.1.0` resolve đúng, không xung đột version với `appcompat 1.2.0`/`material 1.3.0` mà core đã kéo, khi Gradle thật chạy | P0-1 (CI) |
| G-44 | `AndroidKeyStore` sinh khóa thành công trên thiết bị thật (vài máy cũ/giả lập có thể thiếu StrongBox hoặc lỗi provider); 3 điểm gọi `BackupCrypto` trong `MainActivity` (mã hóa khi sao lưu, giải mã khi khôi phục ở cả 2 luồng) chạy đúng, hộp thoại hỏi mã hóa hiển thị đúng | Cài trên máy thật, thử sao lưu có/không mã hóa rồi khôi phục cả hai |
| G-45 | Thông báo `restore_fail_key` hiển thị đúng khi thật sự khôi phục file mã hóa từ máy khác (mới kiểm logic phân loại lỗi trên JVM, chưa kiểm thông điệp hiển thị trên máy) | Mã hóa trên máy A, thử khôi phục trên máy B |

### 20.7 Tóm tắt — 3 việc "cố ý không làm" đã giải quyết thật, 1 việc giữ nguyên

| Việc (phiên 7) | Phiên 8 |
|---|---|
| Material/RecyclerView | **Làm:** RecyclerView + ViewHolder thật, có stub đối chiếu tài liệu [S2]. Material/AppCompat để sau (20.5) |
| Vuốt để thao tác | **Làm:** `ItemTouchHelper` thật (không phải tự vẽ bằng tay như từng cân nhắc ở phiên 7) |
| Mã hóa dữ liệu | **Làm — nhưng đúng vấn đề khác:** mã hóa file sao lưu khi XUẤT RA NGOÀI, không phải dữ liệu guest trong máy (vấn đề đó vẫn không mã hóa được vì lý do kỹ thuật ở phiên 7, không đổi) |
| Giả mạo ID / che overlay | **Giữ nguyên từ chối** — không phải giới hạn kỹ thuật |

---

## 21. Phiên 9: đọc sâu cô lập WebView (giải quyết phần "còn treo" của P1-15)

### 21.1 WebView data dir — CÓ cách ly, không điều kiện, đọc hết 2 lớp

`fake/service/WebViewFactoryProxy.java` (đã đọc ở phiên 7, chỉ proxy các hàm tĩnh của `WebViewFactory` — chọn
class/package nhà cung cấp WebView, KHÔNG liên quan thư mục dữ liệu) **không phải** nơi cách ly thật. Nơi thật là
`app/BActivityThread.java` dòng ~392, trong luồng khởi động tiến trình guest (trước `Application.onCreate`):

```java
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
    WebView.setDataDirectorySuffix(getUserId() + ":" + packageName + ":" + processName);
}
```

Gọi **không điều kiện** cho mọi guest (không phụ thuộc cấu hình, không cần core làm gì thêm), dùng đúng API chuẩn
của Android (`WebView.setDataDirectorySuffix`, có từ API 28) — nghĩa là cookie/localStorage/cache của WebView
**CÓ** cách ly thật giữa các guest khác nhau VÀ giữa các không gian khác nhau của cùng một guest, miễn máy chạy
Android 9+ (API 28+). Đây là tin tốt, phủ định lo ngại trước đó rằng WebView dùng chung dữ liệu.

**Giới hạn thật, không phải suy đoán:** điều kiện `SDK_INT >= P` nghĩa là trên Android 8/8.1 (API 26/27 — vẫn nằm
trong `minSdkVersion 26` của dự án) KHÔNG có dòng này chạy, nên trên 2 bản Android đó WebView của các guest dùng
chung thư mục mặc định (không cách ly). Phạm vi thực tế: rất hẹp (Android 8.x hiện gần như không còn máy nào),
nhưng phải ghi đúng, không nói "luôn luôn cách ly".

### 21.2 O-16 — core ép bật 2 cờ WebView nguy hiểm cho MỌI guest (phát hiện mới)

`fake/service/WebViewProxy.java`, hook constructor của `WebView` (`@ProxyMethod("<init>")`), sau khi tạo xong
instance thật thì gọi `configureWebView(webView)` — hàm này **ép bật vô điều kiện**, cho mọi `WebView` của mọi
guest, không hỏi app gốc có muốn hay không:

```java
settings.setAllowFileAccessFromFileURLs(true);
settings.setAllowUniversalAccessFromFileURLs(true);
```

Hai cờ này là lớp API WebView nguy hiểm nhất (CWE-class: cho phép trang `file://` đọc chéo sang origin khác, hoặc
gọi JS từ file cục bộ với quyền như trang web) — Google đã đổi mặc định hai cờ này thành `false` từ nhiều năm nay
và khuyến cáo rõ không nên bật, vì đây là lối XSS/đọc trộm file kinh điển nếu WebView của guest từng load nội
dung không tin cậy (quảng cáo, trang web bên thứ ba trong app). Nếu app gốc của guest **chủ động để `false`** (vì
lý do bảo mật của chính họ), core vẫn ÉP thành `true` — core làm YẾU bảo mật của guest, không chỉ là không cách ly.

Cùng hàm còn có một đoạn khả nghi (chưa xác nhận được tác dụng thật):
```java
System.setProperty("webview.data.dir", uniqueDataDir);
```
Đường dẫn đặt theo `userId + "_" + Process.myPid()` (theo PID, không theo tên gói) — nhưng `android.webkit.WebView`
chuẩn của AOSP **không đọc** property `"webview.data.dir"` ở đâu cả (không phải API công khai, không khớp tên cờ
hệ thống nào được biết). Nhiều khả năng đây là code thừa/thử nghiệm dở dang, không có tác dụng — cơ chế cách ly
THẬT là `setDataDirectorySuffix` ở 21.1, không phải đoạn này. Ghi vào đây để không ai sau này tưởng nhầm đây là
lớp cách ly chính.

**Mức kiểm chứng:** [V] đọc đúng source ở SHA đã ghim (đọc 2 lần, 2 file khác nhau, khớp nhau). **[?]** tác động
thật trên guest cụ thể nào (game/app nào trong máy thực sự load nội dung `file://` không tin cậy trong WebView)
— cần P0-9 (máy thật, Chẩn đoán) để biết mức độ ảnh hưởng thật, không chỉ khả năng lý thuyết.

### 21.3 Việc mới cho backlog

| ID | Việc | Tiêu chí xong |
|---|---|---|
| P1-24 | ~~Hiển thị O-16 cho người dùng~~ | **[ĐÃ LÀM phiên 11]** Chuỗi `scope_known` (vi/en) trong màn Phạm vi (`activity_setup.xml`): nêu WebView lỗi/cờ file của lõi, tệp ngoài/OBB trên Android 10+, Google services. Chưa có cảnh báo riêng theo từng app (chỉ khi cần) |
| P1-25 | Đo thật trên Android 8/8.1 (nếu còn máy): xác nhận WebView 2 guest dùng chung dữ liệu khi `SDK_INT < 28`, đúng như đọc source | Có hoặc không có máy Android 8.x để thử — ghi rõ cả hai trường hợp |

---

## 22. Phiên 10: audit "chưa nối dây" — hầu hết đã nối đúng, 2 lỗ hổng thật

Người dùng yêu cầu tìm và làm nốt việc dang dở. Audit có hệ thống (đếm chéo tham chiếu từng class, từng id layout,
từng chuỗi) thay vì đọc lướt. Kết quả: **phần lớn là âm tính — đã nối đúng từ các phiên trước**, điều này tự nó
có giá trị (xác nhận lại bằng phương pháp, không phải "chắc là ổn").

### 22.1 Đã xác nhận NỐI ĐÚNG (không phải việc dang dở, dù ban đầu trông đáng ngờ)

| Nghi ngờ ban đầu | Xác nhận thật |
|---|---|
| `GuestHooks` chỉ 1 tham chiếu trong `workspace/` | Được gọi từ `GuestCallback` — lớp SINH TỰ ĐỘNG lúc build (`gen_guest_hooks.py`), không nằm trong cây nguồn tĩnh nên grep tĩnh không thấy; đã xác nhận bằng cách đọc chính script sinh mã |
| `LogBuffer.installCrashHandler` có thể chưa được gọi | Được gọi từ `SpaceApp.onCreate` |
| `autoRestart` có thể chỉ là checkbox không tác dụng | Dùng thật trong `GameModeController.shouldRestart` |
| Lịch hẹn giờ có "giờ kết thúc" nhưng không thấy alarm riêng để dừng | Thiết kế đúng: `Scheduler.onStartAlarm` tính `end` rồi truyền thẳng vào `GameModeController.start(..., forcedEndAt)`, watchdog tick tự so sánh — không cần alarm thứ hai |
| Diagnostics "chỉ copy clipboard" (ghi từ các phiên đầu) | Đã có từ lâu: `ShareProvider.write(...)` xuất file + share thật, clipboard chỉ là lựa chọn phụ |
| `item_app.xml` icon thiếu `contentDescription` (phát hiện giả — lỗi trong chính script audit của tôi, dùng `re.findall` với nhóm bắt chỉ trả về nội dung nhóm) | Sau khi sửa script: **0 ImageView/ImageButton nào** trong toàn bộ layout thiếu `contentDescription` (kể cả `@null` có chủ đích cho icon trang trí) |
| RTL có thể chưa làm | Toàn bộ layout đã dùng `start`/`end`, không có `left`/`right`; `android:supportsRtl="true"` đã khai |
| "Hướng 1" (fake screen off + giảm refresh rate) trong `tech.txt` có thể mới là khung sườn | `GameModeController` gọi thật `GameOverlay`, `DisplayTuning.lowRefreshModeId`, `preferredRefreshRate = 30f` — đúng kỹ thuật đã bàn, không phải chỉ khung |
| `StatusWidget` có thể là widget treo, không cập nhật | Có `refresh()` được gọi khi thông báo foreground đổi; có `widget_info.xml` + layout đầy đủ |

### 22.2 Lỗ hổng thật, đã vá

1. **`.gitignore` không tồn tại** — rủi ro thật khi P0-1 đẩy repo lên GitHub: `local.properties`, `.idea/`, `build/`,
   và nghiêm trọng nhất là **khóa `.jks`** nếu ai đó lỡ tạo cục bộ trong thư mục repo, đều có thể bị commit nhầm.
   Đã thêm, có chú thích vì sao từng dòng (ví dụ: tại sao không cần `.gradle/` của core — core nằm ngoài repo).
2. **Không có PR template / issue template** — mục "Developer experience" từ phân tích PDF gốc, ghi "chưa làm"
   nhiều phiên trước, chưa ai quay lại làm. Đã thêm, theo đúng phong cách của chính dự án (nhãn `[V]/[S]/[?]`,
   tham chiếu mã P0-x/P1-x/G-x, nhắc đọc `docs/PROJECT_HANDOFF.md`, nhắc lại AGENTS.md #9 trong form đề xuất tính
   năng để không ai lách qua issue xin tính năng giả mạo ID).

### 22.3 Cố ý KHÔNG thêm dù PDF gốc có nhắc — và lý do cụ thể

| PDF gốc có nhắc | Vì sao không làm ở phiên này |
|---|---|
| `proguard-rules.pro` / bật R8 | **Mâu thuẫn trực tiếp với quyết định đã ghi (D-08, dòng "Không làm" ở mục 11)**: core dùng reflection nặng, R8 sẽ làm vỡ. Viết rules đón đầu cho một việc đã quyết KHÔNG làm là tạo việc thừa, không phải vá lỗ hổng |
| `lint.xml`/baseline | CI đã gọi `lintDebug` với `continue-on-error: true` (D-24), đợi P1-16 ("CI xanh lần đầu") mới bắt buộc lint — thêm baseline bây giờ là làm sớm một việc đã có kế hoạch rõ ràng, không phải việc bị bỏ quên |
| `CONTRIBUTING.md` | `AGENTS.md` đã tự nhận là "Chỉ dẫn cho AI / lập trình viên tiếp quản" — thêm file thứ hai nói cùng việc là trùng lặp, không phải thiếu |
| AppCompat/Material toàn bộ 9 Activity | Đã có đường đi cụ thể ở mục 20.5 (việc có kế hoạch, không phải "quên"); làm cả 9 cùng lúc không có máy để phát hiện activity nào vỡ là rủi ro, không phải chăm chỉ |


## 23. Phiên 11: dùng mạng GitHub để làm nốt phần làm được

### 23.1 Môi trường (đã thử, không phỏng đoán)
Tới được: `github.com`, `raw.githubusercontent.com`, `archive.ubuntu.com` (apt). KHÔNG tới được: `dl.google.com`, `maven.google.com`, `repo.maven.apache.org`, `services.gradle.org`, `plugins.gradle.org`, `jitpack.io`; `api.github.com` bị rate-limit (HTTP 403) vì IP dùng chung. Hệ quả: vẫn không build bằng Gradle/AGP và không dùng được AndroidX mới (mục 20.5 vẫn chặn). Muốn gỡ: thêm các domain trên vào allowlist; việc cần máy thật (P0-3…) thì mạng không thay được.

### 23.2 Tab Issues của lõi (22 issue, đọc ngày 2026-11-18) — E-4 xong
| ID | Issue của lõi | Ảnh hưởng tới Workspace | Xử lý |
|---|---|---|---|
| #35 | `WebViewProxy.getWho()` trả null nên hook WebView không chạy | Đã đối chiếu source ở SHA ghim: lớp cách ly `BActivityThread:392` (`setDataDirectorySuffix`) vẫn chạy → kết luận mục 21.1 đúng. Nhiều người vẫn báo `ERR_CACHE_MISS` | Cảnh báo trong màn Phạm vi (P1-24) |
| #39 | Component proxy `exported=true` | Manifest lõi có 301 `exported="true"`: 300 stub (6 loại × 50 slot) + `ProxyBroadcastReceiver` | **O-17**: công tắc `VSPACE_HARDEN_EXPORTS=1` / input `harden_exports`, mặc định TẮT; kiểm trên manifest lõi thật trong `verify_real.py`; cần thử máy thật (G-40) |
| #41 | Backup + cleartext mặc định | `allowBackup` đã tắt ở manifest ta. Cleartext: lõi chủ ý đặt `cleartextTrafficPermitted="true"` ở `base-config`; guest chạy chung tiến trình host nên chính sách này áp cho guest | Giữ nguyên (đổi sẽ làm guest dùng HTTP hỏng); mã của ta chỉ dùng HTTPS |
| #55 | App ảo không đọc/ghi được tệp ở thư mục lưu trữ của lõi trên Android 10+ (người duy trì xác nhận) | Ảnh hưởng OBB/dữ liệu ngoài của game | **O-18**: không hứa OBB; cảnh báo trong app |
| #37, #57, #63, #64, #67 | Google services/Play Store/đăng nhập Google lỗi | G-35 (GMS + FCM) kỳ vọng thấp | Hạ kỳ vọng, ghi ở màn Phạm vi |
| #42 | Tiện ích tệp của lõi dựng lệnh shell từ đường dẫn | **[ĐÃ ĐÓNG, G-41]** Ở SHA ghim, `FileUtils.chmod` (nhánh `exec`) và `createSymlink` không có nơi gọi nào trong toàn bộ dự án lõi (mã chết); `Runtime.exec(String)` không qua shell; lệnh `exec` động duy nhất là `logcat -f <thư mục log nội bộ>` (không lấy từ người dùng). Không khai thác được trong sản phẩm này | Không cần xử lý; kiểm lại nếu đổi SHA lõi |

### 23.3 Đã làm
- `scripts/net_check.py` + `NetCheckCli.java`: chạy lớp `UpdateChecker` thật với GitHub thật (tải qua chuyển hướng, sha256 đúng/sai, size sai, hủy, chặn host lạ). 7 ca đạt; ca gọi `api.github.com` ghi SKIP khi bị rate-limit. Tìm và sửa lỗi thật: thông báo "kích thước không khớp" luôn in 0 (đọc `length()` sau `delete()`).
- O-17 (xem trên) + bước `overlay O-17` trong `verify_real.py` (có đột biến).
- `scripts/pin_actions.py` (`--check/--apply/--verify`): 16 chỗ `uses:` ghim SHA commit; `check.py` chạy `--check`.
- NOTICE sửa theo giấy phép thật (O-8).

### 23.4 Tra cứu đường thay thế để build trong sandbox (kết quả: không có)
Đã thử: Gradle 8.10.2 TẢI ĐƯỢC từ `gradle/gradle-distributions` trên GitHub Releases (136 MB); conda-forge có gói `gradle` nhưng không có gói Android nào; npm/PyPI/crates/apt không có AGP/AndroidX/NDK; các kho trên GitHub chỉ có công cụ Android cho ARM64 hoặc rời rạc, không có Google Maven. AGP, AndroidX, Android SDK và NDK chỉ phát hành từ Google nên không dựng được APK thật trong sandbox. Giải pháp thay thế: `scripts/ship.sh <owner/repo>` — một lệnh đẩy mã, chạy `build.yml` (build thật + emulator-smoke trên GitHub Actions) và tải artifact/log về `ci-out/`.

### 23.6 Kiểm tra bằng emulator trong CI (không cần điện thoại) — VIẾT XONG, CHƯA CHẠY LẦN NÀO
Không cần cầm điện thoại cho những việc không cần engine. Job `emulator-smoke` nay chạy ma trận API 30 và 34 (x86_64, KVM) với ba kiểm tra:
| Script | Kiểm gì | Trạng thái tự kiểm trong sandbox |
|---|---|---|
| `scripts/emulator_install_check.sh` | P0-9: APK ghép split + ký ApkSigner v2 có cài được bằng PackageManager/PackageParser THẬT; versionCode/Name đúng; cài đè cùng khóa được; APK bị sửa 1 byte phải bị từ chối | Logic thử bằng `adb` giả ở 2 kịch bản (hệ thống đúng/sai); fixture thật do `verify_real.py` (`VSPACE_FIXTURE_OUT`) tạo, `apksigner` thật báo `CHUNKED_SHA256 digest mismatch` với bản sửa byte 300 |
| `scripts/emulator_screenpower_check.sh` | P0-11/G-18: `ScreenPower` chạy qua `app_process` với quyền shell, panel Off nhưng `mWakefulness=Awake`, tự bật lại sau khi hết giờ. Ba trạng thái PASS / FAIL / INCONCLUSIVE (emulator có thể không khai trạng thái panel) | Logic thử bằng `adb` giả ở 4 kịch bản; CHƯA thử trên Android thật |
| `scripts/emulator_smoke.sh` | App mở được, không FATAL EXCEPTION | Như cũ |
Giới hạn cứng: lõi chỉ có thư viện native `arm64-v8a`/`armeabi-v7a` (`abiFilters` trong `Bcore/build.gradle`), nên engine và guest/game KHÔNG chạy trên emulator x86 → P0-4 (ProcessPinner), P0-6 (cô lập 2 không gian), P0-7/8 (đo game) vẫn cần thiết bị ARM (điện thoại thật, hoặc dịch vụ thiết bị đám mây).

### 23.7 Chạy trên máy thật bằng MỘT LỆNH (không phải tự code)
`scripts/device_suite.py` + `docs/DEVICE_GUIDE.md` (cách A cáp USB, B Gỡ lỗi không dây, C chạy ngay trong điện thoại bằng Termux). Tự động: cài, miễn trừ pin, quyền thông báo, đặt cờ `pin_processes`/`keep_alive` bằng `run-as` (bản Debug), nhập `testguest` bằng intent VIEW và mở bằng `ShortcutActivity`, đo 3 kịch bản (ghim tắt/bật × tắt màn hình thật, ScreenPower), thu chẩn đoán, ghi `REPORT.md`. Cần tay: chọn Không gian 2 (P0-6) và bật Màn hình mờ/đen ở `GameActivity` (không exported nên `adb` không gọi được). Trạng thái: có 7 test cho hàm thuần; luồng thật đã chạy với `adb` giả có trạng thái (sinh đủ báo cáo, cửa sổ 6 giây được kết luận NO-DATA); CHƯA chạy trên điện thoại thật nên các giả định (`run-as`, intent VIEW với `file://`, tên extra `pkg`/`user`) cần xác nhận ở lần chạy đầu.
Không có máy ARM: Firebase Test Lab (thiết bị vật lý, có hạn mức miễn phí) cần tài khoản Google Cloud của chủ dự án và một bài đo chạy trong app; chưa làm.

### 23.8 Đối chiếu từng mục trong PDF với mã thật (quét tự động 68 mục, rồi kiểm tay từng mục báo thiếu)
Quét ban đầu báo 19 mục thiếu. Kiểm lại bằng grep có mục tiêu: 7 mục là BÁO NHẦM (đã có), 6 mục làm mới ở phiên này, 6 mục lúc đầu để lại kèm lý do. Sau đó tra cứu đường khác (mục 23.9) nên 5 trong 6 mục đó cũng đã làm, mục còn lại (splash/màu động) không cần vì hệ thống đã có sẵn. 49 mục còn lại đã có từ trước.
| Mục PDF | Kết quả | Ghi chú |
|---|---|---|
| Phân loại lỗi cài đặt | **ĐÃ LÀM (phiên 11)** | `InstallErrors.classify` (8 nhóm: hết chỗ, ABI, chữ ký, hạ phiên bản, đã tồn tại, SDK, APK hỏng, không rõ) đọc `InstallResult.msg` THẬT của engine; thông báo không rõ kèm nguyên văn lỗi. 4 test + 4 đột biến bị bắt |
| Receiver mạng trở lại | **ĐÃ LÀM (phiên 11)** | `KeepAliveService.watchNetwork`: `registerDefaultNetworkCallback` → gia hạn khóa + `ProcessPinner.refreshNow()`. Giả thuyết G-46 |
| Phát hiện dịch vụ bị hệ thống giết | **ĐÃ LÀM (phiên 11)** | `KillWatch` (hàm thuần, 6 test + 3 đột biến) + nhịp `Prefs.lastAlive` mỗi 5 phút; mất > 2 chu kỳ trong cùng lần bật máy → thông báo hướng dẫn theo hãng. Máy khởi động lại và người dùng tắt không bị tính là bị giết. Giả thuyết G-48 (có thể báo nhầm sau khi cập nhật app) |
| Quick Settings Tile | **ĐÃ LÀM (phiên 11)** | `KeepAliveTile` bật/tắt giữ nền từ thanh kéo; manifest khai `BIND_QUICK_SETTINGS_TILE`. Giả thuyết G-47 (bấm ô có khởi động được FGS trên Android 14+) |
| Haptic | **ĐÃ LÀM (phiên 11)** | `Haptics.confirm/reject` khi cài xong/lỗi (CONFIRM/REJECT từ API 30, VIRTUAL_KEY/LONG_PRESS trước đó). Giả thuyết G-49 |
| Cảnh báo gập máy / bấm nguồn / ốp lưng thông minh | **ĐÃ LÀM (phiên 11)** | Thêm vào `game_explain` (vi/en) |
| Giữ nền theo từng guest | BÁO NHẦM | Đã có: `ProcessPinner.shouldPin(registered, profilePin)` theo hồ sơ từng game |
| Màn chi tiết guest | BÁO NHẦM | Có dạng hộp thoại `details_fmt` (gói, không gian, versionCode, dung lượng, quyền) |
| Màn Quyền | BÁO NHẦM | Có qua Thiết lập lần đầu / Preflight (quyền host + trạng thái + nút mở cài đặt) |
| Dark theme, i18n | BÁO NHẦM | Có `values-night`, `values-en` (quét theo nội dung nên sót thư mục) |
| Log viewer trong app | BÁO NHẦM | Có `SettingsActivity.showLog()` (xem, sao chép, chia sẻ qua `ShareProvider`) |
| Lưu state khi xoay màn hình | BÁO NHẦM | Sắp xếp và "chỉ đang chạy" lưu trong `Prefs`; ô tìm kiếm có id nên hệ thống tự khôi phục và TextWatcher cập nhật `query` |
| Notification group summary | **ĐÃ LÀM (phiên 11b)** | `Notifier.alert` gắn nhóm `vspace_alerts`; từ 2 cảnh báo đang hiện trở lên có thông báo tóm tắt (id 1999). Cần thử trên máy |
| Layout máy tính bảng / landscape | **ĐÃ LÀM (phiên 11b)** | Lề ngang `@dimen/screen_pad_h` cho 3 màn danh sách/cài đặt: 16dp (dọc), 48dp (`values-land`), 120dp (`values-sw600dp`). Chỉ đổi lề, không nhân đôi layout; aapt2 API 35 xác nhận hợp lệ, CHƯA xem bằng mắt |
| Network security config | **ĐÃ LÀM (phiên 11b)** | `res/xml/network_security_config.xml`: `base-config` giữ cleartext như lõi (guest cần HTTP); `domain-config` ép HTTPS cho `github.com`, `api.github.com`, `*.githubusercontent.com`. `check.py` kiểm khớp với `UpdateChecker` |
| Splash Screen / predictive back / per-app language | **ĐÃ LÀM (phiên 11b)** | Dùng `aapt2` 35.0.2 để kiểm với `android.jar` API 35. Per-app language: `locales_config.xml` (vi, en) + `android:localeConfig`. Predictive back: `android:enableOnBackInvokedCallback="true"` (đã grep: mã không có `onBackPressed`/`KEYCODE_BACK` tùy biến). Splash và màu động Material You: KHÔNG cần thêm, `Theme.DeviceDefault.DayNight` ở `values-v29` đã cho cả hai trên Android 12+ |
| Phát hiện STOPPED sau Buộc dừng | **ĐÃ LÀM theo cách khác (phiên 11b)** | Không đọc `FLAG_STOPPED`. Thay bằng `ApplicationExitInfo`: `ExitReasons.classifyCause` (10/11 vuốt Đa nhiệm hoặc Buộc dừng, 14 đóng băng, 3/9 thiếu RAM, 2 tín hiệu, 4–7 lỗi) gắn vào thông báo bị-giết. 2 test |
Chưa làm vì cần thứ ngoài sandbox: Material/AppCompat/ViewModel/Navigation, Hilt, Robolectric/Espresso/Macrobenchmark (đều cần Google Maven, mục 23.4); Firebase Test Lab (cần tài khoản Google Cloud); `ANDROID_ID`/fingerprint riêng từng guest và cầu nối `requestPermissions` (P0-6, P1-3: cần engine chạy trên máy ARM thật); FCM/GMS (G-35: 5 issue của lõi báo hỏng).

Kiểm chứng phiên 11 phần này: `javac` với `android.jar` API 35 (60 tệp, 0 lỗi mã dự án), `aapt` thật cho manifest + chuỗi, 102 test JVM (từ 92), 7 đột biến bị bắt. CHƯA kiểm trên thiết bị: hành vi thật của `NetworkCallback`, `TileService`, haptic và `KillWatch`.
Tồn tại đã biết E-16: nhánh biên dịch bằng stub viết tay (khi không có `android.jar`) vẫn lỗi ở `BottomSheet.java` (thiếu `TypedValue`, `Theme`, `LinearLayout.LayoutParams`…); không ảnh hưởng vì `verify_real.py --fetch` dùng SDK thật. Lint tham chiếu chéo của `check.py` từng báo nhầm `Outer.this` là thành viên không tồn tại; đã sửa.

### 23.9 Tra cứu đường khác cho các việc từng bị bỏ (phiên 11b)
**Kiểm resource/manifest với API 35 không cần máy.** `aapt` của apt (API 28) và `aapt2` của apt (2.19) không đọc được `android.jar` API 35. Tải `aapt2` 35.0.2 dựng sẵn từ `Lzhiyong/android-sdk-tools` (GitHub Releases, sha256 ghim trong `verify_real.py`) thì link được toàn bộ tài nguyên + manifest với `android-35.jar`; bước `aapt2` trong `verify_real.py` xác nhận ba thuộc tính mới (`localeConfig`, `enableOnBackInvokedCallback`, `networkSecurityConfig`) được nhận và thuộc tính giả bị từ chối.

**Emulator ARM64 trong CI: không khả thi.** Runner ARM64 của GitHub không có KVM, và emulator trên máy x86 từ chối ảnh ARM64 (`PANIC: ... not supported by the QEMU2 emulator on x86_64 host`).

**Thay vào đó: build engine cho x86_64 để chạy trên emulator x86 có KVM (job `x86-engine-test`, thử nghiệm, KHÔNG phát hành).** Cơ sở đã kiểm trong sandbox:
| Điều kiện | Kết quả |
|---|---|
| Mã native của lõi có phụ thuộc kiến trúc ARM không | Không: grep không thấy asm/syscall/`__aarch64__` ngoài Dobby và xDL; build bằng `ndk-build` (`Android.mk`) |
| Lõi gọi hàm nào của Dobby | Chỉ `DobbyHook` (một chỗ gọi, trong `VirtualSpoof.cpp`; lần đếm trước lẫn cả `dobby.h`). Dùng `VSPACE_STRIP_CORE_SPOOF=1` cho bản x86 vì VirtualSpoof khai `ro.product.cpu.abi=arm64-v8a`, sai trên x86 |
| Lõi thiếu gì cho x86_64 | Chỉ `Dobby/x86_64/libdobby.a` (lõi kèm sẵn arm64-v8a, armeabi-v7a) và `abiFilters`/`APP_ABI` |
| Dobby bản nào | `libdobby.a` của lõi mang chuỗi `Dobby-20210616-223aabc`. Đầu nhánh master (2024) KHÔNG biên dịch được phần Linux/Android (thiếu `core/arch/Cpu.h`, đổi tên `load_address`), nên ghim `223aabc` |
| `223aabc` có build ra x86_64 không | Có (host x86_64, g++ + shim `__has_feature`): `libdobby.a` xuất đủ 5 ký hiệu như bản dựng sẵn của lõi (`DobbyHook`, `DobbyDestroy`, `DobbyInstrument`, `DobbyBuildVersion`, `DobbySymbolResolver`); `dobby.h` giống hệt, chỉ khác chú thích. Bước `Dobby x86_64` trong `verify_real.py` lặp lại phép kiểm này |
| Công tắc overlay | `VSPACE_X86_64=1` thêm x86_64 vào `APP_ABI` và `abiFilters` (thử trên lõi thật: lặp lại không nhân đôi, thiếu `libdobby.a` x86_64 thì từ chối) |
Luồng CI: `build_dobby.sh` (NDK, cmake) → `overlay.sh` → Gradle `-Pabi=x86_64` → emulator API 34 x86_64 KVM → `device_suite.py --no-manual`. Kết quả ở artifact `device-result-x86_64`.
**CHƯA chạy lần nào**, nên các điểm dưới đây là giả thuyết cần CI xác nhận: (G-50) Dobby `223aabc` biên dịch được bằng clang của NDK 29 cho Android x86_64; (G-51) engine (hook ART, đường dẫn thư viện) chạy được trên x86_64 thật; (G-52) `device_suite.py` chạy tự động được trong emulator (kịch bản tắt màn hình bằng `KEYCODE_SLEEP`). Kể cả khi chạy được, kết quả chỉ thay cho phần engine, giữ nền, cô lập, ScreenPower; đo pin, nhiệt và hành vi từng hãng vẫn cần máy ARM thật.

### 23.5 Còn lại (không làm được ở đây, ghi thẳng)
| ID | Việc | Vì sao chưa |
|---|---|---|
| P0-1/P0-3/P0-4… | Build Gradle thật, cài và đo trên máy thật | Cần Google Maven/Gradle (bị chặn) và thiết bị |
| P1-16 | Bật chặn lỗi CI (bỏ `continue-on-error`) | Chỉ làm sau lần build xanh đầu tiên |
| 20.5 | Chuyển 9 Activity còn lại sang AppCompat/Material | Cần AndroidX từ Google Maven; không thử được giao diện |
| F-20 | VirtualDisplay + Shizuku | Cần phụ thuộc Maven + sửa lõi + máy thật |
| F-24 | Giả lập `getRefreshRate` | Cần hook native trong lõi, không thử được |
| G-40 | Thử `harden_exports` trên máy thật | Cần thiết bị |
| — | Trang "Giấy phép nguồn mở" kèm tệp LICENSE của các thư viện MIT khi phát hành | Làm lúc phát hành |
