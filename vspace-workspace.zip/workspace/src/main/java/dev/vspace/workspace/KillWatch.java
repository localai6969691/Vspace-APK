package dev.vspace.workspace;

/**
 * Phát hiện dịch vụ giữ nền bị HỆ THỐNG/OEM giết giữa chừng (khác: người dùng tắt, hoặc máy khởi động lại).
 * KeepAliveService ghi nhịp "còn sống" mỗi chu kỳ; lần khởi động dịch vụ kế tiếp so nhịp cuối với thời điểm hiện tại.
 */
final class KillWatch {
    private KillWatch() {}

    /**
     * @param wanted   người dùng đang muốn giữ nền (Prefs.keepAlive còn bật)
     * @param lastAlive nhịp cuối đã ghi (ms epoch; 0 = chưa từng)
     * @param now      hiện tại (ms epoch)
     * @param bootTime thời điểm máy khởi động (ms epoch) = now - elapsedRealtime
     * @param renewMs  chu kỳ ghi nhịp
     */
    static boolean looksKilled(boolean wanted, long lastAlive, long now, long bootTime, long renewMs) {
        if (!wanted || lastAlive <= 0) return false;
        if (lastAlive < bootTime) return false;          // nhịp cuối trước lần khởi động này: BootReceiver lo, không phải bị giết
        return now - lastAlive > renewMs * 2;            // mất hơn 2 chu kỳ liền
    }

    static long gapMinutes(long lastAlive, long now) {
        return Math.max(0, (now - lastAlive) / 60000L);
    }
}
