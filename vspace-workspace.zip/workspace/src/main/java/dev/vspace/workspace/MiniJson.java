package dev.vspace.workspace;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Bộ phân tích JSON nhỏ, thuần Java (chạy được trên JVM để test; org.json của Android thì không).
 * Trả về: Map&lt;String,Object&gt;, List&lt;Object&gt;, String, Double, Boolean hoặc null. Giới hạn độ sâu để chống đầu vào độc hại.
 */
final class MiniJson {
    private static final int MAX_DEPTH = 32;

    private final String s;
    private int i;

    private MiniJson(String s) {
        this.s = s;
    }

    static Object parse(String text) {
        if (text == null) throw new IllegalArgumentException("null");
        MiniJson p = new MiniJson(text);
        p.ws();
        Object v = p.value(0);
        p.ws();
        if (p.i != p.s.length()) throw new IllegalArgumentException("dư ký tự ở " + p.i);
        return v;
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> asObject(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : null;
    }

    @SuppressWarnings("unchecked")
    static List<Object> asArray(Object o) {
        return o instanceof List ? (List<Object>) o : null;
    }

    static String str(Map<String, Object> m, String key) {
        Object o = m == null ? null : m.get(key);
        return o instanceof String ? (String) o : null;
    }

    static long num(Map<String, Object> m, String key, long def) {
        Object o = m == null ? null : m.get(key);
        return o instanceof Double ? (long) (double) (Double) o : def;
    }

    static boolean bool(Map<String, Object> m, String key) {
        Object o = m == null ? null : m.get(key);
        return o instanceof Boolean && (Boolean) o;
    }

    private void ws() {
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') i++;
            else break;
        }
    }

    private Object value(int depth) {
        if (depth > MAX_DEPTH) throw new IllegalArgumentException("quá sâu");
        if (i >= s.length()) throw new IllegalArgumentException("hết dữ liệu");
        char c = s.charAt(i);
        if (c == '{') return object(depth);
        if (c == '[') return array(depth);
        if (c == '"') return string();
        if (s.startsWith("true", i)) {
            i += 4;
            return Boolean.TRUE;
        }
        if (s.startsWith("false", i)) {
            i += 5;
            return Boolean.FALSE;
        }
        if (s.startsWith("null", i)) {
            i += 4;
            return null;
        }
        return number();
    }

    private Map<String, Object> object(int depth) {
        Map<String, Object> m = new LinkedHashMap<>();
        i++; // {
        ws();
        if (peek() == '}') {
            i++;
            return m;
        }
        while (true) {
            ws();
            if (peek() != '"') throw new IllegalArgumentException("cần khóa chuỗi ở " + i);
            String k = string();
            ws();
            expect(':');
            ws();
            m.put(k, value(depth + 1));
            ws();
            char c = next();
            if (c == ',') continue;
            if (c == '}') return m;
            throw new IllegalArgumentException("cần , hoặc } ở " + (i - 1));
        }
    }

    private List<Object> array(int depth) {
        List<Object> l = new ArrayList<>();
        i++; // [
        ws();
        if (peek() == ']') {
            i++;
            return l;
        }
        while (true) {
            ws();
            l.add(value(depth + 1));
            ws();
            char c = next();
            if (c == ',') continue;
            if (c == ']') return l;
            throw new IllegalArgumentException("cần , hoặc ] ở " + (i - 1));
        }
    }

    private String string() {
        expect('"');
        StringBuilder sb = new StringBuilder();
        while (true) {
            if (i >= s.length()) throw new IllegalArgumentException("chuỗi không đóng");
            char c = s.charAt(i++);
            if (c == '"') return sb.toString();
            if (c == '\\') {
                char e = next();
                switch (e) {
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/': sb.append('/'); break;
                    case 'b': sb.append('\b'); break;
                    case 'f': sb.append('\f'); break;
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case 'u':
                        if (i + 4 > s.length()) throw new IllegalArgumentException("\\u cụt");
                        sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                        i += 4;
                        break;
                    default:
                        throw new IllegalArgumentException("escape lạ \\" + e);
                }
            } else {
                sb.append(c);
            }
        }
    }

    private Double number() {
        int st = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
        if (st == i) throw new IllegalArgumentException("ký tự lạ ở " + i);
        return Double.valueOf(s.substring(st, i));
    }

    private char peek() {
        return i < s.length() ? s.charAt(i) : '\0';
    }

    private char next() {
        if (i >= s.length()) throw new IllegalArgumentException("hết dữ liệu");
        return s.charAt(i++);
    }

    private void expect(char c) {
        if (next() != c) throw new IllegalArgumentException("cần '" + c + "' ở " + (i - 1));
    }
}
