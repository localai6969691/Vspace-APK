package dev.vspace.workspace;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.Locale;

/** Hẹn giờ chế độ game theo ngày + watchdog dựng lại dịch vụ nếu bị hệ thống kill. */
final class Scheduler {
    private static final long WATCHDOG_MS = 10 * 60_000L;

    static final class Config {
        boolean enabled;
        String pkg = "";
        int userId;
        String label = "";
        int startMin = 23 * 60;
        int endMin = 6 * 60;
    }

    private Scheduler() {}

    // ---- cấu hình ----

    static Config load(Context c) {
        String s = Prefs.sched(c);
        if (s == null) return null;
        try {
            JSONObject o = new JSONObject(s);
            Config k = new Config();
            k.enabled = o.optBoolean("enabled");
            k.pkg = o.optString("pkg", "");
            k.userId = o.optInt("userId", 0);
            k.label = o.optString("label", k.pkg);
            k.startMin = o.optInt("startMin", k.startMin);
            k.endMin = o.optInt("endMin", k.endMin);
            return k;
        } catch (Exception e) {
            return null;
        }
    }

    static void save(Context c, Config k) {
        try {
            JSONObject o = new JSONObject();
            o.put("enabled", k.enabled);
            o.put("pkg", k.pkg);
            o.put("userId", k.userId);
            o.put("label", k.label);
            o.put("startMin", k.startMin);
            o.put("endMin", k.endMin);
            Prefs.setSched(c, o.toString());
        } catch (Exception ignored) {
        }
    }

    static String describe(Context c) {
        Config k = load(c);
        if (k == null || !k.enabled) return "off";
        return String.format(Locale.US, "%s (space %d) %02d:%02d -> %02d:%02d", k.pkg, k.userId,
                k.startMin / 60, k.startMin % 60, k.endMin / 60, k.endMin % 60);
    }

    // ---- lịch hằng ngày ----

    static void armSchedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = pi(c, 11, AlarmReceiver.ACTION_SCHEDULE_START);
        am.cancel(pi);
        Config k = load(c);
        if (k == null || !k.enabled || k.pkg.isEmpty()) return;
        long at = nextOccurrence(k.startMin, System.currentTimeMillis());
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    static long nextOccurrence(int minuteOfDay, long after) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(after);
        cal.set(Calendar.HOUR_OF_DAY, minuteOfDay / 60);
        cal.set(Calendar.MINUTE, minuteOfDay % 60);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= after) cal.add(Calendar.DAY_OF_YEAR, 1);
        return cal.getTimeInMillis();
    }

    /** Alarm bắt đầu phiên theo lịch: bật chế độ game, cố mở game (có thể bị Android chặn), hẹn ngày mai. */
    static void onStartAlarm(Context c) {
        Config k = load(c);
        LogBuffer.i("VSpaceSched", "start alarm fired");
        if (k != null && k.enabled && !k.pkg.isEmpty()) {
            GameProfile p = GameProfile.load(c, k.pkg, k.userId);
            long end = nextOccurrence(k.endMin, System.currentTimeMillis());
            int r = GameModeController.get(c).start(k.pkg, k.userId, k.label, p, end);
            if (r == GameModeController.OK) {
                try {
                    Engine.launch(c, k.pkg, k.userId);
                } catch (Throwable ignored) {
                }
                Notifier.alert(c, c.getString(R.string.alert_sched_title),
                        c.getString(R.string.alert_sched_started, k.label));
            } else {
                Notifier.alert(c, c.getString(R.string.alert_sched_title),
                        c.getString(R.string.alert_sched_no_overlay));
            }
        }
        armSchedule(c);
    }

    // ---- watchdog ----

    static void armWatchdog(Context c) {
        if (!Prefs.keepAlive(c)) return;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        try {
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + WATCHDOG_MS, pi(c, 10, AlarmReceiver.ACTION_WATCHDOG));
        } catch (Throwable ignored) {
        }
    }

    static void cancelWatchdog(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pi(c, 10, AlarmReceiver.ACTION_WATCHDOG));
    }

    private static PendingIntent pi(Context c, int code, String action) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(action);
        return PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }
}
