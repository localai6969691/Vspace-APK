package dev.vspace.workspace;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Bản sao an toàn trước khi gỡ app hoặc xóa dữ liệu, để có nút "Hoàn tác" (PDF mục 2.3: Snackbar + Undo sau khi gỡ guest).
 * Dùng lại định dạng GuestBackup (kèm APK) nên khôi phục đi đúng đường đã có test.
 *
 * Giới hạn có chủ ý: bản sao nằm trong files/trash (bộ nhớ riêng của app, KHÔNG phải cache nên không bị hệ thống dọn), giữ
 * tối đa KEEP bản và tối đa MAX_AGE_MS; dữ liệu lớn hơn MAX_SNAPSHOT_BYTES thì KHÔNG tạo bản sao (game vài GB sẽ làm đầy máy)
 * — khi đó người dùng được báo rõ và nên sao lưu thủ công. Chạy trên luồng nền.
 */
final class TrashBin {
    private static final String TAG = "VSpaceTrash";
    static final int KEEP = 3;
    static final long MAX_AGE_MS = 14L * 24 * 60 * 60 * 1000;
    static final long MAX_SNAPSHOT_BYTES = 1536L * 1024 * 1024;

    private TrashBin() {}

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "trash");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    /**
     * Sao lưu (kèm APK) vào thùng rác.
     * @param why [0] nhận lý do khi trả null (dùng để báo người dùng); có thể null
     * @return file bản sao, hoặc null nếu không tạo được (khi đó người gọi vẫn có thể tiếp tục thao tác nhưng KHÔNG có hoàn tác)
     */
    static File snapshot(Context c, String pkg, int userId, CharSequence label, String[] why) {
        try {
            GuestBackup.Layout l = GuestBackup.locate(c, pkg, userId);
            long size = l.data.isDirectory() ? GuestBackup.sizeOf(l.data, new int[]{300_000}) : 0;
            if (size > MAX_SNAPSHOT_BYTES) {
                if (why != null) why[0] = "TOO_BIG";
                return null;
            }
            Engine.stop(pkg, userId);
            GuestRegistry.waitUntilGone(pkg, userId, 5000);
            File f = new File(dir(c), GuestBackup.backupFileName(pkg, userId, System.currentTimeMillis()));
            try (FileOutputStream out = new FileOutputStream(f)) {
                GuestBackup.backup(c, pkg, userId, label, Engine.installedVersionCode(c, pkg, userId), true, out);
            } catch (Throwable t) {
                //noinspection ResultOfMethodCallIgnored
                f.delete();
                throw t;
            }
            purge(c);
            return f;
        } catch (Throwable t) {
            LogBuffer.e(TAG, "snapshot failed", t);
            if (why != null) why[0] = String.valueOf(t.getMessage());
            return null;
        }
    }

    /** Cài lại APK (nếu app đã bị gỡ) rồi khôi phục dữ liệu từ bản sao. userIdOrMinus1 &lt; 0 = dùng không gian ghi trong bản sao. Ném lỗi nếu thất bại. */
    static GuestBackup.Restored restore(Context c, File snapshot, int userIdOrMinus1) throws IOException {
        GuestBackup.Header h;
        try (InputStream in = new FileInputStream(snapshot)) {
            h = GuestBackup.readHeader(c, in);
        }
        try {
            final int userId = userIdOrMinus1 >= 0 ? userIdOrMinus1 : h.meta.user;
            String pkg = h.meta.pkg;
            if (!Engine.isInstalled(pkg, userId)) {
                if (h.apk == null) throw new IOException("bản sao không kèm APK");
                if (!Engine.installApk(h.apk, pkg, userId)) throw new IOException("không cài lại được app");
            }
            Engine.stop(pkg, userId);
            GuestRegistry.waitUntilGone(pkg, userId, 5000);
            try (InputStream in = new FileInputStream(snapshot)) {
                return GuestBackup.restore(c, in, pkg, userId);
            }
        } finally {
            if (h.apk != null) //noinspection ResultOfMethodCallIgnored
                h.apk.delete();
        }
    }

    /** Xóa bản sao cũ: giữ KEEP bản mới nhất và không quá MAX_AGE_MS. */
    static void purge(Context c) {
        File[] fs = dir(c).listFiles();
        if (fs == null || fs.length == 0) return;
        long[] times = new long[fs.length];
        for (int i = 0; i < fs.length; i++) times[i] = fs[i].lastModified();
        for (int idx : indicesToDelete(times, System.currentTimeMillis(), KEEP, MAX_AGE_MS)) {
            //noinspection ResultOfMethodCallIgnored
            fs[idx].delete();
        }
    }

    /** Hàm thuần: chỉ số các mục cần xóa — mọi mục quá hạn, và mọi mục ngoài `keep` mục mới nhất. */
    static List<Integer> indicesToDelete(long[] times, long now, int keep, long maxAgeMs) {
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < times.length; i++) order.add(i);
        final long[] t = times;
        java.util.Collections.sort(order, (x, y) -> Long.compare(t[y], t[x])); // mới nhất trước
        List<Integer> del = new ArrayList<>();
        for (int rank = 0; rank < order.size(); rank++) {
            int i = order.get(rank);
            if (rank >= keep || now - times[i] > maxAgeMs) del.add(i);
        }
        return del;
    }
}
