package dev.vspace.workspace;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Thanh thông báo nổi ở đáy kèm một nút hành động ("Hoàn tác"), tự ẩn sau một lúc — thay Snackbar của Material mà không cần
 * thêm thư viện. Chỉ một thanh cùng lúc. Phải gọi trên luồng giao diện.
 */
final class UndoBar {
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static View current;
    private static Runnable hider;

    private UndoBar() {}

    static void show(Activity a, CharSequence text, CharSequence action, final Runnable onAction, long ms) {
        dismiss();
        final ViewGroup root = a.findViewById(android.R.id.content);
        if (root == null) return;
        float d = a.getResources().getDisplayMetrics().density;

        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF323232);
        bg.setCornerRadius(8 * d);
        bar.setBackground(bg);
        bar.setElevation(8 * d);
        bar.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);

        TextView tv = new TextView(a);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(14);
        tv.setPadding((int) (16 * d), (int) (14 * d), (int) (8 * d), (int) (14 * d));
        bar.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (action != null && onAction != null) {
            TextView act = new TextView(a);
            act.setText(action);
            act.setTextColor(0xFF8AB4FF);
            act.setTextSize(14);
            act.setAllCaps(true);
            act.setMinHeight((int) (48 * d));
            act.setMinWidth((int) (64 * d));
            act.setGravity(Gravity.CENTER);
            act.setPadding((int) (12 * d), 0, (int) (16 * d), 0);
            act.setOnClickListener(v -> {
                dismiss();
                onAction.run();
            });
            bar.addView(act, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        bar.setOnClickListener(v -> dismiss());

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        int m = (int) (12 * d);
        lp.setMargins(m, m, m, (int) (24 * d));
        root.addView(bar, lp);
        current = bar;
        hider = UndoBar::dismiss;
        H.postDelayed(hider, ms);
    }

    static void dismiss() {
        if (hider != null) H.removeCallbacks(hider);
        hider = null;
        View v = current;
        current = null;
        if (v != null && v.getParent() instanceof ViewGroup) ((ViewGroup) v.getParent()).removeView(v);
    }
}
