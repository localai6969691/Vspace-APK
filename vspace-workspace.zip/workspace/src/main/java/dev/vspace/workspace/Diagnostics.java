package dev.vspace.workspace;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.pm.ApplicationInfo;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * Báo cáo văn bản để KIỂM CHỨNG trên máy thật những thứ chưa chứng minh được bằng đọc tài liệu:
 *  1) ProcessPinner có đưa tiến trình :pN ra khỏi nhóm CACHED không (mục "Tien trinh").
 *  2) Game có thật sự đang chạy logic không (mục "CPU": CPU ~ 0% => dung hinh).
 *  3) Core thật sự có những hàm API nào.
 * Có chờ 1 giây để đo CPU => KHÔNG gọi trên main thread.
 */
final class Diagnostics {

    private Diagnostics() {}

    static String collect(Context c) {
        StringBuilder sb = new StringBuilder();

        sb.append("== Thiet bi ==\n");
        sb.append("Android ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("May: ").append(Build.MANUFACTURER).append(" / ").append(Build.MODEL).append('\n');
        sb.append("ABI: ").append(Arrays.toString(Build.SUPPORTED_ABIS)).append('\n');
        sb.append("Host: ").append(c.getPackageName())
                .append("  targetSdk=").append(c.getApplicationInfo().targetSdkVersion)
                .append("  64bit=").append(android.os.Process.is64Bit()).append('\n');

        sb.append("\n== Giu nen ==\n");
        sb.append("KeepAliveService dang chay: ").append(KeepAliveService.running).append('\n');
        sb.append("Mien tru toi uu pin: ").append(PowerHelper.isIgnoringBatteryOptimizations(c)).append('\n');
        sb.append("Cau hinh ghim tien trinh: ").append(Prefs.pinProcesses(c)).append('\n');
        sb.append("So tien trinh dang ghim: ").append(KeepAliveService.pinnedCount).append('\n');
        sb.append("Watchdog/lich: ").append(Scheduler.describe(c)).append('\n');

        sb.append("\n== Che do game ==\n");
        GameModeController gm = GameModeController.get(c);
        sb.append("Dang chay: ").append(gm.active);
        if (gm.active) {
            sb.append("  pkg=").append(gm.pkg).append(" space=").append(gm.userId)
                    .append(" mode=").append(modeName(gm.profile.mode))
                    .append("  deaths=").append(gm.deaths)
                    .append(" freezeAlerts=").append(gm.freezeAlerts)
                    .append(" screenOffs=").append(gm.screenOffs)
                    .append(" restarts=").append(gm.restarts)
                    .append(" memEvents=").append(gm.memEvents);
        }
        sb.append('\n');
        sb.append("Quyen hien thi tren app khac (overlay): ").append(PowerHelper.canDrawOverlays(c)).append('\n');
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            sb.append("Pin: ").append(scale > 0 ? level * 100 / scale : -1).append("%  nhiet pin: ")
                    .append(String.format(Locale.US, "%.1f", b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0))
                    .append(" C  cam sac=").append(b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)).append('\n');
        }
        if (Build.VERSION.SDK_INT >= 29) {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            if (pm != null) sb.append("Thermal status: ").append(pm.getCurrentThermalStatus()).append(" (0=none .. 3=severe)\n");
        }

        sb.append("\n== Tien trinh cua host (importance) ==\n");
        sb.append("Ky vong: da ghim => FOREGROUND_SERVICE/SERVICE (<=300). CACHED (400) => ghim KHONG hieu qua.\n");
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> procs = am != null ? am.getRunningAppProcesses() : null;
        boolean any = false;
        if (procs != null) {
            List<String> lines = new ArrayList<>();
            for (ActivityManager.RunningAppProcessInfo p : procs) {
                if (p.processName == null || !p.processName.startsWith(c.getPackageName())) continue;
                any = true;
                lines.add("  " + p.processName + "  pid=" + p.pid + "  " + importanceName(p.importance)
                        + " (" + p.importance + ")");
            }
            Collections.sort(lines);
            for (String l : lines) sb.append(l).append('\n');
        }
        if (!any) sb.append("  (khong thay tien trinh nao)\n");

        sb.append("\n== CPU tien trinh (do 1 giay, 100 = 1 loi) ==\n");
        sb.append("Game chay logic => :pN > 1%. ~0% trong luc dang choi => dung hinh (xem tai lieu muc 16).\n");
        Map<String, Double> cpu = CpuSampler.measureAll(c, 1000);
        if (cpu.isEmpty()) sb.append("  (khong doc duoc /proc)\n");
        for (Map.Entry<String, Double> e : cpu.entrySet()) {
            sb.append(String.format(Locale.US, "  %s  %.1f%%\n", e.getKey(), e.getValue()));
        }

        sb.append("\n== RAM / CPU tung tien trinh (PSS, do 1 giay) ==\n");
        List<GuestMonitor.Row> mon = GuestMonitor.collect(c, 1000);
        sb.append("Tong PSS: ").append(GuestMonitor.totalPssKb(mon) / 1024).append(" MB\n");
        for (GuestMonitor.Row r : mon) {
            sb.append(String.format(Locale.US, "  %s  pid=%d  PSS=%s MB  CPU=%s%%  %s%n", r.proc, r.pid,
                    r.pssKb >= 0 ? String.valueOf(r.pssKb / 1024) : "?",
                    r.cpu >= 0 ? String.format(Locale.US, "%.1f", r.cpu) : "?",
                    r.registered ? r.pkg + " (space " + r.user + ")" : ""));
        }

        sb.append("\n== Kiem tra truoc khi chay nen (Preflight) ==\n");
        sb.append(Preflight.describeNow(c)).append('\n');

        sb.append("\n== App ao dang ket noi IPC (pid -> game) ==\n");
        sb.append("Kenh LocalSocket tu AppLifecycleCallback cua core. Trong => hook khong hoat dong (xem GuestGenerated: ")
                .append(GuestGenerated.AVAILABLE ? "co" : "KHONG").append(", ").append(GuestGenerated.INFO).append(")\n");
        sb.append(GuestRegistry.describe());
        if (!GuestRegistry.lastPipResult.isEmpty()) sb.append("  ket qua PiP gan nhat: ").append(GuestRegistry.lastPipResult).append('\n');
        if (!GuestRegistry.lastBoostResult.isEmpty()) sb.append("  nang uu tien luong gan nhat: ").append(GuestRegistry.lastBoostResult).append('\n');

        sb.append("\n== Service stub phat hien theo tien trinh ==\n");
        Map<String, ComponentName> stubs = new TreeMap<>(ProcessPinner.discoverStubs(c));
        sb.append("Tong: ").append(stubs.size()).append('\n');
        int shown = 0;
        for (Map.Entry<String, ComponentName> e : stubs.entrySet()) {
            if (shown++ >= 3) {
                sb.append("  ...\n");
                break;
            }
            sb.append("  ").append(e.getKey()).append(" -> ").append(e.getValue().getShortClassName()).append('\n');
        }

        sb.append("\n== Ly do tien trinh thoat gan day (Android 11+) ==\n");
        sb.append("Tim FREEZER (bi dong bang), LOW_MEMORY, SIGNALED/OTHER (OEM kill), CRASH_NATIVE.\n");
        sb.append(ExitReasons.describe(c, 12));

        sb.append("\n== Vi tri du lieu app ao tren dia (de thiet ke sao luu) ==\n");
        sb.append(GuestBackup.describeLayout(c));

        sb.append("\n== Nhat ky ==\n");
        sb.append("File: vspace.log, ").append(LogBuffer.size() / 1024).append(" KB. 15 dong cuoi:\n");
        sb.append(lastLines(LogBuffer.tail(8000), 15));

        sb.append("\n== API cua BlackBoxCore (public) ==\n");
        sb.append(Engine.apiSurface());
        return sb.toString();
    }

    /** Gắn phần cuối nhật ký vào một báo cáo đã thu thập sẵn (tránh đo lại CPU). */
    static String withLog(Context c, String report) {
        String traces = ExitReasons.latestTraceText(c, 20000);
        return report + "\n== NHAT KY (cuoi) ==\n" + LogBuffer.tail(60000)
                + (traces.isEmpty() ? "" : "\n== CRASH/ANR TRACE (moi nhat) ==\n" + traces);
    }

    /** Báo cáo đầy đủ để chia sẻ: chẩn đoán + phần cuối nhật ký. */
    static String collectForShare(Context c) {
        return withLog(c, collect(c));
    }

    private static String lastLines(String text, int n) {
        String[] lines = text.split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = Math.max(0, lines.length - n); i < lines.length; i++) {
            if (!lines[i].isEmpty()) sb.append("  ").append(lines[i]).append('\n');
        }
        return sb.length() == 0 ? "  (trong)\n" : sb.toString();
    }


    static String modeName(int mode) {
        return mode == GameProfile.MODE_FAKE_OFF ? "FAKE_OFF" : mode == GameProfile.MODE_DIM ? "DIM" : "SAVER";
    }

    static String importanceName(int imp) {
        if (imp <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) return "FOREGROUND";
        if (imp <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND_SERVICE) return "FOREGROUND_SERVICE";
        if (imp <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_TOP_SLEEPING) return "TOP_SLEEPING";
        if (imp <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE) return "VISIBLE";
        if (imp <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_PERCEPTIBLE) return "PERCEPTIBLE";
        if (imp <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_CANT_SAVE_STATE) return "CANT_SAVE_STATE";
        if (imp <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_SERVICE) return "SERVICE";
        if (imp <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED) return "CACHED";
        return "GONE";
    }
}
