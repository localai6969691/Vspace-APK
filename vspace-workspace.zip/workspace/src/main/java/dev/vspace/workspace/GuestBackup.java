package dev.vspace.workspace;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Sao lưu / khôi phục dữ liệu app ảo.
 *
 * Bố cục thư mục — XÁC NHẬN TỪ SOURCE THẬT (phiên 5, core ALEX5402/NewBlackbox, SHA 89b59836c66f173756a4ae258cf379a957649820,
 * file Bcore/src/main/java/top/niunaijun/blackbox/core/env/BEnvironment.java):
 *   gốc nội bộ = <cacheDir của host>.getParent()/blackbox   = /data/data/<host_pkg>/blackbox
 *                ← LÀ ANH EM của cache (sVirtualRoot = new File(getCacheDir().getParent(), "blackbox")), KHÔNG nằm trong cache.
 *                  "Xóa bộ nhớ đệm" (chỉ dọn thư mục cache/) KHÔNG đụng tới thư mục này. Chỉ "Xóa dữ liệu"/"Xóa bộ nhớ" (xóa
 *                  cả /data/data/<host_pkg>) hoặc gỡ cài đặt app mới mất dữ liệu app ảo.
 *                  (SỬA so với bản ghi cũ ở PROJECT_HANDOFF O-9/mục 13.5: lúc đó đoán nhầm là "nằm trong cache".)
 *   gốc ngoài  = context.getExternalFilesDir("blackbox")   = /storage/emulated/0/Android/data/<host_pkg>/files/blackbox
 *                ← khác gốc nội bộ, dùng cho "ext" (Android/data/<pkg> ảo) và OBB (xem ObbImporter).
 *   dữ liệu    = <gốc nội bộ>/data/user/<userId>/<pkg>
 *   ngoài      = <gốc ngoài>/storage/emulated/<userId>/Android/data/<pkg>
 *   apk        = <gốc nội bộ>/data/app/<pkg>/base.apk
 * Dữ liệu vẫn chỉ tồn tại trong vùng riêng của host (mất khi gỡ cài đặt host hoặc "Xóa dữ liệu"), nên sao lưu ra ngoài
 * (thư mục do người dùng chọn qua SAF) vẫn là biện pháp bảo vệ chính khi đổi máy hoặc gỡ cài đặt — chỉ không còn đúng lý do
 * "cache bị hệ thống tự dọn".
 *
 * File sao lưu là zip: meta.json (văn bản key=value) → [app/base.apk] → data/… → ext/…. Thứ tự này cho phép đọc meta và APK
 * mà không phải đọc hết file.
 */
final class GuestBackup {
    private static final String TAG = "VSpaceBackup";
    static final int FORMAT = 1;
    private static final long MAX_RESTORE_BYTES = 12L * 1024 * 1024 * 1024; // chặn zip bomb
    private static final int MAX_ENTRIES = 300_000;
    private static final int KEEP_BACKUPS = 3;

    static final class Layout {
        File data;
        File ext;
        File apk;
        boolean viaProbe;
    }

    static final class Stats {
        long files;
        long bytes;
    }

    static final class Meta {
        int format;
        String pkg = "";
        int user;
        String label = "";
        long versionCode;
        boolean hasApk;
        long createdAt;
    }

    static final class Header {
        Meta meta;
        File apk; // APK trích ra cache/import nếu file sao lưu có kèm
    }

    static final class Restored {
        long files;
        long bytes;
        File safetyDir;
    }

    private GuestBackup() {}

    // ------------------------------------------------------------------ đường dẫn

    /** Gốc nội bộ (data/user, data/app) — anh em của cache, KHÔNG nằm trong cache. Xem ghi chú lớp ở trên. */
    static File virtualRoot(Context c) {
        File parent = c.getCacheDir().getParentFile();
        return new File(parent != null ? parent : c.getCacheDir(), "blackbox");
    }

    /** Gốc ngoài (storage/emulated ảo dùng cho Android/data và OBB) — khác gốc nội bộ, xem ObbImporter. */
    static File externalRoot(Context c) {
        File ext = c.getExternalFilesDir("blackbox");
        return ext != null ? ext : new File(virtualRoot(c), "ext-fallback");
    }

    static Layout locate(Context c, String pkg, int userId) {
        File root = virtualRoot(c);
        Layout l = new Layout();
        l.data = new File(root, "data/user/" + userId + "/" + pkg);
        l.ext = new File(externalRoot(c), "storage/emulated/" + userId + "/Android/data/" + pkg);
        l.apk = new File(root, "data/app/" + pkg + "/base.apk");
        if (!l.data.isDirectory()) {
            // Fork khác có thể đặt khác: tìm thư mục tên gói có cha tên userId.
            File found = probe(root, pkg, userId, 0);
            if (found == null) found = probe(c.getDataDir(), pkg, userId, 0);
            if (found != null) {
                l.data = found;
                l.viaProbe = true;
            }
        }
        return l;
    }

    private static File probe(File dir, String pkg, int userId, int depth) {
        if (depth > 6) return null;
        File[] fs = dir.listFiles();
        if (fs == null) return null;
        for (File f : fs) {
            if (!f.isDirectory()) continue;
            if (f.getName().equals(pkg) && dir.getName().equals(String.valueOf(userId))) return f;
            File r = probe(f, pkg, userId, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    /** Văn bản cho Chẩn đoán: gốc ảo, cảnh báo cache, và đường dẫn dữ liệu từng app ảo. */
    static String describeLayout(Context c) {
        StringBuilder sb = new StringBuilder();
        File root = virtualRoot(c);
        File ext = externalRoot(c);
        sb.append("  goc noi bo: ").append(root).append(root.isDirectory() ? "" : "  (KHONG TON TAI)").append('\n');
        sb.append("  goc ngoai : ").append(ext).append(ext.isDirectory() ? "" : "  (KHONG TON TAI)").append('\n');
        sb.append("  Xac nhan tu source that (SHA 89b5983): goc noi bo la ANH EM cua cache, khong nam trong cache.\n");
        sb.append("  'Xoa bo nho dem' KHONG xoa du lieu app ao. Chi 'Xoa du lieu'/go cai dat Workspace moi xoa.\n");
        boolean any = false;
        for (int space = 0; space < Engine.SPACES; space++) {
            for (android.content.pm.ApplicationInfo ai : Engine.installedApps(space)) {
                any = true;
                Layout l = locate(c, ai.packageName, space);
                sb.append("  ").append(ai.packageName).append(" (space ").append(space).append(")\n");
                sb.append("    data: ").append(rel(c, l.data)).append(l.data.isDirectory() ? "  " + sizeOf(l.data, new int[]{20000}) / 1024 + " KB" : "  (khong co)")
                        .append(l.viaProbe ? "  [tim bang probe]" : "").append('\n');
                sb.append("    ext : ").append(rel(c, l.ext)).append(l.ext.isDirectory() ? "  " + sizeOf(l.ext, new int[]{20000}) / 1024 + " KB" : "  (khong co)").append('\n');
            }
        }
        if (!any) sb.append("  (chua co app ao nao)\n");
        return sb.toString();
    }

    private static String rel(Context c, File f) {
        String base = c.getDataDir().getAbsolutePath();
        String p = f.getAbsolutePath();
        return p.startsWith(base) ? "<data>" + p.substring(base.length()) : p;
    }

    static long sizeOf(File f, int[] budget) {
        if (budget[0]-- <= 0) return 0;
        if (f.isFile()) return f.length();
        long t = 0;
        File[] fs = f.listFiles();
        if (fs != null) for (File x : fs) t += sizeOf(x, budget);
        return t;
    }

    // ------------------------------------------------------------------ hàm thuần (có test)

    /** Chỉ nhận tên mục zip tương đối, không có '..', không dấu '\\', không ký tự NUL, không bắt đầu bằng '/'. */
    static boolean isSafeEntryName(String name) {
        if (name == null || name.isEmpty() || name.length() > 1024) return false;
        if (name.indexOf('\\') >= 0 || name.indexOf('\0') >= 0 || name.startsWith("/")) return false;
        for (String seg : name.split("/")) {
            if (seg.equals("..")) return false;
        }
        return true;
    }

    /** rel: đường dẫn tương đối trong thư mục dữ liệu. Bỏ cache và code_cache (sinh lại được, rất lớn). */
    static boolean shouldSkip(String rel) {
        return rel.equals("cache") || rel.startsWith("cache/") || rel.equals("code_cache") || rel.startsWith("code_cache/");
    }

    static String buildMeta(Meta m) {
        return "format=" + m.format + "\n"
                + "pkg=" + m.pkg + "\n"
                + "user=" + m.user + "\n"
                + "label=" + m.label.replace('\n', ' ').replace('\r', ' ') + "\n"
                + "versionCode=" + m.versionCode + "\n"
                + "hasApk=" + m.hasApk + "\n"
                + "createdAt=" + m.createdAt + "\n";
    }

    static Meta parseMeta(String text) {
        Meta m = new Meta();
        for (String line : text.split("\n")) {
            int eq = line.indexOf('=');
            if (eq <= 0) continue;
            String k = line.substring(0, eq).trim();
            String v = line.substring(eq + 1).trim();
            try {
                switch (k) {
                    case "format": m.format = Integer.parseInt(v); break;
                    case "pkg": m.pkg = v; break;
                    case "user": m.user = Integer.parseInt(v); break;
                    case "label": m.label = v; break;
                    case "versionCode": m.versionCode = Long.parseLong(v); break;
                    case "hasApk": m.hasApk = Boolean.parseBoolean(v); break;
                    case "createdAt": m.createdAt = Long.parseLong(v); break;
                    default: break;
                }
            } catch (NumberFormatException ignored) {
            }
        }
        return m;
    }

    static String backupPrefix(String pkg, int user) {
        return "vspace-" + pkg + "-u" + user + "-";
    }

    static String backupFileName(String pkg, int user, long ts) {
        return backupPrefix(pkg, user) + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date(ts)) + ".zip";
    }

    // ------------------------------------------------------------------ sao lưu

    /** Ghi zip ra out. Game PHẢI đã dừng (gọi Engine.stop + GuestRegistry.waitUntilGone trước). */
    static Stats backup(Context c, String pkg, int userId, CharSequence label, long versionCode, boolean withApk, OutputStream out)
            throws IOException {
        Layout l = locate(c, pkg, userId);
        if (!l.data.isDirectory()) throw new IOException("không có thư mục dữ liệu của " + pkg);
        Stats st = new Stats();
        Meta m = new Meta();
        m.format = FORMAT;
        m.pkg = pkg;
        m.user = userId;
        m.label = label.toString();
        m.versionCode = versionCode;
        m.hasApk = withApk && l.apk.isFile();
        m.createdAt = System.currentTimeMillis();
        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(out))) {
            putText(z, "meta.json", buildMeta(m));
            if (m.hasApk) addFile(z, l.apk, "app/base.apk", st);
            addDir(z, l.data, l.data, "data/", st, true);
            if (l.ext.isDirectory()) addDir(z, l.ext, l.ext, "ext/", st, false);
        }
        LogBuffer.i(TAG, "backup " + pkg + " u" + userId + " files=" + st.files + " bytes=" + st.bytes + " apk=" + m.hasApk);
        return st;
    }

    private static void putText(ZipOutputStream z, String name, String text) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(text.getBytes("UTF-8"));
        z.closeEntry();
    }

    private static void addDir(ZipOutputStream z, File root, File dir, String prefix, Stats st, boolean isData) throws IOException {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            String rel = f.getAbsolutePath().substring(root.getAbsolutePath().length() + 1).replace(File.separatorChar, '/');
            if (isData && shouldSkip(rel)) continue;
            if (Files.isSymbolicLink(f.toPath())) continue;
            if (f.isDirectory()) addDir(z, root, f, prefix, st, isData);
            else if (f.isFile()) addFile(z, f, prefix + rel, st);
        }
    }

    private static void addFile(ZipOutputStream z, File f, String name, Stats st) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setTime(f.lastModified());
        z.putNextEntry(e);
        try (InputStream in = new FileInputStream(f)) {
            ApkImporter.copy(in, z);
        }
        z.closeEntry();
        st.files++;
        st.bytes += f.length();
    }

    // ------------------------------------------------------------------ đọc tiêu đề + APK

    /** Đọc meta (và trích app/base.apk ra cache/import nếu có ngay sau meta). Không đọc phần còn lại của file. */
    static Header readHeader(Context c, InputStream raw) throws IOException {
        Header h = new Header();
        try (ZipInputStream z = new ZipInputStream(new BufferedInputStream(raw))) {
            ZipEntry e = z.getNextEntry();
            if (e == null || !"meta.json".equals(e.getName())) throw new IOException("không phải file sao lưu hợp lệ (thiếu meta)");
            h.meta = parseMeta(new String(readCapped(z, 64 * 1024), "UTF-8"));
            if (h.meta.format != FORMAT || h.meta.pkg.isEmpty()) throw new IOException("định dạng sao lưu không hỗ trợ");
            if (h.meta.hasApk) {
                e = z.getNextEntry();
                if (e != null && "app/base.apk".equals(e.getName())) {
                    File dir = new File(c.getCacheDir(), "import");
                    //noinspection ResultOfMethodCallIgnored
                    dir.mkdirs();
                    File apk = new File(dir, "restore-" + System.currentTimeMillis() + ".apk");
                    try (OutputStream out = new FileOutputStream(apk)) {
                        ApkImporter.copy(z, out);
                    }
                    h.apk = apk;
                }
            }
        }
        return h;
    }

    private static byte[] readCapped(InputStream in, int max) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) {
            if (bo.size() + n > max) throw new IOException("mục quá lớn");
            bo.write(buf, 0, n);
        }
        return bo.toByteArray();
    }

    // ------------------------------------------------------------------ khôi phục

    /**
     * Khôi phục dữ liệu vào không gian userId. Giải nén ra thư mục tạm, kiểm tra xong mới tráo; dữ liệu cũ được GIỮ LẠI
     * ở files/safety/… (giữ 2 bản gần nhất). Game PHẢI đã dừng.
     * @param expectPkg nếu khác null, gói trong file sao lưu phải trùng.
     */
    static Restored restore(Context c, InputStream raw, String expectPkg, int userId) throws IOException {
        File tmp = new File(c.getFilesDir(), "restore-tmp");
        deleteRecursive(tmp);
        //noinspection ResultOfMethodCallIgnored
        tmp.mkdirs();
        String tmpCanon = tmp.getCanonicalPath() + File.separator;
        Restored r = new Restored();
        Meta meta = null;
        int entries = 0;
        long total = 0;
        try (ZipInputStream z = new ZipInputStream(new BufferedInputStream(raw))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                if (++entries > MAX_ENTRIES) throw new IOException("quá nhiều tệp trong file sao lưu");
                String name = e.getName();
                if (meta == null) {
                    if (!"meta.json".equals(name)) throw new IOException("không phải file sao lưu hợp lệ (thiếu meta)");
                    meta = parseMeta(new String(readCapped(z, 64 * 1024), "UTF-8"));
                    if (meta.format != FORMAT || meta.pkg.isEmpty()) throw new IOException("định dạng sao lưu không hỗ trợ");
                    if (expectPkg != null && !expectPkg.equals(meta.pkg)) {
                        throw new IllegalArgumentException("file sao lưu của " + meta.pkg + ", không phải " + expectPkg);
                    }
                    continue;
                }
                if (!isSafeEntryName(name)) throw new IOException("tên tệp không an toàn: " + name);
                if (e.isDirectory() || "app/base.apk".equals(name)) continue; // APK đã được xử lý ở readHeader
                if (!name.startsWith("data/") && !name.startsWith("ext/")) continue;
                File out = new File(tmp, name);
                if (!out.getCanonicalPath().startsWith(tmpCanon)) throw new IOException("tệp thoát khỏi thư mục tạm: " + name);
                //noinspection ResultOfMethodCallIgnored
                out.getParentFile().mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = z.read(buf)) > 0) {
                        total += n;
                        if (total > MAX_RESTORE_BYTES) throw new IOException("dữ liệu giải nén quá lớn");
                        os.write(buf, 0, n);
                    }
                }
                r.files++;
            }
        } catch (IOException | RuntimeException ex) {
            deleteRecursive(tmp);
            throw ex;
        }
        if (meta == null) {
            deleteRecursive(tmp);
            throw new IOException("file rỗng");
        }
        r.bytes = total;

        Layout l = locate(c, meta.pkg, userId);
        File safety = new File(c.getFilesDir(), "safety/" + meta.pkg + "." + userId + "." + System.currentTimeMillis());
        File newData = new File(tmp, "data");
        File newExt = new File(tmp, "ext");
        if (newData.isDirectory()) {
            if (l.data.exists()) moveOrCopy(l.data, new File(safety, "data"));
            moveOrCopy(newData, l.data);
        }
        if (newExt.isDirectory()) {
            if (l.ext.exists()) moveOrCopy(l.ext, new File(safety, "ext"));
            moveOrCopy(newExt, l.ext);
        }
        deleteRecursive(tmp);
        pruneSafety(c, meta.pkg, userId, 2);
        r.safetyDir = safety.exists() ? safety : null;
        LogBuffer.i(TAG, "restore " + meta.pkg + " u" + userId + " files=" + r.files + " bytes=" + r.bytes);
        return r;
    }

    private static void moveOrCopy(File src, File dst) throws IOException {
        File parent = dst.getParentFile();
        if (parent != null) {
            //noinspection ResultOfMethodCallIgnored
            parent.mkdirs();
        }
        if (src.renameTo(dst)) return;
        copyRecursive(src, dst);
        deleteRecursive(src);
    }

    private static void copyRecursive(File src, File dst) throws IOException {
        if (src.isDirectory()) {
            //noinspection ResultOfMethodCallIgnored
            dst.mkdirs();
            File[] fs = src.listFiles();
            if (fs != null) for (File f : fs) copyRecursive(f, new File(dst, f.getName()));
        } else {
            try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                ApkImporter.copy(in, out);
            }
        }
    }

    static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory() && !Files.isSymbolicLink(f.toPath())) {
            File[] fs = f.listFiles();
            if (fs != null) for (File x : fs) deleteRecursive(x);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private static void pruneSafety(Context c, String pkg, int userId, int keep) {
        File dir = new File(c.getFilesDir(), "safety");
        File[] fs = dir.listFiles();
        if (fs == null) return;
        String prefix = pkg + "." + userId + ".";
        List<File> mine = new ArrayList<>();
        for (File f : fs) if (f.getName().startsWith(prefix)) mine.add(f);
        Collections.sort(mine, (a, b) -> b.getName().compareTo(a.getName()));
        for (int i = keep; i < mine.size(); i++) deleteRecursive(mine.get(i));
    }

    // ------------------------------------------------------------------ tự sao lưu ra thư mục SAF

    /** Dừng game rồi sao lưu vào thư mục sao lưu tự động (nếu người dùng đã chọn), giữ 3 bản gần nhất. Chạy ở luồng nền. */
    static void autoBackupAsync(final Context c, final String pkg, final int userId, final String label) {
        final String treeStr = Prefs.backupTree(c);
        if (treeStr == null) {
            LogBuffer.w(TAG, "auto backup bật nhưng chưa chọn thư mục sao lưu");
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Uri tree = Uri.parse(treeStr);
                    Engine.stop(pkg, userId);
                    GuestRegistry.waitUntilGone(pkg, userId, 5000);
                    ContentResolver cr = c.getContentResolver();
                    Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
                    Uri doc = DocumentsContract.createDocument(cr, parent, "application/zip", backupFileName(pkg, userId, System.currentTimeMillis()));
                    if (doc == null) throw new IOException("không tạo được file trong thư mục sao lưu");
                    Stats st;
                    try (OutputStream out = cr.openOutputStream(doc)) {
                        st = backup(c, pkg, userId, label, Engine.installedVersionCode(c, pkg, userId), false, out);
                    }
                    rotate(c, tree, pkg, userId);
                    Notifier.alert(c, c.getString(R.string.alert_backup_ok_title),
                            c.getString(R.string.alert_backup_ok_text, label, st.files, st.bytes / (1024 * 1024)));
                } catch (Throwable t) {
                    LogBuffer.e(TAG, "auto backup failed", t);
                    Notifier.alert(c, c.getString(R.string.alert_backup_fail_title), String.valueOf(t.getMessage()));
                }
            }
        }, "vspace-autobackup").start();
    }

    private static void rotate(Context c, Uri tree, String pkg, int userId) {
        try {
            ContentResolver cr = c.getContentResolver();
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
            String prefix = backupPrefix(pkg, userId);
            List<String[]> items = new ArrayList<>();
            try (Cursor cur = cr.query(children, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
                while (cur != null && cur.moveToNext()) {
                    String name = cur.getString(1);
                    if (name != null && name.startsWith(prefix)) items.add(new String[]{cur.getString(0), name});
                }
            }
            Collections.sort(items, (a, b) -> b[1].compareTo(a[1])); // tên chứa mốc thời gian → mới nhất trước
            for (int i = KEEP_BACKUPS; i < items.size(); i++) {
                try {
                    DocumentsContract.deleteDocument(cr, DocumentsContract.buildDocumentUriUsingTree(tree, items.get(i)[0]));
                } catch (Exception ignored) {
                }
            }
        } catch (Throwable t) {
            LogBuffer.w(TAG, "rotate failed: " + t);
        }
    }
}
