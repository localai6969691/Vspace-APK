package dev.vspace.workspace;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.os.Build;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Lý do các tiến trình của app thoát gần đây (Android 11+). Đây là bằng chứng trực tiếp cho giả thuyết cốt lõi:
 * tiến trình :pN của app ảo có bị đóng băng (FREEZER), thiếu RAM (LOW_MEMORY), bị OEM giết (SIGNALED/OTHER) hay crash không.
 */
final class ExitReasons {
    private ExitReasons() {}

    static String reasonName(int r) {
        switch (r) {
            case 0: return "UNKNOWN";
            case 1: return "EXIT_SELF";
            case 2: return "SIGNALED";
            case 3: return "LOW_MEMORY";
            case 4: return "CRASH";
            case 5: return "CRASH_NATIVE";
            case 6: return "ANR";
            case 7: return "INITIALIZATION_FAILURE";
            case 8: return "PERMISSION_CHANGE";
            case 9: return "EXCESSIVE_RESOURCE_USAGE";
            case 10: return "USER_REQUESTED";
            case 11: return "USER_STOPPED";
            case 12: return "DEPENDENCY_DIED";
            case 13: return "OTHER";
            case 14: return "FREEZER";
            case 15: return "PACKAGE_STATE_CHANGE";
            case 16: return "PACKAGE_UPDATED";
            default: return "REASON_" + r;
        }
    }

    private static String line(ApplicationExitInfo i, SimpleDateFormat fmt) {
        String desc = i.getDescription();
        return fmt.format(new Date(i.getTimestamp())) + " " + i.getProcessName() + " "
                + reasonName(i.getReason()) + " status=" + i.getStatus()
                + " imp=" + Diagnostics.importanceName(i.getImportance())
                + (desc != null ? " [" + desc + "]" : "");
    }

    static String describe(Context c, int max) {
        if (Build.VERSION.SDK_INT < 30) return "  (can Android 11+ de doc ApplicationExitInfo)\n";
        StringBuilder sb = new StringBuilder();
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            List<ApplicationExitInfo> list = am.getHistoricalProcessExitReasons(c.getPackageName(), 0, max);
            SimpleDateFormat fmt = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.US);
            if (list == null || list.isEmpty()) sb.append("  (chua co)\n");
            else for (ApplicationExitInfo i : list) sb.append("  ").append(line(i, fmt)).append('\n');
        } catch (Throwable t) {
            sb.append("  (khong doc duoc: ").append(t).append(")\n");
        }
        return sb.toString();
    }

    /**
     * Với ANR: lưu trace văn bản. Với crash native: lưu tombstone (protobuf, Android 12+) và bản trích chữ đọc được
     * (tên hàm, thư viện, tín hiệu). Hệ thống giữ trace trong bộ đệm vòng toàn máy nên có thể là null.
     */
    private static void saveTrace(Context c, ApplicationExitInfo i) {
        int r = i.getReason();
        if (r != 5 && r != 6) return;
        try (InputStream in = i.getTraceInputStream()) {
            if (in == null) return;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0 && bo.size() < 256 * 1024) bo.write(buf, 0, n);
            byte[] data = bo.toByteArray();
            if (data.length == 0) return;
            File dir = new File(c.getFilesDir(), "crash");
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            String base = (r == 6 ? "anr-" : "native-") + i.getTimestamp();
            String text = r == 6 ? new String(data, "UTF-8") : TraceText.join(TraceText.strings(data, 5, 160));
            try (FileOutputStream fo = new FileOutputStream(new File(dir, base + ".txt"))) {
                fo.write(("# " + reasonName(r) + " " + i.getProcessName() + " pid=" + i.getPid() + "\n" + text).getBytes("UTF-8"));
            }
            if (r == 5) {
                try (FileOutputStream fo = new FileOutputStream(new File(dir, base + ".pb"))) {
                    fo.write(data);
                }
            }
            LogBuffer.w("CRASHTRACE", reasonName(r) + " " + i.getProcessName() + " da luu " + base + " (" + data.length + " byte)");
            File[] all = dir.listFiles();
            if (all != null && all.length > 20) {
                java.util.Arrays.sort(all, (a, b) -> a.getName().compareTo(b.getName()));
                for (int k = 0; k < all.length - 20; k++) //noinspection ResultOfMethodCallIgnored
                    all[k].delete();
            }
        } catch (Throwable t) {
            LogBuffer.w("CRASHTRACE", "khong luu duoc trace: " + t);
        }
    }

    /** Nội dung trace mới nhất đã lưu (tối đa maxChars) để đưa vào báo cáo; rỗng nếu chưa có. */
    static String latestTraceText(Context c, int maxChars) {
        try {
            File[] all = new File(c.getFilesDir(), "crash").listFiles((d, name) -> name.endsWith(".txt"));
            if (all == null || all.length == 0) return "";
            java.util.Arrays.sort(all, (a, b) -> b.getName().compareTo(a.getName()));
            StringBuilder sb = new StringBuilder();
            for (File f : all) {
                byte[] b = java.nio.file.Files.readAllBytes(f.toPath());
                sb.append("--- ").append(f.getName()).append(" ---\n").append(new String(b, "UTF-8")).append('\n');
                if (sb.length() >= maxChars) break;
            }
            return sb.length() > maxChars ? sb.substring(0, maxChars) : sb.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    /** Ghi các lần thoát MỚI (từ lần ghi trước) vào nhật ký, chạy ở luồng nền lúc khởi động tiến trình chính. */
    static void logRecent(final Context c) {
        if (Build.VERSION.SDK_INT < 30) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
                    List<ApplicationExitInfo> list = am.getHistoricalProcessExitReasons(c.getPackageName(), 0, 20);
                    if (list == null) return;
                    long last = Prefs.exitLastTs(c);
                    long newest = last;
                    SimpleDateFormat fmt = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.US);
                    for (int k = list.size() - 1; k >= 0; k--) { // cũ → mới
                        ApplicationExitInfo i = list.get(k);
                        if (i.getTimestamp() <= last) continue;
                        LogBuffer.i("EXIT", line(i, fmt));
                        saveTrace(c, i);
                        newest = Math.max(newest, i.getTimestamp());
                    }
                    if (newest > last) Prefs.setExitLastTs(c, newest);
                } catch (Throwable ignored) {
                }
            }
        }, "vspace-exit-log").start();
    }
}
