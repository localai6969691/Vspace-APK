package dev.vspace.workspace;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * Màn hình đen phủ toàn bộ. Chạm bất kỳ chỗ nào: hiện thông tin 3 giây.
 * Chạm 3 lần liên tiếp ở góc trên-phải: thoát chế độ game. (Còn lối thoát thứ hai: nút trong thông báo.)
 * Không dùng FLAG_NOT_TOUCHABLE nên chạm vào overlay không lọt xuống game.
 */
final class GameOverlay extends FrameLayout {

    interface Listener {
        void onExit();
        String info();
    }

    private final Listener listener;
    private final TextView hint;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable hideHint = new Runnable() {
        @Override
        public void run() {
            hint.setVisibility(View.INVISIBLE);
        }
    };
    private int taps;
    private long firstTap;

    GameOverlay(Context c, Listener l) {
        super(c);
        this.listener = l;
        setBackgroundColor(Color.BLACK);
        hint = new TextView(c);
        hint.setTextColor(0xFF777777);
        hint.setTextSize(14);
        hint.setGravity(Gravity.CENTER);
        int pad = (int) (24 * c.getResources().getDisplayMetrics().density);
        hint.setPadding(pad, pad, pad, pad);
        hint.setVisibility(View.INVISIBLE);
        addView(hint, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            long now = SystemClock.uptimeMillis();
            boolean topRight = e.getX() > getWidth() * 0.6f && e.getY() < getHeight() * 0.25f;
            if (topRight && taps > 0 && now - firstTap < 1500) {
                taps++;
            } else {
                taps = topRight ? 1 : 0;
                firstTap = now;
            }
            if (topRight && taps >= 3) {
                taps = 0;
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        listener.onExit();
                    }
                });
                return true;
            }
            hint.setText(listener.info());
            hint.setVisibility(View.VISIBLE);
            h.removeCallbacks(hideHint);
            h.postDelayed(hideHint, 3000);
        }
        return true;
    }

    @Override
    protected void onDetachedFromWindow() {
        h.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
