package dev.vspace.workspace;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.StrictMode;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 * Application này được nạp trong CẢ tiến trình chính lẫn các tiến trình :p0..:pN chứa app ảo,
 * nên engine phải được khởi tạo ở cả hai nơi. Nhật ký/crash handler chỉ ở tiến trình chính.
 */
public class SpaceApp extends Application {

    /** Application của HOST trong tiến trình hiện tại (dùng ở tiến trình app ảo để biết tên gói host). */
    static volatile SpaceApp instance;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        Engine.attach(base);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        Engine.create();
        if (isMainProcess(this)) {
            LogBuffer.init(this);
            LogBuffer.installCrashHandler(this);
            LogBuffer.i("App", "main process started, sdk=" + Build.VERSION.SDK_INT + " device=" + Build.MODEL);
            ExitReasons.logRecent(this);
            IpcServer.start(this);
            enableStrictModeIfDebuggable();
        } else {
            // Tiến trình :pN / :daemon của engine: đăng ký hook vòng đời app ảo (mã sinh bởi gen_guest_hooks.py).
            GuestGenerated.register();
        }
    }

    /** Hệ thống báo thiếu RAM: chỉ chuyển cho chế độ game ở tiến trình chính (đếm sự kiện, cảnh báo khi nghiêm trọng). */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        try {
            if (isMainProcess(this)) GameModeController.get(this).onTrimMemory(level);
        } catch (Throwable ignored) {
        }
    }

    /** Bản debug: ghi log (không crash) khi có I/O hoặc thao tác chậm trên luồng chính, để bắt nguy cơ ANR sớm. */
    private void enableStrictModeIfDebuggable() {
        try {
            if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) == 0) return;
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build());
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectLeakedClosableObjects().detectLeakedSqlLiteObjects().penaltyLog().build());
        } catch (Throwable ignored) {
        }
    }

    static boolean isMainProcess(Context c) {
        String name = null;
        if (Build.VERSION.SDK_INT >= 28) {
            name = Application.getProcessName();
        } else {
            try (BufferedReader r = new BufferedReader(new FileReader("/proc/self/cmdline"))) {
                String s = r.readLine();
                if (s != null) {
                    int z = s.indexOf('\0');
                    name = (z >= 0 ? s.substring(0, z) : s).trim();
                }
            } catch (Throwable ignored) {
            }
        }
        return name == null || name.equals(c.getPackageName());
    }
}
