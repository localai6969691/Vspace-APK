package dev.vspace.workspace;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {
    static final String ACTION_WATCHDOG = "dev.vspace.workspace.action.WATCHDOG";
    static final String ACTION_SCHEDULE_START = "dev.vspace.workspace.action.SCHEDULE_START";

    @Override
    public void onReceive(Context c, Intent intent) {
        String a = intent != null ? intent.getAction() : null;
        try {
            if (ACTION_WATCHDOG.equals(a)) {
                if (Prefs.keepAlive(c) && !KeepAliveService.running) {
                    try {
                        KeepAliveService.start(c);
                    } catch (Throwable t) {
                        // Android 12+/15 chặn khởi động foreground service từ nền: báo người dùng mở app để tiếp tục.
                        LogBuffer.w("VSpaceAlarm", "watchdog cannot start service: " + t);
                        Notifier.alert(c, c.getString(R.string.alert_fgs_blocked_title), c.getString(R.string.alert_fgs_blocked_text));
                    }
                }
                Scheduler.armWatchdog(c);
            } else if (ACTION_SCHEDULE_START.equals(a)) {
                Scheduler.onStartAlarm(c);
            }
        } catch (Throwable t) {
            LogBuffer.w("VSpaceAlarm", "failed: " + t);
        }
    }
}
