package dev.vspace.workspace;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// Hai import dưới đây được scripts/overlay.sh tự sửa lại cho khớp package thật của core.
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.configuration.ClientConfiguration;

/**
 * Lớp bọc duy nhất gọi vào BlackBox. Muốn đổi engine (VirtualApp, fork khác...) thì chỉ cần sửa file này.
 *
 * CHÚ GIẢI XÁC THỰC (phiên 5): đã đọc trực tiếp source thật của ALEX5402/NewBlackbox, SHA
 * 89b59836c66f173756a4ae258cf379a957649820 (xem PROJECT_HANDOFF.md mục 13.2 để biết bảng đầy đủ). Các hàm dưới đây
 * giờ được gọi TRỰC TIẾP (không qua reflection) vì đã xác nhận có thật với đúng chữ ký ở SHA trên:
 *   doAttachBaseContext, doCreate, getInstalledApplications, installPackageAsUser(File|String, userId) [trả InstallResult,
 *   không phải void — đọc bằng reflection field access vì không import kiểu entity của core, xem readInstallResult],
 *   launchApk (trả boolean — KHÔNG trả Intent ở core này; nhánh Intent giữ lại phòng fork khác),
 *   stopPackage(String,int) [gọi thẳng BProcessManagerService.killPackageAsUser, xác nhận thật],
 *   uninstallPackageAsUser(String,int), uninstallPackage(String), createUser(int) [trả BUserInfo], getUsers().
 * Hàm KHÔNG tồn tại ở core này (đã xác nhận, không còn thử): BActivityManager.killAppByPkg — bỏ khỏi Engine.stop.
 * Core khác/fork đổi tên vẫn không vỡ build vì các lời gọi "không chắc" còn lại vẫn qua reflection như cũ (D-04).
 *
 * "Không gian" = userId của engine: cùng một APK cài ở 2 không gian là 2 bản độc lập (dùng cho nhiều tài khoản game).
 * Việc engine có cô lập dữ liệu giữa các không gian hay không PHẢI được kiểm chứng bằng app testguest (xem tài liệu).
 * Đã đọc được một phần từ source (phiên 5): ANDROID_ID trả nguyên giá trị thật của HOST cho mọi không gian trừ khi giá trị
 * đó rỗng/0 (AndroidIdProxy.GetAndroidId); keystore KHÔNG có lớp proxy nào trong fake/service (không tìm thấy khi grep toàn
 * bộ core) → alias keystore giữa các guest nhiều khả năng KHÔNG cách ly. Đây là thông tin để CẢNH BÁO người dùng
 * (RiskList/scope), KHÔNG dùng để giả mạo hay che giấu (cấm theo AGENTS.md mục 9).
 */
public final class Engine {
    private static final String TAG = "VSpaceEngine";

    /** Số không gian hiển thị (userId 0..SPACES-1). */
    public static final int SPACES = 3;

    private Engine() {}

    static void attach(final Context base) {
        try {
            BlackBoxCore.get().doAttachBaseContext(base, new ClientConfiguration() {
                @Override
                public String getHostPackageName() {
                    return base.getPackageName();
                }

                /**
                 * PHÁT HIỆN BẢO MẬT THẬT (phiên 6, đọc source): ClientConfiguration.getLogSenderChatId() mặc định
                 * trả "-1003719573856" (một chat Telegram CỦA BÊN THỨ BA — tác giả core, không phải Workspace).
                 * BlackBoxCore.sendLogs(...) dùng giá trị này để đẩy logcat của HOST (có thể chứa dữ liệu của mọi
                 * app ảo đang chạy) + thông tin thiết bị lên chat đó. SimpleCrashFix.installSimpleFix() tự chạy
                 * trong static{} của BlackBoxCore (không cần Workspace gọi gì) và tự gọi sendLogs() trên nhiều loại
                 * crash (NullContext/GMS/WebView/Attribution/SocialMedia/uncaught) — nghĩa là mặc định của CORE là
                 * RÒ RỈ dữ liệu người dùng ra ngoài mỗi khi app ảo crash, trừ khi override hàm này về null/rỗng
                 * (đúng điều kiện chặn trong sendLogs: "if (chatId == null || chatId.isEmpty()) return;"). Override
                 * này BẮT BUỘC PHẢI GIỮ — không phải tùy chọn — và không liên quan gì tới việc che giấu/giả mạo
                 * (đây là chặn RÒ RỈ RA NGOÀI, ngược hướng với che giấu/giả mạo mà AGENTS.md mục 9 cấm).
                 */
                @Override
                public String getLogSenderChatId() {
                    return null;
                }
            });
        } catch (Throwable t) {
            LogBuffer.e(TAG, "doAttachBaseContext failed", t);
        }
    }

    static void create() {
        try {
            BlackBoxCore.get().doCreate();
        } catch (Throwable t) {
            LogBuffer.e(TAG, "doCreate failed", t);
        }
    }

    static List<ApplicationInfo> installedApps(int userId) {
        try {
            List<ApplicationInfo> list = BlackBoxCore.get().getInstalledApplications(0, userId);
            if (list != null) return list;
        } catch (Throwable t) {
            LogBuffer.e(TAG, "getInstalledApplications failed (user " + userId + ")", t);
        }
        return new ArrayList<>();
    }

    static boolean isInstalled(String pkg, int userId) {
        for (ApplicationInfo ai : installedApps(userId)) {
            if (pkg.equals(ai.packageName)) return true;
        }
        return false;
    }

    /**
     * Phiên bản (versionCode) của app ảo đã cài trong không gian này.
     * @return -1 nếu chưa cài; 0 nếu đã cài nhưng không đọc được phiên bản.
     */
    @SuppressWarnings("deprecation")
    static long installedVersionCode(Context c, String pkg, int userId) {
        try {
            PackageManager pm = c.getPackageManager();
            for (ApplicationInfo ai : installedApps(userId)) {
                if (!pkg.equals(ai.packageName)) continue;
                if (ai.sourceDir == null) return 0;
                PackageInfo pi = pm.getPackageArchiveInfo(ai.sourceDir, 0);
                if (pi == null) return 0;
                return Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
            }
        } catch (Throwable ignored) {
        }
        return -1;
    }

    /** Một số core cần tạo user trước khi cài vào userId > 0. Không có hàm thì bỏ qua. */
    private static void ensureUser(int userId) {
        if (userId <= 0) return;
        try {
            Object core = BlackBoxCore.get();
            Method m = core.getClass().getMethod("createUser", int.class);
            m.invoke(core, userId);
        } catch (Throwable t) {
            LogBuffer.d(TAG, "createUser unavailable or failed: " + t);
        }
    }

    /** Kết quả cài đặt có thông báo lỗi THẬT từ engine (InstallResult.msg), không chỉ đoán từ isInstalled(). */
    static final class InstallOutcome {
        final boolean ok;
        final String message; // có thể null nếu engine không đưa lý do, hoặc nếu đọc reflection thất bại
        InstallOutcome(boolean ok, String message) { this.ok = ok; this.message = message; }
    }

    /**
     * Đọc trường success/msg của top.niunaijun.blackbox.entity.pm.InstallResult bằng reflection (không import
     * trực tiếp kiểu entity của core để không phải sửa thêm overlay.sh; xem ghi chú lớp). Trả null nếu đối tượng
     * không có các trường này (core khác) — gọi nơi dùng phải tự coi isInstalled() là nguồn sự thật cuối cùng.
     */
    private static InstallOutcome readInstallResult(Object result, String expectedPackage, int userId) {
        boolean installed = isInstalled(expectedPackage, userId);
        if (result == null) return new InstallOutcome(installed, null);
        try {
            Object successField = result.getClass().getField("success").get(result);
            Object msgField = result.getClass().getField("msg").get(result);
            boolean success = !(successField instanceof Boolean) || (Boolean) successField;
            String msg = msgField != null ? msgField.toString() : null;
            // isInstalled() là trọng tài cuối: InstallResult.success mặc định = true ngay cả khi chưa có lỗi gọi installError().
            return new InstallOutcome(installed || success, msg);
        } catch (Throwable t) {
            LogBuffer.d(TAG, "InstallResult reflection unavailable: " + t);
            return new InstallOutcome(installed, null);
        }
    }

    /** Cài từ file APK (chưa cài trên máy). Giữ bản boolean cho các chỗ gọi cũ; dùng installApkVerbose() để có lý do lỗi thật. */
    static boolean installApk(File apk, String expectedPackage, int userId) {
        return installApkVerbose(apk, expectedPackage, userId).ok;
    }

    /** Như installApk, nhưng trả kèm thông báo lỗi thật từ engine (InstallResult.msg) khi cài thất bại. */
    static InstallOutcome installApkVerbose(File apk, String expectedPackage, int userId) {
        ensureUser(userId);
        Object result = null;
        try {
            result = BlackBoxCore.get().installPackageAsUser(apk, userId);
        } catch (Throwable t) {
            LogBuffer.e(TAG, "installPackageAsUser(File) failed", t);
        }
        return readInstallResult(result, expectedPackage, userId);
    }

    /** Nhân bản app đã cài sẵn trên máy vào không gian ảo. */
    static boolean cloneFromDevice(String pkg, int userId) {
        return cloneFromDeviceVerbose(pkg, userId).ok;
    }

    /** Như cloneFromDevice, nhưng trả kèm thông báo lỗi thật từ engine. */
    static InstallOutcome cloneFromDeviceVerbose(String pkg, int userId) {
        ensureUser(userId);
        Object result = null;
        try {
            result = BlackBoxCore.get().installPackageAsUser(pkg, userId);
        } catch (Throwable t) {
            LogBuffer.e(TAG, "installPackageAsUser(String) failed", t);
        }
        return readInstallResult(result, pkg, userId);
    }

    /**
     * Mở app ảo. Gọi bằng reflection vì các fork trả về kiểu khác nhau:
     * bản gốc trả boolean (tự mở activity), một số fork trả Intent (caller phải tự startActivity).
     */
    static boolean launch(Context ctx, String pkg, int userId) {
        try {
            Object core = BlackBoxCore.get();
            Method m = core.getClass().getMethod("launchApk", String.class, int.class);
            Object r = m.invoke(core, pkg, userId);
            if (r instanceof Intent) {
                Intent i = (Intent) r;
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(i);
                return true;
            }
            return !(r instanceof Boolean) || (Boolean) r;
        } catch (Throwable t) {
            LogBuffer.e(TAG, "launchApk failed", t);
            return false;
        }
    }

    /**
     * Tắt tiến trình của app ảo. stopPackage(String,int) đã XÁC NHẬN thật ở core này (gọi thẳng
     * BProcessManagerService.killPackageAsUser — không còn là reflection "thử may rủi" như trước phiên 5), nhưng vẫn gọi
     * qua reflection để không vỡ build nếu fork khác đổi tên (D-04). Không còn thử BActivityManager.killAppByPkg: đã xác
     * nhận hàm này KHÔNG tồn tại trên BActivityManagerService của core này (phiên 5, đọc trực tiếp source, không chỉ
     * README/DeepWiki — mục đó đã sai). Vẫn giữ bước giết thẳng pid từ sổ IPC làm lưới an toàn cuối.
     */
    static boolean stop(String pkg, int userId) {
        boolean ok = invoke("stopPackage", pkg, userId);
        int killed = GuestRegistry.killAll(pkg, userId);
        return ok || killed > 0;
    }

    static boolean uninstall(String pkg, int userId) {
        boolean called = invoke("uninstallPackageAsUser", pkg, userId);
        if (!called) called = invokeNoUser("uninstallPackage", pkg);
        return called && !isInstalled(pkg, userId);
    }

    /** Danh sách public method thật của BlackBoxCore (hiện trong màn hình Chẩn đoán). */
    // ------------------------------------------------------------------ dữ liệu / không gian / Google services (phiên 7)

    /**
     * Xóa DỮ LIỆU của một app ảo nhưng giữ app (BlackBoxCore.clearPackage). Game phải đã dừng. KHÔNG hoàn tác được:
     * người gọi nên sao lưu trước (GuestBackup).
     */
    static boolean clearData(String pkg, int userId) {
        try {
            BlackBoxCore.get().clearPackage(pkg, userId);
            return true;
        } catch (Throwable t) {
            LogBuffer.e(TAG, "clearPackage failed", t);
            return false;
        }
    }

    /** Xóa CẢ không gian (mọi app + dữ liệu) — BlackBoxCore.deleteUser. KHÔNG hoàn tác được. */
    static boolean deleteSpace(int userId) {
        try {
            BlackBoxCore.get().deleteUser(userId);
            return true;
        } catch (Throwable t) {
            LogBuffer.e(TAG, "deleteUser failed", t);
            return false;
        }
    }

    /** Máy host có Google Play services để sao chép vào không gian ảo không (GmsCore chỉ SAO CHÉP gói đã cài, không tải gì từ mạng). */
    static boolean gmsSupported() {
        try {
            return BlackBoxCore.get().isSupportGms();
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean gmsInstalled(int userId) {
        try {
            return BlackBoxCore.get().isInstallGms(userId);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Sao chép Google Play services + Play Store + gói liên quan từ máy vào không gian userId (cần cho FCM/đăng nhập Google; chưa kiểm chứng). */
    static InstallOutcome installGms(int userId) {
        ensureUser(userId);
        Object result = null;
        try {
            result = BlackBoxCore.get().installGms(userId);
        } catch (Throwable t) {
            LogBuffer.e(TAG, "installGms failed", t);
        }
        return readInstallResult(result, "com.google.android.gms", userId);
    }

    static boolean uninstallGms(int userId) {
        try {
            return BlackBoxCore.get().uninstallGms(userId);
        } catch (Throwable t) {
            LogBuffer.e(TAG, "uninstallGms failed", t);
            return false;
        }
    }

    static String apiSurface() {
        StringBuilder sb = new StringBuilder();
        try {
            List<String> lines = new ArrayList<>();
            for (Method m : BlackBoxCore.class.getMethods()) {
                if (m.getDeclaringClass() == Object.class) continue;
                StringBuilder l = new StringBuilder();
                l.append(m.getReturnType().getSimpleName()).append(' ').append(m.getName()).append('(');
                Class<?>[] p = m.getParameterTypes();
                for (int i = 0; i < p.length; i++) {
                    if (i > 0) l.append(", ");
                    l.append(p[i].getSimpleName());
                }
                l.append(')');
                lines.add(l.toString());
            }
            Collections.sort(lines);
            for (String l : lines) sb.append("  ").append(l).append('\n');
        } catch (Throwable t) {
            sb.append("  (khong doc duoc: ").append(t).append(")\n");
        }
        return sb.toString();
    }

    // ---- reflection helpers ----

    private static boolean invoke(String name, String pkg, int userId) {
        try {
            Object core = BlackBoxCore.get();
            Method m = core.getClass().getMethod(name, String.class, int.class);
            m.invoke(core, pkg, userId);
            return true;
        } catch (Throwable t) {
            LogBuffer.w(TAG, name + "(String,int) unavailable: " + t);
            return false;
        }
    }

    private static boolean invokeNoUser(String name, String pkg) {
        try {
            Object core = BlackBoxCore.get();
            Method m = core.getClass().getMethod(name, String.class);
            m.invoke(core, pkg);
            return true;
        } catch (Throwable t) {
            LogBuffer.w(TAG, name + "(String) unavailable: " + t);
            return false;
        }
    }
}
