package dev.vspace.workspace;

import java.util.Locale;

/** Thứ tự sắp xếp danh sách app ảo (hàm thuần, có test). */
final class AppSort {
    static final int BY_NAME = 0;
    static final int BY_SPACE = 1;
    static final int RUNNING_FIRST = 2;
    static final int MODES = 3;

    private AppSort() {}

    static int next(int mode) {
        return (mode + 1) % MODES;
    }

    static int compare(int mode, String labelA, int spaceA, boolean runA, String labelB, int spaceB, boolean runB) {
        if (mode == RUNNING_FIRST && runA != runB) return runA ? -1 : 1;
        if (mode == BY_SPACE && spaceA != spaceB) return spaceA < spaceB ? -1 : 1;
        int c = lower(labelA).compareTo(lower(labelB));
        if (c != 0) return c;
        return spaceA == spaceB ? 0 : (spaceA < spaceB ? -1 : 1);
    }

    private static String lower(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT);
    }
}
