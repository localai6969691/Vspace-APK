package dev.vspace.workspace;

import android.content.Context;

import org.json.JSONObject;

/** Cấu hình chạy nền riêng cho từng game (theo package + không gian). */
final class GameProfile {
    /** Giữ tiến trình sống, màn hình tắt thật. Chỉ hợp với game tính toán phía server / app có socket. */
    static final int MODE_SAVER = 0;
    /** Màn hình đen + giữ màn hình bật: activity game vẫn resumed nên vòng lặp khung hình vẫn chạy. */
    static final int MODE_FAKE_OFF = 1;
    /**
     * Màn hình mờ: giữ màn hình bật + độ sáng thấp nhất ngay trên cửa sổ của game (qua hook trong tiến trình app ảo),
     * KHÔNG cần quyền overlay. Panel vẫn hiện hình game nên tiết kiệm pin ít hơn MODE_FAKE_OFF.
     */
    static final int MODE_DIM = 2;

    int mode = MODE_FAKE_OFF;
    int maxHours = 8;       // 0 = không giới hạn
    int minBattery = 15;    // % ; 0 = tắt kiểm tra
    int delaySec = 20;      // chờ bao lâu rồi mới phủ màn hình đen (để kịp vào game)
    boolean stopOnHot = true;
    boolean mute = true;
    boolean lowRefresh = true;
    boolean autoBackup;     // tự sao lưu dữ liệu game khi phiên kết thúc tự động (hết giờ/pin/nóng)
    boolean autoRestart;    // tự mở lại game nếu tiến trình của nó biến mất giữa phiên (tối đa vài lần; chưa kiểm chứng, G-8)
    boolean boost = true;   // nâng ưu tiên luồng chính/luồng render của game (xem ThreadBoost)
    boolean lowRes;         // thử nghiệm: giảm độ phân giải render của SurfaceView còn LOW_RES_PCT phần trăm
    boolean pin = true;     // ghim tiến trình của game này khi chạy nền (PinPolicy)

    /** Tỷ lệ phần trăm mỗi chiều khi bật giảm độ phân giải. */
    static final int LOW_RES_PCT = 50;

    static String key(String pkg, int userId) {
        return pkg + "." + userId;
    }

    static GameProfile load(Context c, String pkg, int userId) {
        GameProfile p = new GameProfile();
        String s = Prefs.profile(c, key(pkg, userId));
        if (s == null) return p;
        try {
            JSONObject o = new JSONObject(s);
            p.mode = o.optInt("mode", p.mode);
            p.maxHours = o.optInt("maxHours", p.maxHours);
            p.minBattery = o.optInt("minBattery", p.minBattery);
            p.delaySec = o.optInt("delaySec", p.delaySec);
            p.stopOnHot = o.optBoolean("stopOnHot", p.stopOnHot);
            p.mute = o.optBoolean("mute", p.mute);
            p.lowRefresh = o.optBoolean("lowRefresh", p.lowRefresh);
            p.autoBackup = o.optBoolean("autoBackup", p.autoBackup);
            p.autoRestart = o.optBoolean("autoRestart", p.autoRestart);
            p.boost = o.optBoolean("boost", p.boost);
            p.lowRes = o.optBoolean("lowRes", p.lowRes);
            p.pin = o.optBoolean("pin", p.pin);
        } catch (Exception ignored) {
        }
        return p;
    }

    void save(Context c, String pkg, int userId) {
        try {
            JSONObject o = new JSONObject();
            o.put("mode", mode);
            o.put("maxHours", maxHours);
            o.put("minBattery", minBattery);
            o.put("delaySec", delaySec);
            o.put("stopOnHot", stopOnHot);
            o.put("mute", mute);
            o.put("lowRefresh", lowRefresh);
            o.put("autoBackup", autoBackup);
            o.put("autoRestart", autoRestart);
            o.put("boost", boost);
            o.put("lowRes", lowRes);
            o.put("pin", pin);
            Prefs.setProfile(c, key(pkg, userId), o.toString());
        } catch (Exception ignored) {
        }
    }
}
