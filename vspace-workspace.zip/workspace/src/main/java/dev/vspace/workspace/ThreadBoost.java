package dev.vspace.workspace;

import android.os.Process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/**
 * Chạy BÊN TRONG tiến trình app ảo: nâng ưu tiên luồng chính và các luồng render/game đã biết tên.
 *
 * Lý do (tech.txt, mục "Process priority"): khi tiến trình rơi vào nhóm nền, bộ lập lịch đẩy luồng xuống cgroup background
 * (ít lõi, tần thấp). Process.setThreadPriority với mức ưu tiên cao hơn BACKGROUND đưa luồng đó ra khỏi nhóm nền ở tầng luồng.
 * Chỉ tác động tới luồng của CHÍNH tiến trình này, không cần quyền đặc biệt; không đổi được uclamp. Hiệu quả CHƯA đo trên máy thật.
 */
final class ThreadBoost {
    /** Tiền tố tên luồng (comm bị cắt còn 15 ký tự) của các engine game phổ biến. */
    private static final String[] PREFIXES = {
            "UnityMain", "UnityGfx", "GLThread", "RenderThread", "GameThread", "RHIThread", "Cocos", "UE4", "il2cpp", "Godot"
    };

    private ThreadBoost() {}

    static boolean isGameThreadName(String name) {
        if (name == null) return false;
        String n = name.trim();
        for (String p : PREFIXES) {
            if (n.startsWith(p)) return true;
        }
        return false;
    }

    /**
     * Đặt ưu tiên cho luồng chính + luồng game theo tên. Trả về số luồng đã đổi thành công.
     * @param priority ví dụ Process.THREAD_PRIORITY_DISPLAY (-4)
     */
    static int apply(int priority) {
        int changed = 0;
        try {
            Process.setThreadPriority(Process.myPid(), priority); // luồng chính có tid == pid
            changed++;
        } catch (Throwable ignored) {
        }
        try {
            String[] tids = new File("/proc/self/task").list();
            if (tids == null) return changed;
            int main = Process.myPid();
            for (String t : tids) {
                int tid;
                try {
                    tid = Integer.parseInt(t);
                } catch (NumberFormatException e) {
                    continue;
                }
                if (tid == main) continue;
                String name = readComm(tid);
                if (!isGameThreadName(name)) continue;
                try {
                    Process.setThreadPriority(tid, priority);
                    changed++;
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
        return changed;
    }

    private static String readComm(int tid) {
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/self/task/" + tid + "/comm"))) {
            return r.readLine();
        } catch (Throwable t) {
            return null;
        }
    }
}
