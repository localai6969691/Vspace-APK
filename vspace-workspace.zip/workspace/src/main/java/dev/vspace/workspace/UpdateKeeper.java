package dev.vspace.workspace;

import android.content.Context;
import android.os.StatFs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Cập nhật (ghi đè) app ảo mà GIỮ DỮ LIỆU, không phụ thuộc việc engine tự giữ hay không (tài liệu 17.2 ghi "phụ thuộc engine").
 *
 * Cách làm an toàn: dừng game -> sao lưu dữ liệu ra bản "preupdate" -> cài đè -> so dung lượng dữ liệu trước/sau;
 * nếu mất quá nửa thì tự khôi phục từ bản preupdate. Bản preupdate chỉ bị xóa khi mọi thứ ổn; nếu khôi phục lỗi thì GIỮ LẠI để người dùng tự cứu.
 * Chạy trên luồng nền. Chưa kiểm chứng trên máy thật (phụ thuộc bố cục thư mục dữ liệu G-17).
 */
final class UpdateKeeper {
    private static final String TAG = "VSpaceUpdate";

    static final class Result {
        boolean installed;
        boolean hadData;
        boolean restored;
        boolean backupSkipped;
        String error;
    }

    private UpdateKeeper() {}

    /** Dữ liệu sau khi cài còn dưới một nửa so với trước thì coi là bị engine xóa. */
    static boolean needsRestore(long before, long after, boolean installOk) {
        if (!installOk || before <= 0) return false;
        return after < before / 2;
    }

    /** Cần dư dung lượng ít nhất 1,2 lần dữ liệu để sao lưu preupdate. */
    static boolean enoughSpace(long dataBytes, long freeBytes) {
        return freeBytes >= dataBytes + dataBytes / 5;
    }

    private static long dataSize(Context c, String pkg, int space) {
        GuestBackup.Layout l = GuestBackup.locate(c, pkg, space);
        return l.data.isDirectory() ? GuestBackup.sizeOf(l.data, new int[]{200_000}) : 0;
    }

    static Result update(Context c, File apk, String pkg, int space, CharSequence label) {
        Result r = new Result();
        Engine.stop(pkg, space);
        GuestRegistry.waitUntilGone(pkg, space, 4000);

        long before = dataSize(c, pkg, space);
        File safe = null;
        if (before > 0) {
            long free = 0;
            try {
                free = new StatFs(c.getFilesDir().getAbsolutePath()).getAvailableBytes();
            } catch (Throwable ignored) {
            }
            if (!enoughSpace(before, free)) {
                r.backupSkipped = true;
            } else {
                safe = new File(c.getFilesDir(), "preupdate/" + pkg + "." + space + ".zip");
                //noinspection ResultOfMethodCallIgnored
                safe.getParentFile().mkdirs();
                try (OutputStream out = new FileOutputStream(safe)) {
                    GuestBackup.backup(c, pkg, space, label, Engine.installedVersionCode(c, pkg, space), false, out);
                    r.hadData = true;
                } catch (Throwable t) {
                    LogBuffer.w(TAG, "preupdate backup failed: " + t);
                    //noinspection ResultOfMethodCallIgnored
                    safe.delete();
                    safe = null;
                }
            }
        }

        r.installed = Engine.installApk(apk, pkg, space);

        if (safe != null) {
            long after = dataSize(c, pkg, space);
            if (needsRestore(before, after, r.installed)) {
                LogBuffer.w(TAG, "data shrank after update (" + before + " -> " + after + "), restoring " + pkg);
                try (InputStream in = new FileInputStream(safe)) {
                    GuestBackup.restore(c, in, pkg, space);
                    r.restored = true;
                } catch (Throwable t) {
                    r.error = String.valueOf(t.getMessage());
                    LogBuffer.e(TAG, "restore after update failed; keeping " + safe, t);
                    return r; // giữ file preupdate
                }
            }
            //noinspection ResultOfMethodCallIgnored
            safe.delete();
        }
        return r;
    }
}
