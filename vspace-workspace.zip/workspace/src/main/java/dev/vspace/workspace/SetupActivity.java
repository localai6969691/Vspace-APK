package dev.vspace.workspace;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/** Danh sách thiết lập lần đầu + tuyên bố phạm vi (cái gì chạy được, cái gì không hứa). */
public class SetupActivity extends Activity {
    private TextView stNotif;
    private TextView stBattery;
    private TextView stOverlay;
    private Button btNotif;
    private Button btBattery;
    private Button btOverlay;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_setup);
        stNotif = findViewById(R.id.st_notif);
        stBattery = findViewById(R.id.st_battery);
        stOverlay = findViewById(R.id.st_overlay);
        btNotif = findViewById(R.id.bt_notif);
        btBattery = findViewById(R.id.bt_battery);
        btOverlay = findViewById(R.id.bt_overlay);

        btNotif.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 33 && getApplicationInfo().targetSdkVersion >= 33) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            } else {
                try {
                    startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
                } catch (Exception e) {
                    PowerHelper.openAppDetails(this);
                }
            }
        });
        btBattery.setOnClickListener(v -> PowerHelper.requestIgnoreBatteryOptimizations(this));
        btOverlay.setOnClickListener(v -> PowerHelper.requestOverlayPermission(this));
        findViewById(R.id.bt_autostart).setOnClickListener(v -> {
            if (!PowerHelper.openAutostartSettings(this)) {
                android.widget.Toast.makeText(this, R.string.autostart_fallback, android.widget.Toast.LENGTH_LONG).show();
            }
        });
        findViewById(R.id.bt_done).setOnClickListener(v -> {
            Prefs.setSetupSeen(this, true);
            finish();
        });

        String ver = "?";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        ((TextView) findViewById(R.id.tv_about)).setText(getString(R.string.about_fmt, ver));
    }

    @Override
    protected void onResume() {
        super.onResume();
        NotificationManager nm = getSystemService(NotificationManager.class);
        show(stNotif, btNotif, nm == null || nm.areNotificationsEnabled());
        show(stBattery, btBattery, PowerHelper.isIgnoringBatteryOptimizations(this));
        show(stOverlay, btOverlay, PowerHelper.canDrawOverlays(this));
    }

    private void show(TextView status, Button button, boolean ok) {
        status.setText(ok ? R.string.setup_ok : R.string.setup_todo);
        button.setVisibility(ok ? View.GONE : View.VISIBLE);
    }
}
