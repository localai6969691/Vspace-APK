package dev.vspace.workspace;

import android.os.IBinder;
import android.os.Build;

import java.io.InputStream;
import java.lang.reflect.Method;

/**
 * Bật/tắt PANEL màn hình mà KHÔNG làm Android "ngủ", cùng kỹ thuật với `scrcpy --turn-screen-off`.
 *
 * Vì sao cần: game chạy logic theo khung hình. Nếu máy ngủ thì game thôi vẽ nên logic đứng. Nếu chỉ tắt panel (đèn/pixel)
 * còn Android vẫn coi màn hình đang bật thì game vẫn chạy bình thường (cộng đồng đã xác nhận với bot game chạy khi panel tắt).
 * `cmd display power-off` KHÔNG dùng được cho việc này vì Android thôi coi màn hình là bật.
 *
 * Chạy bằng quyền SHELL (không phải trong app): hàm ẩn SurfaceControl.setDisplayPowerMode cần quyền hệ thống.
 * Lớp này nằm sẵn trong APK nên dùng thẳng APK làm classpath, không cần dựng file .jar/.dex riêng:
 *
 *   adb shell "CLASSPATH=$(pm path dev.vspace.workspace | cut -d: -f2) app_process / dev.vspace.workspace.ScreenPower off 28800"
 *
 * Android 14+ đã chuyển hàm lấy "display token" sang DisplayControl trong services.jar (cần nạp libandroid_servers.so),
 * nên có nhánh riêng bên dưới. CHƯA kiểm chứng trên thiết bị thật trong dự án này (xem tài liệu G-18).
 *
 * An toàn: tự bật lại panel khi hết giờ, khi lệnh bị ngắt (shutdown hook), hoặc khi stdin đóng (adb mất kết nối) trừ khi có "detach".
 * Bấm nút nguồn luôn bật lại màn hình.
 */
public final class ScreenPower {
    static final int MODE_OFF = 0;
    static final int MODE_NORMAL = 2;
    static final int DEFAULT_SECONDS = 8 * 3600;
    static final int MIN_SECONDS = 10;
    static final int MAX_SECONDS = 24 * 3600;
    static final String CLASS_NAME = "dev.vspace.workspace.ScreenPower";

    private ScreenPower() {}

    // ------------------------------------------------------------------ hàm thuần (có test)

    /** Số giây từ tham số thứ 2 (sau "off"), mặc định 8 giờ, kẹp trong [10 giây, 24 giờ]. */
    static int parseSeconds(String[] args) {
        if (args.length < 2) return DEFAULT_SECONDS;
        try {
            long v = Long.parseLong(args[1].trim());
            return (int) Math.max(MIN_SECONDS, Math.min(MAX_SECONDS, v));
        } catch (NumberFormatException e) {
            return DEFAULT_SECONDS;
        }
    }

    static boolean hasFlag(String[] args, String flag) {
        for (int i = 1; i < args.length; i++) {
            if (flag.equals(args[i])) return true;
        }
        return false;
    }

    /** Lệnh adb để người dùng chạy. apkPath là đường dẫn APK của host (ApplicationInfo.sourceDir). */
    static String command(String apkPath, String action, int seconds) {
        String a = "on".equals(action) ? "on" : "off " + Math.max(MIN_SECONDS, Math.min(MAX_SECONDS, seconds));
        return "adb shell \"CLASSPATH=" + apkPath + " app_process / " + CLASS_NAME + " " + a + "\"";
    }

    // ------------------------------------------------------------------ chương trình chính (chạy bằng quyền shell)

    public static void main(String[] args) {
        if (args.length == 0 || (!"on".equals(args[0]) && !"off".equals(args[0]))) {
            System.err.println("Dung: ScreenPower on | off [giay] [detach]");
            System.exit(2);
            return;
        }
        final IBinder token;
        try {
            token = findDisplayToken();
        } catch (Throwable t) {
            System.err.println("Khong lay duoc display token: " + t);
            System.err.println("Android " + Build.VERSION.SDK_INT + ". Xem tai lieu muc G-18 de biet cach thu lai (LD_PRELOAD...).");
            System.exit(3);
            return;
        }
        if ("on".equals(args[0])) {
            System.exit(setPower(token, MODE_NORMAL) ? 0 : 4);
            return;
        }

        final int seconds = parseSeconds(args);
        final boolean detach = hasFlag(args, "detach");
        if (!setPower(token, MODE_OFF)) {
            System.exit(4);
            return;
        }
        System.out.println("Panel da TAT (Android van thuc). Tu bat lai sau " + seconds + " giay"
                + (detach ? "" : ", hoac khi dong lenh nay (Ctrl-C) / mat ket noi adb") + ". Bam nut nguon de bat ngay.");
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
                setPower(token, MODE_NORMAL);
            }
        }));
        if (!detach) {
            Thread watcher = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        InputStream in = System.in;
                        while (in.read() != -1) {
                            // bỏ qua dữ liệu; EOF = adb đóng kết nối
                        }
                    } catch (Throwable ignored) {
                    }
                    System.exit(0); // shutdown hook sẽ bật lại panel
                }
            }, "screenpower-stdin");
            watcher.setDaemon(true);
            watcher.start();
        }
        try {
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException ignored) {
        }
        System.exit(0);
    }

    // ------------------------------------------------------------------ hàm ẩn của hệ thống (reflection)

    private static boolean setPower(IBinder token, int mode) {
        try {
            Class<?> sc = Class.forName("android.view.SurfaceControl");
            Method m = sc.getMethod("setDisplayPowerMode", IBinder.class, int.class);
            m.invoke(null, token, mode);
            return true;
        } catch (Throwable t) {
            System.err.println("setDisplayPowerMode that bai: " + t);
            return false;
        }
    }

    private static IBinder findDisplayToken() throws Exception {
        Class<?> sc = Class.forName("android.view.SurfaceControl");
        int sdk = Build.VERSION.SDK_INT;
        if (sdk >= 34) {
            Class<?> dc = loadDisplayControl();
            long[] ids = (long[]) dc.getMethod("getPhysicalDisplayIds").invoke(null);
            if (ids == null || ids.length == 0) throw new IllegalStateException("khong co physical display");
            return (IBinder) dc.getMethod("getPhysicalDisplayToken", long.class).invoke(null, ids[0]);
        }
        if (sdk >= 29) {
            long[] ids = (long[]) sc.getMethod("getPhysicalDisplayIds").invoke(null);
            if (ids == null || ids.length == 0) throw new IllegalStateException("khong co physical display");
            return (IBinder) sc.getMethod("getPhysicalDisplayToken", long.class).invoke(null, ids[0]);
        }
        return (IBinder) sc.getMethod("getBuiltInDisplay", int.class).invoke(null, 0);
    }

    /** Android 14+: nạp DisplayControl từ services.jar rồi nạp libandroid_servers.so (như scrcpy). Thử 2 cách. */
    private static Class<?> loadDisplayControl() throws Exception {
        Throwable first = null;
        try {
            Class<?> factory = Class.forName("com.android.internal.os.ClassLoaderFactory");
            Method create = factory.getDeclaredMethod("createClassLoader", String.class, String.class, String.class,
                    ClassLoader.class, int.class, boolean.class, String.class);
            ClassLoader cl = (ClassLoader) create.invoke(null, "/system/framework/services.jar", null, null,
                    ClassLoader.getSystemClassLoader(), 0, true, null);
            return nativeReady(cl.loadClass("com.android.server.display.DisplayControl"));
        } catch (Throwable t) {
            first = t;
            System.err.println("Cach 1 (ClassLoaderFactory) that bai: " + t);
        }
        try {
            String cp = System.getenv("SYSTEMSERVERCLASSPATH");
            if (cp == null || cp.isEmpty()) cp = "/system/framework/services.jar";
            ClassLoader cl = (ClassLoader) Class.forName("dalvik.system.PathClassLoader")
                    .getConstructor(String.class, ClassLoader.class).newInstance(cp, ClassLoader.getSystemClassLoader());
            return nativeReady(cl.loadClass("com.android.server.display.DisplayControl"));
        } catch (Throwable t) {
            System.err.println("Cach 2 (PathClassLoader) that bai: " + t);
            if (first != null) t.addSuppressed(first);
            throw new Exception(t);
        }
    }

    private static Class<?> nativeReady(Class<?> displayControl) throws Exception {
        Method load = Runtime.class.getDeclaredMethod("loadLibrary0", Class.class, String.class);
        load.setAccessible(true);
        load.invoke(Runtime.getRuntime(), displayControl, "android_servers");
        return displayControl;
    }
}
