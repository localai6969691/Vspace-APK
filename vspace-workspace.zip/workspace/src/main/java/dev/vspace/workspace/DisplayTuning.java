package dev.vspace.workspace;

import android.content.Context;
import android.view.Display;
import android.view.WindowManager;

/**
 * Giảm tải GPU/panel khi chạy nền: chọn chế độ hiển thị tần số thấp (preferredDisplayModeId) và tính kích thước render giảm độ phân giải.
 *
 * Bản đánh giá bên ngoài nhấn mạnh "không giảm tần số quét thì chế độ màn hình đen vô nghĩa về pin". `preferredRefreshRate` chỉ là gợi ý
 * và nhiều ROM bỏ qua; chọn đúng mã chế độ (Display.Mode) cùng độ phân giải nhưng tần số thấp nhất ≥ mục tiêu thường được tôn trọng hơn.
 * Cả hai đều CHƯA kiểm chứng trên máy thật.
 */
final class DisplayTuning {
    /** Kích thước tối thiểu một cạnh khi giảm độ phân giải (tránh game vỡ hình). */
    static final int MIN_SIDE = 320;
    static final int MIN_PCT = 25;
    static final int MAX_PCT = 100;

    private DisplayTuning() {}

    // ------------------------------------------------------------------ hàm thuần (có test)

    /**
     * Trong các chế độ cùng độ phân giải với chế độ hiện tại, chọn chế độ có tần số thấp nhất mà vẫn ≥ targetHz.
     * @return mã chế độ cần đặt, hoặc 0 nếu không tìm được / không cần đổi (đã là chế độ thấp nhất đạt yêu cầu).
     */
    static int pickModeId(int[] ids, float[] rates, int[] widths, int[] heights, int curId, float targetHz) {
        int n = Math.min(Math.min(ids.length, rates.length), Math.min(widths.length, heights.length));
        int cur = -1;
        for (int i = 0; i < n; i++) {
            if (ids[i] == curId) {
                cur = i;
                break;
            }
        }
        if (cur < 0) return 0;
        int best = -1;
        for (int i = 0; i < n; i++) {
            if (widths[i] != widths[cur] || heights[i] != heights[cur]) continue;
            if (rates[i] + 0.5f < targetHz) continue;
            if (best < 0 || rates[i] < rates[best] - 0.01f || (Math.abs(rates[i] - rates[best]) <= 0.01f && ids[i] < ids[best])) {
                best = i;
            }
        }
        if (best < 0 || ids[best] == curId) return 0;
        return ids[best];
    }

    /** Kích thước render sau khi giảm còn pct phần trăm mỗi chiều; số chẵn; không nhỏ hơn MIN_SIDE; không phóng to. */
    static int[] scaledSize(int w, int h, int pct) {
        if (w <= 0 || h <= 0) return new int[]{w, h};
        int p = Math.max(MIN_PCT, Math.min(MAX_PCT, pct));
        int w2 = side(w, p);
        int h2 = side(h, p);
        return new int[]{w2, h2};
    }

    private static int side(int v, int pct) {
        int s = (v * pct / 100) & ~1;
        s = Math.max(s, Math.min(v, MIN_SIDE));
        return Math.min(s, v);
    }

    // ------------------------------------------------------------------ đọc màn hình thật

    /** @return mã Display.Mode nên đặt vào WindowManager.LayoutParams.preferredDisplayModeId, hoặc 0 nếu không cần/không biết. */
    @SuppressWarnings("deprecation")
    static int lowRefreshModeId(Context c, float targetHz) {
        try {
            WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
            Display d = wm.getDefaultDisplay();
            Display.Mode[] modes = d.getSupportedModes();
            int n = modes.length;
            int[] ids = new int[n];
            float[] rates = new float[n];
            int[] ws = new int[n];
            int[] hs = new int[n];
            for (int i = 0; i < n; i++) {
                ids[i] = modes[i].getModeId();
                rates[i] = modes[i].getRefreshRate();
                ws[i] = modes[i].getPhysicalWidth();
                hs[i] = modes[i].getPhysicalHeight();
            }
            return pickModeId(ids, rates, ws, hs, d.getMode().getModeId(), targetHz);
        } catch (Throwable t) {
            return 0;
        }
    }
}
