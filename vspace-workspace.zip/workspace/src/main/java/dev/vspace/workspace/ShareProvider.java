package dev.vspace.workspace;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;

/**
 * Chia sẻ báo cáo/log ra ứng dụng khác (email, Drive, chat…) mà không cần thư viện FileProvider.
 * Chỉ phục vụ file nằm trực tiếp trong cache/share (chặn path traversal).
 */
public class ShareProvider extends ContentProvider {

    static File dir(Context c) {
        File d = new File(c.getCacheDir(), "share");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    static String authority(Context c) {
        return c.getPackageName() + ".share";
    }

    /** Ghi nội dung văn bản ra file chia sẻ được; xóa bớt file cũ. */
    static Uri write(Context c, String name, String content) throws java.io.IOException {
        File d = dir(c);
        File[] old = d.listFiles();
        if (old != null && old.length > 8) {
            for (File f : old) //noinspection ResultOfMethodCallIgnored
                f.delete();
        }
        File f = new File(d, name);
        try (FileWriter w = new FileWriter(f, false)) {
            w.write(content);
        }
        return Uri.parse("content://" + authority(c) + "/" + Uri.encode(name));
    }

    /** Uri content:// của một tệp đã nằm sẵn trong cache/share (ví dụ APK cập nhật vừa tải). */
    static Uri uriFor(Context c, String name) {
        return Uri.parse("content://" + authority(c) + "/" + Uri.encode(name));
    }

    private File resolve(Uri uri) throws FileNotFoundException {
        String name = uri.getLastPathSegment();
        if (name == null || name.contains("/") || name.contains("\\") || name.contains("..")) {
            throw new FileNotFoundException("bad name");
        }
        File f = new File(dir(getContext()), name);
        if (!f.isFile()) throw new FileNotFoundException(name);
        return f;
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        try {
            File f = resolve(uri);
            MatrixCursor c = new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE});
            c.addRow(new Object[]{f.getName(), f.length()});
            return c;
        } catch (FileNotFoundException e) {
            return null;
        }
    }

    @Override
    public String getType(Uri uri) {
        String n = uri.getLastPathSegment();
        return n != null && n.endsWith(".apk") ? "application/vnd.android.package-archive" : "text/plain";
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
