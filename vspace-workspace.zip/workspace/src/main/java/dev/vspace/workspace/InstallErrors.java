package dev.vspace.workspace;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Phân loại thông báo lỗi cài đặt của engine (InstallResult.msg / mã INSTALL_FAILED_*) thành nhóm người dùng hiểu được.
 * Hàm thuần, có test. Việc đổi nhóm -> chuỗi hiển thị nằm ở MainActivity (cần R).
 * Thứ tự kiểm tra QUAN TRỌNG: nhóm cụ thể trước, nhóm chung (parse) sau.
 */
final class InstallErrors {
    enum Kind { NO_SPACE, ABI, SIGNATURE, DOWNGRADE, ALREADY, SDK, PARSE, UNKNOWN }

    private static final Pattern ABI = Pattern.compile("\\babi\\b|no_matching_abis|native (code|lib)|unsatisfiedlink|armeabi|arm64|x86");
    private static final Pattern SPACE = Pattern.compile("enospc|no space|insufficient[_ ]storage|not enough (space|storage)|dung lượng");
    private static final Pattern SIG = Pattern.compile("signature|certificate|update_incompatible|inconsistent_certificates|no_certificates");
    private static final Pattern DOWN = Pattern.compile("downgrade|version_downgrade");
    private static final Pattern EXISTS = Pattern.compile("already[_ ]exists?|duplicate_package|already installed");
    private static final Pattern SDK = Pattern.compile("min_?sdk|older_sdk|newer_sdk|sdk_version|requires.*sdk|target_?sdk");
    private static final Pattern PARSE = Pattern.compile("parse|manifest|corrupt|malformed|invalid[_ ]apk|not a zip|zip|bad_manifest|no_classes");

    private InstallErrors() {}

    static Kind classify(String msg) {
        if (msg == null) return Kind.UNKNOWN;
        String m = msg.trim().toLowerCase(Locale.ROOT);
        if (m.isEmpty()) return Kind.UNKNOWN;
        if (SPACE.matcher(m).find()) return Kind.NO_SPACE;
        if (ABI.matcher(m).find()) return Kind.ABI;
        if (SIG.matcher(m).find()) return Kind.SIGNATURE;
        if (DOWN.matcher(m).find()) return Kind.DOWNGRADE;
        if (EXISTS.matcher(m).find()) return Kind.ALREADY;
        if (SDK.matcher(m).find()) return Kind.SDK;
        if (PARSE.matcher(m).find()) return Kind.PARSE;
        return Kind.UNKNOWN;
    }

    /** Rút gọn thông báo gốc để kèm vào toast khi không phân loại được (tối đa n ký tự, một dòng). */
    static String shorten(String msg, int n) {
        if (msg == null) return "";
        String s = msg.replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() <= n ? s : s.substring(0, n) + "…";
    }
}
