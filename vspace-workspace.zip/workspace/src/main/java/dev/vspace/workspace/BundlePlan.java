package dev.vspace.workspace;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Phân loại các mục trong gói XAPK/APKS/APKM (hàm thuần, có test).
 *
 * Cấu trúc XAPK đã xác nhận qua tài liệu cộng đồng: một ZIP gồm base.apk (hoặc tên gói .apk), các split_config.*.apk,
 * thư mục Android/obb/<gói>/*.obb và manifest.json. APKS/APKM chỉ có các APK.
 */
final class BundlePlan {

    static final class Plan {
        /** Tên các mục .apk (cả APK gốc lẫn split). */
        final List<String> apks = new ArrayList<>();
        /** Số mục là APK gốc (không phải split). */
        int baseCount;
        /** Có ít nhất một split (config.*, split_*, split_config.*). */
        boolean split;
        /** Các mục .obb (tên đầy đủ trong zip). */
        final List<String> obbs = new ArrayList<>();
    }

    private BundlePlan() {}

    /** @param lowerBaseName tên file (không đường dẫn), đã chữ thường */
    static boolean isSplitName(String lowerBaseName) {
        return lowerBaseName.startsWith("config.") || lowerBaseName.startsWith("split_") || lowerBaseName.contains("split_config");
    }

    static String baseName(String entry) {
        int i = Math.max(entry.lastIndexOf('/'), entry.lastIndexOf('\\'));
        return i >= 0 ? entry.substring(i + 1) : entry;
    }

    static Plan plan(List<String> entryNames) {
        Plan p = new Plan();
        for (String name : entryNames) {
            if (name == null || name.endsWith("/")) continue;
            String lower = name.toLowerCase(Locale.ROOT);
            String base = baseName(lower);
            if (lower.endsWith(".apk")) {
                p.apks.add(name);
                if (isSplitName(base)) p.split = true;
                else p.baseCount++;
            } else if (lower.endsWith(".obb") && isSafeObbName(baseName(name))) {
                p.obbs.add(name);
            }
        }
        return p;
    }

    /** Tên file OBB hợp lệ: không rỗng, không chứa dấu gạch chéo/`..`/ký tự điều khiển (chống ghi ra ngoài thư mục đích). */
    static boolean isSafeObbName(String base) {
        if (base == null || base.isEmpty() || base.equals(".") || base.equals("..") || base.contains("..")) return false;
        for (int i = 0; i < base.length(); i++) {
            char ch = base.charAt(i);
            if (ch < 0x20 || ch == '/' || ch == '\\' || ch == ':') return false;
        }
        return true;
    }

    /** Đường dẫn (tương đối với gốc ảo của engine) của thư mục OBB của một app trong một không gian. */
    static String obbDirRel(String pkg, int userId) {
        return "storage/emulated/" + userId + "/Android/obb/" + pkg;
    }
}
