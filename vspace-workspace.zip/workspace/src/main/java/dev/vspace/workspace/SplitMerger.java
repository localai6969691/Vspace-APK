package dev.vspace.workspace;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;

/**
 * Ghép gói split (XAPK/APKS/APKM) thành MỘT APK đơn bằng APKEditor của REAndroid (Apache-2.0, lệnh "m" = merge), gọi qua reflection.
 *
 * Vì sao reflection: thư viện là TÙY CHỌN (CI tải jar APKEditor vào workspace/libs; không có jar thì build vẫn xanh và tính năng báo "chưa có").
 * Đường nhúng com.reandroid.apkeditor.Main.execute(String[]) (khác main(), không gọi System.exit) — XÁC NHẬN bằng javap trên
 * jar thật REAndroid/APKEditor tag V1.4.9 ở phiên 5 (trước đó chỉ dựa theo tài liệu/README của APKEditor, chưa đọc bytecode
 * thật): Main có cả main(String[]) lẫn execute(String[]) tách riêng, đúng như giả định. sha256 của jar V1.4.9 đã tải và tính
 * trong phiên 5: a9cd40df818845456be6d696de6110c89edf4b0a0580cb83438ed6b25a366e67 — có thể dán vào repository variables
 * APKEDITOR_TAG=V1.4.9 / APKEDITOR_SHA256 ở trên để CI ghim đúng bản đã xác minh (P1-1 áp dụng cho cả phụ thuộc này, không
 * chỉ core).
 *
 * KHÔNG kiểm chứng được trong sandbox: (1) jar chạy được trên Android (javap chỉ xác nhận chữ ký, không chạy được vì không
 * có Android SDK/thiết bị ở đây); (2) ~~engine chịu APK ghép chưa ký~~ — ĐÃ TRẢ LỜI (phiên 7, đọc source lõi): engine KHÔNG chịu APK chưa ký (parserApk gọi collectCertificates), nên APK ghép phải đi qua ApkSigner [O-12]; còn lại chỉ là: PackageParser thật có chấp nhận chữ ký v2 đó không [G-33].
 * Kết quả luôn được kiểm bằng chính file đầu ra (tồn tại, đúng chữ ký ZIP), không tin mã trả về.
 */
final class SplitMerger {
    static final String MAIN_CLASS = "com.reandroid.apkeditor.Main";
    private static final String TAG = "VSpaceMerge";

    private SplitMerger() {}

    /** Có jar APKEditor trong APK này không. */
    static boolean available() {
        try {
            Class.forName(MAIN_CLASS);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Tham số lệnh merge của APKEditor: m -i <vào> -o <ra>. */
    static String[] args(File in, File out) {
        return new String[]{"m", "-i", in.getAbsolutePath(), "-o", out.getAbsolutePath()};
    }

    /** File có vẻ là APK/ZIP hợp lệ: đủ lớn và bắt đầu bằng "PK\3\4". */
    static boolean looksLikeApk(File f) {
        if (f == null || !f.isFile() || f.length() < 1024) return false;
        try (InputStream in = new FileInputStream(f)) {
            byte[] h = new byte[4];
            return in.read(h) == 4 && h[0] == 'P' && h[1] == 'K' && h[2] == 3 && h[3] == 4;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Ghép `in` (zip xapk/apks/apkm) thành `out`. Chạy trên luồng nền (có thể mất hàng chục giây và nhiều RAM với app lớn).
     * @return true nếu `out` là APK hợp lệ sau khi chạy
     */
    static boolean merge(File in, File out) {
        //noinspection ResultOfMethodCallIgnored
        out.delete();
        try {
            Class<?> c = Class.forName(MAIN_CLASS);
            Method m = c.getMethod("execute", String[].class);
            Object rc = m.invoke(null, (Object) args(in, out));
            LogBuffer.i(TAG, "APKEditor execute returned " + rc);
        } catch (Throwable t) {
            Throwable cause = t.getCause() != null ? t.getCause() : t;
            LogBuffer.w(TAG, "merge failed: " + cause);
            return false;
        }
        boolean ok = looksLikeApk(out);
        if (!ok) {
            LogBuffer.w(TAG, "merge produced no valid APK at " + out);
            //noinspection ResultOfMethodCallIgnored
            out.delete();
        }
        return ok;
    }
}
