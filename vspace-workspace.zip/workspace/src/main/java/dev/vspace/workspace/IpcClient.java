package dev.vspace.workspace;

import android.net.LocalSocket;
import android.net.LocalSocketAddress;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;

/** Phía app ảo (tiến trình :pN): kết nối tới IpcServer, gửi "hello", nhận lệnh; tự nối lại nếu tiến trình chính khởi động lại. */
final class IpcClient {

    interface CommandHandler {
        void onCommand(JSONObject cmd);
    }

    private final String socketName;
    private final String hello;
    private final CommandHandler handler;
    private volatile LocalSocket socket;

    IpcClient(String socketName, JSONObject hello, CommandHandler handler) {
        this.socketName = socketName;
        this.hello = hello.toString();
        this.handler = handler;
    }

    void start() {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                loop();
            }
        }, "vspace-ipc-client");
        t.setDaemon(true);
        t.start();
    }

    private void loop() {
        long backoff = 1000;
        while (true) {
            try {
                LocalSocket s = new LocalSocket();
                s.connect(new LocalSocketAddress(socketName, LocalSocketAddress.Namespace.ABSTRACT));
                socket = s;
                backoff = 1000;
                send(hello);
                BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
                String line;
                while ((line = br.readLine()) != null) {
                    try {
                        handler.onCommand(new JSONObject(line));
                    } catch (Throwable ignored) {
                    }
                }
            } catch (Throwable ignored) {
                // tiến trình chính chưa chạy hoặc đã chết: thử lại
            }
            socket = null;
            try {
                Thread.sleep(backoff);
            } catch (InterruptedException e) {
                return;
            }
            backoff = Math.min(backoff * 2, 15000);
        }
    }

    synchronized void send(String line) {
        LocalSocket s = socket;
        if (s == null) return;
        try {
            OutputStream o = s.getOutputStream();
            o.write((line + "\n").getBytes("UTF-8"));
            o.flush();
        } catch (Throwable ignored) {
        }
    }
}
