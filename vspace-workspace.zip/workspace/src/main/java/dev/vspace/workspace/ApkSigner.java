package dev.vspace.workspace;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;

/**
 * Ký APK theo APK Signature Scheme v2, bằng Java thuần (chỉ java.*, nên chạy được cả trên JVM để kiểm bằng apksigner thật).
 *
 * VÌ SAO CẦN: core (NewBlackbox) gọi PackageParser.collectCertificates() khi cài (BPackageManagerService.parserApk, đọc từ
 * source thật, SHA 89b5983) và coi lỗi là "parser apk error". APK ghép từ split bằng APKEditor KHÔNG có chữ ký, nên bị core
 * từ chối (G-30 — phiên 7 đọc source và kết luận; trước đó chỉ là nghi ngờ). Với app targetSdk >= 30 hệ thống còn đòi ít nhất
 * scheme v2, nên chữ ký v1 (jar) là không đủ — vì thế viết v2.
 *
 * Khoá: sinh MỘT LẦN trên chính máy người dùng (RSA 2048, chứng chỉ tự ký dựng tay bằng DER), lưu trong bộ nhớ riêng của app.
 * KHÔNG có khoá/chứng chỉ nào nằm trong repo (AGENTS.md mục 17). Ý nghĩa chữ ký: chỉ để bộ phân tích gói của engine chấp nhận
 * APK đã ghép; nó KHÔNG chứng minh nguồn gốc của app. App ảo tự kiểm chữ ký của chính nó (anti-tamper, Play Integrity,
 * Firebase/Maps theo SHA) sẽ thấy chữ ký KHÁC bản gốc — giới hạn không tránh được khi ghép split.
 *
 * Giới hạn: không hỗ trợ ZIP64 (APK > 4 GB); không thêm padding 4096 của apksigner (hệ thống không bắt buộc).
 */
final class ApkSigner {
    static final int ALG_RSA_PKCS1_SHA256 = 0x0103;
    static final int V2_BLOCK_ID = 0x7109871a;
    static final byte[] MAGIC = "APK Sig Block 42".getBytes(Charset.forName("US-ASCII"));
    static final int CHUNK = 1024 * 1024;

    private static final long EOCD_SIG = 0x06054b50L;

    private ApkSigner() {}

    /** Khoá + chứng chỉ dùng để ký. */
    static final class Signer {
        final PrivateKey key;
        final byte[] certDer;
        final byte[] spki;

        Signer(PrivateKey key, byte[] certDer, byte[] spki) {
            this.key = key;
            this.certDer = certDer;
            this.spki = spki;
        }
    }

    // ------------------------------------------------------------------ khoá

    /** Đọc khoá đã lưu trong dir (key.pk8 + cert.der) hoặc sinh mới. */
    static Signer loadOrCreate(File dir) throws Exception {
        File kf = new File(dir, "key.pk8");
        File cf = new File(dir, "cert.der");
        if (kf.isFile() && cf.isFile()) {
            try {
                return fromFiles(kf, cf);
            } catch (Exception broken) {
                // file hỏng: sinh lại bên dưới
            }
        }
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048, new SecureRandom());
        KeyPair kp = g.generateKeyPair();
        byte[] cert = selfSignedCert(kp);
        writeAtomic(kf, kp.getPrivate().getEncoded());
        writeAtomic(cf, cert);
        return fromFiles(kf, cf);
    }

    private static Signer fromFiles(File kf, File cf) throws Exception {
        byte[] pk8 = readAll(kf);
        byte[] cert = readAll(cf);
        PrivateKey key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(pk8));
        X509Certificate x = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new java.io.ByteArrayInputStream(cert));
        return new Signer(key, cert, x.getPublicKey().getEncoded());
    }

    private static void writeAtomic(File f, byte[] data) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) {
            o.write(data);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
        if (!tmp.renameTo(f)) throw new IOException("không ghi được " + f);
    }

    private static byte[] readAll(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        }
    }

    // ------------------------------------------------------------------ DER tối thiểu (chứng chỉ X.509 tự ký)

    static byte[] derLen(int n) {
        if (n < 0x80) return new byte[]{(byte) n};
        if (n <= 0xff) return new byte[]{(byte) 0x81, (byte) n};
        if (n <= 0xffff) return new byte[]{(byte) 0x82, (byte) (n >> 8), (byte) n};
        return new byte[]{(byte) 0x83, (byte) (n >> 16), (byte) (n >> 8), (byte) n};
    }

    static byte[] der(int tag, byte[]... parts) {
        int len = 0;
        for (byte[] p : parts) len += p.length;
        byte[] l = derLen(len);
        byte[] out = new byte[1 + l.length + len];
        out[0] = (byte) tag;
        System.arraycopy(l, 0, out, 1, l.length);
        int o = 1 + l.length;
        for (byte[] p : parts) {
            System.arraycopy(p, 0, out, o, p.length);
            o += p.length;
        }
        return out;
    }

    private static final byte[] OID_SHA256_RSA = {0x2A, (byte) 0x86, 0x48, (byte) 0x86, (byte) 0xF7, 0x0D, 0x01, 0x01, 0x0B};
    private static final byte[] OID_CN = {0x55, 0x04, 0x03};

    static byte[] selfSignedCert(KeyPair kp) throws Exception {
        byte[] sigAlg = der(0x30, der(0x06, OID_SHA256_RSA), der(0x05));
        byte[] name = der(0x30, der(0x31, der(0x30, der(0x06, OID_CN),
                der(0x0C, "VSpace merge signer".getBytes(Charset.forName("UTF-8"))))));
        byte[] validity = der(0x30,
                der(0x17, "200101000000Z".getBytes(Charset.forName("US-ASCII"))),
                der(0x18, "20700101000000Z".getBytes(Charset.forName("US-ASCII"))));
        byte[] serialBytes = new byte[8];
        new SecureRandom().nextBytes(serialBytes);
        serialBytes[0] &= 0x7f;     // số dương
        serialBytes[0] |= 0x40;     // byte đầu khác 0 → mã hóa INTEGER gọn, không cần đệm
        byte[] tbs = der(0x30,
                der(0xA0, der(0x02, new byte[]{2})),   // version v3
                der(0x02, serialBytes),
                sigAlg, name, validity, name,
                kp.getPublic().getEncoded());
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(kp.getPrivate());
        s.update(tbs);
        byte[] sig = s.sign();
        byte[] bits = new byte[sig.length + 1];
        System.arraycopy(sig, 0, bits, 1, sig.length);
        return der(0x30, tbs, sigAlg, der(0x03, bits));
    }

    // ------------------------------------------------------------------ byte helpers

    static byte[] u32(long v) {
        return new byte[]{(byte) v, (byte) (v >> 8), (byte) (v >> 16), (byte) (v >> 24)};
    }

    static byte[] u64(long v) {
        return new byte[]{(byte) v, (byte) (v >> 8), (byte) (v >> 16), (byte) (v >> 24),
                (byte) (v >> 32), (byte) (v >> 40), (byte) (v >> 48), (byte) (v >> 56)};
    }

    static byte[] lenPrefixed(byte[] b) {
        return concat(u32(b.length), b);
    }

    static byte[] concat(byte[]... parts) {
        int n = 0;
        for (byte[] p : parts) n += p.length;
        byte[] out = new byte[n];
        int o = 0;
        for (byte[] p : parts) {
            System.arraycopy(p, 0, out, o, p.length);
            o += p.length;
        }
        return out;
    }

    static long readU32(byte[] b, int off) {
        return (b[off] & 0xffL) | ((b[off + 1] & 0xffL) << 8) | ((b[off + 2] & 0xffL) << 16) | ((b[off + 3] & 0xffL) << 24);
    }

    static long readU64(byte[] b, int off) {
        return readU32(b, off) | (readU32(b, off + 4) << 32);
    }

    // ------------------------------------------------------------------ ZIP

    /** Vị trí và nội dung các phần của một APK/ZIP cần cho việc ký. */
    static final class Layout {
        long eocdOffset;
        long cdOffset;
        long cdSize;
        /** Vị trí kết thúc phần nội dung các mục (= đầu khối chữ ký cũ nếu có, hoặc = cdOffset). */
        long entriesEnd;
        long oldBlockSize;
    }

    static Layout locate(RandomAccessFile raf) throws IOException {
        long len = raf.length();
        if (len < 22) throw new IOException("không phải ZIP/APK");
        int tail = (int) Math.min(len, 22 + 65535);
        byte[] t = new byte[tail];
        raf.seek(len - tail);
        raf.readFully(t);
        int pos = -1;
        for (int i = tail - 22; i >= 0; i--) {
            if (readU32(t, i) == EOCD_SIG) {
                int commentLen = (t[i + 20] & 0xff) | ((t[i + 21] & 0xff) << 8);
                if (i + 22 + commentLen == tail) {
                    pos = i;
                    break;
                }
            }
        }
        if (pos < 0) throw new IOException("không thấy EOCD (không phải ZIP)");
        Layout l = new Layout();
        l.eocdOffset = len - tail + pos;
        l.cdSize = readU32(t, pos + 12);
        l.cdOffset = readU32(t, pos + 16);
        if (l.cdSize == 0xffffffffL || l.cdOffset == 0xffffffffL) throw new IOException("ZIP64 chưa hỗ trợ");
        if (l.cdOffset + l.cdSize != l.eocdOffset) throw new IOException("ZIP không nhất quán (CD/EOCD)");
        if (l.cdSize > Integer.MAX_VALUE - 1024) throw new IOException("central directory quá lớn");
        l.entriesEnd = l.cdOffset;
        // Đã có khối chữ ký → bỏ đi (ký lại)
        if (l.cdOffset >= 32) {
            byte[] m = new byte[16];
            raf.seek(l.cdOffset - 16);
            raf.readFully(m);
            if (Arrays.equals(m, MAGIC)) {
                byte[] sz = new byte[8];
                raf.seek(l.cdOffset - 24);
                raf.readFully(sz);
                long size = readU64(sz, 0);
                long total = size + 8;
                if (size >= 24 && total <= l.cdOffset) {
                    l.oldBlockSize = total;
                    l.entriesEnd = l.cdOffset - total;
                }
            }
        }
        return l;
    }

    // ------------------------------------------------------------------ digest + khối chữ ký

    /** Digest toàn APK theo v2: băm từng đoạn 1 MiB của (mục, central directory, EOCD đã sửa offset). */
    static byte[] contentDigest(RandomAccessFile raf, long entriesEnd, byte[] cd, byte[] eocdForDigest) throws Exception {
        ByteArrayOutputStream chunkDigests = new ByteArrayOutputStream();
        int count = 0;
        byte[] buf = new byte[CHUNK];
        long pos = 0;
        raf.seek(0);
        while (pos < entriesEnd) {
            int n = (int) Math.min(CHUNK, entriesEnd - pos);
            raf.readFully(buf, 0, n);
            chunkDigests.write(chunkDigest(buf, n));
            count++;
            pos += n;
        }
        for (byte[] section : new byte[][]{cd, eocdForDigest}) {
            for (int off = 0; off < section.length; off += CHUNK) {
                int n = Math.min(CHUNK, section.length - off);
                chunkDigests.write(chunkDigest(Arrays.copyOfRange(section, off, off + n), n));
                count++;
            }
        }
        MessageDigest top = MessageDigest.getInstance("SHA-256");
        top.update((byte) 0x5a);
        top.update(u32(count));
        top.update(chunkDigests.toByteArray());
        return top.digest();
    }

    private static byte[] chunkDigest(byte[] data, int n) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update((byte) 0xa5);
        md.update(u32(n));
        md.update(data, 0, n);
        return md.digest();
    }

    static byte[] buildSigningBlock(Signer s, byte[] contentDigest) throws Exception {
        byte[] digestRecord = lenPrefixed(concat(u32(ALG_RSA_PKCS1_SHA256), lenPrefixed(contentDigest)));
        byte[] digests = lenPrefixed(digestRecord);
        byte[] certs = lenPrefixed(lenPrefixed(s.certDer));
        byte[] attrs = lenPrefixed(new byte[0]);
        byte[] signedData = concat(digests, certs, attrs);

        Signature sg = Signature.getInstance("SHA256withRSA");
        sg.initSign(s.key);
        sg.update(signedData);
        byte[] sig = sg.sign();

        byte[] sigRecord = lenPrefixed(concat(u32(ALG_RSA_PKCS1_SHA256), lenPrefixed(sig)));
        byte[] signatures = lenPrefixed(sigRecord);
        byte[] signer = concat(lenPrefixed(signedData), signatures, lenPrefixed(s.spki));
        byte[] signers = lenPrefixed(lenPrefixed(signer));

        byte[] pair = concat(u64(4L + signers.length), u32(V2_BLOCK_ID), signers);
        long sizeField = pair.length + 8L + 16L;
        return concat(u64(sizeField), pair, u64(sizeField), MAGIC);
    }

    // ------------------------------------------------------------------ ký

    /** Ký `in` thành `out` (hai file khác nhau). */
    static void sign(File in, File out, Signer s) throws Exception {
        try (RandomAccessFile raf = new RandomAccessFile(in, "r")) {
            Layout l = locate(raf);
            byte[] cd = new byte[(int) l.cdSize];
            raf.seek(l.cdOffset);
            raf.readFully(cd);
            byte[] eocd = new byte[(int) (raf.length() - l.eocdOffset)];
            raf.seek(l.eocdOffset);
            raf.readFully(eocd);

            byte[] eocdForDigest = eocd.clone();
            System.arraycopy(u32(l.entriesEnd), 0, eocdForDigest, 16, 4);
            byte[] digest = contentDigest(raf, l.entriesEnd, cd, eocdForDigest);
            byte[] block = buildSigningBlock(s, digest);

            byte[] eocdOut = eocd.clone();
            System.arraycopy(u32(l.entriesEnd + block.length), 0, eocdOut, 16, 4);

            try (FileOutputStream fo = new FileOutputStream(out)) {
                byte[] buf = new byte[64 * 1024];
                raf.seek(0);
                long left = l.entriesEnd;
                while (left > 0) {
                    int n = (int) Math.min(buf.length, left);
                    raf.readFully(buf, 0, n);
                    fo.write(buf, 0, n);
                    left -= n;
                }
                fo.write(block);
                fo.write(cd);
                fo.write(eocdOut);
            }
        }
    }

    /**
     * Ký tại chỗ (qua file tạm rồi thay thế). Khoá lấy/sinh trong keyDir.
     * @return null nếu thành công, ngược lại là thông báo lỗi (để người gọi ghi log).
     */
    static String signInPlace(File apk, File keyDir) {
        File tmp = new File(apk.getPath() + ".signed");
        try {
            Signer s = loadOrCreate(keyDir);
            sign(apk, tmp, s);
            //noinspection ResultOfMethodCallIgnored
            apk.delete();
            if (!tmp.renameTo(apk)) return "không thay được file đã ký";
            return null;
        } catch (Throwable t) {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
            return String.valueOf(t);
        }
    }
}
