package dev.vspace.workspace;

import android.os.Process;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Sổ đăng ký các tiến trình app ảo đang sống (pid → gói/không gian), do tiến trình chính giữ.
 * Dữ liệu đến từ kênh IPC (IpcServer) khi app ảo khởi động và gửi "hello". Nhờ đó biết CHÍNH XÁC game nào ở tiến trình :pN nào,
 * thay vì phải đoán theo tên tiến trình.
 */
final class GuestRegistry {

    static final class Info {
        final int pid;
        final String pkg;
        final String proc;
        final int user;
        volatile boolean resumed;
        volatile String lastCls = "";
        volatile long lastEventAt;
        volatile IpcServer.Conn conn;

        Info(int pid, String pkg, String proc, int user) {
            this.pid = pid;
            this.pkg = pkg;
            this.proc = proc;
            this.user = user;
            this.lastEventAt = System.currentTimeMillis();
        }
    }

    private static final Map<Integer, Info> MAP = new ConcurrentHashMap<>();
    /** Kết quả lệnh PiP gần nhất do app ảo báo về (để Chẩn đoán hiển thị). */
    static volatile String lastPipResult = "";
    /** Kết quả nâng ưu tiên luồng gần nhất do app ảo báo về (để Chẩn đoán hiển thị). */
    static volatile String lastBoostResult = "";

    private GuestRegistry() {}

    static void put(Info i) {
        MAP.put(i.pid, i);
    }

    static Info get(int pid) {
        return MAP.get(pid);
    }

    static void remove(int pid) {
        MAP.remove(pid);
    }

    static List<Info> snapshot() {
        return new ArrayList<>(MAP.values());
    }

    static List<Info> forPackage(String pkg, int user) {
        List<Info> r = new ArrayList<>();
        for (Info i : MAP.values()) {
            if (i.pkg.equals(pkg) && i.user == user) r.add(i);
        }
        return r;
    }

    static Set<Integer> pidsFor(String pkg, int user) {
        Set<Integer> s = new HashSet<>();
        for (Info i : forPackage(pkg, user)) s.add(i.pid);
        return s;
    }

    /** Gửi một dòng JSON tới mọi tiến trình của app ảo đó. @return số kết nối đã gửi được. */
    static int send(String pkg, int user, String json) {
        int n = 0;
        for (Info i : forPackage(pkg, user)) {
            IpcServer.Conn c = i.conn;
            if (c != null && c.send(json)) n++;
        }
        return n;
    }

    /** Giết mọi tiến trình của app ảo đó (cùng UID nên được phép). @return số tiến trình đã gửi tín hiệu. */
    static int killAll(String pkg, int user) {
        int n = 0;
        for (Info i : forPackage(pkg, user)) {
            try {
                Process.killProcess(i.pid);
                n++;
            } catch (Throwable ignored) {
            }
        }
        return n;
    }

    /** Chờ tối đa timeoutMs cho tới khi không còn tiến trình nào của app ảo đó. */
    static boolean waitUntilGone(String pkg, int user, long timeoutMs) {
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            if (forPackage(pkg, user).isEmpty()) return true;
            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {
                return false;
            }
        }
        return forPackage(pkg, user).isEmpty();
    }

    static String describe() {
        List<Info> all = snapshot();
        if (all.isEmpty()) return "  (chua co app ao nao ket noi qua IPC)\n";
        StringBuilder sb = new StringBuilder();
        for (Info i : all) {
            sb.append("  pid=").append(i.pid).append(' ').append(i.proc).append(" -> ").append(i.pkg)
                    .append(" (space ").append(i.user).append(')')
                    .append(i.resumed ? " [dang hien thi] " : " [nen] ").append(i.lastCls).append('\n');
        }
        return sb.toString();
    }
}
