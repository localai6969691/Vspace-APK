package dev.vspace.workspace;

import android.app.Activity;
import android.os.Bundle;

/** Trạm trung chuyển cho phím tắt ngoài màn hình chính: mở app ảo rồi đóng ngay (không có giao diện). */
public class ShortcutActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String pkg = getIntent().getStringExtra(GameActivity.EXTRA_PKG);
        int user = getIntent().getIntExtra(GameActivity.EXTRA_USER, 0);
        // Chỉ mở app đã cài trong không gian ảo; ứng dụng khác gửi gói lạ sẽ không làm được gì.
        if (pkg != null && user >= 0 && user < Engine.SPACES && Engine.isInstalled(pkg, user)) {
            Engine.launch(this, pkg, user);
        }
        finish();
    }
}
