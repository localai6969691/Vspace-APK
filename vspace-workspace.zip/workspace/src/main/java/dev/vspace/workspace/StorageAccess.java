package dev.vspace.workspace;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

/**
 * Quyền "Truy cập mọi tệp" (MANAGE_EXTERNAL_STORAGE) trên Android 11+. Lõi (BlackBoxCore.launchApk) chỉ ghi cảnh báo trong log
 * khi thiếu quyền này rồi VẪN mở app (callback mặc định trả false) → thao tác tệp ở bộ nhớ chung của app ảo có thể hỏng âm thầm.
 * Workspace chủ động hỏi người dùng TRƯỚC khi mở một app có nhu cầu bộ nhớ chung (xem MainActivity.openGuest).
 */
final class StorageAccess {
    private StorageAccess() {}

    static boolean needsAllFilesAccess() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager();
    }

    /** Trang cài đặt cấp quyền cho riêng Workspace; nếu máy không có thì rơi về trang chung. */
    static Intent settingsIntent(Context c) {
        Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + c.getPackageName()));
        if (i.resolveActivity(c.getPackageManager()) == null) {
            i = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
        }
        return i;
    }
}
