package dev.vspace.workspace;

import android.content.Context;
import android.net.LocalServerSocket;
import android.net.LocalSocket;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;

/**
 * Máy chủ IPC trong tiến trình chính, lắng nghe trên socket UNIX trừu tượng.
 * Dùng LocalSocket thay vì broadcast/ContentProvider vì engine hook ActivityManager trong tiến trình app ảo,
 * có thể chuyển hướng broadcast/provider vào "hệ thống ảo"; socket không đi qua đường đó.
 * Bảo mật: chỉ nhận kết nối có UID trùng UID của app (kiểm bằng SO_PEERCRED).
 */
final class IpcServer {
    private static final String TAG = "VSpaceIpc";
    private static boolean started;

    private IpcServer() {}

    static String socketName(Context c) {
        return "vspace-ipc-" + c.getPackageName();
    }

    static synchronized void start(Context c) {
        if (started) return;
        started = true;
        final Context app = c.getApplicationContext();
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                serve(app);
            }
        }, "vspace-ipc-accept");
        t.setDaemon(true);
        t.start();
    }

    private static void serve(Context app) {
        while (true) {
            LocalServerSocket server = null;
            try {
                server = new LocalServerSocket(socketName(app));
                LogBuffer.i(TAG, "listening on " + socketName(app));
                while (true) {
                    accept(app, server.accept());
                }
            } catch (Throwable t) {
                LogBuffer.w(TAG, "server error: " + t);
                try {
                    if (server != null) server.close();
                } catch (Throwable ignored) {
                }
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }

    private static void accept(final Context app, LocalSocket s) {
        try {
            if (s.getPeerCredentials().getUid() != Process.myUid()) {
                LogBuffer.w(TAG, "rejected peer with foreign uid");
                s.close();
                return;
            }
        } catch (Throwable t) {
            try {
                s.close();
            } catch (Throwable ignored) {
            }
            return;
        }
        final Conn conn = new Conn(s);
        Thread r = new Thread(new Runnable() {
            @Override
            public void run() {
                conn.readLoop(app);
            }
        }, "vspace-ipc-conn");
        r.setDaemon(true);
        r.start();
    }

    /** Một kết nối từ một tiến trình app ảo. */
    static final class Conn {
        private final LocalSocket socket;
        private volatile int pid = -1;

        Conn(LocalSocket s) {
            this.socket = s;
        }

        synchronized boolean send(String line) {
            try {
                OutputStream o = socket.getOutputStream();
                o.write((line + "\n").getBytes("UTF-8"));
                o.flush();
                return true;
            } catch (Throwable t) {
                return false;
            }
        }

        void readLoop(Context app) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.length() > 8192) continue;
                    try {
                        onMessage(app, new JSONObject(line));
                    } catch (Throwable t) {
                        LogBuffer.w(TAG, "bad message: " + t);
                    }
                }
            } catch (Throwable ignored) {
            } finally {
                if (pid > 0) {
                    GuestRegistry.Info i = GuestRegistry.get(pid);
                    if (i != null && i.conn == this) GuestRegistry.remove(pid);
                }
                try {
                    socket.close();
                } catch (Throwable ignored) {
                }
            }
        }

        private void onMessage(final Context app, JSONObject o) throws Exception {
            String t = o.optString("t");
            if ("hello".equals(t)) {
                pid = o.getInt("pid");
                final GuestRegistry.Info info = new GuestRegistry.Info(pid, o.optString("pkg"), o.optString("proc"),
                        o.optInt("user", 0));
                info.conn = this;
                GuestRegistry.put(info);
                LogBuffer.i(TAG, "guest hello pid=" + pid + " pkg=" + info.pkg + " proc=" + info.proc + " user=" + info.user);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        GameModeController.get(app).onGuestHello(info);
                    }
                });
            } else if ("act".equals(t)) {
                GuestRegistry.Info i = GuestRegistry.get(pid);
                if (i != null) {
                    i.resumed = "resumed".equals(o.optString("state"));
                    i.lastCls = o.optString("cls");
                    i.lastEventAt = System.currentTimeMillis();
                }
            } else if ("boostres".equals(t)) {
                GuestRegistry.lastBoostResult = "pid " + pid + ": " + o.optInt("n", 0) + " luong";
            } else if ("pipres".equals(t)) {
                GuestRegistry.lastPipResult = o.optString("msg");
                LogBuffer.i(TAG, "pip result from pid " + pid + ": " + GuestRegistry.lastPipResult);
            }
        }
    }
}
