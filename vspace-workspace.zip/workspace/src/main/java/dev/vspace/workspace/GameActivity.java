package dev.vspace.workspace;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.widget.ScrollView;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Hồ sơ chạy nền cho từng game + nút bắt đầu chế độ game. */
public class GameActivity extends Activity {
    static final String EXTRA_PKG = "pkg";
    static final String EXTRA_USER = "user";
    static final String EXTRA_LABEL = "label";

    private String pkg;
    private String label;
    private int userId;

    private RadioButton rbSaver;
    private RadioButton rbFake;
    private RadioButton rbDim;
    private CheckBox cbAutoBackup;
    private CheckBox cbAutoRestart;
    private CheckBox cbBoost;
    private CheckBox cbLowRes;
    private CheckBox cbPin;
    private EditText edHours;
    private EditText edBattery;
    private EditText edDelay;
    private CheckBox cbHot;
    private CheckBox cbMute;
    private CheckBox cbLow;
    private CheckBox cbSched;
    private Button btnStartTime;
    private Button btnEndTime;
    private Button btnOverlay;
    private TextView tvOverlay;
    private int startMin = 23 * 60;
    private int endMin = 6 * 60;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_game);

        pkg = getIntent().getStringExtra(EXTRA_PKG);
        label = getIntent().getStringExtra(EXTRA_LABEL);
        userId = getIntent().getIntExtra(EXTRA_USER, 0);
        if (pkg == null) {
            finish();
            return;
        }
        if (label == null) label = pkg;

        ((TextView) findViewById(R.id.tv_title)).setText(label);
        ((TextView) findViewById(R.id.tv_sub)).setText(pkg + " · " + getString(R.string.space_n, userId + 1));

        rbSaver = findViewById(R.id.rb_saver);
        rbFake = findViewById(R.id.rb_fake);
        rbDim = findViewById(R.id.rb_dim);
        cbAutoBackup = findViewById(R.id.cb_autobackup);
        cbAutoRestart = findViewById(R.id.cb_autorestart);
        cbBoost = findViewById(R.id.cb_boost);
        cbLowRes = findViewById(R.id.cb_lowres);
        cbPin = findViewById(R.id.cb_pin);
        edHours = findViewById(R.id.ed_hours);
        edBattery = findViewById(R.id.ed_battery);
        edDelay = findViewById(R.id.ed_delay);
        cbHot = findViewById(R.id.cb_hot);
        cbMute = findViewById(R.id.cb_mute);
        cbLow = findViewById(R.id.cb_lowrefresh);
        cbSched = findViewById(R.id.cb_sched);
        btnStartTime = findViewById(R.id.btn_start_time);
        btnEndTime = findViewById(R.id.btn_end_time);
        btnOverlay = findViewById(R.id.btn_overlay);
        tvOverlay = findViewById(R.id.tv_overlay);

        GameProfile p = GameProfile.load(this, pkg, userId);
        rbFake.setChecked(p.mode == GameProfile.MODE_FAKE_OFF);
        rbDim.setChecked(p.mode == GameProfile.MODE_DIM);
        rbSaver.setChecked(p.mode == GameProfile.MODE_SAVER);
        cbAutoBackup.setChecked(p.autoBackup);
        cbAutoRestart.setChecked(p.autoRestart);
        cbBoost.setChecked(p.boost);
        cbLowRes.setChecked(p.lowRes);
        cbPin.setChecked(p.pin);
        edHours.setText(String.valueOf(p.maxHours));
        edBattery.setText(String.valueOf(p.minBattery));
        edDelay.setText(String.valueOf(p.delaySec));
        cbHot.setChecked(p.stopOnHot);
        cbMute.setChecked(p.mute);
        cbLow.setChecked(p.lowRefresh);

        Scheduler.Config sc = Scheduler.load(this);
        if (sc != null && sc.pkg.equals(pkg) && sc.userId == userId) {
            cbSched.setChecked(sc.enabled);
            startMin = sc.startMin;
            endMin = sc.endMin;
        }
        refreshTimeButtons();

        btnStartTime.setOnClickListener(v -> pickTime(true));
        btnEndTime.setOnClickListener(v -> pickTime(false));
        btnOverlay.setOnClickListener(v -> PowerHelper.requestOverlayPermission(this));
        // Chuỗi xác nhận: cảnh báo anti-cheat -> kiểm tra máy (pin/standby/data saver/nhiệt/RAM...) -> bắt đầu.
        findViewById(R.id.btn_start_game).setOnClickListener(v ->
                RiskList.confirm(this, pkg, () -> Preflight.confirm(this, readProfile(), this::doStart), null));
        findViewById(R.id.btn_stats).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle(R.string.btn_stats)
                        .setMessage(SessionStats.describe(this, pkg, userId))
                        .setPositiveButton(R.string.close, null)
                        .show());
        findViewById(R.id.btn_panel_off).setOnClickListener(v -> showPanelOffHelp());
        findViewById(R.id.btn_pip).setOnClickListener(v -> {
            int n = GameModeController.requestPip(pkg, userId);
            Toast.makeText(this, n > 0 ? R.string.pip_sent : R.string.pip_no_guest, Toast.LENGTH_LONG).show();
        });
        findViewById(R.id.btn_report).setOnClickListener(v -> {
            String r = Prefs.lastReport(this);
            new AlertDialog.Builder(this)
                    .setTitle(R.string.btn_report)
                    .setMessage(r != null ? r : getString(R.string.report_none))
                    .setPositiveButton(R.string.close, null)
                    .show();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshOverlayStatus();
    }

    @Override
    protected void onPause() {
        if (pkg != null) {
            readProfile().save(this, pkg, userId);
            saveSchedule();
        }
        super.onPause();
    }

    /** Hướng dẫn tắt hẳn panel bằng ADB (ScreenPower chạy bằng quyền shell). Chỉ hiển thị lệnh, không tự chạy gì. */
    private void showPanelOffHelp() {
        String apk = getApplicationInfo().sourceDir;
        final String off = ScreenPower.command(apk, "off", ScreenPower.DEFAULT_SECONDS);
        String on = ScreenPower.command(apk, "on", 0);
        TextView tv = new TextView(this);
        tv.setText(getString(R.string.panel_off_body, off, on));
        tv.setTextIsSelectable(true);
        tv.setTextSize(12);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        tv.setPadding(pad, pad, pad, pad);
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle(R.string.panel_off_title)
                .setView(sv)
                .setPositiveButton(R.string.panel_off_copy, (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("vspace-panel-off", off));
                    Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton(R.string.panel_off_dev, (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
                    } catch (Exception e) {
                        PowerHelper.openAppDetails(this);
                    }
                })
                .setNegativeButton(R.string.close, null)
                .show();
    }

    private void refreshOverlayStatus() {
        boolean ok = PowerHelper.canDrawOverlays(this);
        tvOverlay.setText(ok ? R.string.overlay_ok : R.string.overlay_missing);
        btnOverlay.setVisibility(ok ? View.GONE : View.VISIBLE);
        // Chế độ "mờ" không cần quyền overlay: nếu thiếu quyền thì gợi ý dùng nó
        if (!ok && rbFake.isChecked()) tvOverlay.setText(getString(R.string.overlay_missing) + "\n" + getString(R.string.overlay_or_dim));
    }

    private void pickTime(final boolean start) {
        int cur = start ? startMin : endMin;
        new TimePickerDialog(this, (view, h, m) -> {
            if (start) startMin = h * 60 + m;
            else endMin = h * 60 + m;
            refreshTimeButtons();
        }, cur / 60, cur % 60, true).show();
    }

    private void refreshTimeButtons() {
        btnStartTime.setText(getString(R.string.sched_start_fmt, hhmm(startMin)));
        btnEndTime.setText(getString(R.string.sched_end_fmt, hhmm(endMin)));
    }

    private static String hhmm(int minutes) {
        return String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60);
    }

    private GameProfile readProfile() {
        GameProfile p = new GameProfile();
        p.mode = rbFake.isChecked() ? GameProfile.MODE_FAKE_OFF
                : rbDim.isChecked() ? GameProfile.MODE_DIM : GameProfile.MODE_SAVER;
        p.autoBackup = cbAutoBackup.isChecked();
        p.autoRestart = cbAutoRestart.isChecked();
        p.boost = cbBoost.isChecked();
        p.lowRes = cbLowRes.isChecked();
        p.pin = cbPin.isChecked();
        p.maxHours = clamp(parse(edHours, 8), 0, 48);
        p.minBattery = clamp(parse(edBattery, 15), 0, 90);
        p.delaySec = clamp(parse(edDelay, 20), 0, 600);
        p.stopOnHot = cbHot.isChecked();
        p.mute = cbMute.isChecked();
        p.lowRefresh = cbLow.isChecked();
        return p;
    }

    private void saveSchedule() {
        Scheduler.Config cur = Scheduler.load(this);
        boolean mine = cur != null && cur.pkg.equals(pkg) && cur.userId == userId;
        if (!cbSched.isChecked() && !mine) return; // đừng ghi đè lịch của game khác
        Scheduler.Config k = new Scheduler.Config();
        k.enabled = cbSched.isChecked();
        k.pkg = pkg;
        k.userId = userId;
        k.label = label;
        k.startMin = startMin;
        k.endMin = endMin;
        Scheduler.save(this, k);
        Scheduler.armSchedule(this);
    }

    private void doStart() {
        GameProfile p = readProfile();
        p.save(this, pkg, userId);
        saveSchedule();
        int r = GameModeController.get(this).start(pkg, userId, label, p, 0);
        if (r == GameModeController.ERR_OVERLAY) {
            Toast.makeText(this, R.string.overlay_needed, Toast.LENGTH_LONG).show();
            PowerHelper.requestOverlayPermission(this);
            return;
        }
        Engine.launch(this, pkg, userId);
        Toast.makeText(this, R.string.game_started, Toast.LENGTH_LONG).show();
        finish();
    }

    private static int parse(EditText e, int def) {
        try {
            return Integer.parseInt(e.getText().toString().trim());
        } catch (Exception ex) {
            return def;
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
