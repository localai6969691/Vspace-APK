package dev.vspace.workspace;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.PowerManager;
import android.provider.Settings;

/** Các thao tác xin miễn trừ pin / mở trang "tự khởi động" của từng hãng. */
final class PowerHelper {

    private PowerHelper() {}

    /** {package, activity} của trang quản lý tự khởi động / chạy nền theo từng hãng. */
    private static final String[][] OEM_SCREENS = {
            // Xiaomi / Redmi / POCO
            {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
            // Huawei / Honor
            {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
            {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"},
            // Oppo / Realme (ColorOS)
            {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
            {"com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"},
            {"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"},
            // Vivo / iQOO
            {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
            {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"},
            // Samsung
            {"com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"},
            // OnePlus
            {"com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"},
            // Asus
            {"com.asus.mobilemanager", "com.asus.mobilemanager.powersaver.PowerSaverSettings"},
            // Letv
            {"com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity"},
            // Nokia
            {"com.evenwell.powersaving.g3", "com.evenwell.powersaving.g3.exception.PowerSaverExceptionActivity"},
    };

    static boolean isIgnoringBatteryOptimizations(Context c) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
    }

    @SuppressLint("BatteryLife")
    static void requestIgnoreBatteryOptimizations(Activity a) {
        try {
            a.startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + a.getPackageName())));
        } catch (Exception e) {
            try {
                a.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
                openAppDetails(a);
            }
        }
    }

    /** @return true nếu mở được trang riêng của hãng; false nếu phải dùng trang thông tin app. */
    static boolean openAutostartSettings(Activity a) {
        for (String[] s : OEM_SCREENS) {
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(s[0], s[1]));
                a.startActivity(i);
                return true;
            } catch (Exception ignored) {
                // hãng khác / ROM khác -> thử mục tiếp theo
            }
        }
        openAppDetails(a);
        return false;
    }

    /** Quyền "Hiển thị trên các ứng dụng khác" – cần cho overlay đen của chế độ game. */
    static boolean canDrawOverlays(Context c) {
        return Settings.canDrawOverlays(c);
    }

    static void requestOverlayPermission(Activity a) {
        try {
            a.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + a.getPackageName())));
        } catch (Exception e) {
            openAppDetails(a);
        }
    }

    static void openAppDetails(Activity a) {
        try {
            a.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + a.getPackageName())));
        } catch (Exception ignored) {
        }
    }
}
