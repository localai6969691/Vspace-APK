package dev.vspace.workspace;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Trích chữ đọc được từ dữ liệu nhị phân (tombstone protobuf của crash native) — giống lệnh `strings`. */
final class TraceText {
    private TraceText() {}

    /** Các chuỗi ASCII in được dài >= minLen, bỏ trùng, giữ thứ tự, tối đa maxLines. */
    static List<String> strings(byte[] data, int minLen, int maxLines) {
        Set<String> out = new LinkedHashSet<>();
        StringBuilder cur = new StringBuilder();
        for (int i = 0; i <= data.length; i++) {
            int b = i < data.length ? data[i] & 0xff : 0;
            if (b >= 0x20 && b <= 0x7e) {
                cur.append((char) b);
            } else {
                if (cur.length() >= minLen) {
                    out.add(cur.toString());
                    if (out.size() >= maxLines) break;
                }
                cur.setLength(0);
            }
        }
        return new ArrayList<>(out);
    }

    static String join(List<String> lines) {
        StringBuilder sb = new StringBuilder();
        for (String s : lines) sb.append(s).append('\n');
        return sb.toString();
    }
}
