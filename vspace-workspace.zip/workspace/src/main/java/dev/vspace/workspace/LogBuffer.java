package dev.vspace.workspace;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Nhật ký vòng lưu ra file để người dùng xuất báo lỗi mà KHÔNG cần adb. Mọi dòng cũng được ghi vào Logcat.
 * Chỉ tiến trình chính gọi init(); ở tiến trình :pN file == null nên chỉ ghi Logcat (tránh nhiều tiến trình ghi chung 1 file).
 */
final class LogBuffer {
    private static final int MAX_BYTES = 256 * 1024;
    private static final int KEEP_BYTES = 128 * 1024;
    private static final SimpleDateFormat FMT = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.US);
    private static File file;

    private LogBuffer() {}

    static synchronized void init(Context c) {
        if (file != null) return;
        file = new File(c.getFilesDir(), "vspace.log");
        trimIfNeeded();
    }

    static void d(String tag, String msg) {
        try {
            Log.d(tag, msg);
        } catch (Throwable ignored) {
            // test đơn vị trên JVM: android.util.Log có thể ném UnsatisfiedLinkError; bộ đệm trong RAM vẫn được ghi
        }
        append("D", tag, msg);
    }

    static void i(String tag, String msg) {
        try {
            Log.i(tag, msg);
        } catch (Throwable ignored) {
            // test đơn vị trên JVM: android.util.Log có thể ném UnsatisfiedLinkError; bộ đệm trong RAM vẫn được ghi
        }
        append("I", tag, msg);
    }

    static void w(String tag, String msg) {
        try {
            Log.w(tag, msg);
        } catch (Throwable ignored) {
            // test đơn vị trên JVM: android.util.Log có thể ném UnsatisfiedLinkError; bộ đệm trong RAM vẫn được ghi
        }
        append("W", tag, msg);
    }

    static void e(String tag, String msg) {
        try {
            Log.e(tag, msg);
        } catch (Throwable ignored) {
            // test đơn vị trên JVM: android.util.Log có thể ném UnsatisfiedLinkError; bộ đệm trong RAM vẫn được ghi
        }
        append("E", tag, msg);
    }

    static void e(String tag, String msg, Throwable t) {
        try {
            Log.e(tag, msg, t);
        } catch (Throwable ignored) {
            // xem chú thích ở trên
        }
        append("E", tag, msg + "\n" + stack(t));
    }

    static String stack(Throwable t) {
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }

    static synchronized void append(String level, String tag, String msg) {
        if (file == null) return;
        try (FileWriter w = new FileWriter(file, true)) {
            w.write(FMT.format(new Date()) + " " + level + "/" + tag + ": " + msg + "\n");
        } catch (Throwable ignored) {
        }
        if (file.length() > MAX_BYTES) trimIfNeeded();
    }

    private static void trimIfNeeded() {
        try {
            if (file.length() <= MAX_BYTES) return;
            String tail = tailBytes(KEEP_BYTES);
            try (FileWriter w = new FileWriter(file, false)) {
                w.write(tail);
            }
        } catch (Throwable ignored) {
        }
    }

    /** Phần cuối của nhật ký (tối đa maxBytes byte, bắt đầu ở đầu dòng). */
    static synchronized String tail(int maxBytes) {
        return tailBytes(maxBytes);
    }

    private static String tailBytes(int maxBytes) {
        if (file == null || !file.exists()) return "";
        try (RandomAccessFile r = new RandomAccessFile(file, "r")) {
            long len = r.length();
            long start = Math.max(0, len - maxBytes);
            r.seek(start);
            byte[] b = new byte[(int) (len - start)];
            r.readFully(b);
            String s = new String(b, "UTF-8");
            if (start > 0) {
                int nl = s.indexOf('\n');
                if (nl >= 0) s = s.substring(nl + 1);
            }
            return s;
        } catch (Throwable t) {
            return "";
        }
    }

    static synchronized long size() {
        return file != null && file.exists() ? file.length() : 0;
    }

    /** Ghi lại crash của tiến trình chính rồi chuyển cho handler gốc (hệ thống vẫn xử lý như bình thường). */
    static void installCrashHandler(final Context c) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    append("F", "CRASH", "thread=" + t.getName() + "\n" + stack(e));
                    GameModeController.restoreVolume(c); // không để máy bị câm vĩnh viễn nếu crash lúc đang tắt tiếng
                } catch (Throwable ignored) {
                }
                if (prev != null) prev.uncaughtException(t, e);
            }
        });
    }
}
