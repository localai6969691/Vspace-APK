package dev.vspace.workspace;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Cài đặt chung: nhắc nhở, kiểm tra máy, hướng dẫn theo hãng, xem nhật ký, xóa thống kê, giới thiệu/nhật ký thay đổi. */
public class SettingsActivity extends Activity {
    static final String EXTRA_CHECK_UPDATE = "check_update";

    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);

        Switch swLong = findViewById(R.id.sw_remind_long);
        Switch swOta = findViewById(R.id.sw_ota);
        swLong.setChecked(Prefs.remindLong(this));
        swOta.setChecked(Prefs.otaRemind(this));
        swLong.setOnCheckedChangeListener((v, on) -> Prefs.setRemindLong(this, on));
        swOta.setOnCheckedChangeListener((v, on) -> Prefs.setOtaRemind(this, on));

        Switch swUpd = findViewById(R.id.sw_update_auto);
        swUpd.setChecked(Prefs.updateAuto(this));
        swUpd.setOnCheckedChangeListener((v, on) -> Prefs.setUpdateAuto(this, on));
        findViewById(R.id.btn_update_check).setOnClickListener(v -> checkUpdate());
        findViewById(R.id.btn_spaces).setOnClickListener(v -> chooseSpace());
        findViewById(R.id.btn_trash).setOnClickListener(v -> showTrash());
        if (getIntent().getBooleanExtra(EXTRA_CHECK_UPDATE, false)) checkUpdate();

        findViewById(R.id.btn_preflight).setOnClickListener(v -> showPreflight());
        findViewById(R.id.btn_oem).setOnClickListener(v -> OemGuide.show(this));
        findViewById(R.id.btn_log).setOnClickListener(v -> showLog());
        findViewById(R.id.btn_clear_stats).setOnClickListener(v -> confirmClearStats());
        findViewById(R.id.btn_open_setup).setOnClickListener(v -> startActivity(new Intent(this, SetupActivity.class)));

        String ver = "?";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        ((TextView) findViewById(R.id.tv_about_settings)).setText(getString(R.string.about_fmt, ver) + "\n\n" + getString(R.string.changelog_text));
    }

    private void checkUpdate() {
        Toast.makeText(this, R.string.update_checking, Toast.LENGTH_SHORT).show();
        UpdateFlow.check(this, (r, err) -> {
            if (r == null) {
                new AlertDialog.Builder(this).setTitle(R.string.update_title)
                        .setMessage(getString(R.string.update_failed, err))
                        .setPositiveButton(R.string.close, null).show();
            } else {
                UpdateFlow.showResult(this, r);
            }
        });
    }

    // ------------------------------------------------------------------ không gian ảo (Google services / xóa cả không gian)

    private void chooseSpace() {
        String[] names = new String[Engine.SPACES];
        for (int i = 0; i < names.length; i++) names[i] = getString(R.string.space_n, i + 1);
        new AlertDialog.Builder(this).setTitle(R.string.settings_spaces)
                .setItems(names, (d, which) -> showSpaceMenu(which)).show();
    }

    private void showSpaceMenu(final int space) {
        io.execute(() -> {
            final int apps = Engine.installedApps(space).size();
            final boolean gmsOk = Engine.gmsSupported();
            final boolean gmsOn = gmsOk && Engine.gmsInstalled(space);
            runOnUiThread(() -> {
                if (isFinishing()) return;
                List<String> labels = new ArrayList<>();
                final List<Runnable> acts = new ArrayList<>();
                if (gmsOk) {
                    labels.add(getString(gmsOn ? R.string.space_gms_remove : R.string.space_gms_install));
                    acts.add(() -> {
                        if (gmsOn) doUninstallGms(space);
                        else confirmInstallGms(space);
                    });
                } else {
                    labels.add(getString(R.string.space_gms_unsupported));
                    acts.add(() -> Toast.makeText(this, R.string.space_gms_unsupported_hint, Toast.LENGTH_LONG).show());
                }
                labels.add(getString(R.string.space_delete));
                acts.add(() -> confirmDeleteSpace(space, apps));
                new AlertDialog.Builder(this)
                        .setTitle(getString(R.string.space_n, space + 1))
                        .setMessage(getString(R.string.space_info, apps))
                        .setItems(labels.toArray(new String[0]), (d, which) -> acts.get(which).run())
                        .setNegativeButton(R.string.close, null).show();
            });
        });
    }

    private void confirmInstallGms(final int space) {
        new AlertDialog.Builder(this).setTitle(R.string.space_gms_install).setMessage(R.string.space_gms_confirm)
                .setPositiveButton(android.R.string.ok, (d, w) -> io.execute(() -> {
                    final Engine.InstallOutcome o = Engine.installGms(space);
                    runOnUiThread(() -> Toast.makeText(this, o.ok ? getString(R.string.space_gms_done)
                            : getString(R.string.space_gms_fail, String.valueOf(o.message)), Toast.LENGTH_LONG).show());
                }))
                .setNegativeButton(android.R.string.cancel, null).show();
    }

    private void doUninstallGms(final int space) {
        io.execute(() -> {
            final boolean ok = Engine.uninstallGms(space);
            runOnUiThread(() -> Toast.makeText(this, ok ? R.string.space_gms_removed : R.string.space_gms_remove_fail, Toast.LENGTH_LONG).show());
        });
    }

    private void confirmDeleteSpace(final int space, int apps) {
        new AlertDialog.Builder(this).setTitle(R.string.space_delete)
                .setMessage(getString(R.string.space_delete_confirm, space + 1, apps))
                .setPositiveButton(R.string.space_delete, (d, w) -> io.execute(() -> {
                    final boolean ok = Engine.deleteSpace(space);
                    runOnUiThread(() -> Toast.makeText(this, ok ? R.string.space_deleted : R.string.space_delete_fail, Toast.LENGTH_LONG).show());
                }))
                .setNegativeButton(android.R.string.cancel, null).show();
    }

    // ------------------------------------------------------------------ thùng rác (bản sao an toàn khi gỡ/xóa dữ liệu)

    private void showTrash() {
        File[] fs = TrashBin.dir(this).listFiles();
        if (fs == null || fs.length == 0) {
            new AlertDialog.Builder(this).setTitle(R.string.settings_trash).setMessage(R.string.trash_empty)
                    .setPositiveButton(R.string.close, null).show();
            return;
        }
        final List<File> files = new ArrayList<>(Arrays.asList(fs));
        Collections.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        String[] names = new String[files.size()];
        DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
        for (int i = 0; i < names.length; i++) {
            File f = files.get(i);
            names[i] = f.getName().replace("vspace-", "").replace(".zip", "") + "\n" + df.format(new Date(f.lastModified()))
                    + " · " + f.length() / (1024 * 1024) + " MB";
        }
        new AlertDialog.Builder(this).setTitle(R.string.settings_trash).setMessage(R.string.trash_hint)
                .setItems(names, (d, which) -> confirmRestoreTrash(files.get(which)))
                .setNegativeButton(R.string.close, null).show();
    }

    private void confirmRestoreTrash(final File f) {
        new AlertDialog.Builder(this).setTitle(R.string.settings_trash).setMessage(R.string.trash_restore_confirm)
                .setPositiveButton(android.R.string.ok, (d, w) -> io.execute(() -> {
                    String msg;
                    try {
                        TrashBin.restore(this, f, -1);
                        //noinspection ResultOfMethodCallIgnored
                        f.delete();
                        msg = getString(R.string.trash_restored);
                    } catch (Throwable t) {
                        LogBuffer.e("VSpaceTrash", "restore from trash failed", t);
                        msg = getString(R.string.undo_failed, String.valueOf(t.getMessage()));
                    }
                    final String m = msg;
                    runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show());
                }))
                .setNeutralButton(R.string.trash_delete, (d, w) -> {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                })
                .setNegativeButton(android.R.string.cancel, null).show();
    }

    @Override
    protected void onDestroy() {
        io.shutdown();
        super.onDestroy();
    }

    private void showPreflight() {
        io.execute(() -> {
            final String text = Preflight.describeNow(this);
            runOnUiThread(() -> {
                if (isFinishing()) return;
                new AlertDialog.Builder(this)
                        .setTitle(R.string.settings_preflight)
                        .setMessage(text)
                        .setPositiveButton(R.string.close, null)
                        .show();
            });
        });
    }

    private void showLog() {
        final String log = LogBuffer.tail(30000);
        TextView tv = new TextView(this);
        tv.setText(log.isEmpty() ? getString(R.string.log_empty) : log);
        tv.setTextIsSelectable(true);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(10);
        int pad = (int) (12 * getResources().getDisplayMetrics().density);
        tv.setPadding(pad, pad, pad, pad);
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle(R.string.settings_log)
                .setView(sv)
                .setPositiveButton(R.string.copy, (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("vspace-log", log));
                    Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton(R.string.btn_share, (d, w) -> shareLog(log))
                .setNegativeButton(R.string.close, null)
                .show();
    }

    private void shareLog(final String log) {
        io.execute(() -> {
            Uri uri = null;
            try {
                uri = ShareProvider.write(this, "vspace-log-" + System.currentTimeMillis() + ".txt", log);
            } catch (Exception e) {
                LogBuffer.w("VSpaceShare", "share log failed: " + e);
            }
            final Uri shared = uri;
            runOnUiThread(() -> {
                if (shared == null) {
                    Toast.makeText(this, R.string.share_fail, Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_STREAM, shared);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(send, getString(R.string.share_title)));
            });
        });
    }

    private void confirmClearStats() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.settings_clear_stats)
                .setMessage(R.string.settings_clear_stats_msg)
                .setPositiveButton(android.R.string.ok, (d, w) -> {
                    Prefs.clearStats(this);
                    Toast.makeText(this, R.string.settings_cleared, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}
