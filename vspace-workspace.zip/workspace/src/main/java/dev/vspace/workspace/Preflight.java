package dev.vspace.workspace;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;
import android.os.Process;

import java.util.ArrayList;
import java.util.List;

/**
 * Kiểm tra máy TRƯỚC khi vào chế độ chạy nền (tài liệu kỹ thuật tech.txt: "3 thứ bắt buộc" + các điều kiện làm game đứng âm thầm).
 *
 * Tách làm hai phần để test được:
 *  - evaluate(Snapshot): hàm THUẦN, biến ảnh chụp trạng thái máy thành danh sách vấn đề (có test đơn vị);
 *  - snapshot(Context, GameProfile): đọc API Android thật (chưa kiểm chứng trên máy thật; mỗi lần đọc đều bọc try/catch).
 *
 * Chỉ CẢNH BÁO, không chặn: người dùng quyết định có tiếp tục không.
 */
final class Preflight {
    static final int SEV_INFO = 0;
    static final int SEV_WARN = 1;

    static final String BATTERY_OPT = "battery_opt";
    static final String BUCKET = "bucket";
    static final String DATA_SAVER = "data_saver";
    static final String THERMAL = "thermal";
    static final String BATTERY_LOW = "battery_low";
    static final String OVERLAY = "overlay";
    static final String NOTIF = "notif";
    static final String LOW_MEMORY = "low_memory";
    static final String HOST32 = "host32";
    static final String AUTO_REVOKE = "auto_revoke";
    static final String OEM = "oem";
    static final String POWER_SAVE = "power_save";
    static final String BG_RESTRICTED = "bg_restricted";

    /** UsageStatsManager.STANDBY_BUCKET_RARE (40) trở lên: job/alarm/mạng nền bị hoãn mạnh. */
    static final int BUCKET_RARE = 40;
    static final int BUCKET_RESTRICTED = 45;
    /** ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED. */
    static final int DATA_SAVER_ENABLED = 3;
    /** PowerManager.THERMAL_STATUS_MODERATE. */
    static final int THERMAL_MODERATE = 2;
    static final long LOW_MEMORY_MB = 400;

    /** Ảnh chụp trạng thái máy. Giá trị mặc định = "không có vấn đề / không biết". */
    static final class Snapshot {
        boolean ignoringBattery = true;
        int bucket = -1;
        int restrictBackground = -1;
        int thermal = -1;
        int batteryPct = -1;
        boolean charging;
        int minBattery;
        int mode = GameProfile.MODE_FAKE_OFF;
        boolean overlay = true;
        boolean notifications = true;
        long availMb = -1;
        boolean lowMemory;
        boolean host64 = true;
        /** -1 không biết, 0 chưa miễn trừ, 1 đã miễn trừ khỏi tự thu hồi quyền / ngủ đông (Android 11+). */
        int autoRevoke = -1;
        boolean oemAggressive;
        /** Chế độ Tiết kiệm pin (Battery Saver) của hệ thống đang bật (PowerManager.isPowerSaveMode, API 21). */
        boolean powerSave;
        /** Người dùng đặt Workspace ở mức "Hạn chế" trong cài đặt pin (ActivityManager.isBackgroundRestricted, API 28). */
        boolean bgRestricted;
    }

    static final class Issue {
        final String code;
        final int severity;
        final String arg;

        Issue(String code, int severity, String arg) {
            this.code = code;
            this.severity = severity;
            this.arg = arg;
        }
    }

    private Preflight() {}

    // ------------------------------------------------------------------ hàm thuần

    static List<Issue> evaluate(Snapshot s) {
        List<Issue> r = new ArrayList<>();
        if (!s.ignoringBattery) r.add(new Issue(BATTERY_OPT, SEV_WARN, ""));
        if (s.bucket >= BUCKET_RARE) r.add(new Issue(BUCKET, SEV_WARN, bucketName(s.bucket)));
        if (s.restrictBackground == DATA_SAVER_ENABLED) r.add(new Issue(DATA_SAVER, SEV_WARN, ""));
        if (s.thermal >= THERMAL_MODERATE) r.add(new Issue(THERMAL, SEV_WARN, String.valueOf(s.thermal)));
        if (s.batteryPct >= 0 && !s.charging && s.minBattery > 0 && s.batteryPct <= s.minBattery + 5) {
            r.add(new Issue(BATTERY_LOW, SEV_WARN, String.valueOf(s.batteryPct)));
        }
        if (s.mode == GameProfile.MODE_FAKE_OFF && !s.overlay) r.add(new Issue(OVERLAY, SEV_WARN, ""));
        if (!s.notifications) r.add(new Issue(NOTIF, SEV_WARN, ""));
        if (s.lowMemory || (s.availMb >= 0 && s.availMb < LOW_MEMORY_MB)) {
            r.add(new Issue(LOW_MEMORY, SEV_WARN, String.valueOf(Math.max(0, s.availMb))));
        }
        if (!s.host64 && s.mode != GameProfile.MODE_SAVER) r.add(new Issue(HOST32, SEV_INFO, ""));
        if (s.autoRevoke == 0) r.add(new Issue(AUTO_REVOKE, SEV_INFO, ""));
        if (s.oemAggressive) r.add(new Issue(OEM, SEV_INFO, ""));
        // "Hạn chế" chặn cả dịch vụ nền lẫn job/alarm; Tiết kiệm pin chỉ giảm bớt (không chặn hẳn) nên mức cảnh báo thấp hơn.
        if (s.bgRestricted) r.add(new Issue(BG_RESTRICTED, SEV_WARN, ""));
        if (s.powerSave && !s.charging) r.add(new Issue(POWER_SAVE, SEV_WARN, ""));
        return r;
    }

    static boolean hasWarnings(List<Issue> issues) {
        for (Issue i : issues) {
            if (i.severity >= SEV_WARN) return true;
        }
        return false;
    }

    static boolean has(List<Issue> issues, String code) {
        for (Issue i : issues) {
            if (i.code.equals(code)) return true;
        }
        return false;
    }

    static String bucketName(int bucket) {
        if (bucket >= BUCKET_RESTRICTED) return "RESTRICTED";
        if (bucket >= BUCKET_RARE) return "RARE";
        if (bucket >= 30) return "FREQUENT";
        if (bucket >= 20) return "WORKING_SET";
        if (bucket >= 10) return "ACTIVE";
        if (bucket >= 5) return "EXEMPTED";
        return String.valueOf(bucket);
    }

    // ------------------------------------------------------------------ đọc trạng thái máy thật

    static Snapshot snapshot(Context c, GameProfile p) {
        Snapshot s = new Snapshot();
        s.mode = p.mode;
        s.minBattery = p.minBattery;
        s.host64 = Process.is64Bit();
        s.oemAggressive = OemGuide.isAggressive(Build.MANUFACTURER);
        try {
            s.ignoringBattery = PowerHelper.isIgnoringBatteryOptimizations(c);
        } catch (Throwable ignored) {
        }
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
                if (usm != null) s.bucket = usm.getAppStandbyBucket();
            }
        } catch (Throwable ignored) {
        }
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) s.restrictBackground = cm.getRestrictBackgroundStatus();
        } catch (Throwable ignored) {
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
                if (pm != null) s.thermal = pm.getCurrentThermalStatus();
            }
        } catch (Throwable ignored) {
        }
        try {
            Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (level >= 0 && scale > 0) s.batteryPct = level * 100 / scale;
                s.charging = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
            }
        } catch (Throwable ignored) {
        }
        try {
            s.overlay = PowerHelper.canDrawOverlays(c);
        } catch (Throwable ignored) {
        }
        try {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (nm != null) s.notifications = nm.areNotificationsEnabled();
        } catch (Throwable ignored) {
        }
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                s.availMb = mi.availMem / (1024 * 1024);
                s.lowMemory = mi.lowMemory;
            }
        } catch (Throwable ignored) {
        }
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            if (pm != null) s.powerSave = pm.isPowerSaveMode();
        } catch (Throwable ignored) {
        }
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
                if (am != null) s.bgRestricted = am.isBackgroundRestricted();
            }
        } catch (Throwable ignored) {
        }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                s.autoRevoke = c.getPackageManager().isAutoRevokeWhitelisted() ? 1 : 0;
            }
        } catch (Throwable ignored) {
        }
        return s;
    }

    // ------------------------------------------------------------------ hiển thị

    static String text(Context c, Issue i) {
        switch (i.code) {
            case BATTERY_OPT:
                return c.getString(R.string.pf_battery_opt);
            case BUCKET:
                return c.getString(R.string.pf_bucket, i.arg);
            case DATA_SAVER:
                return c.getString(R.string.pf_data_saver);
            case THERMAL:
                return c.getString(R.string.pf_thermal, i.arg);
            case BATTERY_LOW:
                return c.getString(R.string.pf_battery_low, i.arg);
            case OVERLAY:
                return c.getString(R.string.pf_overlay);
            case NOTIF:
                return c.getString(R.string.pf_notif);
            case LOW_MEMORY:
                return c.getString(R.string.pf_low_memory, i.arg);
            case HOST32:
                return c.getString(R.string.pf_host32);
            case AUTO_REVOKE:
                return c.getString(R.string.pf_auto_revoke);
            case OEM:
                return c.getString(R.string.pf_oem, Build.MANUFACTURER);
            case POWER_SAVE:
                return c.getString(R.string.pf_power_save);
            case BG_RESTRICTED:
                return c.getString(R.string.pf_bg_restricted);
            default:
                return i.code;
        }
    }

    /** Văn bản nhiều dòng cho một danh sách vấn đề ("⚠" = nên xử lý, "ℹ" = thông tin). */
    static String describe(Context c, List<Issue> issues) {
        if (issues.isEmpty()) return c.getString(R.string.pf_all_ok);
        StringBuilder sb = new StringBuilder();
        for (Issue i : issues) {
            sb.append(i.severity >= SEV_WARN ? "\u26A0 " : "\u2139 ").append(text(c, i)).append("\n\n");
        }
        return sb.toString().trim();
    }

    /** Báo cáo kiểm tra máy cho màn hình Cài đặt (không bắt người dùng chọn gì). */
    static String describeNow(Context c) {
        return describe(c, evaluate(snapshot(c, new GameProfile())));
    }

    /**
     * Trước khi bắt đầu phiên: nếu có cảnh báo thì hiện hộp thoại (Vẫn bắt đầu / Hủy / Khắc phục), ngược lại chạy onGo ngay.
     * Chỉ gọi trên main thread.
     */
    static void confirm(final Activity a, GameProfile p, final Runnable onGo) {
        List<Issue> issues = evaluate(snapshot(a, p));
        if (!hasWarnings(issues)) {
            onGo.run();
            return;
        }
        new AlertDialog.Builder(a)
                .setTitle(R.string.pf_title)
                .setMessage(describe(a, issues))
                .setPositiveButton(R.string.pf_go_anyway, (d, w) -> onGo.run())
                .setNeutralButton(R.string.pf_fix, (d, w) -> a.startActivity(new Intent(a, SetupActivity.class)))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}
