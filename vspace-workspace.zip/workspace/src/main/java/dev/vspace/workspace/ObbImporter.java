package dev.vspace.workspace;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Chép các tệp OBB trong gói XAPK vào thư mục OBB ẢO của app trong một không gian.
 *
 * Đích XÁC NHẬN TỪ SOURCE THẬT (phiên 5, SHA 89b59836c66f173756a4ae258cf379a957649820,
 * BEnvironment.getExternalObbDir/getExternalUserDir): KHÔNG nằm dưới gốc nội bộ (cache-sibling) như G-31 từng đoán, mà dưới
 * gốc NGOÀI riêng: context.getExternalFilesDir("blackbox")/storage/emulated/<không gian>/Android/obb/<gói>/.
 * G-31 coi như đã giải quyết phần "đường dẫn đích"; phần còn lại CHƯA kiểm chứng: lõi có thật sự ĐỌC từ đây khi game chạy
 * hay không (cần P0-5/P1-20 trên máy thật với 1 game có OBB).
 */
final class ObbImporter {
    private static final String TAG = "VSpaceObb";

    private ObbImporter() {}

    static File targetDir(Context c, String pkg, int userId) {
        return new File(GuestBackup.externalRoot(c), BundlePlan.obbDirRel(pkg, userId));
    }

    /** Dung lượng cần có (kèm 10% dự phòng) để chép các OBB. */
    static long requiredBytes(long obbBytes) {
        return obbBytes + obbBytes / 10;
    }

    /** Tổng kích thước giải nén của các mục OBB; trả -1 nếu không đọc được. */
    static long totalBytes(File bundle, List<String> entries) {
        long sum = 0;
        try (ZipFile z = new ZipFile(bundle)) {
            for (String n : entries) {
                ZipEntry e = z.getEntry(n);
                if (e != null && e.getSize() > 0) sum += e.getSize();
            }
            return sum;
        } catch (Throwable t) {
            return -1;
        }
    }

    /** Chép vào thư mục OBB ảo của (gói, không gian). Xem copyTo. */
    static int copy(Context c, File bundle, List<String> entries, String pkg, int userId) {
        return copyTo(targetDir(c, pkg, userId), bundle, entries);
    }

    /**
     * Chép các OBB trong zip vào dir (qua file tạm rồi đổi tên; bỏ qua tệp đã có cùng kích thước; bỏ qua tên không an toàn).
     * @return số tệp OBB hiện có ở đích sau khi chép; -1 nếu lỗi
     */
    static int copyTo(File dir, File bundle, List<String> entries) {
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        int count = 0;
        try (ZipFile z = new ZipFile(bundle)) {
            for (String n : entries) {
                String name = BundlePlan.baseName(n);
                if (!BundlePlan.isSafeObbName(name)) continue;
                ZipEntry e = z.getEntry(n);
                if (e == null) continue;
                File dest = new File(dir, name);
                if (dest.isFile() && e.getSize() >= 0 && dest.length() == e.getSize()) {
                    count++;
                    continue;
                }
                File tmp = new File(dir, name + ".part");
                try (InputStream in = z.getInputStream(e); OutputStream out = new FileOutputStream(tmp)) {
                    ApkImporter.copy(in, out);
                }
                //noinspection ResultOfMethodCallIgnored
                dest.delete();
                if (!tmp.renameTo(dest)) {
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                    LogBuffer.w(TAG, "cannot rename " + tmp);
                    return -1;
                }
                count++;
            }
        } catch (Throwable t) {
            LogBuffer.w(TAG, "obb copy failed: " + t);
            return -1;
        }
        LogBuffer.i(TAG, "copied " + count + " obb file(s) to " + dir);
        return count;
    }
}
