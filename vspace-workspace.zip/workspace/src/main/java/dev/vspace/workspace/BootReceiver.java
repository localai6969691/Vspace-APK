package dev.vspace.workspace;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/** Bật lại dịch vụ giữ nền, lịch game và watchdog sau khi khởi động máy / cập nhật app. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String a = intent != null ? intent.getAction() : null;
        boolean boot = Intent.ACTION_BOOT_COMPLETED.equals(a)
                || "android.intent.action.QUICKBOOT_POWERON".equals(a);
        if (boot) {
            // Sau reboot app ảo không còn chạy: bỏ phiên game cũ và trả âm lượng nếu lần trước bị kill khi đang tắt tiếng.
            Prefs.clearSession(context);
            GameModeController.restoreVolume(context);
        }
        try {
            Scheduler.armSchedule(context);
        } catch (Throwable t) {
            LogBuffer.w("VSpaceBoot", "cannot arm schedule: " + t);
        }
        if (!Prefs.keepAlive(context)) return;
        try {
            KeepAliveService.start(context);
        } catch (Throwable t) {
            LogBuffer.w("VSpaceBoot", "cannot start keep-alive service: " + t);
        }
    }
}
