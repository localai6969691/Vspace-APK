package dev.vspace.workspace;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Cầu nối quyền runtime (P1-3). App ảo chạy dưới UID của host nên quyền của nó = quyền đã khai báo VÀ đã được cấp cho Workspace.
 * Lớp này đọc manifest của app ảo, đối chiếu với manifest + trạng thái cấp quyền của host và nói rõ từng quyền thuộc loại nào:
 *  - GRANTED: đã cấp, app ảo dùng được;
 *  - REQUESTABLE: Workspace có khai báo nhưng người dùng chưa cấp → có thể xin ngay từ màn hình này;
 *  - BLOCKED: Workspace KHÔNG khai báo quyền này → không xin được (phải thêm vào manifest rồi build lại), tính năng tương ứng sẽ lỗi.
 * Không giả mạo gì cả: chỉ báo trạng thái thật.
 */
final class PermissionBridge {

    static final class Report {
        final List<String> granted = new ArrayList<>();
        final List<String> requestable = new ArrayList<>();
        final List<String> blocked = new ArrayList<>();
        /** Mọi quyền khai báo của app ảo (kể cả không nguy hiểm) — dùng để nhận biết app cần bộ nhớ chung. */
        final Set<String> declared = new LinkedHashSet<>();
    }

    private PermissionBridge() {}

    /** Hàm thuần (có test): phân loại quyền nguy hiểm của app ảo. */
    static Report classify(Collection<String> guestDangerous, Set<String> hostDeclared, Set<String> hostGranted) {
        Report r = new Report();
        for (String p : guestDangerous) {
            if (hostGranted.contains(p)) r.granted.add(p);
            else if (hostDeclared.contains(p)) r.requestable.add(p);
            else r.blocked.add(p);
        }
        return r;
    }

    static String shortName(String perm) {
        int dot = perm.lastIndexOf('.');
        return dot >= 0 ? perm.substring(dot + 1) : perm;
    }

    /** App có nhu cầu bộ nhớ chung (đọc/ghi ngoài) — căn cứ để gợi ý "Truy cập mọi tệp". Hàm thuần. */
    static boolean wantsSharedStorage(Collection<String> declared) {
        return declared.contains("android.permission.READ_EXTERNAL_STORAGE")
                || declared.contains("android.permission.WRITE_EXTERNAL_STORAGE")
                || declared.contains("android.permission.MANAGE_EXTERNAL_STORAGE");
    }

    /** null nếu không đọc được APK của app ảo. Gọi trên luồng nền. */
    @SuppressWarnings("deprecation")
    static Report forGuest(Context c, String pkg, int userId) {
        try {
            PackageManager pm = c.getPackageManager();
            File apk = GuestBackup.locate(c, pkg, userId).apk;
            if (apk == null || !apk.isFile()) return null;
            PackageInfo gi = pm.getPackageArchiveInfo(apk.getAbsolutePath(), PackageManager.GET_PERMISSIONS);
            if (gi == null) return null;
            PackageInfo hi = pm.getPackageInfo(c.getPackageName(), PackageManager.GET_PERMISSIONS);

            Set<String> hostDeclared = new LinkedHashSet<>();
            Set<String> hostGranted = new LinkedHashSet<>();
            if (hi.requestedPermissions != null) {
                for (String p : hi.requestedPermissions) {
                    hostDeclared.add(p);
                    if (c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) hostGranted.add(p);
                }
            }
            List<String> dangerous = new ArrayList<>();
            Set<String> declared = new LinkedHashSet<>();
            if (gi.requestedPermissions != null) {
                for (String name : gi.requestedPermissions) {
                    declared.add(name);
                    try {
                        PermissionInfo info = pm.getPermissionInfo(name, 0);
                        if ((info.protectionLevel & PermissionInfo.PROTECTION_MASK_BASE) == PermissionInfo.PROTECTION_DANGEROUS) {
                            dangerous.add(name);
                        }
                    } catch (Exception ignored) {
                        // quyền tùy biến / không có trên máy này
                    }
                }
            }
            Report r = classify(dangerous, hostDeclared, hostGranted);
            r.declared.addAll(declared);
            return r;
        } catch (Throwable t) {
            LogBuffer.w("VSpacePerm", "đọc quyền app ảo lỗi: " + t);
            return null;
        }
    }
}
