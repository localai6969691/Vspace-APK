package dev.vspace.workspace;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Kiểm tra và tải bản cập nhật từ GitHub Releases của chính dự án (không có máy chủ nào khác).
 *
 * Nguyên tắc (AGENTS.md mục 21 — lõi từng rò dữ liệu ra bên thứ ba, nên mọi lưu lượng mạng của chính Workspace phải minh bạch):
 *  - CHỈ chạy khi người dùng bấm nút, hoặc khi bật "tự kiểm tra" (MẶC ĐỊNH TẮT). Chỉ gửi một yêu cầu GET tới api.github.com
 *    kèm User-Agent "VSpace/&lt;phiên bản&gt;"; KHÔNG gửi mã thiết bị, danh sách app, hay bất cứ dữ liệu người dùng nào.
 *  - Chỉ HTTPS. Mỗi lần chuyển hướng được kiểm host (github.com, api.github.com, *.githubusercontent.com), tối đa 5 bước.
 *  - Tệp tải về phải khớp sha256 do GitHub công bố (trường "digest") trước khi được đưa cho trình cài đặt; không có sha256 thì
 *    người gọi phải hỏi người dùng rõ ràng.
 *  - Không có kho cấu hình (updateRepo trống) thì tính năng tắt hẳn.
 * Lớp này không dùng android.* nên test được trên JVM (phần mạng thì không test được trong sandbox; xem handoff).
 */
final class UpdateChecker {
    static final long MAX_JSON = 1024 * 1024;
    static final long MAX_APK = 400L * 1024 * 1024;
    private static final int MAX_REDIRECTS = 5;
    private static final Pattern REPO = Pattern.compile("^[A-Za-z0-9_.-]{1,39}/[A-Za-z0-9_.-]{1,100}$");
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private UpdateChecker() {}

    static final class Asset {
        String name = "";
        String url = "";
        long size;
        /** sha256 dạng hex thường, hoặc null nếu GitHub không công bố. */
        String sha256;
    }

    static final class Release {
        String tag = "";
        String title = "";
        String body = "";
        String pageUrl = "";
        boolean prerelease;
        boolean draft;
        final List<Asset> assets = new ArrayList<>();
    }

    interface Progress {
        /** @return false để hủy */
        boolean onProgress(long done, long total);
    }

    // ------------------------------------------------------------------ hàm thuần

    static boolean validRepo(String repo) {
        return repo != null && REPO.matcher(repo).matches() && !repo.contains("..");
    }

    static boolean allowedHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        return h.equals("github.com") || h.equals("api.github.com") || h.endsWith(".githubusercontent.com");
    }

    static Release parseRelease(String json) {
        Map<String, Object> o = MiniJson.asObject(MiniJson.parse(json));
        if (o == null) throw new IllegalArgumentException("không phải đối tượng JSON");
        Release r = new Release();
        r.tag = nz(MiniJson.str(o, "tag_name"));
        r.title = nz(MiniJson.str(o, "name"));
        r.body = nz(MiniJson.str(o, "body"));
        r.pageUrl = nz(MiniJson.str(o, "html_url"));
        r.prerelease = MiniJson.bool(o, "prerelease");
        r.draft = MiniJson.bool(o, "draft");
        List<Object> assets = MiniJson.asArray(o.get("assets"));
        if (assets != null) {
            for (Object ao : assets) {
                Map<String, Object> m = MiniJson.asObject(ao);
                if (m == null) continue;
                Asset a = new Asset();
                a.name = nz(MiniJson.str(m, "name"));
                a.url = nz(MiniJson.str(m, "browser_download_url"));
                a.size = MiniJson.num(m, "size", 0);
                String d = MiniJson.str(m, "digest");
                if (d != null && d.toLowerCase(Locale.ROOT).startsWith("sha256:")) {
                    String hex = d.substring(7).toLowerCase(Locale.ROOT);
                    if (hex.matches("[0-9a-f]{64}")) a.sha256 = hex;
                }
                r.assets.add(a);
            }
        }
        return r;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    /** Chọn APK hợp ABI: bản 64-bit ưu tiên tên có "arm64", bản 32-bit ưu tiên "armeabi"/"v7a"; nếu không khớp lấy APK đầu tiên. */
    static Asset pickAsset(Release r, boolean is64) {
        Asset firstApk = null;
        for (Asset a : r.assets) {
            String n = a.name.toLowerCase(Locale.ROOT);
            if (!n.endsWith(".apk")) continue;
            if (firstApk == null) firstApk = a;
            boolean arm64 = n.contains("arm64");
            boolean arm32 = n.contains("armeabi") || n.contains("v7a");
            if (is64 && arm64) return a;
            if (!is64 && arm32) return a;
        }
        return firstApk;
    }

    /** So sánh phiên bản dạng 1.2.3 (bỏ chữ v đầu; hậu tố -beta/-rc nhỏ hơn bản chính). &lt;0, 0, &gt;0. */
    static int compareVersions(String a, String b) {
        String[] pa = split(a);
        String[] pb = split(b);
        int n = Math.max(pa.length, pb.length);
        for (int i = 0; i < n; i++) {
            long x = i < pa.length ? lead(pa[i]) : 0;
            long y = i < pb.length ? lead(pb[i]) : 0;
            if (x != y) return x < y ? -1 : 1;
        }
        boolean preA = isPre(a);
        boolean preB = isPre(b);
        if (preA != preB) return preA ? -1 : 1;
        return 0;
    }

    private static String core(String v) {
        String s = v == null ? "" : v.trim();
        if (s.startsWith("v") || s.startsWith("V")) s = s.substring(1);
        int dash = s.indexOf('-');
        int plus = s.indexOf('+');
        int cut = dash < 0 ? plus : plus < 0 ? dash : Math.min(dash, plus);
        return cut >= 0 ? s.substring(0, cut) : s;
    }

    private static boolean isPre(String v) {
        String s = v == null ? "" : v.trim();
        return s.indexOf('-') >= 0;
    }

    private static String[] split(String v) {
        return core(v).split("\\.");
    }

    private static long lead(String part) {
        int e = 0;
        while (e < part.length() && Character.isDigit(part.charAt(e)) && e < 9) e++;
        return e == 0 ? 0 : Long.parseLong(part.substring(0, e));
    }

    static boolean isNewer(String latestTag, String currentVersionName) {
        if (latestTag == null || latestTag.trim().isEmpty()) return false;
        return compareVersions(latestTag, currentVersionName) > 0;
    }

    static String sha256Hex(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            StringBuilder sb = new StringBuilder();
            for (byte x : md.digest()) sb.append(String.format(Locale.US, "%02x", x & 0xff));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }

    // ------------------------------------------------------------------ mạng

    private static HttpURLConnection open(String url, String userAgent, String accept) throws IOException {
        URL u = new URL(url);
        if (!"https".equals(u.getProtocol())) throw new IOException("chỉ cho phép HTTPS: " + u.getProtocol());
        if (!allowedHost(u.getHost())) throw new IOException("host không nằm trong danh sách cho phép: " + u.getHost());
        HttpURLConnection c = (HttpURLConnection) u.openConnection();
        c.setInstanceFollowRedirects(false);   // tự kiểm từng bước chuyển hướng
        c.setConnectTimeout(15_000);
        c.setReadTimeout(30_000);
        c.setRequestProperty("User-Agent", userAgent);
        c.setRequestProperty("Accept", accept);
        return c;
    }

    /** GET có theo dõi chuyển hướng (đã kiểm host). Người gọi phải đóng luồng của kết quả. */
    private static HttpURLConnection openFollowing(String url, String userAgent, String accept) throws IOException {
        String cur = url;
        for (int hop = 0; hop <= MAX_REDIRECTS; hop++) {
            HttpURLConnection c = open(cur, userAgent, accept);
            int code = c.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("chuyển hướng không có Location");
                cur = new URL(new URL(cur), loc).toString();
                continue;
            }
            if (code == 403 || code == 429) {
                c.disconnect();
                throw new IOException("GitHub từ chối (HTTP " + code + "), có thể do giới hạn số lần gọi; thử lại sau");
            }
            if (code == 404) {
                c.disconnect();
                throw new IOException("không có bản phát hành nào (HTTP 404)");
            }
            if (code != 200) {
                c.disconnect();
                throw new IOException("HTTP " + code);
            }
            return c;
        }
        throw new IOException("quá nhiều lần chuyển hướng");
    }

    /** Lấy bản phát hành mới nhất (không tính bản nháp/tiền phát hành). Chạy trên luồng nền. */
    static Release fetchLatest(String repo, String userAgent) throws IOException {
        if (!validRepo(repo)) throw new IOException("kho không hợp lệ: " + repo);
        HttpURLConnection c = openFollowing("https://api.github.com/repos/" + repo + "/releases/latest", userAgent,
                "application/vnd.github+json");
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                if (bo.size() + n > MAX_JSON) throw new IOException("phản hồi quá lớn");
                bo.write(buf, 0, n);
            }
            return parseRelease(new String(bo.toByteArray(), UTF8));
        } catch (IllegalArgumentException e) {
            throw new IOException("phản hồi không phải JSON hợp lệ: " + e.getMessage());
        } finally {
            c.disconnect();
        }
    }

    /**
     * Tải asset về dest (qua dest.part), kiểm sha256 nếu có. Chạy trên luồng nền.
     * @return true nếu tải xong; false nếu bị hủy. Ném IOException khi lỗi hoặc sha256 không khớp (tệp bị xóa).
     */
    static boolean download(File dest, Asset a, String userAgent, Progress p) throws IOException {
        File part = new File(dest.getPath() + ".part");
        //noinspection ResultOfMethodCallIgnored
        part.delete();
        HttpURLConnection c = openFollowing(a.url, userAgent, "application/octet-stream");
        try {
            long total = c.getContentLengthLong();
            if (total > MAX_APK || a.size > MAX_APK) throw new IOException("tệp quá lớn");
            long done = 0;
            try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(part)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) {
                    done += n;
                    if (done > MAX_APK) throw new IOException("tệp quá lớn");
                    out.write(buf, 0, n);
                    if (p != null && !p.onProgress(done, total > 0 ? total : a.size)) {
                        //noinspection ResultOfMethodCallIgnored
                        part.delete();
                        return false;
                    }
                }
            }
            if (a.size > 0 && part.length() != a.size) {
                final long got = part.length();   // đọc TRƯỚC khi xóa (bản cũ in luôn 0 vì đọc sau delete — lỗi tìm ra bằng net_check.py)
                //noinspection ResultOfMethodCallIgnored
                part.delete();
                throw new IOException("kích thước không khớp: " + got + " ≠ " + a.size);
            }
            if (a.sha256 != null && !a.sha256.equals(sha256Hex(part))) {
                //noinspection ResultOfMethodCallIgnored
                part.delete();
                throw new IOException("sha256 KHÔNG khớp: tệp bị thay đổi hoặc hỏng, đã xóa");
            }
            //noinspection ResultOfMethodCallIgnored
            dest.delete();
            if (!part.renameTo(dest)) throw new IOException("không đổi tên được tệp tải về");
            return true;
        } finally {
            c.disconnect();
        }
    }
}
