package dev.vspace.workspace;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.ActivityInfo;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.os.StatFs;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Chuẩn bị file APK trước khi cài: sao chép ra cache, nhận diện XAPK/APKS có đúng 1 APK gốc,
 * kiểm tra ABI (32/64-bit) và dung lượng trống, đọc thông tin để HIỂN THỊ cho người dùng xác nhận
 * (tên, phiên bản, chữ ký SHA-256, quyền nhạy cảm, thành phần hệ thống có thể không chạy được).
 * Gọi trên luồng nền.
 */
final class ApkImporter {

    static final class Prepared {
        File apk;
        String pkg;
        int errorRes;
        int warningRes;
        CharSequence label = "";
        String versionName = "";
        long versionCode;
        long size;
        String certSha256;
        int permCount;
        final List<String> sensitivePerms = new ArrayList<>();
        final List<String> sysComps = new ArrayList<>();
        /** Gói XAPK gốc, chỉ giữ lại khi có OBB cần chép sau khi cài (ObbImporter). */
        File bundle;
        final List<String> obbEntries = new ArrayList<>();
        long obbBytes;
        /** APK này do SplitMerger ghép từ các split rồi được ApkSigner ký lại bằng khóa riêng của máy. */
        boolean merged;

        /** Xóa APK tạm và gói XAPK giữ lại (nếu có). */
        void discard() {
            if (apk != null) {
                //noinspection ResultOfMethodCallIgnored
                apk.delete();
            }
            if (bundle != null) {
                //noinspection ResultOfMethodCallIgnored
                bundle.delete();
            }
        }
    }

    /** Quyền gắn với thành phần cần đăng ký với PackageManager thật → khó chạy trong không gian ảo. */
    private static final Map<String, String> SYSTEM_BOUND = new HashMap<>();

    static {
        SYSTEM_BOUND.put("android.permission.BIND_ACCESSIBILITY_SERVICE", "Accessibility");
        SYSTEM_BOUND.put("android.permission.BIND_VPN_SERVICE", "VPN");
        SYSTEM_BOUND.put("android.permission.BIND_NOTIFICATION_LISTENER_SERVICE", "NotificationListener");
        SYSTEM_BOUND.put("android.permission.BIND_INPUT_METHOD", "Keyboard");
        SYSTEM_BOUND.put("android.permission.BIND_WALLPAPER", "Wallpaper");
        SYSTEM_BOUND.put("android.permission.BIND_AUTOFILL_SERVICE", "Autofill");
        SYSTEM_BOUND.put("android.permission.BIND_QUICK_SETTINGS_TILE", "QuickSettingsTile");
        SYSTEM_BOUND.put("android.permission.BIND_SCREENING_SERVICE", "CallScreening");
        SYSTEM_BOUND.put("android.permission.BIND_NFC_SERVICE", "NFC-HCE");
        SYSTEM_BOUND.put("android.permission.BIND_DEVICE_ADMIN", "DeviceAdmin");
    }

    private ApkImporter() {}

    static Prepared prepare(Context c, Uri uri) {
        Prepared r = new Prepared();
        File dir = new File(c.getCacheDir(), "import");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File raw = new File(dir, System.currentTimeMillis() + "-" + System.nanoTime() % 100000 + ".bin");

        try (InputStream in = c.getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(raw)) {
            copy(in, out);
        } catch (Exception e) {
            raw.delete();
            r.errorRes = R.string.err_copy;
            return r;
        }

        PackageManager pm = c.getPackageManager();
        File apk = raw;
        PackageInfo pi = pm.getPackageArchiveInfo(raw.getAbsolutePath(), 0);
        if (pi == null) {
            // Có thể là XAPK / APKS / APKM: lấy APK gốc, hoặc ghép các split bằng APKEditor nếu jar có sẵn
            File extracted = extractFromBundle(c, raw, dir, r);
            if (r.bundle == null) raw.delete(); // chỉ giữ gói khi có OBB cần chép
            if (extracted == null) {
                r.discard();
                return r; // r.errorRes đã được đặt
            }
            apk = extracted;
            pi = pm.getPackageArchiveInfo(apk.getAbsolutePath(), 0);
            if (pi == null) {
                apk.delete();
                r.discard();
                r.errorRes = r.merged ? R.string.err_merge_invalid : R.string.err_invalid_apk;
                return r;
            }
            r.warningRes = r.merged ? R.string.warn_merged
                    : !r.obbEntries.isEmpty() ? R.string.warn_obb_copy : R.string.warn_bundle_extracted;
        }

        int abiErr = checkAbi(apk);
        if (abiErr != 0) {
            apk.delete();
            r.discard();
            r.errorRes = abiErr;
            return r;
        }
        try {
            long free = new StatFs(c.getFilesDir().getAbsolutePath()).getAvailableBytes();
            long need = Math.max(apk.length() * 3, r.bundle != null ? ObbImporter.requiredBytes(r.obbBytes) : 0);
            if (free < need) {
                apk.delete();
                r.discard();
                r.errorRes = R.string.err_no_space;
                return r;
            }
        } catch (Throwable ignored) {
        }

        r.apk = apk;
        r.pkg = pi.packageName;
        r.size = apk.length();
        fillDetails(pm, apk, r);
        return r;
    }

    // ------------------------------------------------------------------ thông tin để xác nhận

    @SuppressWarnings("deprecation")
    private static void fillDetails(PackageManager pm, File apk, Prepared r) {
        try {
            int flags = PackageManager.GET_PERMISSIONS | PackageManager.GET_SERVICES | PackageManager.GET_RECEIVERS
                    | (Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES
                    : PackageManager.GET_SIGNATURES);
            PackageInfo pi = pm.getPackageArchiveInfo(apk.getAbsolutePath(), flags);
            if (pi == null) return;

            ApplicationInfo a = pi.applicationInfo;
            if (a != null) {
                a.sourceDir = apk.getAbsolutePath();
                a.publicSourceDir = apk.getAbsolutePath();
                r.label = a.loadLabel(pm);
            }
            r.versionName = pi.versionName != null ? pi.versionName : "";
            r.versionCode = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
            r.certSha256 = certSha256(pi);

            if (pi.requestedPermissions != null) {
                r.permCount = pi.requestedPermissions.length;
                for (String name : pi.requestedPermissions) {
                    try {
                        PermissionInfo p = pm.getPermissionInfo(name, 0);
                        if ((p.protectionLevel & PermissionInfo.PROTECTION_MASK_BASE) == PermissionInfo.PROTECTION_DANGEROUS) {
                            r.sensitivePerms.add(shortPerm(name));
                        }
                    } catch (Exception ignored) {
                        // quyền tùy biến / không biết trên máy này
                    }
                }
            }

            Set<String> sys = new LinkedHashSet<>();
            if (pi.services != null) {
                for (ServiceInfo si : pi.services) {
                    String tag = si.permission != null ? SYSTEM_BOUND.get(si.permission) : null;
                    if (tag != null) sys.add(tag);
                }
            }
            if (pi.receivers != null) {
                for (ActivityInfo ri : pi.receivers) {
                    String tag = ri.permission != null ? SYSTEM_BOUND.get(ri.permission) : null;
                    if (tag != null) sys.add(tag);
                }
            }
            r.sysComps.addAll(sys);
        } catch (Throwable ignored) {
        }
    }

    static String shortPerm(String name) {
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(dot + 1) : name;
    }

    @SuppressWarnings("deprecation")
    private static String certSha256(PackageInfo pi) {
        try {
            Signature[] sigs = null;
            if (Build.VERSION.SDK_INT >= 28) {
                SigningInfo si = pi.signingInfo;
                if (si != null) {
                    sigs = si.hasMultipleSigners() ? si.getApkContentsSigners() : si.getSigningCertificateHistory();
                }
            } else {
                sigs = pi.signatures;
            }
            if (sigs == null || sigs.length == 0) return null;
            byte[] h = MessageDigest.getInstance("SHA-256").digest(sigs[0].toByteArray());
            return hex(h);
        } catch (Throwable t) {
            return null;
        }
    }

    /** SHA-256 dạng "AB:CD:…" (viết hoa, phân tách bằng dấu hai chấm). */
    static String hex(byte[] h) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < h.length; i++) {
            if (i > 0) sb.append(':');
            sb.append(String.format(Locale.US, "%02X", h[i] & 0xff));
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ XAPK / ABI

    /**
     * Lấy APK từ gói zip: một APK gốc thì giải nén; có split thì ghép bằng APKEditor (nếu có jar) rồi ký lại (ApkSigner), nếu không thì báo lỗi.
     * Nếu gói có OBB, đặt r.bundle = raw (người gọi KHÔNG xóa raw) để chép OBB sau khi cài.
     */
    private static File extractFromBundle(Context c, File raw, File dir, Prepared r) {
        List<String> names = new ArrayList<>();
        try (ZipFile z = new ZipFile(raw)) {
            for (Enumeration<? extends ZipEntry> e = z.entries(); e.hasMoreElements(); ) names.add(e.nextElement().getName());
        } catch (Exception e) {
            r.errorRes = R.string.err_invalid_apk;
            return null;
        }
        BundlePlan.Plan plan = BundlePlan.plan(names);
        if (plan.apks.isEmpty()) {
            r.errorRes = R.string.err_invalid_apk;
            return null;
        }
        File out = new File(dir, System.currentTimeMillis() + "-" + System.nanoTime() % 100000 + "-x.apk");
        if (plan.split) {
            if (!SplitMerger.available()) {
                r.errorRes = R.string.err_split;
                return null;
            }
            if (!SplitMerger.merge(raw, out)) {
                r.errorRes = R.string.err_merge_failed;
                return null;
            }
            // Core gọi collectCertificates() khi cài nên APK ghép (APKEditor không ký) bị từ chối nếu không ký (G-30, đọc từ source thật).
            String signErr = ApkSigner.signInPlace(out, new File(c.getFilesDir(), "merge-signer"));
            if (signErr != null) {
                LogBuffer.w("VSpaceSign", "không ký được APK ghép: " + signErr);
                //noinspection ResultOfMethodCallIgnored
                out.delete();
                r.errorRes = R.string.err_merge_sign;
                return null;
            }
            r.merged = true;
        } else if (plan.baseCount == 1) {
            String baseEntry = null;
            for (String n : plan.apks) baseEntry = n;
            try (ZipFile z = new ZipFile(raw);
                 InputStream in = z.getInputStream(z.getEntry(baseEntry));
                 OutputStream os = new FileOutputStream(out)) {
                copy(in, os);
            } catch (Exception e) {
                r.errorRes = R.string.err_invalid_apk;
                return null;
            }
        } else {
            r.errorRes = R.string.err_invalid_apk;
            return null;
        }
        if (!plan.obbs.isEmpty()) {
            r.obbEntries.addAll(plan.obbs);
            r.obbBytes = Math.max(0, ObbImporter.totalBytes(raw, plan.obbs));
            r.bundle = raw;
        }
        return out;
    }

    /** 0 = tương thích, 1 = APK chỉ có lib 32-bit mà host 64-bit, 2 = APK chỉ có lib 64-bit mà host 32-bit. */
    static int abiVerdict(Set<String> abis, boolean host64) {
        if (abis.isEmpty()) return 0; // thuần Java
        boolean has64 = abis.contains("arm64-v8a") || abis.contains("x86_64");
        boolean has32 = abis.contains("armeabi-v7a") || abis.contains("armeabi") || abis.contains("x86");
        if (host64 && !has64) return 1;
        if (!host64 && !has32) return 2;
        return 0;
    }

    /** @return 0 nếu tương thích, ngược lại là id chuỗi lỗi. */
    private static int checkAbi(File apk) {
        Set<String> abis = new HashSet<>();
        try (ZipFile z = new ZipFile(apk)) {
            for (Enumeration<? extends ZipEntry> e = z.entries(); e.hasMoreElements(); ) {
                String n = e.nextElement().getName();
                if (!n.startsWith("lib/")) continue;
                String[] parts = n.split("/");
                if (parts.length >= 3) abis.add(parts[1]);
            }
        } catch (Exception ignored) {
        }
        int v = abiVerdict(abis, Process.is64Bit());
        return v == 1 ? R.string.err_abi_need32 : v == 2 ? R.string.err_abi_need64 : 0;
    }

    static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }
}
