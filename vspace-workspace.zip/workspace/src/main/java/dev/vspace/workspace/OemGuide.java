package dev.vspace.workspace;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/**
 * Hướng dẫn theo hãng máy (các ROM Xiaomi/Huawei/Oppo/Vivo/Samsung... tự kill app nền dù đã miễn trừ pin) và
 * phát hiện "miễn trừ pin bị mất sau khi cập nhật hệ thống (OTA)".
 *
 * Nội dung các bước lấy từ kinh nghiệm cộng đồng (dontkillmyapp.com) nên chỉ là [R]: tên menu thay đổi theo phiên bản ROM.
 */
final class OemGuide {
    static final String XIAOMI = "xiaomi";
    static final String HUAWEI = "huawei";
    static final String OPPO = "oppo";
    static final String ONEPLUS = "oneplus";
    static final String VIVO = "vivo";
    static final String SAMSUNG = "samsung";
    static final String ASUS = "asus";
    static final String NOKIA = "nokia";
    static final String MEIZU = "meizu";
    static final String GENERIC = "generic";

    private OemGuide() {}

    // ------------------------------------------------------------------ hàm thuần (có test)

    /** Họ ROM theo Build.MANUFACTURER (không phân biệt hoa thường). */
    static String family(String manufacturer) {
        String m = manufacturer == null ? "" : manufacturer.trim().toLowerCase(Locale.ROOT);
        if (m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")) return XIAOMI;
        if (m.contains("huawei") || m.contains("honor")) return HUAWEI;
        if (m.contains("oneplus")) return ONEPLUS;
        if (m.contains("oppo") || m.contains("realme")) return OPPO;
        if (m.contains("vivo") || m.contains("iqoo")) return VIVO;
        if (m.contains("samsung")) return SAMSUNG;
        if (m.contains("asus")) return ASUS;
        if (m.contains("nokia") || m.contains("hmd")) return NOKIA;
        if (m.contains("meizu")) return MEIZU;
        return GENERIC;
    }

    /** Hãng có ROM nổi tiếng kill app nền mạnh tay (cần hướng dẫn riêng). */
    static boolean isAggressive(String manufacturer) {
        return !GENERIC.equals(family(manufacturer));
    }

    /** Địa chỉ trang hướng dẫn của hãng trên dontkillmyapp.com. */
    static String url(String family) {
        return GENERIC.equals(family) ? "https://dontkillmyapp.com/" : "https://dontkillmyapp.com/" + family;
    }

    /**
     * Miễn trừ pin bị mất sau OTA: đã từng miễn trừ (lưu dấu vân tay bản build lúc đó) nhưng bản build đổi và hiện không còn miễn trừ.
     * @param savedFp   Build.FINGERPRINT lúc còn miễn trừ lần gần nhất (null nếu chưa từng ghi nhận)
     * @param currentFp Build.FINGERPRINT hiện tại
     */
    static boolean otaReminderNeeded(String savedFp, String currentFp, boolean ignoringNow) {
        if (ignoringNow) return false;
        if (savedFp == null || savedFp.isEmpty() || currentFp == null) return false;
        return !savedFp.equals(currentFp);
    }

    // ------------------------------------------------------------------ giao diện

    static int stepsRes(String family) {
        switch (family) {
            case XIAOMI:
                return R.string.oem_xiaomi;
            case HUAWEI:
                return R.string.oem_huawei;
            case OPPO:
                return R.string.oem_oppo;
            case ONEPLUS:
                return R.string.oem_oneplus;
            case VIVO:
                return R.string.oem_vivo;
            case SAMSUNG:
                return R.string.oem_samsung;
            case ASUS:
                return R.string.oem_asus;
            case NOKIA:
                return R.string.oem_nokia;
            case MEIZU:
                return R.string.oem_meizu;
            default:
                return R.string.oem_generic;
        }
    }

    /** Hộp thoại hướng dẫn cho máy hiện tại (có nút mở trang tự khởi động và trang dontkillmyapp.com). */
    static void show(final Activity a) {
        final String fam = family(Build.MANUFACTURER);
        TextView tv = new TextView(a);
        tv.setText(a.getString(R.string.oem_intro, Build.MANUFACTURER, Build.MODEL) + "\n\n" + a.getString(stepsRes(fam)));
        tv.setTextIsSelectable(true);
        tv.setTextSize(14);
        int pad = (int) (16 * a.getResources().getDisplayMetrics().density);
        tv.setPadding(pad, pad, pad, pad);
        ScrollView sv = new ScrollView(a);
        sv.addView(tv);
        new AlertDialog.Builder(a)
                .setTitle(R.string.oem_title)
                .setView(sv)
                .setPositiveButton(R.string.oem_open_autostart, (d, w) -> {
                    if (!PowerHelper.openAutostartSettings(a)) {
                        Toast.makeText(a, R.string.autostart_fallback, Toast.LENGTH_LONG).show();
                    }
                })
                .setNeutralButton(R.string.oem_open_web, (d, w) -> {
                    try {
                        a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url(fam))));
                    } catch (Exception e) {
                        Toast.makeText(a, R.string.oem_no_browser, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.close, null)
                .show();
    }

    // ------------------------------------------------------------------ OTA

    /** Ghi nhận bản build hiện tại khi đang được miễn trừ pin; trả về true nếu cần nhắc người dùng cấp lại (chỉ nhắc 1 lần mỗi bản build). */
    static boolean checkOta(Context c) {
        try {
            boolean ignoring = PowerHelper.isIgnoringBatteryOptimizations(c);
            if (ignoring) {
                Prefs.setExemptFingerprint(c, Build.FINGERPRINT);
                return false;
            }
            if (!Prefs.otaRemind(c)) return false;
            String saved = Prefs.exemptFingerprint(c);
            if (!otaReminderNeeded(saved, Build.FINGERPRINT, false)) return false;
            if (Build.FINGERPRINT.equals(Prefs.otaRemindedFingerprint(c))) return false;
            Prefs.setOtaRemindedFingerprint(c, Build.FINGERPRINT);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
