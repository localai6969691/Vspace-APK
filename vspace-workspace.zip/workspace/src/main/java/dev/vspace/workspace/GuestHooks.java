package dev.vspace.workspace;

import android.app.Activity;
import android.app.Application;
import android.app.PictureInPictureParams;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;

/**
 * Chạy BÊN TRONG tiến trình app ảo (:pN). Được GuestCallback (do scripts/gen_guest_hooks.py sinh từ source của core)
 * gọi khi app ảo khởi tạo Application. Ở đây ta có đối tượng Application THẬT của app ảo nên đăng ký được
 * ActivityLifecycleCallbacks (điều mà SpaceApp của host không làm được: xem tài liệu F-13).
 *
 * Việc làm: báo cho tiến trình chính biết (gói, không gian, pid, activity đang hiển thị), và thực hiện lệnh:
 *  - dim: giữ màn hình bật + độ sáng thấp nhất ngay trên cửa sổ của game (không cần quyền overlay);
 *  - pip: thu nhỏ activity đang hiển thị vào Picture-in-Picture (thử nghiệm);
 *  - boost: nâng ưu tiên luồng chính/luồng render để bộ lập lịch không đẩy xuống nhóm nền (ThreadBoost);
 *  - lowres: giảm độ phân giải render của SurfaceView (setFixedSize; thử nghiệm, đảo ngược được);
 *  - fps: gợi ý tần số khung hình cho Surface của game (Surface.setFrameRate, Android 11+).
 * Mọi lệnh đều chỉ tác động tới cửa sổ/luồng của CHÍNH tiến trình app ảo và hoàn nguyên khi nhận lệnh tắt.
 */
final class GuestHooks {
    private static final String TAG = "VSpaceGuest";
    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static final WeakHashMap<Activity, float[]> SAVED = new WeakHashMap<>(); // {độ sáng gốc, đã có KEEP_SCREEN_ON?}

    private static boolean inited;
    private static IpcClient client;
    private static volatile boolean dimOn;
    private static volatile boolean boostOn;
    private static volatile int lowResPct;
    private static volatile int fpsHz;
    private static int lastBoostCount = -1;
    private static final WeakHashMap<SurfaceView, int[]> SURFACES = new WeakHashMap<>(); // kích thước gốc theo bố cục
    private static final long BOOST_PERIOD_MS = 60_000L;

    /** Luồng game có thể sinh thêm sau khi bắt đầu, nên áp lại định kỳ. */
    private static final Runnable BOOST_TICK = new Runnable() {
        @Override
        public void run() {
            if (!boostOn) return;
            int n = ThreadBoost.apply(Process.THREAD_PRIORITY_DISPLAY);
            if (n != lastBoostCount) {
                lastBoostCount = n;
                sendBoostResult(n);
            }
            UI.postDelayed(this, BOOST_PERIOD_MS);
        }
    };
    private static volatile WeakReference<Activity> resumed = new WeakReference<>(null);

    private GuestHooks() {}

    /** Điểm vào duy nhất từ mã sinh tự động. args: (packageName, processName, Context|Application, userId) hoặc tương tự. */
    static void onEvent(String name, Object[] args) {
        try {
            Application app = null;
            String pkg = null;
            String proc = null;
            int user = 0;
            boolean userSet = false;
            for (Object a : args) {
                if (a instanceof Application && app == null) {
                    app = (Application) a;
                } else if (a instanceof String) {
                    if (pkg == null) pkg = (String) a;
                    else if (proc == null) proc = (String) a;
                } else if (a instanceof Integer && !userSet) {
                    user = (Integer) a;
                    userSet = true;
                }
            }
            if (app == null || pkg == null) return; // sự kiện chưa có Application (ví dụ beforeCreateApplication)
            synchronized (GuestHooks.class) {
                if (inited) return;
                inited = true;
            }
            init(app, pkg, proc != null ? proc : pkg, user);
        } catch (Throwable t) {
            LogBuffer.w(TAG, "onEvent(" + name + ") failed: " + t);
        }
    }

    private static void init(Application app, String pkg, String proc, int user) throws Exception {
        LogBuffer.i(TAG, "init pkg=" + pkg + " proc=" + proc + " user=" + user + " pid=" + Process.myPid());
        app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity a, Bundle b) { }

            @Override
            public void onActivityStarted(Activity a) { }

            @Override
            public void onActivityResumed(Activity a) {
                resumed = new WeakReference<>(a);
                sendAct("resumed", a);
                if (dimOn) applyDim(a);
                scheduleSurfaceTuning(a);
            }

            @Override
            public void onActivityPaused(Activity a) {
                sendAct("paused", a);
            }

            @Override
            public void onActivityStopped(Activity a) { }

            @Override
            public void onActivitySaveInstanceState(Activity a, Bundle b) { }

            @Override
            public void onActivityDestroyed(Activity a) {
                SAVED.remove(a);
                sendAct("destroyed", a);
            }
        });

        JSONObject hello = new JSONObject();
        hello.put("t", "hello");
        hello.put("pid", Process.myPid());
        hello.put("pkg", pkg);
        hello.put("proc", proc);
        hello.put("user", user);
        client = new IpcClient("vspace-ipc-" + hostPackage(app), hello, new IpcClient.CommandHandler() {
            @Override
            public void onCommand(final JSONObject cmd) {
                UI.post(new Runnable() {
                    @Override
                    public void run() {
                        handle(cmd);
                    }
                });
            }
        });
        client.start();
    }

    /** Tên gói của HOST (không phải app ảo): lấy từ Context gốc của SpaceApp. */
    private static String hostPackage(Application guestApp) {
        Application host = SpaceApp.instance;
        return host != null ? host.getPackageName() : guestApp.getPackageName();
    }

    private static void sendAct(String state, Activity a) {
        try {
            IpcClient c = client;
            if (c == null) return;
            JSONObject o = new JSONObject();
            o.put("t", "act");
            o.put("state", state);
            o.put("cls", a.getClass().getName());
            c.send(o.toString());
        } catch (Throwable ignored) {
        }
    }

    private static void handle(JSONObject cmd) {
        String t = cmd.optString("t");
        if ("dim".equals(t)) {
            dimOn = cmd.optBoolean("on");
            Activity a = resumed.get();
            if (a != null) {
                if (dimOn) applyDim(a);
                else clearDim(a);
            }
        } else if ("pip".equals(t)) {
            enterPip();
        } else if ("boost".equals(t)) {
            boolean on = cmd.optBoolean("on");
            UI.removeCallbacks(BOOST_TICK);
            boostOn = on;
            if (on) {
                UI.post(BOOST_TICK);
            } else {
                ThreadBoost.apply(Process.THREAD_PRIORITY_DEFAULT);
                lastBoostCount = -1;
            }
        } else if ("lowres".equals(t)) {
            lowResPct = cmd.optInt("pct", 0);
            Activity a = resumed.get();
            if (a != null) applySurfaceTuning(a);
        } else if ("fps".equals(t)) {
            fpsHz = cmd.optInt("hz", 0);
            Activity a = resumed.get();
            if (a != null) applySurfaceTuning(a);
        }
    }

    private static void sendBoostResult(int n) {
        try {
            IpcClient c = client;
            if (c == null) return;
            JSONObject o = new JSONObject();
            o.put("t", "boostres");
            o.put("n", n);
            c.send(o.toString());
        } catch (Throwable ignored) {
        }
    }

    /** SurfaceView thường chưa có kích thước ngay lúc onResume: áp ngay và áp lại sau 2 giây. */
    private static void scheduleSurfaceTuning(final Activity a) {
        if (lowResPct <= 0 && fpsHz <= 0) return;
        applySurfaceTuning(a);
        UI.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (resumed.get() == a) applySurfaceTuning(a);
            }
        }, 2000);
    }

    private static void collectSurfaces(View v, List<SurfaceView> out) {
        if (v instanceof SurfaceView) out.add((SurfaceView) v);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) collectSurfaces(g.getChildAt(i), out);
        }
    }

    /**
     * Giảm độ phân giải render (setFixedSize: bộ hợp thành phóng lớn lại) và đặt gợi ý tần số khung hình cho Surface của game.
     * Chưa kiểm chứng trên game thật: có game tự đặt lại kích thước hoặc vẽ sai khi surface đổi; tắt lệnh sẽ trả về kích thước theo bố cục.
     */
    private static void applySurfaceTuning(Activity a) {
        try {
            List<SurfaceView> list = new ArrayList<>();
            collectSurfaces(a.getWindow().getDecorView(), list);
            for (SurfaceView sv : list) {
                SurfaceHolder h = sv.getHolder();
                if (lowResPct > 0 && lowResPct < 100) {
                    int[] orig = SURFACES.get(sv);
                    if (orig == null && sv.getWidth() > 0 && sv.getHeight() > 0) {
                        orig = new int[]{sv.getWidth(), sv.getHeight()};
                        SURFACES.put(sv, orig);
                    }
                    if (orig != null) {
                        int[] t = DisplayTuning.scaledSize(orig[0], orig[1], lowResPct);
                        h.setFixedSize(t[0], t[1]);
                    }
                } else if (SURFACES.containsKey(sv)) {
                    h.setSizeFromLayout();
                    SURFACES.remove(sv);
                }
                if (Build.VERSION.SDK_INT >= 30) {
                    try {
                        Surface surface = h.getSurface();
                        if (surface != null && surface.isValid()) {
                            surface.setFrameRate((float) Math.max(0, fpsHz), Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
                        }
                    } catch (Throwable ignored) {
                    }
                }
            }
        } catch (Throwable t) {
            LogBuffer.w(TAG, "applySurfaceTuning failed: " + t);
        }
    }

    private static void applyDim(Activity a) {
        try {
            Window w = a.getWindow();
            WindowManager.LayoutParams lp = w.getAttributes();
            if (!SAVED.containsKey(a)) {
                SAVED.put(a, new float[]{lp.screenBrightness, (lp.flags & WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) != 0 ? 1f : 0f});
            }
            lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_OFF;
            lp.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            w.setAttributes(lp);
        } catch (Throwable t) {
            LogBuffer.w(TAG, "applyDim failed: " + t);
        }
    }

    private static void clearDim(Activity a) {
        try {
            float[] s = SAVED.remove(a);
            if (s == null) return;
            Window w = a.getWindow();
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.screenBrightness = s[0];
            if (s[1] == 0f) lp.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            w.setAttributes(lp);
        } catch (Throwable t) {
            LogBuffer.w(TAG, "clearDim failed: " + t);
        }
    }

    private static void enterPip() {
        String result;
        Activity a = resumed.get();
        if (a == null) {
            result = "khong co activity dang hien thi";
        } else {
            try {
                boolean ok = a.enterPictureInPictureMode(new PictureInPictureParams.Builder().build());
                result = ok ? "ok" : "he thong tu choi";
            } catch (Throwable t) {
                result = t.toString();
            }
        }
        try {
            IpcClient c = client;
            if (c != null) {
                JSONObject o = new JSONObject();
                o.put("t", "pipres");
                o.put("msg", result);
                c.send(o.toString());
            }
        } catch (Throwable ignored) {
        }
    }
}
