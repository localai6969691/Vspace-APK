package dev.vspace.workspace;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Lý do cần lớp này:
 * App ảo chạy trong các tiến trình phụ ":p0".. ":p49" của host. Khi tắt màn hình, activity của
 * app ảo bị stop => tiến trình đó chỉ còn là tiến trình "cached": Android kill nó đầu tiên,
 * hoặc đóng băng (cached app freezer, Android 11+) khiến mạng/CPU của nó ngừng hẳn.
 *
 * Cách xử lý: từ tiến trình chính (đang là foreground service) bind vào một service "stub"
 * nằm trong từng tiến trình :pN đang chạy, với cờ BIND_IMPORTANT. Mức ưu tiên của tiến trình
 * bị bind được nâng lên ngang tiến trình foreground service => không còn là cached.
 *
 * Không cần biết app ảo nào đang nằm ở tiến trình nào: ta quét tiến trình đang chạy rồi ghim hết.
 */
final class ProcessPinner {
    private static final String TAG = "VSpacePinner";
    private static final long SCAN_INTERVAL_MS = 15_000L;
    private static final Pattern GUEST_PROC = Pattern.compile("^.+:p\\d+$");
    /** :pN (app ảo) và :daemon (dịch vụ hệ thống ảo của engine: nếu nó chết/đóng băng thì MỌI app ảo mất dịch vụ). */
    private static final Pattern PIN_PROC = Pattern.compile("^.+:(p\\d+|daemon)$");

    private final Context ctx;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, ServiceConnection> pinned = new HashMap<>();
    private Map<String, ComponentName> stubs;
    private boolean running;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            try {
                scan();
            } catch (Throwable t) {
                LogBuffer.w(TAG, "scan failed: " + t);
            }
            handler.postDelayed(this, SCAN_INTERVAL_MS);
        }
    };

    ProcessPinner(Context context) {
        this.ctx = context.getApplicationContext();
    }

    void start() {
        if (running) return;
        running = true;
        handler.post(tick);
    }

    void stop() {
        running = false;
        handler.removeCallbacks(tick);
        for (String name : new ArrayList<>(pinned.keySet())) drop(name);
        KeepAliveService.pinnedCount = 0;
    }

    private void scan() {
        ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return;

        Map<String, Integer> alive = new HashMap<>();
        List<ActivityManager.RunningAppProcessInfo> procs = am.getRunningAppProcesses();
        if (procs != null) {
            for (ActivityManager.RunningAppProcessInfo p : procs) {
                String n = p.processName;
                if (isPinTarget(ctx.getPackageName(), n)) {
                    alive.put(n, p.pid);
                }
            }
        }

        // Ghim chọn lọc: game đã đăng ký IPC và tắt "Ghim tiến trình" trong hồ sơ thì không ghim (xem shouldPin).
        Set<String> desired = new HashSet<>();
        for (Map.Entry<String, Integer> e : alive.entrySet()) {
            if (wantsPin(e.getKey(), e.getValue())) desired.add(e.getKey());
        }

        for (String name : desired) {
            if (!pinned.containsKey(name)) pin(name);
        }
        for (String name : new ArrayList<>(pinned.keySet())) {
            if (!alive.containsKey(name)) died(name);
            else if (!desired.contains(name)) drop(name); // người dùng vừa tắt ghim cho game này: bỏ ghim, không báo "bị kill"
        }
        KeepAliveService.pinnedCount = pinned.size();
    }

    /** Có nên ghim tiến trình này không: :daemon luôn ghim; :pN đã biết game nào thì theo hồ sơ game đó; chưa biết thì ghim. */
    private boolean wantsPin(String processName, int pid) {
        if (!isGuestProcess(ctx.getPackageName(), processName)) return true;
        GuestRegistry.Info i = GuestRegistry.get(pid);
        if (i == null) return shouldPin(false, true);
        return shouldPin(true, GameProfile.load(ctx, i.pkg, i.user).pin);
    }

    /** Hàm thuần (có test): chỉ không ghim khi biết rõ game đó và người dùng đã tắt ghim cho nó. */
    static boolean shouldPin(boolean registered, boolean profilePin) {
        return !registered || profilePin;
    }

    private void pin(final String processName) {
        ComponentName stub = stubs().get(processName);
        if (stub == null) {
            LogBuffer.w(TAG, "no stub service found for " + processName);
            return;
        }
        ServiceConnection conn = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) { }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                died(processName); // tiến trình đã chết -> bỏ ghim, tránh hệ thống tự dựng lại tiến trình rỗng
            }

            @Override
            public void onBindingDied(ComponentName name) {
                died(processName);
            }

            @Override
            public void onNullBinding(ComponentName name) { }
        };
        try {
            Intent i = new Intent().setComponent(stub);
            // KHÔNG dùng BIND_ABOVE_CLIENT: trên Android 14/15 nó kẹp oom_adj của CLIENT về mức cached
            // (900) khi client không ở foreground => chính app host bị đóng băng dù có foreground service.
            boolean ok = ctx.bindService(i, conn, Context.BIND_AUTO_CREATE | Context.BIND_IMPORTANT);
            if (ok) {
                pinned.put(processName, conn);
            } else {
                ctx.unbindService(conn);
            }
        } catch (Throwable t) {
            LogBuffer.w(TAG, "pin " + processName + " failed: " + t);
        }
        KeepAliveService.pinnedCount = pinned.size();
    }

    /** Tiến trình app ảo biến mất ngoài ý muốn: bỏ ghim và báo cho chế độ game (nếu đang chạy). */
    private void died(String processName) {
        boolean wasPinned = pinned.containsKey(processName);
        drop(processName);
        if (!wasPinned) return;
        if (isGuestProcess(ctx.getPackageName(), processName)) {
            GameModeController.get(ctx).onGuestProcessDied(processName);
        } else {
            LogBuffer.w(TAG, "engine daemon process died: " + processName);
        }
    }

    /** Tiến trình cần ghim: :pN và :daemon của engine. */
    static boolean isPinTarget(String hostPkg, String processName) {
        return processName != null
                && processName.startsWith(hostPkg + ":")
                && PIN_PROC.matcher(processName).matches();
    }

    static boolean isGuestProcess(String hostPkg, String processName) {
        return processName != null
                && processName.startsWith(hostPkg + ":p")
                && GUEST_PROC.matcher(processName).matches();
    }

    private void drop(String processName) {
        ServiceConnection c = pinned.remove(processName);
        if (c != null) {
            try {
                ctx.unbindService(c);
            } catch (Throwable ignored) {
            }
        }
        KeepAliveService.pinnedCount = pinned.size();
    }

    /** processName -> service stub của core nằm trong tiến trình đó (đọc từ manifest đã merge). */
    private Map<String, ComponentName> stubs() {
        if (stubs == null) stubs = discoverStubs(ctx);
        return stubs;
    }

    static Map<String, ComponentName> discoverStubs(Context ctx) {
        Map<String, ComponentName> map = new HashMap<>();
        try {
            PackageInfo pi = ctx.getPackageManager()
                    .getPackageInfo(ctx.getPackageName(), PackageManager.GET_SERVICES);
            if (pi.services != null) {
                // Lượt 1: ưu tiên service tên ProxyService (không phải JobService)
                for (ServiceInfo si : pi.services) {
                    if (!isGuestStub(si)) continue;
                    String simple = si.name.substring(si.name.lastIndexOf('.') + 1);
                    if ((simple.contains("ProxyService") || simple.contains("DaemonService")) && !simple.contains("Job")) {
                        map.put(si.processName, new ComponentName(si.packageName, si.name));
                    }
                }
                // Lượt 2: tiến trình nào chưa có thì lấy service bất kỳ không phải Job
                for (ServiceInfo si : pi.services) {
                    if (!isGuestStub(si) || map.containsKey(si.processName)) continue;
                    if (si.name.contains("Job")) continue;
                    map.put(si.processName, new ComponentName(si.packageName, si.name));
                }
            }
        } catch (Throwable t) {
            LogBuffer.w(TAG, "stub discovery failed: " + t);
        }
        LogBuffer.i(TAG, "discovered stub services for " + map.size() + " guest processes");
        return map;
    }

    private static boolean isGuestStub(ServiceInfo si) {
        return si.enabled
                && si.processName != null
                && PIN_PROC.matcher(si.processName).matches()
                && !si.name.equals(KeepAliveService.class.getName());
    }
}
