package dev.vspace.workspace;

import android.content.Context;
import android.content.SharedPreferences;

/** Chỉ dùng trong tiến trình chính. */
final class Prefs {
    private static final String FILE = "vspace";

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static boolean keepAlive(Context c) { return sp(c).getBoolean("keep_alive", false); }
    static void setKeepAlive(Context c, boolean v) { sp(c).edit().putBoolean("keep_alive", v).apply(); }

    static boolean pinProcesses(Context c) { return sp(c).getBoolean("pin_processes", true); }
    static void setPinProcesses(Context c, boolean v) { sp(c).edit().putBoolean("pin_processes", v).apply(); }

    // ---- phiên chế độ game (commit đồng bộ: phải sống sót khi tiến trình bị kill) ----
    static String session(Context c) { return sp(c).getString("game_session", null); }
    static void setSession(Context c, String json) { sp(c).edit().putString("game_session", json).commit(); }
    static void clearSession(Context c) { sp(c).edit().remove("game_session").commit(); }

    /** Âm lượng media gốc trước khi tắt tiếng; -1 = không có gì cần khôi phục. */
    static int volRestore(Context c) { return sp(c).getInt("vol_restore", -1); }
    static void setVolRestore(Context c, int v) { sp(c).edit().putInt("vol_restore", v).commit(); }

    static String lastReport(Context c) { return sp(c).getString("last_report", null); }
    static void setLastReport(Context c, String s) { sp(c).edit().putString("last_report", s).apply(); }

    static String profile(Context c, String key) { return sp(c).getString("profile." + key, null); }
    static void setProfile(Context c, String key, String json) { sp(c).edit().putString("profile." + key, json).apply(); }

    static boolean setupSeen(Context c) { return sp(c).getBoolean("setup_seen", false); }
    static void setSetupSeen(Context c, boolean v) { sp(c).edit().putBoolean("setup_seen", v).apply(); }

    static long exitLastTs(Context c) { return sp(c).getLong("exit_last_ts", 0L); }
    static void setExitLastTs(Context c, long v) { sp(c).edit().putLong("exit_last_ts", v).apply(); }

    /** Tên hiển thị do người dùng đặt cho một app ảo (null = dùng tên gốc). */
    static String customLabel(Context c, String pkg, int userId) {
        return sp(c).getString("label." + pkg + "." + userId, null);
    }
    static void setCustomLabel(Context c, String pkg, int userId, String label) {
        SharedPreferences.Editor e = sp(c).edit();
        if (label == null || label.isEmpty()) e.remove("label." + pkg + "." + userId);
        else e.putString("label." + pkg + "." + userId, label);
        e.apply();
    }

    /** Thư mục (SAF tree URI) để tự sao lưu dữ liệu app ảo; null = chưa chọn. */
    static String backupTree(Context c) { return sp(c).getString("backup_tree", null); }
    static void setBackupTree(Context c, String uri) {
        SharedPreferences.Editor e = sp(c).edit();
        if (uri == null) e.remove("backup_tree"); else e.putString("backup_tree", uri);
        e.apply();
    }

    static String sched(Context c) { return sp(c).getString("sched", null); }
    static void setSched(Context c, String json) { sp(c).edit().putString("sched", json).apply(); }

    // ---- nhắc nhở / OTA ----
    /** Nhắc khi một phiên chế độ game chạy hơn 12 giờ liên tục (chống quên tắt). */
    static boolean remindLong(Context c) { return sp(c).getBoolean("remind_long", true); }
    static void setRemindLong(Context c, boolean v) { sp(c).edit().putBoolean("remind_long", v).apply(); }

    /** Nhắc cấp lại miễn trừ pin sau khi hệ thống cập nhật (OTA) làm mất nó. */
    static boolean otaRemind(Context c) { return sp(c).getBoolean("ota_remind", true); }
    static void setOtaRemind(Context c, boolean v) { sp(c).edit().putBoolean("ota_remind", v).apply(); }

    /** Build.FINGERPRINT lần gần nhất app còn được miễn trừ pin. */
    static String exemptFingerprint(Context c) { return sp(c).getString("exempt_fp", null); }
    static void setExemptFingerprint(Context c, String v) { sp(c).edit().putString("exempt_fp", v).apply(); }

    /** Build.FINGERPRINT đã nhắc cấp lại miễn trừ (mỗi bản build chỉ nhắc một lần). */
    static String otaRemindedFingerprint(Context c) { return sp(c).getString("ota_reminded_fp", null); }
    static void setOtaRemindedFingerprint(Context c, String v) { sp(c).edit().putString("ota_reminded_fp", v).apply(); }

    // ---- thống kê từng game (SessionStats) ----
    static String stats(Context c, String key) { return sp(c).getString("stats." + key, null); }
    static void setStats(Context c, String key, String text) { sp(c).edit().putString("stats." + key, text).apply(); }
    static void clearStats(Context c) {
        SharedPreferences s = sp(c);
        SharedPreferences.Editor e = s.edit();
        for (String k : s.getAll().keySet()) {
            if (k.startsWith("stats.")) e.remove(k);
        }
        e.apply();
    }

    // ---- sắp xếp / lọc danh sách ----
    static int sortMode(Context c) { return sp(c).getInt("sort_mode", 0); }
    static void setSortMode(Context c, int v) { sp(c).edit().putInt("sort_mode", v).apply(); }
    static boolean onlyRunning(Context c) { return sp(c).getBoolean("only_running", false); }
    static void setOnlyRunning(Context c, boolean v) { sp(c).edit().putBoolean("only_running", v).apply(); }

    // ---- cập nhật trong app (chỉ chạy khi người dùng bật/bấm; mặc định TẮT) ----
    static boolean updateAuto(Context c) { return sp(c).getBoolean("update_auto", false); }
    static void setUpdateAuto(Context c, boolean v) { sp(c).edit().putBoolean("update_auto", v).apply(); }
    static long updateLastCheck(Context c) { return sp(c).getLong("update_last_check", 0L); }
    static void setUpdateLastCheck(Context c, long v) { sp(c).edit().putLong("update_last_check", v).apply(); }
    static String updateSkipTag(Context c) { return sp(c).getString("update_skip_tag", null); }
    static void setUpdateSkipTag(Context c, String v) { sp(c).edit().putString("update_skip_tag", v).apply(); }

    // ---- gợi ý "Truy cập mọi tệp" (Android 11+) đã tắt cho từng app ảo ----
    static boolean storageHintDismissed(Context c, String pkg) { return sp(c).getBoolean("storage_hint." + pkg, false); }
    static void setStorageHintDismissed(Context c, String pkg) { sp(c).edit().putBoolean("storage_hint." + pkg, true).apply(); }
}
