package dev.vspace.workspace;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.net.TrafficStats;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.util.Log;
import android.view.Gravity;
import android.view.WindowManager;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * "Chế độ game": giữ cho game CHẠY LOGIC khi người dùng không nhìn màn hình.
 *
 * Vì sao cần: hầu hết game chạy logic trong vòng lặp khung hình (VSync). Tắt màn hình thật => hết VSync =>
 * logic đứng, dù tiến trình còn sống. Chế độ MODE_FAKE_OFF phủ overlay đen + FLAG_KEEP_SCREEN_ON để activity game
 * vẫn ở trạng thái resumed và vẫn nhận VSync, trong khi màn hình nhìn như tắt (OLED: pixel đen = không phát sáng).
 *
 * Toàn bộ chạy trên main thread của tiến trình chính.
 */
final class GameModeController {
    private static final String TAG = "VSpaceGame";
    static final int OK = 0;
    static final int ERR_OVERLAY = 1;
    private static final long TICK_MS = 30_000L;
    /** Nhắc một lần khi phiên chạy liên tục lâu hơn mức này (chống quên tắt). */
    static final long LONG_SESSION_MS = 12L * 3600_000L;
    static final int MAX_RESTARTS = 5;
    static final long RESTART_MIN_GAP_MS = 60_000L;
    /** Mã onTrimMemory (ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW / RUNNING_CRITICAL). */
    static final int TRIM_RUNNING_LOW = 10;
    static final int TRIM_RUNNING_CRITICAL = 15;
    private static final long MEM_ALERT_GAP_MS = 10 * 60_000L;

    private static GameModeController inst;

    static synchronized GameModeController get(Context c) {
        if (inst == null) inst = new GameModeController(c.getApplicationContext());
        return inst;
    }

    private final Context app;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final CpuSampler cpu = new CpuSampler();

    // ---- trạng thái phiên ----
    volatile boolean active;
    String pkg = "";
    int userId;
    CharSequence label = "";
    GameProfile profile = new GameProfile();
    long startedAt;
    long endAt;
    int batStart = -1;
    int batNow = -1;
    int pluggedNow;
    int lastTempDeci;
    int maxTempDeci;
    int maxThermal;
    long rxStart;
    long txStart;
    int deaths;
    int freezeAlerts;
    int screenOffs;
    int lowCpuStreak;
    long lastFreezeAlert;
    long lastDeathAlert;
    int restarts;
    int memEvents;
    boolean anyPlugged;
    boolean longRemindSent;
    boolean guestSeen;
    long lastRestartAt;
    long lastMemAlert;

    private GameOverlay overlay;
    private BroadcastReceiver screenReceiver;

    private final Runnable showOverlayRunnable = new Runnable() {
        @Override
        public void run() {
            showOverlay();
        }
    };

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!active) return;
            try {
                onTick();
            } catch (Throwable t) {
                LogBuffer.w(TAG, "tick failed: " + t);
            }
            if (active) h.postDelayed(this, TICK_MS);
        }
    };

    private GameModeController(Context app) {
        this.app = app;
    }

    // ------------------------------------------------------------------ vòng đời phiên

    /** @return OK hoặc ERR_OVERLAY (thiếu quyền hiển thị trên ứng dụng khác). */
    int start(String pkg, int userId, CharSequence label, GameProfile p, long forcedEndAt) {
        if (p.mode == GameProfile.MODE_FAKE_OFF && !PowerHelper.canDrawOverlays(app)) return ERR_OVERLAY;
        if (active) stop(app.getString(R.string.reason_restart));
        long now = System.currentTimeMillis();
        long end = forcedEndAt > 0 ? forcedEndAt : (p.maxHours > 0 ? now + p.maxHours * 3600_000L : 0);
        begin(pkg, userId, label, p, now, end, p.delaySec * 1000L);
        return OK;
    }

    /** Gọi khi dịch vụ khởi động lại (bị kill rồi dựng lại): dựng lại overlay nếu phiên còn hiệu lực. */
    void resumeIfNeeded() {
        if (active) return;
        String s = Prefs.session(app);
        if (s == null) {
            restoreVolume(app);
            return;
        }
        try {
            JSONObject o = new JSONObject(s);
            long end = o.optLong("endAt", 0);
            if (end > 0 && System.currentTimeMillis() >= end) {
                Prefs.clearSession(app);
                restoreVolume(app);
                return;
            }
            String p = o.getString("pkg");
            int u = o.optInt("userId", 0);
            GameProfile gp = GameProfile.load(app, p, u);
            if (gp.mode == GameProfile.MODE_FAKE_OFF && !PowerHelper.canDrawOverlays(app)) {
                Prefs.clearSession(app);
                restoreVolume(app);
                return;
            }
            begin(p, u, o.optString("label", p), gp, o.optLong("startedAt", System.currentTimeMillis()), end, 0);
        } catch (Throwable t) {
            Prefs.clearSession(app);
        }
    }

    private void begin(String pkg, int userId, CharSequence label, GameProfile p,
                       long started, long end, long overlayDelayMs) {
        this.pkg = pkg;
        this.userId = userId;
        this.label = label;
        this.profile = p;
        this.startedAt = started;
        this.endAt = end;
        deaths = 0;
        freezeAlerts = 0;
        screenOffs = 0;
        lowCpuStreak = 0;
        lastFreezeAlert = 0;
        lastDeathAlert = 0;
        restarts = 0;
        memEvents = 0;
        anyPlugged = false;
        longRemindSent = false;
        guestSeen = false;
        lastRestartAt = 0;
        lastMemAlert = 0;
        maxTempDeci = 0;
        maxThermal = 0;
        readBattery();
        batStart = batNow;
        int uid = Process.myUid();
        rxStart = Math.max(0L, TrafficStats.getUidRxBytes(uid));
        txStart = Math.max(0L, TrafficStats.getUidTxBytes(uid));
        LogBuffer.i(TAG, "begin pkg=" + pkg + " user=" + userId + " mode=" + p.mode + " end=" + end
                + " delayMs=" + overlayDelayMs);
        active = true;

        Prefs.setKeepAlive(app, true);
        try {
            KeepAliveService.start(app);
        } catch (Throwable t) {
            // Android 12+/15 có thể chặn khởi động FGS từ nền (alarm theo lịch, watchdog): báo người dùng thay vì im lặng.
            LogBuffer.w(TAG, "cannot start keep-alive service: " + t);
            Notifier.alert(app, app.getString(R.string.alert_fgs_blocked_title), app.getString(R.string.alert_fgs_blocked_text));
        }
        if (p.mute) muteMusic();
        if (p.mode == GameProfile.MODE_FAKE_OFF) {
            registerScreenReceiver();
            if (overlayDelayMs > 0) h.postDelayed(showOverlayRunnable, overlayDelayMs);
            else showOverlay();
        } else if (p.mode == GameProfile.MODE_DIM) {
            registerScreenReceiver();
        }
        sendTuning(true); // nếu game chưa chạy, onGuestHello sẽ gửi lại khi nó kết nối
        saveSession();
        h.removeCallbacks(tick);
        h.postDelayed(tick, TICK_MS);
        Notifier.updateForeground(app);
    }

    void stop(String reason) {
        stop(reason, false);
    }

    /**
     * @param automatic true khi phiên kết thúc do điều kiện tự động (hết giờ/pin thấp/quá nóng). Chỉ khi đó mới tự sao lưu
     *                  (sao lưu cần dừng game; không được tự dừng game khi người dùng chủ động thoát chế độ để chơi tiếp).
     */
    void stop(String reason, boolean automatic) {
        if (!active) {
            restoreVolume(app);
            return;
        }
        LogBuffer.i(TAG, "stop reason=" + reason + " automatic=" + automatic + " pkg=" + pkg);
        active = false;
        h.removeCallbacks(tick);
        h.removeCallbacks(showOverlayRunnable);
        hideOverlay();
        sendTuning(false);
        unregisterScreenReceiver();
        restoreVolume(app);
        readBattery();
        SessionStats.Entry entry = buildEntry(reason);
        try {
            SessionStats.record(app, pkg, userId, entry);
        } catch (Throwable t) {
            LogBuffer.w(TAG, "cannot record stats: " + t);
        }
        String report = buildReport(reason, entry);
        Prefs.setLastReport(app, report);
        Prefs.clearSession(app);
        Notifier.alert(app, app.getString(R.string.alert_session_end, label.toString()), report);
        Notifier.updateForeground(app);
        if (automatic && profile.autoBackup) GuestBackup.autoBackupAsync(app, pkg, userId, label.toString());
    }

    // ------------------------------------------------------------------ kiểm tra định kỳ

    private void onTick() {
        long now = System.currentTimeMillis();
        if (endAt > 0 && now >= endAt) {
            stop(app.getString(R.string.reason_timer), true);
            return;
        }
        readBattery();
        if (profile.minBattery > 0 && batNow >= 0 && batNow <= profile.minBattery && pluggedNow == 0) {
            stop(app.getString(R.string.reason_battery), true);
            return;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                int ts = pm.getCurrentThermalStatus();
                maxThermal = Math.max(maxThermal, ts);
                if (profile.stopOnHot && ts >= PowerManager.THERMAL_STATUS_SEVERE) {
                    stop(app.getString(R.string.reason_hot), true);
                    return;
                }
            }
        }
        checkFrozen(now);
        checkGuestGone(now);
        if (shouldRemindLong(now - startedAt, longRemindSent, Prefs.remindLong(app))) {
            longRemindSent = true;
            Notifier.alert(app, app.getString(R.string.alert_long_title),
                    app.getString(R.string.alert_long_text, label.toString(), fmt(now - startedAt)));
        }
        // overlay bị mất (ví dụ vừa cấp lại quyền) -> thử dựng lại
        if (profile.mode == GameProfile.MODE_FAKE_OFF && overlay == null
                && now - startedAt > profile.delaySec * 1000L + 1000L) {
            showOverlay();
        }
        Notifier.updateForeground(app);
    }

    /** Tiến trình app ảo còn sống nhưng CPU ≈ 0 liên tục >= 60 giây => nhiều khả năng game đứng. */
    private void checkFrozen(long now) {
        java.util.Set<Integer> pids = GuestRegistry.pidsFor(pkg, userId);
        double pct = pids.isEmpty() ? cpu.sampleGuestMaxPercent(app) : cpu.sampleForPids(pids);
        if (pct < 0) return;
        if (pct < 0.5) lowCpuStreak++;
        else lowCpuStreak = 0;
        if (lowCpuStreak >= 2 && now - lastFreezeAlert > 10 * 60_000L) {
            lastFreezeAlert = now;
            freezeAlerts++;
            Notifier.alert(app, app.getString(R.string.alert_freeze_title),
                    app.getString(profile.mode == GameProfile.MODE_SAVER
                            ? R.string.alert_freeze_text_saver : R.string.alert_freeze_text_fake));
        }
    }

    /** ProcessPinner gọi khi một tiến trình :pN của app ảo biến mất (bị hệ thống/OEM kill hoặc game crash). */
    void onGuestProcessDied(String proc) {
        if (!active) return;
        deaths++;
        long now = System.currentTimeMillis();
        if (now - lastDeathAlert > 2 * 60_000L) {
            lastDeathAlert = now;
            Notifier.alert(app, app.getString(R.string.alert_guest_died_title),
                    app.getString(R.string.alert_guest_died_text, proc));
        }
    }

    /**
     * Tự mở lại game khi tiến trình của nó biến mất giữa phiên. Chỉ hoạt động khi hook của lõi đã báo game kết nối IPC ít nhất một lần
     * (guestSeen), để không lặp vô hạn khi không biết game có đang chạy hay không. Việc mở từ nền có thể bị Android chặn (F-4, G-8);
     * riêng chế độ "Màn hình đen" đang có cửa sổ overlay hiển thị nên thường được miễn.
     */
    private void checkGuestGone(long now) {
        boolean present = !GuestRegistry.pidsFor(pkg, userId).isEmpty();
        if (present) guestSeen = true;
        if (!shouldRestart(profile.autoRestart, guestSeen, present, restarts, now, lastRestartAt)) return;
        restarts++;
        lastRestartAt = now;
        guestSeen = false;
        LogBuffer.w(TAG, "guest gone, relaunching " + pkg + " (attempt " + restarts + ")");
        boolean ok = Engine.launch(app, pkg, userId);
        Notifier.alert(app, app.getString(R.string.alert_restart_title),
                app.getString(ok ? R.string.alert_restart_text : R.string.alert_restart_fail, label.toString(), restarts));
    }

    /** Hàm thuần (có test): có nên mở lại game lúc này không. */
    static boolean shouldRestart(boolean enabled, boolean wasSeen, boolean presentNow, int restartsDone, long now, long lastRestartAt) {
        return enabled && wasSeen && !presentNow && restartsDone < MAX_RESTARTS && now - lastRestartAt >= RESTART_MIN_GAP_MS;
    }

    /** Hàm thuần (có test): có nên nhắc "phiên đã chạy quá lâu" không. */
    static boolean shouldRemindLong(long elapsedMs, boolean alreadySent, boolean enabled) {
        return enabled && !alreadySent && elapsedMs >= LONG_SESSION_MS;
    }

    /** SpaceApp.onTrimMemory chuyển tiếp: hệ thống báo thiếu RAM (có thể sắp kill tiến trình nền). */
    void onTrimMemory(int level) {
        if (!active || level < TRIM_RUNNING_LOW) return;
        memEvents++;
        long now = System.currentTimeMillis();
        LogBuffer.w(TAG, "onTrimMemory level=" + level + " (events=" + memEvents + ")");
        if (level >= TRIM_RUNNING_CRITICAL && now - lastMemAlert > MEM_ALERT_GAP_MS) {
            lastMemAlert = now;
            Notifier.alert(app, app.getString(R.string.alert_memory_title), app.getString(R.string.alert_memory_text));
        }
    }

    // ------------------------------------------------------------------ hook trong tiến trình app ảo (qua IPC)

    /** App ảo vừa kết nối IPC: nếu đang có phiên cho đúng app đó thì gửi ngay các lệnh tinh chỉnh (dim/boost/fps/lowres). */
    void onGuestHello(GuestRegistry.Info i) {
        if (!active) return;
        if (!i.pkg.equals(pkg) || i.user != userId) return;
        IpcServer.Conn c = i.conn;
        if (c == null) return;
        for (String cmd : tuningCommands(profile, true)) c.send(cmd);
    }

    /**
     * Các lệnh JSON gửi vào tiến trình app ảo theo hồ sơ (hàm thuần, có test). on=false là lệnh hoàn nguyên.
     *  - boost: mọi chế độ (kể cả "Tắt màn hình thật": giúp luồng không bị đẩy xuống nhóm nền);
     *  - dim: chỉ chế độ mờ; fps/lowres: chỉ khi game còn hiển thị (không phải chế độ tắt màn hình thật).
     */
    static List<String> tuningCommands(GameProfile p, boolean on) {
        List<String> r = new ArrayList<>();
        if (p.boost) r.add("{\"t\":\"boost\",\"on\":" + on + "}");
        if (p.mode == GameProfile.MODE_DIM) r.add("{\"t\":\"dim\",\"on\":" + on + "}");
        if (p.mode != GameProfile.MODE_SAVER) {
            if (p.lowRefresh) r.add("{\"t\":\"fps\",\"hz\":" + (on ? 30 : 0) + "}");
            if (p.lowRes) r.add("{\"t\":\"lowres\",\"pct\":" + (on ? GameProfile.LOW_RES_PCT : 0) + "}");
        }
        return r;
    }

    private void sendTuning(boolean on) {
        int n = 0;
        for (String cmd : tuningCommands(profile, on)) n += GuestRegistry.send(pkg, userId, cmd);
        LogBuffer.i(TAG, "tuning " + (on ? "on" : "off") + ": " + n + " message(s) sent");
    }

    /** Yêu cầu app ảo thu nhỏ vào Picture-in-Picture (thử nghiệm). @return số tiến trình nhận lệnh. */
    static int requestPip(String pkg, int user) {
        return GuestRegistry.send(pkg, user, "{\"t\":\"pip\"}");
    }

    // ------------------------------------------------------------------ overlay

    private void showOverlay() {
        if (!active || profile.mode != GameProfile.MODE_FAKE_OFF || overlay != null) return;
        if (!PowerHelper.canDrawOverlays(app)) return;
        try {
            WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
            GameOverlay v = new GameOverlay(app, new GameOverlay.Listener() {
                @Override
                public void onExit() {
                    stop(app.getString(R.string.reason_overlay));
                }

                @Override
                public String info() {
                    return infoText();
                }
            });
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.OPAQUE);
            lp.gravity = Gravity.TOP | Gravity.START;
            // Độ sáng theo cửa sổ: hệ thống tự khôi phục khi overlay bị gỡ (kể cả khi tiến trình chết).
            lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_OFF;
            if (profile.lowRefresh) {
                lp.preferredRefreshRate = 30f; // gợi ý, game có thể vote cao hơn
                int modeId = DisplayTuning.lowRefreshModeId(app, 30f); // mã chế độ cùng độ phân giải, tần số thấp nhất ≥ 30 Hz
                if (modeId != 0) lp.preferredDisplayModeId = modeId;
            }
            if (Build.VERSION.SDK_INT >= 30) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            } else if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            wm.addView(v, lp);
            overlay = v;
        } catch (Throwable t) {
            LogBuffer.e(TAG, "cannot show overlay", t);
        }
    }

    private void hideOverlay() {
        if (overlay == null) return;
        try {
            ((WindowManager) app.getSystemService(Context.WINDOW_SERVICE)).removeViewImmediate(overlay);
        } catch (Throwable ignored) {
        }
        overlay = null;
    }

    private void registerScreenReceiver() {
        if (screenReceiver != null) return;
        screenReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!active || profile.mode == GameProfile.MODE_SAVER) return;
                screenOffs++;
                Notifier.alert(app, app.getString(R.string.alert_screen_off_title),
                        app.getString(R.string.alert_screen_off_text));
            }
        };
        app.registerReceiver(screenReceiver, new IntentFilter(Intent.ACTION_SCREEN_OFF));
    }

    private void unregisterScreenReceiver() {
        if (screenReceiver == null) return;
        try {
            app.unregisterReceiver(screenReceiver);
        } catch (Throwable ignored) {
        }
        screenReceiver = null;
    }

    // ------------------------------------------------------------------ âm lượng

    private void muteMusic() {
        try {
            AudioManager am = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return;
            // Chỉ lưu giá trị gốc một lần để start lại không ghi đè bằng 0.
            if (Prefs.volRestore(app) < 0) Prefs.setVolRestore(app, am.getStreamVolume(AudioManager.STREAM_MUSIC));
            am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
        } catch (Throwable t) {
            LogBuffer.w(TAG, "mute failed: " + t);
        }
    }

    static void restoreVolume(Context c) {
        try {
            int v = Prefs.volRestore(c);
            if (v < 0) return;
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
            Prefs.setVolRestore(c, -1);
        } catch (Throwable t) {
            LogBuffer.w(TAG, "restore volume failed: " + t);
        }
    }

    // ------------------------------------------------------------------ tiện ích

    private void readBattery() {
        Intent b = app.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b == null) return;
        int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        batNow = (level >= 0 && scale > 0) ? level * 100 / scale : -1;
        pluggedNow = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        if (pluggedNow != 0) anyPlugged = true;
        lastTempDeci = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
        maxTempDeci = Math.max(maxTempDeci, lastTempDeci);
    }

    private void saveSession() {
        try {
            JSONObject o = new JSONObject();
            o.put("pkg", pkg);
            o.put("userId", userId);
            o.put("label", label.toString());
            o.put("startedAt", startedAt);
            o.put("endAt", endAt);
            Prefs.setSession(app, o.toString());
        } catch (Throwable ignored) {
        }
    }

    static String fmt(long ms) {
        long m = Math.max(0, ms) / 60_000L;
        return (m / 60) + "h " + (m % 60) + "m";
    }

    private String batText() {
        return batNow >= 0 ? batNow + "%" : "?";
    }

    String shortStatus() {
        long now = System.currentTimeMillis();
        String remain = endAt > 0 ? fmt(endAt - now) : "\u221e";
        return app.getString(R.string.status_game_fmt, label.toString(), remain, batText(), lastTempDeci / 10.0);
    }

    private String infoText() {
        long now = System.currentTimeMillis();
        String remain = endAt > 0 ? fmt(endAt - now) : "\u221e";
        return app.getString(R.string.overlay_info, label.toString(), fmt(now - startedAt), remain,
                batText(), lastTempDeci / 10.0);
    }

    private SessionStats.Entry buildEntry(String reason) {
        SessionStats.Entry e = new SessionStats.Entry();
        e.start = startedAt;
        e.durMs = System.currentTimeMillis() - startedAt;
        e.batStart = batStart;
        e.batEnd = batNow;
        e.maxTempDeci = maxTempDeci;
        e.maxThermal = maxThermal;
        e.deaths = deaths;
        e.freezes = freezeAlerts;
        e.restarts = restarts;
        e.memEvents = memEvents;
        e.plugged = anyPlugged;
        e.mode = profile.mode;
        e.reason = reason;
        return e;
    }

    private String buildReport(String reason, SessionStats.Entry entry) {
        long now = System.currentTimeMillis();
        int uid = Process.myUid();
        long rx = Math.max(0L, TrafficStats.getUidRxBytes(uid) - rxStart);
        long tx = Math.max(0L, TrafficStats.getUidTxBytes(uid) - txStart);
        long mb = (rx + tx) / (1024 * 1024);
        double rate = SessionStats.drainPerHour(entry);
        String rateText = rate >= 0 ? String.format(java.util.Locale.US, "%.1f", rate)
                : app.getString(anyPlugged ? R.string.rate_plugged : R.string.rate_unknown);
        return app.getString(R.string.report_fmt, label.toString(), fmt(now - startedAt),
                batStart >= 0 ? batStart + "%" : "?", batText(), maxTempDeci / 10.0, mb,
                deaths, freezeAlerts, screenOffs, reason, rateText, restarts, memEvents);
    }
}
