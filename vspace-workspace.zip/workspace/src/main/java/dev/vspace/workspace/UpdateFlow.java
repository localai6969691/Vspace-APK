package dev.vspace.workspace;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Process;
import android.provider.Settings;
import android.widget.TextView;

import java.io.File;

/**
 * Luồng cập nhật trong app (giao diện + luồng nền); logic mạng/kiểm tra nằm ở UpdateChecker. Chỉ chạy khi người dùng bấm
 * nút hoặc đã bật "tự kiểm tra" (mặc định tắt). Kho GitHub lấy từ meta-data của manifest (CI truyền -PupdateRepo=owner/repo);
 * trống thì tính năng tắt hẳn và không có yêu cầu mạng nào.
 */
final class UpdateFlow {
    private static final String TAG = "VSpaceUpdate";
    static final String META_REPO = "dev.vspace.update_repo";
    private static final String APK_NAME = "vspace-update.apk";
    private static final long AUTO_INTERVAL_MS = 24L * 60 * 60 * 1000;

    private UpdateFlow() {}

    interface Callback {
        /** Gọi trên luồng giao diện. error != null khi lỗi; còn lại r luôn khác null. */
        void done(UpdateChecker.Release r, String error);
    }

    /** "owner/repo" từ manifest, hoặc null nếu chưa cấu hình. */
    static String repo(Context c) {
        try {
            ApplicationInfo ai = c.getPackageManager().getApplicationInfo(c.getPackageName(), PackageManager.GET_META_DATA);
            String r = ai.metaData != null ? ai.metaData.getString(META_REPO) : null;
            return UpdateChecker.validRepo(r) ? r : null;
        } catch (Throwable t) {
            return null;
        }
    }

    static String currentVersion(Context c) {
        try {
            String v = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
            return v != null ? v : "0";
        } catch (Throwable t) {
            return "0";
        }
    }

    private static String userAgent(Context c) {
        return "VSpace/" + currentVersion(c);
    }

    /** Hỏi GitHub bản mới nhất (luồng nền), trả kết quả trên luồng giao diện. */
    static void check(final Activity a, final Callback cb) {
        final String repo = repo(a);
        if (repo == null) {
            cb.done(null, a.getString(R.string.update_no_repo));
            return;
        }
        Prefs.setUpdateLastCheck(a, System.currentTimeMillis());
        new Thread(() -> {
            UpdateChecker.Release r = null;
            String err = null;
            try {
                r = UpdateChecker.fetchLatest(repo, userAgent(a));
            } catch (Throwable t) {
                err = String.valueOf(t.getMessage() != null ? t.getMessage() : t);
                LogBuffer.w(TAG, "check failed: " + t);
            }
            final UpdateChecker.Release fr = r;
            final String fe = err;
            a.runOnUiThread(() -> {
                if (!a.isFinishing()) cb.done(fr, fe);
            });
        }, "vspace-update-check").start();
    }

    /** Có nên tự kiểm tra lúc mở app không (đã bật, có kho, quá 24 giờ kể từ lần trước). */
    static boolean autoCheckDue(Context c) {
        return Prefs.updateAuto(c) && repo(c) != null
                && System.currentTimeMillis() - Prefs.updateLastCheck(c) > AUTO_INTERVAL_MS;
    }

    // ------------------------------------------------------------------ giao diện

    static void showResult(final Activity a, final UpdateChecker.Release r) {
        final String cur = currentVersion(a);
        if (!UpdateChecker.isNewer(r.tag, cur)) {
            new AlertDialog.Builder(a).setTitle(R.string.update_title)
                    .setMessage(a.getString(R.string.update_latest, cur, r.tag))
                    .setPositiveButton(R.string.close, null).show();
            return;
        }
        final UpdateChecker.Asset asset = UpdateChecker.pickAsset(r, Process.is64Bit());
        String notes = r.body.length() > 1500 ? r.body.substring(0, 1500) + "…" : r.body;
        StringBuilder msg = new StringBuilder(a.getString(R.string.update_available, r.tag, cur));
        if (!notes.isEmpty()) msg.append("\n\n").append(notes);
        if (asset != null) {
            msg.append("\n\n").append(a.getString(R.string.update_asset, asset.name, asset.size / (1024 * 1024)));
            msg.append("\n").append(a.getString(asset.sha256 != null ? R.string.update_sha_ok : R.string.update_sha_missing));
        } else {
            msg.append("\n\n").append(a.getString(R.string.update_no_asset));
        }
        AlertDialog.Builder b = new AlertDialog.Builder(a).setTitle(R.string.update_title).setMessage(msg.toString())
                .setNeutralButton(R.string.update_open_page, (d, w) -> openPage(a, r.pageUrl))
                .setNegativeButton(R.string.update_skip, (d, w) -> Prefs.setUpdateSkipTag(a, r.tag));
        if (asset != null) b.setPositiveButton(R.string.update_download, (d, w) -> confirmDownload(a, asset));
        b.show();
    }

    private static void openPage(Activity a, String url) {
        if (url == null || !url.startsWith("https://github.com/")) return;
        try {
            a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Throwable t) {
            LogBuffer.w(TAG, "open page failed: " + t);
        }
    }

    private static void confirmDownload(final Activity a, final UpdateChecker.Asset asset) {
        if (asset.sha256 != null) {
            download(a, asset);
            return;
        }
        new AlertDialog.Builder(a).setTitle(R.string.update_title).setMessage(R.string.update_nosha_confirm)
                .setPositiveButton(R.string.update_download, (d, w) -> download(a, asset))
                .setNegativeButton(android.R.string.cancel, null).show();
    }

    private static void download(final Activity a, final UpdateChecker.Asset asset) {
        final TextView tv = new TextView(a);
        int pad = (int) (20 * a.getResources().getDisplayMetrics().density);
        tv.setPadding(pad, pad, pad, pad);
        tv.setText(R.string.update_downloading);
        final boolean[] cancelled = {false};
        final AlertDialog dlg = new AlertDialog.Builder(a).setTitle(R.string.update_title).setView(tv)
                .setCancelable(false)
                .setNegativeButton(android.R.string.cancel, (d, w) -> cancelled[0] = true).show();
        final File dest = new File(ShareProvider.dir(a), APK_NAME);
        new Thread(() -> {
            String err = null;
            boolean ok = false;
            try {
                ok = UpdateChecker.download(dest, asset, userAgent(a), (done, total) -> {
                    final String s = a.getString(R.string.update_progress, done / (1024 * 1024), total > 0 ? total / (1024 * 1024) : 0);
                    a.runOnUiThread(() -> tv.setText(s));
                    return !cancelled[0];
                });
            } catch (Throwable t) {
                err = String.valueOf(t.getMessage() != null ? t.getMessage() : t);
                LogBuffer.w(TAG, "download failed: " + t);
            }
            final boolean fok = ok;
            final String fe = err;
            a.runOnUiThread(() -> {
                try {
                    dlg.dismiss();
                } catch (Throwable ignored) {
                }
                if (a.isFinishing()) return;
                if (fe != null) {
                    new AlertDialog.Builder(a).setTitle(R.string.update_title)
                            .setMessage(a.getString(R.string.update_failed, fe))
                            .setPositiveButton(R.string.close, null).show();
                } else if (fok) {
                    install(a, dest);
                }
            });
        }, "vspace-update-dl").start();
    }

    private static void install(final Activity a, File apk) {
        if (!a.getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(a).setTitle(R.string.update_title).setMessage(R.string.update_need_unknown_sources)
                    .setPositiveButton(R.string.update_open_settings, (d, w) -> {
                        try {
                            a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                    Uri.parse("package:" + a.getPackageName())));
                        } catch (Throwable t) {
                            LogBuffer.w(TAG, "open unknown sources settings failed: " + t);
                        }
                    })
                    .setNegativeButton(android.R.string.cancel, null).show();
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(ShareProvider.uriFor(a, apk.getName()), "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(i);
        } catch (Throwable t) {
            LogBuffer.w(TAG, "install intent failed: " + t);
            new AlertDialog.Builder(a).setTitle(R.string.update_title)
                    .setMessage(a.getString(R.string.update_failed, String.valueOf(t)))
                    .setPositiveButton(R.string.close, null).show();
        }
    }
}
