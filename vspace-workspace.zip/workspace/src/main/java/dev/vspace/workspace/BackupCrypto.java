package dev.vspace.workspace;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Mã hóa bản sao lưu TRƯỚC KHI nó rời khỏi bộ nhớ riêng của app (xuất qua Storage Access Framework ở
 * MainActivity.doBackup/doRestoreFrom — người dùng chọn lưu ở Tải xuống, Drive, thẻ nhớ…).
 *
 * KHÔNG nhầm với việc "mã hóa dữ liệu app ảo trong máy" mà phiên 7 đã từ chối: trong máy, guest và host vẫn chung
 * UID kernel nên mã hóa tại chỗ không tạo cách ly thật (lý do đó vẫn đúng, không đổi). Lớp này giải quyết một vấn đề
 * KHÁC: một khi file .zip rời khỏi thư mục riêng của app, bất cứ app nào có quyền đọc bộ nhớ dùng chung, hoặc dịch
 * vụ đồng bộ đám mây, đều đọc được dữ liệu riêng của app ảo bên trong nó (mật khẩu đã lưu, token đăng nhập, ảnh…).
 * Với file đã rời máy, AES-GCM + khóa trong AndroidKeyStore là biện pháp thật, không phải cảm giác an toàn giả.
 *
 * Khóa: AES-256-GCM, sinh MỘT LẦN trong AndroidKeyStore (phần cứng bảo mật nếu máy có, không bao giờ xuất ra được
 * dạng byte), không gắn sinh trắc học (setUserAuthenticationRequired mặc định false) để khôi phục không cần mở khóa
 * lại. Hệ quả PHẢI nói rõ với người dùng trước khi bật: khóa gắn với CÀI ĐẶT ứng dụng này trên CHÍNH máy này — gỡ
 * cài đặt hoặc đổi máy thì mọi file đã mã hóa theo cách này KHÔNG THỂ mở lại, kể cả bởi chính Workspace.
 *
 * Định dạng file: 8 byte "VSPACEE1" + 1 byte độ dài IV + IV (12 byte, GCM chuẩn) + xyz là bản mã (gồm cả thẻ xác
 * thực 16 byte GCM do Cipher tự nối vào). Magic được chọn để không bao giờ trùng 4 byte đầu thật của ZIP (PK\3\4),
 * nên wrapDecrypt phân biệt được file cũ (chưa mã hóa, từ trước khi có tính năng này) và file mới, không cần cờ
 * riêng — người dùng phục hồi file cũ vẫn chạy được, không hỏi gì thêm.
 */
final class BackupCrypto {
    private static final String ALIAS = "vspace-backup-key";
    private static final byte[] MAGIC = "VSPACEE1".getBytes(Charset.forName("US-ASCII"));
    private static final int IV_LEN = 12;
    private static final int GCM_TAG_BITS = 128;

    private BackupCrypto() {}

    private static SecretKey keyOrCreate() throws GeneralSecurityException, IOException {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) {
            KeyStore.Entry e = ks.getEntry(ALIAS, null);
            if (e instanceof KeyStore.SecretKeyEntry) return ((KeyStore.SecretKeyEntry) e).getSecretKey();
            ks.deleteEntry(ALIAS); // bị hỏng/sai loại entry: sinh lại bên dưới thay vì kẹt cứng
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return kg.generateKey();
    }

    /** Khóa đã tồn tại hay AndroidKeyStore khả dụng trên máy này (vài máy cũ/giả lập có thể không hỗ trợ đầy đủ). */
    static boolean available() {
        try {
            keyOrCreate();
            return true;
        } catch (Throwable t) {
            LogBuffer.w("VSpaceCrypto", "AndroidKeyStore không dùng được: " + t);
            return false;
        }
    }

    /**
     * Bọc OutputStream đích (ví dụ từ SAF) để mọi byte ghi vào đều được mã hóa. Ghi header (magic + IV) thẳng vào
     * `out` trước, KHÔNG qua mã hóa (IV không cần giữ bí mật). Đóng stream trả về sẽ tự đóng luôn `out`.
     */
    static OutputStream wrapEncrypt(OutputStream out) throws GeneralSecurityException, IOException {
        return wrapEncrypt(out, keyOrCreate());
    }

    /** Overload nhận thẳng khóa: tách riêng để BackupCryptoTest kiểm được định dạng file trên JVM thường (không có
     * provider "AndroidKeyStore"), dùng một SecretKey AES tạo bằng javax.crypto.KeyGenerator thuần thay cho Keystore. */
    static OutputStream wrapEncrypt(OutputStream out, SecretKey key) throws GeneralSecurityException, IOException {
        byte[] iv = new byte[IV_LEN];
        new SecureRandom().nextBytes(iv);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        out.write(MAGIC);
        out.write(IV_LEN);
        out.write(iv);
        return new CipherOutputStream(out, c);
    }

    /**
     * Bọc InputStream nguồn: nếu 8 byte đầu là magic của lớp này thì giải mã; nếu không (file cũ, hoặc người dùng
     * đưa thẳng một .zip không mã hóa) thì trả lại nguyên vẹn luồng gốc (đã lùi 8 byte đã đọc thử, không mất dữ liệu).
     */
    static InputStream wrapDecrypt(InputStream in) throws GeneralSecurityException, IOException {
        return wrapDecrypt(in, keyOrCreate());
    }

    /** Overload nhận thẳng khóa (xem ghi chú ở wrapEncrypt(OutputStream, SecretKey) — dùng cho test trên JVM). */
    static InputStream wrapDecrypt(InputStream in, SecretKey key) throws GeneralSecurityException, IOException {
        PushbackInputStream pb = new PushbackInputStream(in, MAGIC.length);
        byte[] head = new byte[MAGIC.length];
        int n = readFully(pb, head);
        if (n < head.length || !Arrays.equals(head, MAGIC)) {
            if (n > 0) pb.unread(head, 0, n);
            return pb;
        }
        int ivLen = pb.read();
        if (ivLen <= 0 || ivLen > 32) throw new IOException("độ dài IV không hợp lệ: " + ivLen);
        byte[] iv = new byte[ivLen];
        if (readFully(pb, iv) != ivLen) throw new IOException("file mã hóa bị cắt cụt (thiếu IV)");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return new CipherInputStream(pb, c);
    }

    /** true nếu stream bắt đầu bằng magic của lớp này (dùng để quyết định hiển thị gì trước khi thật sự giải mã). */
    static boolean looksEncrypted(byte[] first8Bytes) {
        return first8Bytes != null && first8Bytes.length >= MAGIC.length
                && Arrays.equals(Arrays.copyOf(first8Bytes, MAGIC.length), MAGIC);
    }

    /** True nếu lỗi là do khóa không khớp (file mã hóa trên máy khác) hoặc file bị sửa/hỏng (thẻ xác thực GCM sai). */
    static boolean isKeyOrIntegrityFailure(Throwable t) {
        for (Throwable c = t; c != null; c = c.getCause()) {
            if (c instanceof javax.crypto.AEADBadTagException || c instanceof javax.crypto.BadPaddingException) return true;
        }
        return false;
    }

    private static int readFully(InputStream in, byte[] buf) throws IOException {
        int off = 0;
        while (off < buf.length) {
            int r = in.read(buf, off, buf.length - off);
            if (r < 0) break;
            off += r;
        }
        return off;
    }
}
