package dev.vspace.workspace;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Debug;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Theo dõi tài nguyên từng tiến trình của workspace (đề xuất "pin/RAM từng guest"): RAM (PSS), CPU, mức ưu tiên, và game nào ở tiến trình nào
 * (nhờ sổ pid của IPC). Android không cho app thường đọc pin tiêu thụ theo tiến trình, nên CPU được dùng làm chỉ số thay thế
 * (tỷ lệ CPU ≈ tỷ lệ năng lượng của phần xử lý; KHÔNG gồm GPU/mạng). Có chờ đo CPU => không gọi trên main thread.
 */
final class GuestMonitor {

    static final class Row {
        String proc = "";
        int pid;
        int importance;
        long pssKb = -1;
        double cpu = -1;
        String pkg = "";
        int user;
        boolean registered;
        boolean guest;
    }

    private GuestMonitor() {}

    /** Hàng nặng nhất trước (PSS giảm dần). */
    static final Comparator<Row> BY_PSS = new Comparator<Row>() {
        @Override
        public int compare(Row a, Row b) {
            return Long.compare(b.pssKb, a.pssKb);
        }
    };

    static List<Row> collect(Context c, long cpuWindowMs) {
        List<Row> rows = new ArrayList<>();
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> ps = am != null ? am.getRunningAppProcesses() : null;
        if (ps == null) return rows;
        Map<Integer, Row> byPid = new HashMap<>();
        for (ActivityManager.RunningAppProcessInfo p : ps) {
            if (p.processName == null || !p.processName.startsWith(c.getPackageName())) continue;
            Row r = new Row();
            r.proc = p.processName;
            r.pid = p.pid;
            r.importance = p.importance;
            r.guest = ProcessPinner.isGuestProcess(c.getPackageName(), p.processName);
            GuestRegistry.Info i = GuestRegistry.get(p.pid);
            if (i != null) {
                r.registered = true;
                r.pkg = i.pkg;
                r.user = i.user;
            }
            byPid.put(p.pid, r);
            rows.add(r);
        }
        if (rows.isEmpty()) return rows;
        try {
            int[] pids = new int[rows.size()];
            for (int k = 0; k < pids.length; k++) pids[k] = rows.get(k).pid;
            Debug.MemoryInfo[] mi = am.getProcessMemoryInfo(pids);
            if (mi != null) {
                for (int k = 0; k < mi.length && k < pids.length; k++) byPid.get(pids[k]).pssKb = mi[k].getTotalPss();
            }
        } catch (Throwable t) {
            LogBuffer.w("VSpaceMonitor", "getProcessMemoryInfo failed: " + t);
        }
        Map<Integer, Double> cpu = CpuSampler.measurePids(byPid.keySet(), cpuWindowMs);
        for (Map.Entry<Integer, Double> e : cpu.entrySet()) byPid.get(e.getKey()).cpu = e.getValue();
        Collections.sort(rows, BY_PSS);
        return rows;
    }

    static long totalPssKb(List<Row> rows) {
        long t = 0;
        for (Row r : rows) {
            if (r.pssKb > 0) t += r.pssKb;
        }
        return t;
    }

    /** Tổng CPU% của các hàng (100 = 1 lõi). */
    static double totalCpu(List<Row> rows) {
        double t = 0;
        for (Row r : rows) {
            if (r.cpu > 0) t += r.cpu;
        }
        return t;
    }

    /** Tỷ lệ CPU của một hàng trong tổng CPU của workspace (0..100), -1 nếu không có số liệu. */
    static double cpuShare(Row r, double total) {
        if (r.cpu < 0 || total <= 0) return -1;
        return Math.min(100.0, r.cpu / total * 100.0);
    }

    static String describe(Context c, List<Row> rows) {
        if (rows.isEmpty()) return c.getString(R.string.mon_none);
        double totalCpu = totalCpu(rows);
        StringBuilder sb = new StringBuilder();
        sb.append(c.getString(R.string.mon_total, totalPssKb(rows) / 1024, String.format(Locale.US, "%.1f", totalCpu))).append("\n\n");
        for (Row r : rows) {
            String who = r.registered ? r.pkg + " (" + c.getString(R.string.space_n, r.user + 1) + ")"
                    : (r.guest ? c.getString(R.string.mon_unknown_guest) : c.getString(R.string.mon_engine));
            double share = cpuShare(r, totalCpu);
            sb.append(c.getString(R.string.mon_row, r.proc, r.pid, Diagnostics.importanceName(r.importance),
                    r.pssKb >= 0 ? String.valueOf(r.pssKb / 1024) : "?",
                    r.cpu >= 0 ? String.format(Locale.US, "%.1f", r.cpu) : "?",
                    share >= 0 ? String.format(Locale.US, "%.0f", share) : "?", who)).append("\n\n");
        }
        sb.append(c.getString(R.string.mon_note));
        return sb.toString();
    }
}
