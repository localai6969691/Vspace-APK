package dev.vspace.workspace;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;

/**
 * Foreground service giữ cho CẢ UID của app (host + mọi app ảo) ở trạng thái "đang chạy":
 *  - thông báo ongoing  -> hệ thống không coi app là cached/idle
 *  - PARTIAL_WAKE_LOCK  -> CPU không ngủ khi tắt màn hình
 *  - WifiLock           -> Wi-Fi không bị hạ công suất khi tắt màn hình
 *  - ProcessPinner      -> bind vào từng tiến trình :pN đang chứa app ảo để chúng không bị xếp vào nhóm "cached"
 *  - Watchdog (alarm)   -> dựng lại dịch vụ nếu bị hệ thống/OEM kill
 *  - GameModeController -> overlay đen + giữ màn hình bật cho game chạy theo vòng lặp khung hình
 *
 * Lưu ý: giữ TIẾN TRÌNH sống KHÔNG đủ để game chạy logic khi tắt màn hình; xem GameModeController.
 */
public class KeepAliveService extends Service {
    private static final String TAG = "VSpaceKeepAlive";

    static final String ACTION_STOP = "dev.vspace.workspace.action.STOP";
    static final String ACTION_STOP_GAME = "dev.vspace.workspace.action.STOP_GAME";

    private static final long WAKELOCK_TIMEOUT_MS = 10 * 60 * 1000L;
    private static final long RENEW_INTERVAL_MS = 5 * 60 * 1000L;

    /** Trạng thái để UI hiển thị (cùng tiến trình chính). */
    static volatile boolean running;
    static volatile int pinnedCount;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;
    private ProcessPinner pinner;
    private ConnectivityManager.NetworkCallback netCb;

    private final Runnable renew = new Runnable() {
        @Override
        public void run() {
            acquireLocks();
            Prefs.setLastAlive(KeepAliveService.this, System.currentTimeMillis());   // nhịp "còn sống" cho KillWatch
            handler.postDelayed(this, RENEW_INTERVAL_MS);
        }
    };

    static void start(Context c) {
        c.startForegroundService(new Intent(c, KeepAliveService.class));
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, KeepAliveService.class));
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Notifier.ensureChannels(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_STOP.equals(action)) {
            GameModeController.get(this).stop(getString(R.string.reason_notification));
            Prefs.setKeepAlive(this, false);
            Scheduler.cancelWatchdog(this);
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }

        LogBuffer.i(TAG, "onStartCommand action=" + action + " pin=" + Prefs.pinProcesses(this));
        if (!running) detectKilled();   // lần khởi động này có phải sau khi bị hệ thống/OEM giết giữa chừng không
        enterForeground();
        running = true;
        Prefs.setLastAlive(this, System.currentTimeMillis());
        watchNetwork();

        GameModeController gm = GameModeController.get(this);
        if (ACTION_STOP_GAME.equals(action)) {
            gm.stop(getString(R.string.reason_notification));
        }

        acquireLocks();
        handler.removeCallbacks(renew);
        handler.postDelayed(renew, RENEW_INTERVAL_MS);

        if (pinner == null) pinner = new ProcessPinner(getApplicationContext());
        if (Prefs.pinProcesses(this)) {
            pinner.start();
        } else {
            pinner.stop();
            pinnedCount = 0;
        }

        Scheduler.armWatchdog(this);
        if (!ACTION_STOP_GAME.equals(action)) gm.resumeIfNeeded();
        Notifier.updateForeground(this);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        pinnedCount = 0;
        handler.removeCallbacksAndMessages(null);
        unwatchNetwork();
        if (pinner != null) pinner.stop();
        releaseLocks();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ------------------------------------------------------------------

    /** So nhịp cuối với hiện tại: nếu mất > 2 chu kỳ trong cùng một lần bật máy => bị hệ thống/OEM giết, báo người dùng. */
    private void detectKilled() {
        try {
            long now = System.currentTimeMillis();
            long boot = now - SystemClock.elapsedRealtime();
            long last = Prefs.lastAlive(this);
            if (KillWatch.looksKilled(Prefs.keepAlive(this), last, now, boot, RENEW_INTERVAL_MS)) {
                long min = KillWatch.gapMinutes(last, now);
                LogBuffer.w(TAG, "dịch vụ giữ nền bị dừng ngoài ý muốn ~" + min + " phút (OEM kill / Buộc dừng?)");
                String text = getString(R.string.alert_killed_text, min);
                int causeRes = causeNote(ExitReasons.latestCause(this));
                if (causeRes != 0) text = text + " " + getString(causeRes);
                Notifier.alert(this, getString(R.string.alert_killed_title), text);
            }
        } catch (Throwable t) {
            LogBuffer.w(TAG, "detectKilled failed: " + t);
        }
    }

    private static int causeNote(ExitReasons.Cause c) {
        switch (c) {
            case USER: return R.string.alert_cause_user;
            case FROZEN: return R.string.alert_cause_frozen;
            case MEMORY: return R.string.alert_cause_memory;
            case SIGNAL: return R.string.alert_cause_signal;
            case CRASH: return R.string.alert_cause_crash;
            default: return 0;   // OTHER / NONE: không đoán
        }
    }

    /** Khi mạng (Wi-Fi/4G) trở lại: gia hạn khóa, quét lại ghim, làm mới thông báo — game online thường mất kết nối ở đúng lúc này. */
    private void watchNetwork() {
        if (netCb != null) return;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return;
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    handler.post(() -> {
                        if (!running) return;
                        LogBuffer.i(TAG, "mạng trở lại: gia hạn khóa + quét lại ghim");
                        acquireLocks();
                        if (pinner != null && Prefs.pinProcesses(KeepAliveService.this)) pinner.refreshNow();
                        Notifier.updateForeground(KeepAliveService.this);
                    });
                }
            };
            cm.registerDefaultNetworkCallback(netCb);   // API 24, cần ACCESS_NETWORK_STATE (đã khai)
        } catch (Throwable t) {
            LogBuffer.w(TAG, "registerDefaultNetworkCallback failed: " + t);
            netCb = null;
        }
    }

    private void unwatchNetwork() {
        if (netCb == null) return;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) cm.unregisterNetworkCallback(netCb);
        } catch (Throwable ignored) {
            // đã hủy hoặc chưa đăng ký
        }
        netCb = null;
    }

    private void enterForeground() {
        Notification n = Notifier.buildForeground(this);
        if (Build.VERSION.SDK_INT >= 34 && getApplicationInfo().targetSdkVersion >= 34) {
            startForeground(Notifier.ID_FGS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(Notifier.ID_FGS, n);
        }
    }

    @SuppressWarnings("deprecation")
    private void acquireLocks() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                if (wakeLock == null) {
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vspace:keepalive");
                    wakeLock.setReferenceCounted(false);
                }
                wakeLock.acquire(WAKELOCK_TIMEOUT_MS); // được gia hạn mỗi RENEW_INTERVAL_MS
            }

            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm != null) {
                if (wifiLock == null) {
                    int mode = Build.VERSION.SDK_INT >= 29
                            ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                            : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                    wifiLock = wm.createWifiLock(mode, "vspace:wifi");
                    wifiLock.setReferenceCounted(false);
                }
                if (!wifiLock.isHeld()) wifiLock.acquire();
            }
        } catch (Throwable t) {
            LogBuffer.w(TAG, "acquireLocks failed: " + t);
        }
    }

    private void releaseLocks() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        } catch (Throwable t) {
            LogBuffer.w(TAG, "releaseLocks failed: " + t);
        }
    }
}
