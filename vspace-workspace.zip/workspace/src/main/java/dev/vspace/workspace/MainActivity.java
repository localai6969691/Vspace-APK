package dev.vspace.workspace;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {

    private static final int REQ_PICK_APK = 100;
    private static final int REQ_NOTIF = 101;
    private static final int REQ_EXPORT = 102;
    private static final int REQ_BACKUP_CREATE = 103;
    private static final int REQ_RESTORE_PICK = 104;
    private static final int REQ_BACKUP_TREE = 105;
    private static final int REQ_RESTORE_GLOBAL = 106;
    private static final int REQ_PERMS = 107;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<GuestApp> all = new ArrayList<>();
    private final List<GuestApp> shown = new ArrayList<>();
    private String query = "";
    private int busyCount;
    private GuestApp pendingExport;
    private GuestApp pendingBackupApp;
    private boolean pendingBackupWithApk;
    private boolean pendingBackupEncrypt;
    private GuestApp pendingRestoreApp;

    private GuestAdapter adapter;
    private View emptyView;
    private TextView status;
    private TextView gameStatus;
    private Button btnGameStop;
    private View busy;
    private Switch swKeep;
    private Switch swPin;
    private Button btnSort;
    private CheckBox cbRunning;
    private int sortMode;
    private int tickCount;
    private String runningSig = "";

    private final Runnable statusTick = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            refreshGameStatus();
            // Trạng thái "đang chạy" của từng app đổi chậm: 5 giây mới kiểm một lần, chỉ vẽ lại danh sách khi có thay đổi.
            if (++tickCount % 5 == 0) {
                String sig = runningSignature();
                if (!sig.equals(runningSig)) {
                    runningSig = sig;
                    applyFilter();
                }
            }
            ui.postDelayed(this, 1000);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        gameStatus = findViewById(R.id.game_status);
        btnGameStop = findViewById(R.id.btn_game_stop);
        busy = findViewById(R.id.busy);
        swKeep = findViewById(R.id.sw_keep);
        swPin = findViewById(R.id.sw_pin);
        btnSort = findViewById(R.id.btn_sort);
        cbRunning = findViewById(R.id.cb_running);
        sortMode = Prefs.sortMode(this);
        cbRunning.setChecked(Prefs.onlyRunning(this));
        updateSortLabel();
        btnSort.setOnClickListener(v -> {
            sortMode = AppSort.next(sortMode);
            Prefs.setSortMode(this, sortMode);
            updateSortLabel();
            applyFilter();
        });
        cbRunning.setOnCheckedChangeListener((v, on) -> {
            Prefs.setOnlyRunning(this, on);
            applyFilter();
        });
        findViewById(R.id.btn_monitor).setOnClickListener(v -> showMonitor());
        findViewById(R.id.btn_oem).setOnClickListener(v -> OemGuide.show(this));
        findViewById(R.id.btn_settings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));

        emptyView = findViewById(R.id.empty);
        RecyclerView list = findViewById(R.id.list);
        adapter = new GuestAdapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        new ItemTouchHelper(new GuestSwipeCallback()).attachToRecyclerView(list);

        EditText search = findViewById(R.id.search);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable s) {
                query = s.toString().trim().toLowerCase(Locale.ROOT);
                applyFilter();
            }
        });

        swKeep.setChecked(Prefs.keepAlive(this));
        swPin.setChecked(Prefs.pinProcesses(this));
        swKeep.setOnCheckedChangeListener((v, on) -> onKeepAliveToggled(on));
        swPin.setOnCheckedChangeListener((v, on) -> {
            Prefs.setPinProcesses(this, on);
            if (Prefs.keepAlive(this)) startKeepAlive(); // service đọc lại cấu hình
        });

        findViewById(R.id.btn_add).setOnClickListener(v -> pickApk());
        findViewById(R.id.btn_clone).setOnClickListener(v -> showCloneDialog());
        findViewById(R.id.btn_battery).setOnClickListener(v -> PowerHelper.requestIgnoreBatteryOptimizations(this));
        findViewById(R.id.btn_autostart).setOnClickListener(v -> {
            if (!PowerHelper.openAutostartSettings(this)) toast(R.string.autostart_fallback);
        });
        findViewById(R.id.btn_perm).setOnClickListener(v -> PowerHelper.openAppDetails(this));
        findViewById(R.id.btn_diag).setOnClickListener(v -> showDiagnostics());
        findViewById(R.id.btn_setup).setOnClickListener(v -> startActivity(new Intent(this, SetupActivity.class)));
        findViewById(R.id.btn_backup).setOnClickListener(v -> showBackupMenu());
        btnGameStop.setOnClickListener(v -> {
            GameModeController.get(this).stop(getString(R.string.reason_user));
            refreshGameStatus();
        });

        io.execute(() -> TrashBin.purge(this));
        if (savedInstanceState == null) {
            if (!Prefs.setupSeen(this)) startActivity(new Intent(this, SetupActivity.class));
            handleIncoming(getIntent());
            if (UpdateFlow.autoCheckDue(this)) autoCheckUpdate();
        }
    }

    /** Chỉ chạy khi người dùng ĐÃ bật "tự kiểm tra cập nhật" (mặc định tắt) và quá 24 giờ kể từ lần trước. */
    private void autoCheckUpdate() {
        UpdateFlow.check(this, (r, err) -> {
            if (r == null || !UpdateChecker.isNewer(r.tag, UpdateFlow.currentVersion(this))) return;
            if (r.tag.equals(Prefs.updateSkipTag(this))) return;
            UndoBar.show(this, getString(R.string.update_bar, r.tag), getString(R.string.update_view),
                    () -> startActivity(new Intent(this, SettingsActivity.class)
                            .putExtra(SettingsActivity.EXTRA_CHECK_UPDATE, true)), 10000);
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList();
        if (Prefs.keepAlive(this) && !KeepAliveService.running) startKeepAlive();
        ui.removeCallbacks(statusTick);
        ui.post(statusTick);
        if (OemGuide.checkOta(this)) {
            // Cập nhật hệ thống thường xóa miễn trừ pin: nhắc cấp lại (mỗi bản build chỉ nhắc một lần).
            new AlertDialog.Builder(this)
                    .setTitle(R.string.ota_title)
                    .setMessage(R.string.ota_msg)
                    .setPositiveButton(R.string.battery_go, (d, w) -> PowerHelper.requestIgnoreBatteryOptimizations(this))
                    .setNegativeButton(R.string.later, null)
                    .show();
        }
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(statusTick);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        io.shutdown();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ keep-alive

    private void onKeepAliveToggled(boolean on) {
        Prefs.setKeepAlive(this, on);
        if (on) {
            requestNotificationPermissionIfNeeded();
            startKeepAlive();
            if (!PowerHelper.isIgnoringBatteryOptimizations(this)) askBatteryExemption();
        } else {
            GameModeController.get(this).stop(getString(R.string.reason_user));
            Scheduler.cancelWatchdog(this);
            KeepAliveService.stop(this);
        }
        refreshStatus();
    }

    private void startKeepAlive() {
        try {
            KeepAliveService.start(this);
        } catch (Throwable t) {
            toast(R.string.start_failed);
        }
    }

    private void askBatteryExemption() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.battery_title)
                .setMessage(R.string.battery_msg)
                .setPositiveButton(R.string.battery_go, (d, w) -> PowerHelper.requestIgnoreBatteryOptimizations(this))
                .setNegativeButton(R.string.later, null)
                .show();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && getApplicationInfo().targetSdkVersion >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
    }

    private void refreshStatus() {
        String on = getString(KeepAliveService.running ? R.string.on : R.string.off);
        String bat = getString(PowerHelper.isIgnoringBatteryOptimizations(this)
                ? R.string.battery_ok : R.string.battery_no);
        status.setText(getString(R.string.status_fmt, on, bat, KeepAliveService.pinnedCount));
        if (swKeep.isChecked() != Prefs.keepAlive(this)) swKeep.setChecked(Prefs.keepAlive(this));
    }

    private void refreshGameStatus() {
        GameModeController gm = GameModeController.get(this);
        if (gm.active) {
            gameStatus.setVisibility(View.VISIBLE);
            gameStatus.setText(gm.shortStatus());
            btnGameStop.setVisibility(View.VISIBLE);
        } else {
            gameStatus.setVisibility(View.GONE);
            btnGameStop.setVisibility(View.GONE);
        }
    }

    // ------------------------------------------------------------------ install (từ file, nhiều file, hoặc từ ứng dụng khác)

    private void pickApk() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/vnd.android.package-archive", "application/octet-stream", "application/zip"});
        startActivityForResult(i, REQ_PICK_APK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQ_PICK_APK) {
            List<Uri> uris = new ArrayList<>();
            ClipData cd = data.getClipData();
            if (cd != null) {
                for (int k = 0; k < cd.getItemCount(); k++) {
                    Uri u = cd.getItemAt(k).getUri();
                    if (u != null) uris.add(u);
                }
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            if (!uris.isEmpty()) importUris(uris);
        } else if (requestCode == REQ_EXPORT) {
            if (pendingExport != null && data.getData() != null) exportApk(pendingExport, data.getData());
            pendingExport = null;
        } else if (requestCode == REQ_BACKUP_CREATE) {
            if (pendingBackupApp != null && data.getData() != null) doBackup(pendingBackupApp, pendingBackupWithApk, pendingBackupEncrypt, data.getData());
            pendingBackupApp = null;
        } else if (requestCode == REQ_RESTORE_PICK) {
            if (pendingRestoreApp != null && data.getData() != null) confirmRestore(pendingRestoreApp, data.getData());
            pendingRestoreApp = null;
        } else if (requestCode == REQ_RESTORE_GLOBAL) {
            if (data.getData() != null) globalRestore(data.getData());
        } else if (requestCode == REQ_BACKUP_TREE) {
            Uri tree = data.getData();
            if (tree != null) {
                try {
                    getContentResolver().takePersistableUriPermission(tree,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                } catch (Exception e) {
                    LogBuffer.w("VSpaceBackup", "persist permission failed: " + e);
                }
                Prefs.setBackupTree(this, tree.toString());
                toast(R.string.backup_folder_saved);
            }
        }
    }

    /** Mở APK từ trình quản lý file (VIEW) hoặc chia sẻ (SEND). */
    @SuppressWarnings("deprecation")
    private void handleIncoming(Intent in) {
        if (in == null) return;
        String action = in.getAction();
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(action)) u = in.getData();
        else if (Intent.ACTION_SEND.equals(action)) u = in.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u == null) return;
        in.setAction(Intent.ACTION_MAIN); // không xử lý lại khi activity được dựng lại
        List<Uri> one = new ArrayList<>();
        one.add(u);
        importUris(one);
    }

    private void importUris(final List<Uri> uris) {
        toast(R.string.installing);
        setBusy(true);
        io.execute(() -> {
            final List<ApkImporter.Prepared> okList = new ArrayList<>();
            final List<Integer> errors = new ArrayList<>();
            for (Uri u : uris) {
                ApkImporter.Prepared p = ApkImporter.prepare(this, u);
                if (p.errorRes != 0) errors.add(p.errorRes);
                else okList.add(p);
            }
            ui.post(() -> {
                setBusy(false);
                if (!errors.isEmpty()) toastLong(errors.get(0));
                if (okList.isEmpty()) return;
                final Runnable discard = () -> discardAll(okList);
                showPreview(okList,
                        () -> RiskList.confirmAny(this, pkgsOf(okList),
                                () -> chooseSpace(space -> checkOverwriteThenInstall(okList, space), discard),
                                discard),
                        discard);
            });
        });
    }

    private static List<String> pkgsOf(List<ApkImporter.Prepared> list) {
        List<String> r = new ArrayList<>();
        for (ApkImporter.Prepared p : list) r.add(p.pkg);
        return r;
    }

    private static void discardAll(List<ApkImporter.Prepared> list) {
        for (ApkImporter.Prepared p : list) p.discard();
    }

    private void showPreview(final List<ApkImporter.Prepared> list, final Runnable yes, final Runnable no) {
        String title;
        String msg;
        if (list.size() == 1) {
            title = getString(R.string.preview_title);
            msg = previewText(list.get(0));
        } else {
            title = getString(R.string.preview_batch_title, list.size());
            StringBuilder sb = new StringBuilder();
            for (ApkImporter.Prepared p : list) {
                sb.append(getString(R.string.preview_item, p.label.toString(), p.versionName)).append('\n');
                if (!p.sysComps.isEmpty()) {
                    sb.append("   ").append(getString(R.string.preview_syscomp, TextUtils.join(", ", p.sysComps))).append('\n');
                }
            }
            msg = sb.toString();
        }
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton(R.string.preview_install, (d, w) -> yes.run())
                .setNegativeButton(android.R.string.cancel, (d, w) -> no.run())
                .setOnCancelListener(d -> no.run())
                .show();
    }

    private String previewText(ApkImporter.Prepared p) {
        StringBuilder sb = new StringBuilder();
        sb.append(getString(R.string.preview_header, p.label.toString(), p.versionName, String.valueOf(p.versionCode))).append('\n');
        sb.append(p.pkg).append('\n');
        sb.append(getString(R.string.preview_size, p.size / (1024.0 * 1024.0))).append('\n');
        sb.append(p.certSha256 != null
                ? getString(R.string.preview_cert, p.certSha256)
                : getString(R.string.preview_cert_none)).append("\n\n");
        if (p.sensitivePerms.isEmpty()) {
            sb.append(getString(R.string.preview_perms_none, p.permCount));
        } else {
            sb.append(getString(R.string.preview_perms, p.permCount, TextUtils.join(", ", p.sensitivePerms)));
        }
        if (!p.sysComps.isEmpty()) {
            sb.append("\n\n").append(getString(R.string.preview_syscomp, TextUtils.join(", ", p.sysComps)));
        }
        if (!p.obbEntries.isEmpty()) {
            sb.append("\n\n").append(getString(R.string.preview_obb, p.obbEntries.size(), p.obbBytes / (1024.0 * 1024.0)));
        }
        if (p.warningRes != 0) sb.append("\n\n").append(getString(p.warningRes));
        return sb.toString();
    }

    private void chooseSpace(final IntConsumer ok, final Runnable cancel) {
        String[] names = new String[Engine.SPACES];
        for (int i = 0; i < names.length; i++) names[i] = getString(R.string.space_n, i + 1);
        new AlertDialog.Builder(this)
                .setTitle(R.string.choose_space)
                .setItems(names, (d, which) -> ok.accept(which))
                .setOnCancelListener(d -> {
                    if (cancel != null) cancel.run();
                })
                .show();
    }

    /** Nếu app đã có trong không gian đó: cảnh báo ghi đè / hạ phiên bản trước khi cài. */
    private void checkOverwriteThenInstall(final List<ApkImporter.Prepared> list, final int space) {
        setBusy(true);
        io.execute(() -> {
            final StringBuilder conflicts = new StringBuilder();
            boolean downgrade = false;
            for (ApkImporter.Prepared p : list) {
                long cur = Engine.installedVersionCode(this, p.pkg, space);
                if (cur < 0) continue;
                if (p.versionCode > 0 && cur > p.versionCode) downgrade = true;
                conflicts.append(getString(R.string.overwrite_item, p.label.toString(),
                        String.valueOf(cur), String.valueOf(p.versionCode))).append('\n');
            }
            final boolean isDowngrade = downgrade;
            ui.post(() -> {
                setBusy(false);
                if (conflicts.length() == 0) {
                    installBatch(list, space);
                    return;
                }
                new AlertDialog.Builder(this)
                        .setTitle(isDowngrade ? R.string.overwrite_downgrade : R.string.overwrite_title)
                        .setMessage(getString(R.string.overwrite_msg, space + 1, conflicts.toString()))
                        .setPositiveButton(android.R.string.ok, (d, w) -> installBatch(list, space))
                        .setNegativeButton(android.R.string.cancel, (d, w) -> discardAll(list))
                        .setOnCancelListener(d -> discardAll(list))
                        .show();
            });
        });
    }

    private void installBatch(final List<ApkImporter.Prepared> list, final int space) {
        setBusy(true);
        io.execute(() -> {
            int ok = 0;
            int restored = 0;
            int obbCopied = 0;
            boolean obbFailed = false;
            boolean skipped = false;
            for (ApkImporter.Prepared p : list) {
                boolean installedNow;
                if (Engine.isInstalled(p.pkg, space)) {
                    // Cập nhật đè: sao lưu dữ liệu trước, cài, kiểm dữ liệu còn không, mất thì tự khôi phục.
                    UpdateKeeper.Result r = UpdateKeeper.update(this, p.apk, p.pkg, space, p.label);
                    installedNow = r.installed;
                    if (r.restored) restored++;
                    if (r.backupSkipped) skipped = true;
                } else {
                    installedNow = Engine.installApk(p.apk, p.pkg, space);
                }
                if (installedNow) {
                    ok++;
                    if (p.bundle != null && !p.obbEntries.isEmpty()) {
                        // OBB của game lớn: chép vào thư mục OBB ảo (đường dẫn chưa kiểm chứng, G-31).
                        int n = ObbImporter.copy(this, p.bundle, p.obbEntries, p.pkg, space);
                        if (n < 0) obbFailed = true;
                        else obbCopied += n;
                    }
                }
                p.discard();
            }
            final int obbN = obbCopied;
            final boolean obbBad = obbFailed;
            final int done = ok;
            final int restoredN = restored;
            final boolean backupSkipped = skipped;
            ui.post(() -> {
                setBusy(false);
                if (restoredN > 0) toastLong(R.string.update_restored);
                else if (backupSkipped) toastLong(R.string.update_backup_skipped);
                if (obbBad) toastLong(R.string.obb_failed);
                else if (obbN > 0) Toast.makeText(this, getString(R.string.obb_done, obbN), Toast.LENGTH_LONG).show();
                if (list.size() == 1) {
                    toast(done == 1 ? R.string.install_ok : R.string.install_fail);
                    if (done == 1 && list.get(0).warningRes != 0) toastLong(list.get(0).warningRes);
                } else {
                    Toast.makeText(this, getString(R.string.installed_n, done, list.size()), Toast.LENGTH_LONG).show();
                }
                refreshList();
            });
        });
    }

    private void showCloneDialog() {
        setBusy(true);
        io.execute(() -> {
            PackageManager pm = getPackageManager();
            List<GuestApp> candidates = new ArrayList<>();
            for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                if (ai.packageName.equals(getPackageName())) continue;
                candidates.add(new GuestApp(ai.packageName, pm.getApplicationLabel(ai), null, 0, null));
            }
            Collections.sort(candidates,
                    (a, b) -> a.label.toString().compareToIgnoreCase(b.label.toString()));

            final String[] pkgs = new String[candidates.size()];
            final String[] labels = new String[candidates.size()];
            for (int i = 0; i < candidates.size(); i++) {
                pkgs[i] = candidates.get(i).pkg;
                labels[i] = candidates.get(i).label + "\n" + candidates.get(i).pkg;
            }
            ui.post(() -> {
                setBusy(false);
                if (isFinishing()) return;
                new AlertDialog.Builder(this)
                        .setTitle(R.string.btn_clone)
                        .setItems(labels, (d, which) -> {
                            final String pkg = pkgs[which];
                            RiskList.confirm(this, pkg,
                                    () -> chooseSpace(space -> cloneFromDevice(pkg, space), null),
                                    null);
                        })
                        .show();
            });
        });
    }

    private void cloneFromDevice(final String pkg, final int space) {
        setBusy(true);
        io.execute(() -> {
            final boolean ok = Engine.cloneFromDevice(pkg, space);
            ui.post(() -> {
                setBusy(false);
                toast(ok ? R.string.install_ok : R.string.install_fail);
                refreshList();
            });
        });
    }

    // ------------------------------------------------------------------ list / menu

    private void refreshList() {
        io.execute(() -> {
            PackageManager pm = getPackageManager();
            final List<GuestApp> out = new ArrayList<>();
            for (int space = 0; space < Engine.SPACES; space++) {
                for (ApplicationInfo ai : Engine.installedApps(space)) {
                    GuestApp g = GuestApp.load(pm, ai, space);
                    String custom = Prefs.customLabel(this, ai.packageName, space);
                    out.add(custom != null ? new GuestApp(g.pkg, custom, g.icon, space, g.sourceDir) : g);
                }
            }
            Collections.sort(out, (a, b) -> a.label.toString().compareToIgnoreCase(b.label.toString()));
            ui.post(() -> {
                all.clear();
                all.addAll(out);
                applyFilter();
            });
        });
    }

    private static boolean isRunning(GuestApp a) {
        return !GuestRegistry.forPackage(a.pkg, a.userId).isEmpty();
    }

    /** Chuỗi đại diện tập app đang chạy (để biết khi nào cần vẽ lại danh sách). */
    private String runningSignature() {
        StringBuilder sb = new StringBuilder();
        for (GuestApp a : all) {
            if (isRunning(a)) sb.append(a.pkg).append('.').append(a.userId).append(';');
        }
        return sb.toString();
    }

    private void updateSortLabel() {
        int res = sortMode == AppSort.BY_SPACE ? R.string.sort_space
                : sortMode == AppSort.RUNNING_FIRST ? R.string.sort_running : R.string.sort_name;
        btnSort.setText(res);
    }

    private void applyFilter() {
        shown.clear();
        boolean onlyRunning = cbRunning != null && cbRunning.isChecked();
        for (GuestApp a : all) {
            if (onlyRunning && !isRunning(a)) continue;
            if (query.isEmpty()
                    || a.label.toString().toLowerCase(Locale.ROOT).contains(query)
                    || a.pkg.toLowerCase(Locale.ROOT).contains(query)) {
                shown.add(a);
            }
        }
        final int mode = sortMode;
        Collections.sort(shown, (x, y) -> AppSort.compare(mode, x.label.toString(), x.userId, isRunning(x),
                y.label.toString(), y.userId, isRunning(y)));
        runningSig = runningSignature();
        adapter.notifyDataSetChanged();
        // RecyclerView không có setEmptyView() như ListView (G-40): ẩn/hiện danh sách và dòng "trống" thủ công.
        emptyView.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
    }

    /** RAM / CPU từng tiến trình (đo CPU 1 giây nên chạy nền); có nút Làm mới. */
    private void showMonitor() {
        setBusy(true);
        io.execute(() -> {
            final String text = GuestMonitor.describe(this, GuestMonitor.collect(this, 1000));
            ui.post(() -> {
                setBusy(false);
                if (isFinishing()) return;
                TextView tv = new TextView(this);
                tv.setText(text);
                tv.setTextIsSelectable(true);
                tv.setTypeface(Typeface.MONOSPACE);
                tv.setTextSize(11);
                int pad = (int) (16 * getResources().getDisplayMetrics().density);
                tv.setPadding(pad, pad, pad, pad);
                ScrollView sv = new ScrollView(this);
                sv.addView(tv);
                new AlertDialog.Builder(this)
                        .setTitle(R.string.btn_monitor)
                        .setView(sv)
                        .setPositiveButton(R.string.refresh, (d, w) -> showMonitor())
                        .setNegativeButton(R.string.close, null)
                        .show();
            });
        });
    }

    private void showMenu(final GuestApp app) {
        List<BottomSheet.Item> it = new ArrayList<>();
        it.add(BottomSheet.Item.of(getString(R.string.menu_open), () -> openGuest(app.pkg, app.userId)));
        it.add(BottomSheet.Item.of(getString(R.string.menu_game), () -> startActivity(new Intent(this, GameActivity.class)
                .putExtra(GameActivity.EXTRA_PKG, app.pkg)
                .putExtra(GameActivity.EXTRA_USER, app.userId)
                .putExtra(GameActivity.EXTRA_LABEL, app.label.toString()))));
        it.add(BottomSheet.Item.of(getString(R.string.menu_pip),
                () -> toast(GameModeController.requestPip(app.pkg, app.userId) > 0 ? R.string.pip_sent : R.string.pip_no_guest)));
        it.add(BottomSheet.Item.divider());
        it.add(BottomSheet.Item.of(getString(R.string.menu_details), () -> showDetails(app)));
        it.add(BottomSheet.Item.of(getString(R.string.menu_permissions), () -> showPermissions(app)));
        it.add(BottomSheet.Item.of(getString(R.string.menu_rename), () -> renameApp(app)));
        it.add(BottomSheet.Item.of(getString(R.string.menu_shortcut), () -> pinShortcut(app)));
        it.add(BottomSheet.Item.divider());
        it.add(BottomSheet.Item.of(getString(R.string.menu_export), () -> startExport(app)));
        it.add(BottomSheet.Item.of(getString(R.string.menu_backup), () -> startBackup(app)));
        it.add(BottomSheet.Item.of(getString(R.string.menu_restore), () -> startRestore(app)));
        it.add(BottomSheet.Item.divider());
        it.add(BottomSheet.Item.of(getString(R.string.menu_stop), () -> stopApp(app)));
        it.add(BottomSheet.Item.danger(getString(R.string.menu_clear_data), () -> confirmClearData(app)));
        it.add(BottomSheet.Item.danger(getString(R.string.menu_uninstall), () -> confirmUninstall(app)));
        BottomSheet.show(this, app.label, it);
    }

    // ------------------------------------------------------------------ mở app (gợi ý "Truy cập mọi tệp") / chi tiết / quyền

    /**
     * Mở app ảo. Trên Android 11+ thiếu "Truy cập mọi tệp" thì lõi chỉ ghi cảnh báo rồi vẫn mở (BlackBoxCore.launchApk, callback
     * mặc định false) → ghi tệp ở bộ nhớ chung có thể hỏng âm thầm. Nếu app ảo khai báo quyền bộ nhớ chung, hỏi người dùng một lần.
     */
    private void openGuest(final String pkg, final int user) {
        if (!StorageAccess.needsAllFilesAccess() || Prefs.storageHintDismissed(this, pkg)) {
            Engine.launch(this, pkg, user);
            return;
        }
        io.execute(() -> {
            PermissionBridge.Report r = PermissionBridge.forGuest(this, pkg, user);
            final boolean want = r != null && PermissionBridge.wantsSharedStorage(r.declared);
            ui.post(() -> {
                if (!want) {
                    Engine.launch(this, pkg, user);
                    return;
                }
                new AlertDialog.Builder(this).setTitle(R.string.storage_hint_title).setMessage(R.string.storage_hint_msg)
                        .setPositiveButton(R.string.storage_hint_open, (d, w) -> {
                            try {
                                startActivity(StorageAccess.settingsIntent(this));
                            } catch (Throwable t) {
                                toast(R.string.storage_hint_fail);
                            }
                        })
                        .setNeutralButton(R.string.storage_hint_launch, (d, w) -> Engine.launch(this, pkg, user))
                        .setNegativeButton(R.string.storage_hint_never, (d, w) -> {
                            Prefs.setStorageHintDismissed(this, pkg);
                            Engine.launch(this, pkg, user);
                        })
                        .show();
            });
        });
    }

    private void showDetails(final GuestApp app) {
        setBusy(true);
        io.execute(() -> {
            final long ver = Engine.installedVersionCode(this, app.pkg, app.userId);
            GuestBackup.Layout l = GuestBackup.locate(this, app.pkg, app.userId);
            final long data = l.data.isDirectory() ? GuestBackup.sizeOf(l.data, new int[]{300_000}) : 0;
            final long ext = l.ext.isDirectory() ? GuestBackup.sizeOf(l.ext, new int[]{300_000}) : 0;
            final long apk = l.apk.isFile() ? l.apk.length() : 0;
            final PermissionBridge.Report r = PermissionBridge.forGuest(this, app.pkg, app.userId);
            ui.post(() -> {
                setBusy(false);
                String perms = r == null ? getString(R.string.details_perm_unknown)
                        : getString(R.string.details_perm_fmt, r.granted.size(), r.requestable.size(), r.blocked.size());
                String msg = getString(R.string.details_fmt, app.pkg, getString(R.string.space_n, app.userId + 1), ver,
                        apk / (1024 * 1024), data / (1024 * 1024), ext / (1024 * 1024), perms);
                new AlertDialog.Builder(this).setTitle(app.label).setMessage(msg)
                        .setPositiveButton(R.string.close, null)
                        .setNeutralButton(R.string.menu_permissions, (d, w) -> showPermissions(app))
                        .show();
            });
        });
    }

    private void showPermissions(final GuestApp app) {
        setBusy(true);
        io.execute(() -> {
            final PermissionBridge.Report r = PermissionBridge.forGuest(this, app.pkg, app.userId);
            ui.post(() -> {
                setBusy(false);
                if (r == null) {
                    toast(R.string.perm_unreadable);
                    return;
                }
                StringBuilder sb = new StringBuilder(getString(R.string.perm_intro)).append("\n");
                appendPerms(sb, R.string.perm_granted, r.granted);
                appendPerms(sb, R.string.perm_requestable, r.requestable);
                appendPerms(sb, R.string.perm_blocked, r.blocked);
                if (r.granted.isEmpty() && r.requestable.isEmpty() && r.blocked.isEmpty()) sb.append("\n").append(getString(R.string.perm_none));
                AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(app.label).setMessage(sb.toString())
                        .setNegativeButton(R.string.close, null)
                        .setNeutralButton(R.string.perm_app_settings, (d, w) -> PowerHelper.openAppDetails(this));
                if (!r.requestable.isEmpty()) {
                    final String[] ask = r.requestable.toArray(new String[0]);
                    b.setPositiveButton(R.string.perm_request, (d, w) -> requestPermissions(ask, REQ_PERMS));
                }
                b.show();
            });
        });
    }

    private void appendPerms(StringBuilder sb, int titleRes, List<String> perms) {
        if (perms.isEmpty()) return;
        sb.append("\n").append(getString(titleRes)).append('\n');
        for (String p : perms) sb.append("  • ").append(PermissionBridge.shortName(p)).append('\n');
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMS) {
            int ok = 0;
            for (int g : grantResults) if (g == PackageManager.PERMISSION_GRANTED) ok++;
            Toast.makeText(this, getString(R.string.perm_result, ok, grantResults.length), Toast.LENGTH_LONG).show();
        }
    }

    private void renameApp(final GuestApp a) {
        final EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(a.label);
        e.setHint(R.string.rename_hint);
        new AlertDialog.Builder(this)
                .setTitle(R.string.menu_rename)
                .setView(e)
                .setPositiveButton(android.R.string.ok, (d, w) -> {
                    Prefs.setCustomLabel(this, a.pkg, a.userId, e.getText().toString().trim());
                    refreshList();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void pinShortcut(GuestApp a) {
        ShortcutManager sm = getSystemService(ShortcutManager.class);
        if (sm == null || !sm.isRequestPinShortcutSupported()) {
            toast(R.string.shortcut_unsupported);
            return;
        }
        Intent target = new Intent(this, ShortcutActivity.class)
                .setAction(Intent.ACTION_MAIN)
                .putExtra(GameActivity.EXTRA_PKG, a.pkg)
                .putExtra(GameActivity.EXTRA_USER, a.userId);
        ShortcutInfo info = new ShortcutInfo.Builder(this, "g-" + a.pkg + "-" + a.userId)
                .setShortLabel(a.label)
                .setIcon(Icon.createWithBitmap(toBitmap(a.icon)))
                .setIntent(target)
                .build();
        sm.requestPinShortcut(info, null);
        toast(R.string.shortcut_requested);
    }

    private static Bitmap toBitmap(Drawable d) {
        int size = 192;
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, size, size);
        d.draw(c);
        return b;
    }

    private void startExport(GuestApp a) {
        if (a.sourceDir == null) {
            toast(R.string.export_fail);
            return;
        }
        pendingExport = a;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.android.package-archive");
        i.putExtra(Intent.EXTRA_TITLE, a.label.toString().replaceAll("[^\\p{L}\\p{N}._-]", "_") + ".apk");
        startActivityForResult(i, REQ_EXPORT);
    }

    private void exportApk(final GuestApp a, final Uri dest) {
        setBusy(true);
        io.execute(() -> {
            boolean ok = false;
            try (InputStream in = new FileInputStream(a.sourceDir);
                 OutputStream out = getContentResolver().openOutputStream(dest)) {
                ApkImporter.copy(in, out);
                ok = true;
            } catch (Exception e) {
                LogBuffer.w("VSpaceExport", "export failed: " + e);
            }
            final boolean done = ok;
            ui.post(() -> {
                setBusy(false);
                toast(done ? R.string.export_ok : R.string.export_fail);
            });
        });
    }

    private void stopApp(final GuestApp app) {
        io.execute(() -> {
            final boolean ok = Engine.stop(app.pkg, app.userId);
            ui.post(() -> toast(ok ? R.string.stop_ok : R.string.stop_unsupported));
        });
    }

    private void confirmUninstall(final GuestApp app) {
        new AlertDialog.Builder(this)
                .setTitle(app.label)
                .setMessage(R.string.uninstall_confirm)
                .setPositiveButton(android.R.string.ok, (d, w) -> doUninstall(app))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    /** Tạo bản sao an toàn (nếu dữ liệu không quá lớn) → gỡ → hiện thanh "Hoàn tác". */
    private void doUninstall(final GuestApp app) {
        setBusy(true);
        io.execute(() -> {
            final String[] why = new String[1];
            final File snap = TrashBin.snapshot(this, app.pkg, app.userId, app.label, why);
            final boolean ok = Engine.uninstall(app.pkg, app.userId);
            ui.post(() -> {
                setBusy(false);
                refreshList();
                if (!ok) {
                    if (snap != null) //noinspection ResultOfMethodCallIgnored
                        snap.delete();
                    toast(R.string.uninstall_fail);
                    return;
                }
                if (snap != null) {
                    UndoBar.show(this, getString(R.string.undo_uninstalled, app.label), getString(R.string.undo),
                            () -> undoFromSnapshot(app, snap), 12000);
                } else {
                    toastLong("TOO_BIG".equals(why[0]) ? R.string.uninstall_ok_nocopy_big : R.string.uninstall_ok_nocopy);
                }
            });
        });
    }

    private void confirmClearData(final GuestApp app) {
        new AlertDialog.Builder(this)
                .setTitle(app.label)
                .setMessage(R.string.clear_confirm)
                .setPositiveButton(android.R.string.ok, (d, w) -> doClearData(app))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    /** Xóa dữ liệu nhưng giữ app: cũng tạo bản sao an toàn để hoàn tác. */
    private void doClearData(final GuestApp app) {
        setBusy(true);
        io.execute(() -> {
            final String[] why = new String[1];
            final File snap = TrashBin.snapshot(this, app.pkg, app.userId, app.label, why);
            stopGuestAndWait(app.pkg, app.userId);
            final boolean ok = Engine.clearData(app.pkg, app.userId);
            ui.post(() -> {
                setBusy(false);
                if (!ok) {
                    if (snap != null) //noinspection ResultOfMethodCallIgnored
                        snap.delete();
                    toast(R.string.clear_fail);
                    return;
                }
                if (snap != null) {
                    UndoBar.show(this, getString(R.string.undo_cleared, app.label), getString(R.string.undo),
                            () -> undoFromSnapshot(app, snap), 12000);
                } else {
                    toastLong("TOO_BIG".equals(why[0]) ? R.string.clear_ok_nocopy_big : R.string.clear_ok_nocopy);
                }
            });
        });
    }

    private void undoFromSnapshot(final GuestApp app, final File snap) {
        setBusy(true);
        io.execute(() -> {
            String msg;
            try {
                TrashBin.restore(this, snap, app.userId);
                //noinspection ResultOfMethodCallIgnored
                snap.delete();
                msg = getString(R.string.undo_restored, app.label);
            } catch (Throwable t) {
                LogBuffer.e("VSpaceTrash", "undo failed", t);
                msg = getString(R.string.undo_failed, String.valueOf(t.getMessage()));
            }
            final String m = msg;
            ui.post(() -> {
                setBusy(false);
                Toast.makeText(this, m, Toast.LENGTH_LONG).show();
                refreshList();
            });
        });
    }

    // ------------------------------------------------------------------ sao lưu / khôi phục dữ liệu

    /** Dừng game và chờ tiến trình biến mất (sao lưu/khôi phục khi game đang ghi dữ liệu sẽ làm hỏng cơ sở dữ liệu). */
    private void stopGuestAndWait(String pkg, int user) {
        Engine.stop(pkg, user);
        GuestRegistry.waitUntilGone(pkg, user, 4000);
    }

    private void startBackup(final GuestApp a) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.menu_backup)
                .setMessage(R.string.backup_with_apk_msg)
                .setPositiveButton(R.string.yes_with_apk, (d, w) -> askEncryptThenPick(a, true))
                .setNegativeButton(R.string.no_data_only, (d, w) -> askEncryptThenPick(a, false))
                .setNeutralButton(android.R.string.cancel, null)
                .show();
    }

    /**
     * File sao lưu rời khỏi thư mục riêng của app (người dùng chọn nơi lưu qua SAF) nên hỏi có mã hóa không mỗi
     * lần, thay vì một công tắc chung dễ quên: hệ quả (chỉ mở lại được trên đúng máy này, xem BackupCrypto) đáng
     * để hỏi lại. Khôi phục thì KHÔNG cần hỏi gì — BackupCrypto.wrapDecrypt tự nhận ra file có mã hóa hay không.
     */
    private void askEncryptThenPick(final GuestApp a, final boolean withApk) {
        new AlertDialog.Builder(this).setTitle(R.string.backup_encrypt_title).setMessage(R.string.backup_encrypt_msg)
                .setPositiveButton(R.string.backup_encrypt_yes, (d, w) -> pickBackupDest(a, withApk, true))
                .setNegativeButton(R.string.backup_encrypt_no, (d, w) -> pickBackupDest(a, withApk, false))
                .show();
    }

    private void pickBackupDest(GuestApp a, boolean withApk, boolean encrypt) {
        pendingBackupApp = a;
        pendingBackupWithApk = withApk;
        pendingBackupEncrypt = encrypt;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        i.putExtra(Intent.EXTRA_TITLE, GuestBackup.backupFileName(a.pkg, a.userId, System.currentTimeMillis()));
        startActivityForResult(i, REQ_BACKUP_CREATE);
    }

    private void doBackup(final GuestApp a, final boolean withApk, final boolean encrypt, final Uri dest) {
        setBusy(true);
        io.execute(() -> {
            String err = null;
            GuestBackup.Stats st = null;
            try {
                stopGuestAndWait(a.pkg, a.userId);
                long ver = Engine.installedVersionCode(this, a.pkg, a.userId);
                try (OutputStream raw = getContentResolver().openOutputStream(dest);
                     OutputStream out = encrypt ? BackupCrypto.wrapEncrypt(raw) : raw) {
                    st = GuestBackup.backup(this, a.pkg, a.userId, a.label, ver, withApk, out);
                }
            } catch (Throwable t) {
                err = String.valueOf(t.getMessage());
                LogBuffer.e("VSpaceBackup", "backup failed", t);
            }
            final String e = err;
            final GuestBackup.Stats s = st;
            ui.post(() -> {
                setBusy(false);
                Toast.makeText(this, e == null && s != null
                        ? getString(R.string.backup_ok, s.files, s.bytes / (1024 * 1024))
                        : getString(R.string.backup_fail, e), Toast.LENGTH_LONG).show();
            });
        });
    }

    private void startRestore(GuestApp a) {
        pendingRestoreApp = a;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/octet-stream"});
        startActivityForResult(i, REQ_RESTORE_PICK);
    }

    private void confirmRestore(final GuestApp a, final Uri uri) {
        new AlertDialog.Builder(this)
                .setTitle(a.label)
                .setMessage(R.string.restore_confirm)
                .setPositiveButton(android.R.string.ok, (d, w) -> doRestore(a, uri))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    /** Mở stream đọc file sao lưu từ SAF, tự giải mã nếu file được tạo với "Mã hóa" bật (BackupCrypto tự nhận ra). */
    private InputStream openBackupStream(Uri uri) throws IOException, GeneralSecurityException {
        InputStream raw = getContentResolver().openInputStream(uri);
        if (raw == null) throw new IOException("openInputStream trả null");
        return BackupCrypto.wrapDecrypt(raw);
    }

    private void doRestore(final GuestApp a, final Uri uri) {
        setBusy(true);
        io.execute(() -> {
            String msg;
            try {
                stopGuestAndWait(a.pkg, a.userId);
                GuestBackup.Restored r;
                try (InputStream in = openBackupStream(uri)) {
                    r = GuestBackup.restore(this, in, a.pkg, a.userId);
                }
                msg = getString(R.string.restore_ok, r.files, r.bytes / (1024 * 1024),
                        r.safetyDir != null ? r.safetyDir.getName() : "-");
            } catch (Throwable t) {
                msg = BackupCrypto.isKeyOrIntegrityFailure(t) ? getString(R.string.restore_fail_key)
                        : getString(R.string.restore_fail, String.valueOf(t.getMessage()));
                LogBuffer.e("VSpaceBackup", "restore failed", t);
            }
            final String m = msg;
            ui.post(() -> {
                setBusy(false);
                Toast.makeText(this, m, Toast.LENGTH_LONG).show();
            });
        });
    }

    /** Khôi phục từ file sao lưu bất kỳ (kể cả trên máy mới: nếu file có kèm APK thì tự cài rồi khôi phục). */
    private void globalRestore(final Uri uri) {
        setBusy(true);
        io.execute(() -> {
            GuestBackup.Header h = null;
            String err = null;
            try (InputStream in = openBackupStream(uri)) {
                h = GuestBackup.readHeader(this, in);
            } catch (Throwable t) {
                err = BackupCrypto.isKeyOrIntegrityFailure(t) ? getString(R.string.restore_fail_key_short) : String.valueOf(t.getMessage());
            }
            final GuestBackup.Header header = h;
            final String e = err;
            ui.post(() -> {
                setBusy(false);
                if (header == null) {
                    Toast.makeText(this, getString(R.string.restore_fail, e), Toast.LENGTH_LONG).show();
                    return;
                }
                chooseSpace(space -> finishGlobalRestore(uri, header, space), () -> {
                    if (header.apk != null) header.apk.delete();
                });
            });
        });
    }

    private void finishGlobalRestore(final Uri uri, final GuestBackup.Header h, final int space) {
        setBusy(true);
        io.execute(() -> {
            String msg;
            try {
                if (!Engine.isInstalled(h.meta.pkg, space)) {
                    if (h.apk == null) throw new IllegalStateException(getString(R.string.restore_need_install));
                    if (!Engine.installApk(h.apk, h.meta.pkg, space)) throw new IllegalStateException(getString(R.string.install_fail));
                }
                stopGuestAndWait(h.meta.pkg, space);
                GuestBackup.Restored r;
                try (InputStream in = openBackupStream(uri)) {
                    r = GuestBackup.restore(this, in, h.meta.pkg, space);
                }
                msg = getString(R.string.restore_ok, r.files, r.bytes / (1024 * 1024),
                        r.safetyDir != null ? r.safetyDir.getName() : "-");
            } catch (Throwable t) {
                msg = BackupCrypto.isKeyOrIntegrityFailure(t) ? getString(R.string.restore_fail_key)
                        : getString(R.string.restore_fail, String.valueOf(t.getMessage()));
                LogBuffer.e("VSpaceBackup", "global restore failed", t);
            } finally {
                if (h.apk != null) h.apk.delete();
            }
            final String m = msg;
            ui.post(() -> {
                setBusy(false);
                Toast.makeText(this, m, Toast.LENGTH_LONG).show();
                refreshList();
            });
        });
    }

    private void showBackupMenu() {
        String tree = Prefs.backupTree(this);
        new AlertDialog.Builder(this)
                .setTitle(R.string.btn_backup)
                .setMessage(getString(R.string.backup_cache_warning) + "\n\n"
                        + (tree != null ? getString(R.string.backup_folder_set, Uri.decode(tree))
                        : getString(R.string.backup_folder_none)))
                .setPositiveButton(R.string.backup_choose_folder, (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(i, REQ_BACKUP_TREE);
                })
                .setNeutralButton(R.string.backup_restore_file, (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/octet-stream"});
                    startActivityForResult(i, REQ_RESTORE_GLOBAL);
                })
                .setNegativeButton(R.string.close, null)
                .show();
    }

    // ------------------------------------------------------------------ diagnostics

    /** Báo cáo chẩn đoán: dán nguyên văn vào chat/issue, hoặc bấm Chia sẻ để gửi kèm nhật ký. */
    private void showDiagnostics() {
        toast(R.string.diag_collecting);
        setBusy(true);
        io.execute(() -> {
            final String report = Diagnostics.collect(this);
            ui.post(() -> {
                setBusy(false);
                if (isFinishing()) return;
                TextView tv = new TextView(this);
                tv.setText(report);
                tv.setTextIsSelectable(true);
                tv.setTypeface(Typeface.MONOSPACE);
                tv.setTextSize(11);
                int pad = (int) (16 * getResources().getDisplayMetrics().density);
                tv.setPadding(pad, pad, pad, pad);
                ScrollView sv = new ScrollView(this);
                sv.addView(tv);
                new AlertDialog.Builder(this)
                        .setTitle(R.string.diag_title)
                        .setView(sv)
                        .setPositiveButton(R.string.copy, (d, w) -> {
                            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("vspace-diagnostics", report));
                            toast(R.string.copied);
                        })
                        .setNeutralButton(R.string.btn_share, (d, w) -> shareReport(report))
                        .setNegativeButton(R.string.close, null)
                        .show();
            });
        });
    }

    private void shareReport(final String report) {
        setBusy(true);
        io.execute(() -> {
            Uri uri = null;
            try {
                uri = ShareProvider.write(this, "vspace-report-" + System.currentTimeMillis() + ".txt",
                        Diagnostics.withLog(this, report));
            } catch (Exception e) {
                LogBuffer.w("VSpaceShare", "share failed: " + e);
            }
            final Uri shared = uri;
            ui.post(() -> {
                setBusy(false);
                if (shared == null) {
                    toast(R.string.share_fail);
                    return;
                }
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_STREAM, shared);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(send, getString(R.string.share_title)));
            });
        });
    }

    // ------------------------------------------------------------------ helpers

    private void setBusy(boolean on) {
        busyCount = Math.max(0, busyCount + (on ? 1 : -1));
        busy.setVisibility(busyCount > 0 ? View.VISIBLE : View.GONE);
    }

    private void toast(int res) {
        Toast.makeText(this, res, Toast.LENGTH_SHORT).show();
    }

    private void toastLong(int res) {
        Toast.makeText(this, res, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------ model / adapter

    private static final class GuestApp {
        final String pkg;
        final CharSequence label;
        final Drawable icon;
        final int userId;
        final String sourceDir;

        GuestApp(String pkg, CharSequence label, Drawable icon, int userId, String sourceDir) {
            this.pkg = pkg;
            this.label = label;
            this.icon = icon;
            this.userId = userId;
            this.sourceDir = sourceDir;
        }

        static GuestApp load(PackageManager pm, ApplicationInfo ai, int userId) {
            CharSequence label = ai.packageName;
            Drawable icon = null;
            try {
                String path = ai.sourceDir;
                if (path != null) {
                    // App ảo không có trong PackageManager thật -> đọc nhãn/icon thẳng từ file APK
                    PackageInfo pi = pm.getPackageArchiveInfo(path, 0);
                    if (pi != null && pi.applicationInfo != null) {
                        ApplicationInfo a = pi.applicationInfo;
                        a.sourceDir = path;
                        a.publicSourceDir = path;
                        label = a.loadLabel(pm);
                        icon = a.loadIcon(pm);
                    }
                }
            } catch (Throwable ignored) {
            }
            if (icon == null) icon = pm.getDefaultActivityIcon();
            return new GuestApp(ai.packageName, label, icon, userId, ai.sourceDir);
        }
    }

    /**
     * Danh sách app ảo bằng RecyclerView (phiên 8, thay ListView/BaseAdapter trước đó): dùng ViewHolder thật (đỡ
     * findViewById lặp lại mỗi lần cuộn) và cho phép ItemTouchHelper gắn vuốt để thao tác (GuestSwipeCallback bên dưới).
     * Vẫn đọc trực tiếp {@link #shown} như adapter cũ — applyFilter() gọi notifyDataSetChanged() sau khi lọc/sắp xếp
     * xong, y hệt trước đây; chưa chuyển sang DiffUtil (G-41, để tránh rủi ro vỡ thứ tự/animation khi chưa có máy
     * thật để nhìn bằng mắt).
     */
    private final class GuestAdapter extends RecyclerView.Adapter<GuestAdapter.VH> {
        @Override
        public VH onCreateViewHolder(ViewGroup parent, int viewType) {
            return new VH(getLayoutInflater().inflate(R.layout.item_app, parent, false));
        }

        @Override
        public void onBindViewHolder(VH h, int position) {
            GuestApp a = shown.get(position);
            h.icon.setImageDrawable(a.icon);
            h.label.setText(a.label);
            h.pkg.setText(a.pkg);
            h.space.setText(getString(R.string.space_n, a.userId + 1));
            boolean running = isRunning(a);
            h.state.setVisibility(running ? View.VISIBLE : View.GONE);
            if (running) h.state.setText(getString(R.string.state_running));
            h.itemView.setContentDescription(a.label + ", " + getString(R.string.space_n, a.userId + 1)
                    + (running ? ", " + getString(R.string.state_running) : ""));
            h.itemView.setOnClickListener(v -> {
                int p = h.getAdapterPosition();
                if (p != RecyclerView.NO_POSITION) openGuest(shown.get(p).pkg, shown.get(p).userId);
            });
            h.itemView.setOnLongClickListener(v -> {
                int p = h.getAdapterPosition();
                if (p != RecyclerView.NO_POSITION) showMenu(shown.get(p));
                return true;
            });
        }

        @Override
        public int getItemCount() {
            return shown.size();
        }

        final class VH extends RecyclerView.ViewHolder {
            final ImageView icon;
            final TextView label, pkg, space, state;

            VH(View v) {
                super(v);
                icon = v.findViewById(R.id.icon);
                label = v.findViewById(R.id.label);
                pkg = v.findViewById(R.id.pkg);
                space = v.findViewById(R.id.space);
                state = v.findViewById(R.id.state);
            }
        }
    }

    /**
     * Vuốt phải = mở app (như chạm); vuốt trái = menu (như chạm giữ). Không xóa/ẩn hàng nào — {@code onSwiped} chỉ
     * kích hoạt hành động rồi {@code notifyItemChanged} để hàng tự trả về vị trí cũ (snap back), vì đây là lối tắt
     * cho hành động đã có, không phải "vuốt để xóa". {@code onChildDraw} vẽ nền màu + chữ để người dùng biết hướng
     * vuốt làm gì; CHƯA xem được bằng mắt trên máy thật (G-39/G-42), chỉ biên dịch sạch với stub androidx thủ công
     * đối chiếu tài liệu chính thức (scripts/stubs/androidx_api.spec).
     */
    private final class GuestSwipeCallback extends ItemTouchHelper.SimpleCallback {
        private final ColorDrawable openBg = new ColorDrawable(0xFF2E7D32);
        private final ColorDrawable menuBg = new ColorDrawable(0xFF455A64);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        GuestSwipeCallback() {
            super(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT);
            textPaint.setColor(0xFFFFFFFF);
            textPaint.setTextSize(getResources().getDisplayMetrics().scaledDensity * 14f);
        }

        @Override
        public boolean onMove(RecyclerView rv, RecyclerView.ViewHolder vh, RecyclerView.ViewHolder target) {
            return false; // không hỗ trợ kéo-thả sắp xếp lại, chỉ vuốt
        }

        @Override
        public void onSwiped(RecyclerView.ViewHolder vh, int direction) {
            int p = vh.getAdapterPosition();
            if (p == RecyclerView.NO_POSITION || p >= shown.size()) return;
            GuestApp a = shown.get(p);
            if (direction == ItemTouchHelper.RIGHT) openGuest(a.pkg, a.userId);
            else showMenu(a);
            adapter.notifyItemChanged(p); // hàng không bị xóa khỏi danh sách -> trả về chỗ cũ
        }

        @Override
        public void onChildDraw(Canvas c, RecyclerView rv, RecyclerView.ViewHolder vh, float dX, float dY,
                int actionState, boolean isCurrentlyActive) {
            View v = vh.itemView;
            if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {
                String label;
                if (dX > 0) {
                    openBg.setBounds(v.getLeft(), v.getTop(), v.getLeft() + (int) dX, v.getBottom());
                    openBg.draw(c);
                    label = getString(R.string.swipe_open);
                } else if (dX < 0) {
                    menuBg.setBounds(v.getRight() + (int) dX, v.getTop(), v.getRight(), v.getBottom());
                    menuBg.draw(c);
                    label = getString(R.string.swipe_menu);
                } else {
                    label = null;
                }
                if (label != null) {
                    float pad = 24f * getResources().getDisplayMetrics().density;
                    float x = dX > 0 ? v.getLeft() + pad : v.getRight() - pad - textPaint.measureText(label);
                    float y = v.getTop() + v.getHeight() / 2f - (textPaint.descent() + textPaint.ascent()) / 2f;
                    c.drawText(label, x, y, textPaint);
                }
            }
            super.onChildDraw(c, rv, vh, dX, dY, actionState, isCurrentlyActive);
        }
    }
}
