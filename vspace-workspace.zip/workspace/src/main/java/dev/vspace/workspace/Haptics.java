package dev.vspace.workspace;

import android.os.Build;
import android.view.HapticFeedbackConstants;
import android.view.View;

/** Phản hồi rung nhẹ cho thao tác quan trọng (không cần quyền VIBRATE khi dùng performHapticFeedback trên View). */
final class Haptics {
    private Haptics() {}

    static void confirm(View v) {
        if (v == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 30) v.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
            else v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        } catch (Throwable ignored) {
            // thiết bị không hỗ trợ: bỏ qua
        }
    }

    static void reject(View v) {
        if (v == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 30) v.performHapticFeedback(HapticFeedbackConstants.REJECT);
            else v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        } catch (Throwable ignored) {
            // bỏ qua
        }
    }
}
