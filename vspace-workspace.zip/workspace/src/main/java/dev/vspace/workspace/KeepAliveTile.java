package dev.vspace.workspace;

import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/**
 * Ô Cài đặt nhanh "Giữ nền": bật/tắt dịch vụ giữ nền ngay từ thanh kéo xuống, không cần mở app
 * (hữu ích khi đang chơi game hoặc màn hình có overlay). Trạng thái đọc từ Prefs.keepAlive.
 */
public class KeepAliveTile extends TileService {
    private static final String TAG = "VSpaceTile";

    @Override
    public void onStartListening() {
        super.onStartListening();
        refresh();
    }

    @Override
    public void onClick() {
        super.onClick();
        try {
            boolean wasOn = Prefs.keepAlive(this);
            if (wasOn) {
                Prefs.setKeepAlive(this, false);
                Scheduler.cancelWatchdog(this);
                KeepAliveService.stop(this);
            } else {
                Prefs.setKeepAlive(this, true);
                KeepAliveService.start(this);
            }
            LogBuffer.i(TAG, "tile toggle -> keepAlive=" + !wasOn);
        } catch (Throwable t) {
            LogBuffer.w(TAG, "tile toggle failed: " + t);
        }
        refresh();
    }

    private void refresh() {
        Tile t = getQsTile();
        if (t == null) return;
        t.setState(Prefs.keepAlive(this) ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.updateTile();
    }
}
