package dev.vspace.workspace;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Bảng hành động dán đáy màn hình (kiểu bottom sheet) dựng bằng framework: AlertDialog có view tùy biến, gravity đáy, nhóm mục
 * có đường kẻ, mục nguy hiểm màu đỏ, mỗi dòng cao ≥ 48dp. Thay danh sách phẳng trước đây và không thêm thư viện nào.
 */
final class BottomSheet {
    static final class Item {
        final String label;
        final boolean danger;
        final boolean divider;
        final Runnable run;

        private Item(String label, boolean danger, boolean divider, Runnable run) {
            this.label = label;
            this.danger = danger;
            this.divider = divider;
            this.run = run;
        }

        static Item of(String label, Runnable run) {
            return new Item(label, false, false, run);
        }

        static Item danger(String label, Runnable run) {
            return new Item(label, true, false, run);
        }

        static Item divider() {
            return new Item("", false, true, null);
        }
    }

    private BottomSheet() {}

    static void show(Activity a, CharSequence title, List<Item> items) {
        float d = a.getResources().getDisplayMetrics().density;
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (8 * d);
        col.setPadding(0, pad, 0, pad);

        TextView t = new TextView(a);
        t.setText(title);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        t.setPadding((int) (20 * d), (int) (12 * d), (int) (20 * d), (int) (12 * d));
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(t);

        final AlertDialog[] dlg = new AlertDialog[1];
        TypedValue ripple = new TypedValue();
        boolean haveRipple = a.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, ripple, true);
        TypedValue colorPrimary = new TypedValue();
        a.getTheme().resolveAttribute(android.R.attr.textColorPrimary, colorPrimary, true);
        int textColor = a.getResources().getColor(colorPrimary.resourceId, a.getTheme());

        for (final Item it : new ArrayList<>(items)) {
            if (it.divider) {
                View line = new View(a);
                line.setBackgroundColor(0x33888888);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) Math.max(1, d));
                lp.setMargins(0, (int) (4 * d), 0, (int) (4 * d));
                col.addView(line, lp);
                continue;
            }
            TextView row = new TextView(a);
            row.setText(it.label);
            row.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            row.setTextColor(it.danger ? 0xFFD32F2F : textColor);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setMinHeight((int) (48 * d));
            row.setPadding((int) (20 * d), (int) (8 * d), (int) (20 * d), (int) (8 * d));
            if (haveRipple) row.setBackgroundResource(ripple.resourceId);
            row.setClickable(true);
            row.setOnClickListener(v -> {
                if (dlg[0] != null) dlg[0].dismiss();
                if (it.run != null) it.run.run();
            });
            col.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        ScrollView sv = new ScrollView(a);
        sv.addView(col);
        dlg[0] = new AlertDialog.Builder(a).setView(sv).create();
        Window w = dlg[0].getWindow();
        if (w != null) {
            w.setGravity(Gravity.BOTTOM);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setWindowAnimations(android.R.style.Animation_InputMethod);
        }
        dlg[0].show();
    }
}
