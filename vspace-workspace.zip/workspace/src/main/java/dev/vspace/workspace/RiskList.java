package dev.vspace.workspace;

import android.app.Activity;
import android.app.AlertDialog;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Danh sách THAM KHẢO (không đầy đủ, có thể sai) các game thường có anti-cheat / phát hiện môi trường ảo.
 * Workspace KHÔNG cố che giấu môi trường ảo; chỉ cảnh báo để người dùng tự quyết định.
 */
final class RiskList {
    private static final Set<String> EXACT = new HashSet<>(Arrays.asList(
            "com.tencent.ig", "com.pubg.imobile", "com.pubg.krmobile", "com.vng.pubgmobile",
            "com.dts.freefireth", "com.dts.freefiremax",
            "com.garena.game.kgvn", "com.levelinfinite.sgameGlobal",
            "com.activision.callofduty.shooter", "com.mobile.legends"));
    private static final String[] PREFIX = {
            "com.tencent.tmgp.", "com.miHoYo.", "com.HoYoverse.", "com.netease."
    };

    private RiskList() {}

    static boolean isRisky(String pkg) {
        if (pkg == null) return false;
        if (EXACT.contains(pkg)) return true;
        for (String p : PREFIX) if (pkg.startsWith(p)) return true;
        return false;
    }

    /** Nếu game có rủi ro thì hỏi xác nhận, ngược lại chạy luôn onYes. */
    static void confirm(Activity a, String pkg, final Runnable onYes, final Runnable onNo) {
        confirmAny(a, java.util.Collections.singletonList(pkg), onYes, onNo);
    }

    /** Hỏi xác nhận một lần cho cả danh sách nếu có ít nhất một gói thuộc danh sách rủi ro. */
    static void confirmAny(Activity a, java.util.List<String> pkgs, final Runnable onYes, final Runnable onNo) {
        StringBuilder risky = new StringBuilder();
        for (String p : pkgs) {
            if (isRisky(p)) {
                if (risky.length() > 0) risky.append(", ");
                risky.append(p);
            }
        }
        if (risky.length() == 0) {
            onYes.run();
            return;
        }
        new AlertDialog.Builder(a)
                .setTitle(R.string.risk_title)
                .setMessage(a.getString(R.string.risk_msg, risky.toString()))
                .setPositiveButton(R.string.risk_continue, (d, w) -> onYes.run())
                .setNegativeButton(android.R.string.cancel, (d, w) -> {
                    if (onNo != null) onNo.run();
                })
                .setOnCancelListener(d -> {
                    if (onNo != null) onNo.run();
                })
                .show();
    }
}
