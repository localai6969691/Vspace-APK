package dev.vspace.workspace;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;

/** Toàn bộ thông báo của app: thông báo foreground (cố định) và các cảnh báo (kênh riêng). */
final class Notifier {
    static final String CH_KEEP = "keepalive";
    static final String CH_ALERT = "alerts";
    static final int ID_FGS = 1001;
    private static int alertCounter;

    private Notifier() {}

    static void ensureChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel keep = new NotificationChannel(
                CH_KEEP, c.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW);
        keep.setShowBadge(false);
        nm.createNotificationChannel(keep);
        NotificationChannel alert = new NotificationChannel(
                CH_ALERT, c.getString(R.string.notif_alert_channel), NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(alert);
    }

    private static PendingIntent openMain(Context c) {
        Intent open = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static Notification.Action action(Context c, int titleRes, String act, int req) {
        Intent i = new Intent(c, KeepAliveService.class).setAction(act);
        PendingIntent pi = PendingIntent.getService(c, req, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(
                Icon.createWithResource(c, R.drawable.ic_stat), c.getString(titleRes), pi).build();
    }

    static Notification buildForeground(Context c) {
        GameModeController gm = GameModeController.get(c);
        Notification.Builder b = new Notification.Builder(c, CH_KEEP)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentIntent(openMain(c))
                .setOngoing(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_SERVICE);
        if (gm.active) {
            b.setContentTitle(c.getString(R.string.notif_game_title, gm.label.toString()));
            b.setContentText(gm.shortStatus());
            b.addAction(action(c, R.string.notif_stop_game, KeepAliveService.ACTION_STOP_GAME, 2));
        } else {
            b.setContentTitle(c.getString(R.string.notif_title));
            b.setContentText(c.getString(R.string.notif_text));
        }
        b.addAction(action(c, R.string.notif_stop, KeepAliveService.ACTION_STOP, 1));
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    /** Cập nhật nội dung thông báo foreground (chỉ khi dịch vụ đang chạy, tránh tạo thông báo thường trùng ID). */
    static void updateForeground(Context c) {
        if (!KeepAliveService.running) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(ID_FGS, buildForeground(c));
        StatusWidget.refresh(c);
    }

    private static final String GROUP_ALERTS = "vspace_alerts";
    private static final int ID_ALERT_SUMMARY = 1999;
    private static final int ID_ALERT_BASE = 2000;
    private static final int ALERT_SLOTS = 10;

    /** Khi có từ 2 cảnh báo trở lên đang hiện, thêm thông báo tóm tắt để chúng gom thành một nhóm gọn trên thanh thông báo. */
    private static void postAlertSummary(Context c, NotificationManager nm) {
        try {
            int active = 0;
            for (android.service.notification.StatusBarNotification s : nm.getActiveNotifications()) {
                int id = s.getId();
                if (id >= ID_ALERT_BASE && id < ID_ALERT_BASE + ALERT_SLOTS) active++;
            }
            if (active < 2) return;
            Notification sum = new Notification.Builder(c, CH_ALERT)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(c.getString(R.string.alert_group_title))
                    .setContentText(c.getString(R.string.alert_group_text, active))
                    .setGroup(GROUP_ALERTS)
                    .setGroupSummary(true)
                    .setContentIntent(openMain(c))
                    .setAutoCancel(true)
                    .build();
            nm.notify(ID_ALERT_SUMMARY, sum);
        } catch (Throwable ignored) {
            // không có thông báo tóm tắt cũng không sao
        }
    }

    static void alert(Context c, String title, String text) {
        try {
            ensureChannels(c);
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (nm == null) return;
            Notification n = new Notification.Builder(c, CH_ALERT)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(openMain(c))
                    .setGroup(GROUP_ALERTS)
                    .setAutoCancel(true)
                    .build();
            nm.notify(ID_ALERT_BASE + (alertCounter++ % ALERT_SLOTS), n);
            postAlertSummary(c, nm);
        } catch (Throwable ignored) {
        }
    }
}
