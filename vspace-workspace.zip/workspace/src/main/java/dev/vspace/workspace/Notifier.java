package dev.vspace.workspace;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;

/** Toàn bộ thông báo của app: thông báo foreground (cố định) và các cảnh báo (kênh riêng). */
final class Notifier {
    static final String CH_KEEP = "keepalive";
    static final String CH_ALERT = "alerts";
    static final int ID_FGS = 1001;
    private static int alertCounter;

    private Notifier() {}

    static void ensureChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel keep = new NotificationChannel(
                CH_KEEP, c.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW);
        keep.setShowBadge(false);
        nm.createNotificationChannel(keep);
        NotificationChannel alert = new NotificationChannel(
                CH_ALERT, c.getString(R.string.notif_alert_channel), NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(alert);
    }

    private static PendingIntent openMain(Context c) {
        Intent open = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static Notification.Action action(Context c, int titleRes, String act, int req) {
        Intent i = new Intent(c, KeepAliveService.class).setAction(act);
        PendingIntent pi = PendingIntent.getService(c, req, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(
                Icon.createWithResource(c, R.drawable.ic_stat), c.getString(titleRes), pi).build();
    }

    static Notification buildForeground(Context c) {
        GameModeController gm = GameModeController.get(c);
        Notification.Builder b = new Notification.Builder(c, CH_KEEP)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentIntent(openMain(c))
                .setOngoing(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_SERVICE);
        if (gm.active) {
            b.setContentTitle(c.getString(R.string.notif_game_title, gm.label.toString()));
            b.setContentText(gm.shortStatus());
            b.addAction(action(c, R.string.notif_stop_game, KeepAliveService.ACTION_STOP_GAME, 2));
        } else {
            b.setContentTitle(c.getString(R.string.notif_title));
            b.setContentText(c.getString(R.string.notif_text));
        }
        b.addAction(action(c, R.string.notif_stop, KeepAliveService.ACTION_STOP, 1));
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    /** Cập nhật nội dung thông báo foreground (chỉ khi dịch vụ đang chạy, tránh tạo thông báo thường trùng ID). */
    static void updateForeground(Context c) {
        if (!KeepAliveService.running) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(ID_FGS, buildForeground(c));
        StatusWidget.refresh(c);
    }

    static void alert(Context c, String title, String text) {
        try {
            ensureChannels(c);
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (nm == null) return;
            Notification n = new Notification.Builder(c, CH_ALERT)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(openMain(c))
                    .setAutoCancel(true)
                    .build();
            nm.notify(2000 + (alertCounter++ % 10), n);
        } catch (Throwable ignored) {
        }
    }
}
