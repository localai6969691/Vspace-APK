package dev.vspace.workspace;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Lịch sử các phiên chế độ game của MỖI game (gói + không gian): thời gian chạy nền, pin tụt/giờ, nhiệt cao nhất, số lần bị kill...
 * Dùng cho màn hình "Thống kê" trong hồ sơ game (đề xuất mục 8 của bản đánh giá bên ngoài) và để đo pin thật thay vì hứa suông.
 *
 * Định dạng lưu: mỗi phiên một dòng "k=v;k=v;..." (KHÔNG dùng org.json: lớp này được test đơn vị trên JVM, nơi org.json trả giá trị rỗng).
 */
final class SessionStats {
    static final int CAP = 30;
    /** Phiên ngắn hơn mức này không đủ để tính pin tụt mỗi giờ (nhiễu làm tròn 1 phần trăm). */
    static final long MIN_RATE_MS = 10 * 60_000L;

    static final class Entry {
        long start;
        long durMs;
        int batStart = -1;
        int batEnd = -1;
        int maxTempDeci;
        int maxThermal;
        int deaths;
        int freezes;
        int restarts;
        int memEvents;
        boolean plugged;
        int mode;
        String reason = "";
    }

    static final class Summary {
        int sessions;
        long totalMs;
        /** Trung bình pin tụt mỗi giờ qua các phiên đủ dài và không cắm sạc; -1 nếu chưa có phiên nào đủ điều kiện. */
        double avgDrainPerHour = -1;
        int deaths;
        int restarts;
        int maxTempDeci;
    }

    private SessionStats() {}

    // ------------------------------------------------------------------ hàm thuần

    static String line(Entry e) {
        return "s=" + e.start + ";d=" + e.durMs + ";b0=" + e.batStart + ";b1=" + e.batEnd + ";t=" + e.maxTempDeci
                + ";th=" + e.maxThermal + ";x=" + e.deaths + ";f=" + e.freezes + ";r=" + e.restarts + ";m=" + e.memEvents
                + ";p=" + (e.plugged ? 1 : 0) + ";mode=" + e.mode + ";why=" + clean(e.reason);
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replace(';', ',').replace('=', ' ').replace('\n', ' ').replace('\r', ' ');
    }

    static Entry parseLine(String line) {
        if (line == null) return null;
        Entry e = new Entry();
        boolean any = false;
        for (String part : line.split(";")) {
            int eq = part.indexOf('=');
            if (eq <= 0) continue;
            String k = part.substring(0, eq);
            String v = part.substring(eq + 1);
            try {
                switch (k) {
                    case "s":
                        e.start = Long.parseLong(v);
                        any = true;
                        break;
                    case "d":
                        e.durMs = Long.parseLong(v);
                        break;
                    case "b0":
                        e.batStart = Integer.parseInt(v);
                        break;
                    case "b1":
                        e.batEnd = Integer.parseInt(v);
                        break;
                    case "t":
                        e.maxTempDeci = Integer.parseInt(v);
                        break;
                    case "th":
                        e.maxThermal = Integer.parseInt(v);
                        break;
                    case "x":
                        e.deaths = Integer.parseInt(v);
                        break;
                    case "f":
                        e.freezes = Integer.parseInt(v);
                        break;
                    case "r":
                        e.restarts = Integer.parseInt(v);
                        break;
                    case "m":
                        e.memEvents = Integer.parseInt(v);
                        break;
                    case "p":
                        e.plugged = "1".equals(v);
                        break;
                    case "mode":
                        e.mode = Integer.parseInt(v);
                        break;
                    case "why":
                        e.reason = v;
                        break;
                    default:
                        break;
                }
            } catch (NumberFormatException ignored) {
                // trường hỏng thì bỏ qua, giữ các trường còn lại
            }
        }
        return any ? e : null;
    }

    static List<Entry> parse(String text) {
        List<Entry> r = new ArrayList<>();
        if (text == null) return r;
        for (String l : text.split("\n")) {
            if (l.trim().isEmpty()) continue;
            Entry e = parseLine(l.trim());
            if (e != null) r.add(e);
        }
        return r;
    }

    /** Thêm một phiên vào cuối danh sách, chỉ giữ cap phiên gần nhất. */
    static String append(String existing, Entry e, int cap) {
        List<String> lines = new ArrayList<>();
        if (existing != null) {
            for (String l : existing.split("\n")) {
                if (!l.trim().isEmpty()) lines.add(l.trim());
            }
        }
        lines.add(line(e));
        int from = Math.max(0, lines.size() - Math.max(1, cap));
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < lines.size(); i++) sb.append(lines.get(i)).append('\n');
        return sb.toString();
    }

    /** Pin tụt mỗi giờ của một phiên, hoặc -1 nếu không đủ điều kiện (ngắn, thiếu số liệu, có cắm sạc, pin tăng). */
    static double drainPerHour(Entry e) {
        if (e.durMs < MIN_RATE_MS || e.batStart < 0 || e.batEnd < 0 || e.plugged) return -1;
        int drop = e.batStart - e.batEnd;
        if (drop < 0) return -1;
        return drop / (e.durMs / 3_600_000.0);
    }

    static Summary summarize(List<Entry> list) {
        Summary s = new Summary();
        double sum = 0;
        int n = 0;
        for (Entry e : list) {
            s.sessions++;
            s.totalMs += Math.max(0, e.durMs);
            s.deaths += e.deaths;
            s.restarts += e.restarts;
            s.maxTempDeci = Math.max(s.maxTempDeci, e.maxTempDeci);
            double d = drainPerHour(e);
            if (d >= 0) {
                sum += d;
                n++;
            }
        }
        if (n > 0) s.avgDrainPerHour = sum / n;
        return s;
    }

    static String key(String pkg, int userId) {
        return pkg + "." + userId;
    }

    // ------------------------------------------------------------------ lưu / đọc

    static void record(Context c, String pkg, int userId, Entry e) {
        String k = key(pkg, userId);
        Prefs.setStats(c, k, append(Prefs.stats(c, k), e, CAP));
    }

    static String describe(Context c, String pkg, int userId) {
        List<Entry> list = parse(Prefs.stats(c, key(pkg, userId)));
        if (list.isEmpty()) return c.getString(R.string.stats_none);
        Summary s = summarize(list);
        StringBuilder sb = new StringBuilder();
        sb.append(c.getString(R.string.stats_summary, s.sessions, GameModeController.fmt(s.totalMs),
                s.avgDrainPerHour >= 0 ? String.format(Locale.US, "%.1f", s.avgDrainPerHour) : "?",
                s.maxTempDeci / 10.0, s.deaths, s.restarts)).append("\n\n");
        int from = Math.max(0, list.size() - 8);
        for (int i = list.size() - 1; i >= from; i--) {
            Entry e = list.get(i);
            double d = drainPerHour(e);
            sb.append(c.getString(R.string.stats_row,
                    new java.text.SimpleDateFormat("MM-dd HH:mm", Locale.US).format(new java.util.Date(e.start)),
                    GameModeController.fmt(e.durMs),
                    e.batStart >= 0 ? String.valueOf(e.batStart) : "?",
                    e.batEnd >= 0 ? String.valueOf(e.batEnd) : "?",
                    d >= 0 ? String.format(Locale.US, "%.1f", d) : "?",
                    e.reason)).append('\n');
        }
        return sb.toString();
    }
}
