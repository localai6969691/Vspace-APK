package dev.vspace.workspace;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;

/**
 * Widget màn hình chính: trạng thái chạy nền / phiên game đang chạy, chạm để mở Workspace, có nút thoát chế độ game.
 * Không tự cập nhật theo chu kỳ (updatePeriodMillis=0, tiết kiệm pin); được làm mới mỗi khi thông báo foreground đổi (Notifier.updateForeground).
 */
public class StatusWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        try {
            manager.updateAppWidget(appWidgetIds, build(context));
        } catch (Throwable t) {
            LogBuffer.w("VSpaceWidget", "update failed: " + t);
        }
    }

    /** Làm mới mọi widget đang có trên màn hình chính (an toàn khi không có widget nào). */
    static void refresh(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, StatusWidget.class));
            if (ids == null || ids.length == 0) return;
            m.updateAppWidget(ids, build(c));
        } catch (Throwable ignored) {
        }
    }

    /** Dòng trạng thái (hàm thuần theo tham số, để dễ kiểm). */
    static String statusLine(Context c, boolean keepRunning, boolean gameActive, String gameStatus) {
        if (gameActive) return gameStatus;
        return c.getString(keepRunning ? R.string.widget_keep_on : R.string.widget_keep_off);
    }

    private static RemoteViews build(Context c) {
        GameModeController g = GameModeController.get(c);
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_status);
        v.setTextViewText(R.id.w_status, statusLine(c, KeepAliveService.running, g.active, g.active ? g.shortStatus() : ""));
        Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        v.setOnClickPendingIntent(R.id.w_root,
                PendingIntent.getActivity(c, 20, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        if (g.active) {
            Intent stop = new Intent(c, KeepAliveService.class).setAction(KeepAliveService.ACTION_STOP_GAME);
            v.setOnClickPendingIntent(R.id.w_stop,
                    PendingIntent.getService(c, 21, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
            v.setViewVisibility(R.id.w_stop, View.VISIBLE);
        } else {
            v.setViewVisibility(R.id.w_stop, View.GONE);
        }
        return v;
    }
}
