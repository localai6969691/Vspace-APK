package dev.vspace.workspace;

import android.app.ActivityManager;
import android.content.Context;
import android.os.SystemClock;
import android.system.Os;
import android.system.OsConstants;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Đo CPU của các tiến trình cùng UID bằng /proc/<pid>/stat (đọc được vì cùng UID/domain).
 * Dùng để phát hiện "game đứng hình": tiến trình còn sống nhưng CPU ≈ 0.
 */
final class CpuSampler {
    private final Map<Integer, long[]> last = new HashMap<>(); // pid -> {ticks, elapsedRealtimeMs}

    private static long hz() {
        try {
            long h = Os.sysconf(OsConstants._SC_CLK_TCK);
            if (h > 0) return h;
        } catch (Throwable ignored) {
        }
        return 100;
    }

    /**
     * utime + stime (tick) từ một dòng /proc/<pid>/stat, hoặc -1 nếu dòng không hợp lệ.
     * Tên tiến trình (trường 2) nằm trong ngoặc và có thể chứa khoảng trắng/ngoặc nên cắt sau dấu ')' CUỐI CÙNG.
     */
    static long parseTicks(String line) {
        try {
            if (line == null) return -1;
            int i = line.lastIndexOf(')');
            if (i < 0) return -1;
            String[] f = line.substring(i + 2).split(" ");
            return Long.parseLong(f[11]) + Long.parseLong(f[12]);
        } catch (Throwable t) {
            return -1;
        }
    }

    /** utime + stime (đơn vị tick) hoặc -1 nếu không đọc được. */
    static long readTicks(int pid) {
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/" + pid + "/stat"))) {
            return parseTicks(r.readLine());
        } catch (Throwable t) {
            return -1;
        }
    }

    /**
     * CPU% (100 = 1 lõi) của tiến trình :pN bận nhất kể từ lần gọi trước.
     * @return -1 nếu chưa đủ dữ liệu / không có tiến trình app ảo nào.
     */
    double sampleGuestMaxPercent(Context c) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> ps = am != null ? am.getRunningAppProcesses() : null;
        if (ps == null) return -1;
        double best = -1;
        Set<Integer> seen = new HashSet<>();
        long hz = hz();
        for (ActivityManager.RunningAppProcessInfo p : ps) {
            if (!ProcessPinner.isGuestProcess(c.getPackageName(), p.processName)) continue;
            long ticks = readTicks(p.pid);
            if (ticks < 0) continue;
            long now = SystemClock.elapsedRealtime();
            seen.add(p.pid);
            long[] prev = last.put(p.pid, new long[]{ticks, now});
            if (prev != null) {
                double dt = (now - prev[1]) / 1000.0;
                if (dt >= 1.0) best = Math.max(best, (ticks - prev[0]) / (double) hz / dt * 100.0);
            }
        }
        last.keySet().retainAll(seen);
        return best;
    }

    /** CPU% cao nhất trong các pid cho trước (chính xác hơn khi biết game nằm ở tiến trình nào). -1 nếu chưa đủ dữ liệu. */
    double sampleForPids(Set<Integer> pids) {
        double best = -1;
        Set<Integer> seen = new HashSet<>();
        long hz = hz();
        for (int pid : pids) {
            long ticks = readTicks(pid);
            if (ticks < 0) continue;
            long now = SystemClock.elapsedRealtime();
            seen.add(pid);
            long[] prev = last.put(pid, new long[]{ticks, now});
            if (prev != null) {
                double dt = (now - prev[1]) / 1000.0;
                if (dt >= 1.0) best = Math.max(best, (ticks - prev[0]) / (double) hz / dt * 100.0);
            }
        }
        last.keySet().retainAll(seen);
        return best;
    }

    /** Đo CPU% (100 = 1 lõi) của các pid cho trước trong windowMs (chặn luồng gọi; không gọi trên main thread). */
    static Map<Integer, Double> measurePids(java.util.Collection<Integer> pids, long windowMs) {
        Map<Integer, Double> out = new HashMap<>();
        Map<Integer, Long> t0 = new HashMap<>();
        for (int pid : pids) {
            long t = readTicks(pid);
            if (t >= 0) t0.put(pid, t);
        }
        long n0 = SystemClock.elapsedRealtime();
        try {
            Thread.sleep(windowMs);
        } catch (InterruptedException ignored) {
        }
        double dt = Math.max(0.001, (SystemClock.elapsedRealtime() - n0) / 1000.0);
        long hz = hz();
        for (Map.Entry<Integer, Long> e : t0.entrySet()) {
            long t1 = readTicks(e.getKey());
            if (t1 < 0) continue;
            out.put(e.getKey(), (t1 - e.getValue()) / (double) hz / dt * 100.0);
        }
        return out;
    }

    /** Đo tất cả tiến trình của app trong windowMs (chặn luồng gọi; không gọi trên main thread). */
    static Map<String, Double> measureAll(Context c, long windowMs) {
        Map<String, Double> out = new TreeMap<>();
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> ps = am != null ? am.getRunningAppProcesses() : null;
        if (ps == null) return out;
        Map<Integer, String> names = new HashMap<>();
        for (ActivityManager.RunningAppProcessInfo p : ps) {
            if (p.processName == null || !p.processName.startsWith(c.getPackageName())) continue;
            names.put(p.pid, p.processName);
        }
        Map<Integer, Double> cpu = measurePids(names.keySet(), windowMs);
        for (Map.Entry<Integer, Double> e : cpu.entrySet()) out.put(names.get(e.getKey()), e.getValue());
        return out;
    }
}
