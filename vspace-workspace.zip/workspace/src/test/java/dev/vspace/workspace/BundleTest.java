package dev.vspace.workspace;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Gói XAPK/APKS: phân loại mục, ghép split (qua APKEditor giả), chép OBB. */
public class BundleTest {

    private static File tempDir() throws Exception {
        File d = File.createTempFile("vspace-bundle", "");
        d.delete();
        d.mkdirs();
        d.deleteOnExit();
        return d;
    }

    private static File zip(File dir, String name, String[] entries, int[] sizes) throws Exception {
        File f = new File(dir, name);
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(f))) {
            for (int i = 0; i < entries.length; i++) {
                z.putNextEntry(new ZipEntry(entries[i]));
                if (!entries[i].endsWith("/")) z.write(new byte[sizes[i]]);
                z.closeEntry();
            }
        }
        return f;
    }

    // ---- BundlePlan ----

    @Test
    public void plan_singleApkWithObb() {
        BundlePlan.Plan p = BundlePlan.plan(Arrays.asList(
                "com.game.apk", "Android/obb/com.game/main.12.com.game.obb", "Android/obb/com.game/", "manifest.json"));
        assertEquals(1, p.baseCount);
        assertFalse(p.split);
        assertEquals(1, p.obbs.size());
    }

    @Test
    public void plan_detectsSplitsInAllNamingStyles() {
        assertTrue(BundlePlan.plan(Arrays.asList("base.apk", "split_config.arm64_v8a.apk")).split);
        assertTrue(BundlePlan.plan(Arrays.asList("base.apk", "config.xxhdpi.apk")).split);
        assertTrue(BundlePlan.plan(Arrays.asList("com.x.apk", "split_feature.apk")).split);
        BundlePlan.Plan p = BundlePlan.plan(Arrays.asList("base.apk", "split_config.en.apk", "split_config.arm64_v8a.apk"));
        assertEquals(3, p.apks.size());
        assertEquals(1, p.baseCount);
    }

    @Test
    public void plan_splitNameContainingSplitConfigInTheMiddle() {
        assertTrue(BundlePlan.isSplitName("com.x.split_config.en.apk"));
        assertTrue(BundlePlan.plan(Arrays.asList("base.apk", "com.x.split_config.en.apk")).split);
        assertFalse(BundlePlan.isSplitName("base.apk"));
        assertFalse(BundlePlan.isSplitName("com.game.apk"));
    }

    @Test
    public void plan_ignoresDirectoriesAndNoise() {
        BundlePlan.Plan p = BundlePlan.plan(Arrays.asList("dir/", "readme.txt", "icon.png", null));
        assertTrue(p.apks.isEmpty());
        assertTrue(p.obbs.isEmpty());
        assertEquals(0, p.baseCount);
    }

    @Test
    public void plan_rejectsUnsafeObbNames() {
        assertTrue(BundlePlan.isSafeObbName("main.12.com.game.obb"));
        assertFalse(BundlePlan.isSafeObbName(""));
        assertFalse(BundlePlan.isSafeObbName(".."));
        assertFalse(BundlePlan.isSafeObbName("a..b.obb"));
        assertFalse(BundlePlan.isSafeObbName("a/b.obb"));
        assertFalse(BundlePlan.isSafeObbName("a\\b.obb"));
        assertFalse(BundlePlan.isSafeObbName("c:evil.obb"));
        assertFalse(BundlePlan.isSafeObbName("bad\u0001.obb"));
        // mục có đường dẫn lên trên bị loại ngay từ plan
        BundlePlan.Plan p = BundlePlan.plan(Arrays.asList("Android/obb/x/../../evil..obb", "Android/obb/x/main.1.x.obb"));
        assertEquals(1, p.obbs.size());
        assertEquals("Android/obb/x/main.1.x.obb", p.obbs.get(0));
    }

    @Test
    public void plan_obbDirIsPerPackageAndSpace() {
        assertEquals("storage/emulated/0/Android/obb/com.game", BundlePlan.obbDirRel("com.game", 0));
        assertEquals("storage/emulated/2/Android/obb/com.game", BundlePlan.obbDirRel("com.game", 2));
        assertEquals("main.obb", BundlePlan.baseName("Android/obb/com.game/main.obb"));
        assertEquals("main.obb", BundlePlan.baseName("main.obb"));
    }

    // ---- SplitMerger (APKEditor giả trong thư mục test) ----

    @Test
    public void splitMerger_argsAreMergeCommand() throws Exception {
        File d = tempDir();
        String[] a = SplitMerger.args(new File(d, "in.xapk"), new File(d, "out.apk"));
        assertEquals("m", a[0]);
        assertEquals("-i", a[1]);
        assertEquals("-o", a[3]);
        assertTrue(a[2].endsWith("in.xapk"));
        assertTrue(a[4].endsWith("out.apk"));
    }

    @Test
    public void splitMerger_happyPathWritesValidApk() throws Exception {
        com.reandroid.apkeditor.Main.mode = 0;
        assertTrue(SplitMerger.available());
        File d = tempDir();
        File out = new File(d, "merged.apk");
        assertTrue(SplitMerger.merge(new File(d, "in.xapk"), out));
        assertTrue(SplitMerger.looksLikeApk(out));
        assertEquals("m", com.reandroid.apkeditor.Main.lastArgs[0]);
    }

    @Test
    public void splitMerger_failureModesAreRejectedByCheckingOutputNotReturnCode() throws Exception {
        File d = tempDir();
        File out = new File(d, "merged.apk");
        com.reandroid.apkeditor.Main.mode = 1; // trả mã lỗi, không ghi file
        assertFalse(SplitMerger.merge(new File(d, "in.xapk"), out));
        com.reandroid.apkeditor.Main.mode = 2; // ném ngoại lệ
        assertFalse(SplitMerger.merge(new File(d, "in.xapk"), out));
        com.reandroid.apkeditor.Main.mode = 3; // ghi file rác không phải ZIP: trả 0 nhưng vẫn bị từ chối và bị xóa
        assertFalse(SplitMerger.merge(new File(d, "in.xapk"), out));
        assertFalse(out.exists());
        com.reandroid.apkeditor.Main.mode = 0;
    }

    @Test
    public void splitMerger_looksLikeApkRejectsTinyOrMissingFiles() throws Exception {
        File d = tempDir();
        assertFalse(SplitMerger.looksLikeApk(null));
        assertFalse(SplitMerger.looksLikeApk(new File(d, "nope.apk")));
        File tiny = new File(d, "tiny.apk");
        try (FileOutputStream f = new FileOutputStream(tiny)) {
            f.write(new byte[]{'P', 'K', 3, 4});
        }
        assertFalse(SplitMerger.looksLikeApk(tiny));
    }

    // ---- ObbImporter ----

    @Test
    public void obb_copyToCopiesSkipsUnsafeAndIsIdempotent() throws Exception {
        File d = tempDir();
        File bundle = zip(d, "g.xapk",
                new String[]{"com.g.apk", "Android/obb/com.g/main.1.com.g.obb", "Android/obb/com.g/patch.1.com.g.obb", "x/../evil..obb"},
                new int[]{10, 5000, 300, 10});
        List<String> entries = BundlePlan.plan(Arrays.asList("com.g.apk", "Android/obb/com.g/main.1.com.g.obb",
                "Android/obb/com.g/patch.1.com.g.obb")).obbs;
        File dest = new File(d, "dest/obb/com.g");
        assertEquals(2, ObbImporter.copyTo(dest, bundle, entries));
        assertEquals(5000L, new File(dest, "main.1.com.g.obb").length());
        assertEquals(300L, new File(dest, "patch.1.com.g.obb").length());
        assertFalse(new File(dest, "main.1.com.g.obb.part").exists());
        long t = new File(dest, "main.1.com.g.obb").lastModified();
        assertEquals(2, ObbImporter.copyTo(dest, bundle, entries)); // lần hai: bỏ qua vì cùng kích thước
        assertEquals(t, new File(dest, "main.1.com.g.obb").lastModified());
        // mục không an toàn không bao giờ được ghi ra ngoài thư mục đích
        List<String> evil = new ArrayList<>(Arrays.asList("x/../evil..obb"));
        assertEquals(0, ObbImporter.copyTo(dest, bundle, evil));
        assertFalse(new File(d, "evil..obb").exists());
    }

    @Test
    public void obb_copyToReplacesFileWithDifferentSize() throws Exception {
        File d = tempDir();
        File bundle = zip(d, "g.xapk", new String[]{"Android/obb/com.g/main.1.com.g.obb"}, new int[]{4000});
        File dest = new File(d, "dest");
        dest.mkdirs();
        try (FileOutputStream f = new FileOutputStream(new File(dest, "main.1.com.g.obb"))) {
            f.write(new byte[123]); // bản dở dang/cũ khác kích thước
        }
        assertEquals(1, ObbImporter.copyTo(dest, bundle, Arrays.asList("Android/obb/com.g/main.1.com.g.obb")));
        assertEquals(4000L, new File(dest, "main.1.com.g.obb").length());
    }

    @Test
    public void obb_totalBytesAndRequiredBytes() throws Exception {
        File d = tempDir();
        File bundle = zip(d, "g.xapk", new String[]{"a.obb", "b.obb"}, new int[]{1000, 2000});
        assertEquals(3000L, ObbImporter.totalBytes(bundle, Arrays.asList("a.obb", "b.obb")));
        assertEquals(1000L, ObbImporter.totalBytes(bundle, Arrays.asList("a.obb", "khong-co.obb")));
        assertEquals(-1L, ObbImporter.totalBytes(new File(d, "khong-ton-tai.zip"), Arrays.asList("a.obb")));
        assertEquals(1100L, ObbImporter.requiredBytes(1000));
        assertEquals(-1, ObbImporter.copyTo(new File(d, "dest"), new File(d, "khong-ton-tai.zip"), Arrays.asList("a.obb")));
    }
}
