package dev.vspace.workspace;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class PermissionBridgeTest {

    private static HashSet<String> set(String... s) {
        return new HashSet<>(Arrays.asList(s));
    }

    @Test
    public void classifiesGrantedRequestableAndBlocked() {
        PermissionBridge.Report r = PermissionBridge.classify(
                Arrays.asList("android.permission.CAMERA", "android.permission.RECORD_AUDIO", "android.permission.READ_CONTACTS"),
                set("android.permission.CAMERA", "android.permission.RECORD_AUDIO"),
                set("android.permission.CAMERA"));
        assertEquals(Collections.singletonList("android.permission.CAMERA"), r.granted);
        assertEquals(Collections.singletonList("android.permission.RECORD_AUDIO"), r.requestable);
        assertEquals(Collections.singletonList("android.permission.READ_CONTACTS"), r.blocked);
    }

    @Test
    public void grantedWinsEvenIfNotListedAsDeclared() {
        PermissionBridge.Report r = PermissionBridge.classify(
                Collections.singletonList("android.permission.CAMERA"), set(), set("android.permission.CAMERA"));
        assertEquals(1, r.granted.size());
        assertTrue(r.blocked.isEmpty());
    }

    @Test
    public void emptyInputGivesEmptyReport() {
        PermissionBridge.Report r = PermissionBridge.classify(Collections.<String>emptyList(), set(), set());
        assertTrue(r.granted.isEmpty() && r.requestable.isEmpty() && r.blocked.isEmpty());
    }

    @Test
    public void shortNameStripsPrefix() {
        assertEquals("CAMERA", PermissionBridge.shortName("android.permission.CAMERA"));
        assertEquals("X", PermissionBridge.shortName("X"));
    }

    @Test
    public void detectsSharedStorageNeed() {
        List<String> a = Arrays.asList("android.permission.INTERNET", "android.permission.WRITE_EXTERNAL_STORAGE");
        assertTrue(PermissionBridge.wantsSharedStorage(a));
        assertTrue(PermissionBridge.wantsSharedStorage(Collections.singletonList("android.permission.MANAGE_EXTERNAL_STORAGE")));
        assertFalse(PermissionBridge.wantsSharedStorage(Collections.singletonList("android.permission.INTERNET")));
    }

    @Test
    public void trashPurgePlanKeepsNewestAndDropsExpired() {
        long day = 24L * 60 * 60 * 1000;
        long now = 100 * day;
        long[] times = {now - 1 * day, now - 20 * day, now - 2 * day, now - 3 * day, now - 4 * day};
        // keep=3: giữ #0 (1 ngày), #2 (2), #3 (3); #4 (4 ngày) vượt keep; #1 quá hạn 14 ngày
        List<Integer> del = TrashBin.indicesToDelete(times, now, 3, 14 * day);
        assertEquals(new HashSet<>(Arrays.asList(1, 4)), new HashSet<>(del));
        assertTrue(TrashBin.indicesToDelete(new long[0], now, 3, 14 * day).isEmpty());
        assertEquals(1, TrashBin.indicesToDelete(new long[]{now - 30 * day}, now, 3, 14 * day).size());
    }
}
