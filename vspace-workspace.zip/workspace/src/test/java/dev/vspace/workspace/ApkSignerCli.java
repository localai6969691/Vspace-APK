package dev.vspace.workspace;

import java.io.File;

/** Tiện ích dòng lệnh cho scripts/verify_real.py: ký một APK bằng ApkSigner rồi để apksigner THẬT kiểm tra. Không phải test. */
public final class ApkSignerCli {
    public static void main(String[] a) throws Exception {
        ApkSigner.Signer s = ApkSigner.loadOrCreate(new File(a[2]));
        ApkSigner.sign(new File(a[0]), new File(a[1]), s);
        System.out.println("signed " + a[1]);
    }
}
