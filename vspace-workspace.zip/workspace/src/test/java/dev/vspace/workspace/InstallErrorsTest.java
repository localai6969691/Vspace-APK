package dev.vspace.workspace;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class InstallErrorsTest {
    @Test
    public void classifiesKnownFailures() {
        assertEquals(InstallErrors.Kind.NO_SPACE, InstallErrors.classify("INSTALL_FAILED_INSUFFICIENT_STORAGE"));
        assertEquals(InstallErrors.Kind.NO_SPACE, InstallErrors.classify("write failed: ENOSPC (No space left on device)"));
        assertEquals(InstallErrors.Kind.ABI, InstallErrors.classify("INSTALL_FAILED_NO_MATCHING_ABIS: Failed to extract native libraries"));
        assertEquals(InstallErrors.Kind.SIGNATURE, InstallErrors.classify("INSTALL_FAILED_UPDATE_INCOMPATIBLE: signatures do not match"));
        assertEquals(InstallErrors.Kind.SIGNATURE, InstallErrors.classify("INSTALL_PARSE_FAILED_NO_CERTIFICATES"));
        assertEquals(InstallErrors.Kind.DOWNGRADE, InstallErrors.classify("INSTALL_FAILED_VERSION_DOWNGRADE"));
        assertEquals(InstallErrors.Kind.ALREADY, InstallErrors.classify("Package already exists"));
        assertEquals(InstallErrors.Kind.SDK, InstallErrors.classify("INSTALL_FAILED_OLDER_SDK"));
        assertEquals(InstallErrors.Kind.PARSE, InstallErrors.classify("INSTALL_PARSE_FAILED_BAD_MANIFEST"));
        assertEquals(InstallErrors.Kind.PARSE, InstallErrors.classify("java.util.zip.ZipException: invalid entry"));
    }

    @Test
    public void specificBeforeGeneric() {
        // chữ ký có chứa "parse" nhưng phải ra SIGNATURE, không phải PARSE
        assertEquals(InstallErrors.Kind.SIGNATURE, InstallErrors.classify("INSTALL_PARSE_FAILED_INCONSISTENT_CERTIFICATES"));
        // "abi" phải khớp theo từ, không khớp trong "habit"
        assertEquals(InstallErrors.Kind.UNKNOWN, InstallErrors.classify("bad habit detected"));
    }

    @Test
    public void unknownAndEmpty() {
        assertEquals(InstallErrors.Kind.UNKNOWN, InstallErrors.classify(null));
        assertEquals(InstallErrors.Kind.UNKNOWN, InstallErrors.classify("   "));
        assertEquals(InstallErrors.Kind.UNKNOWN, InstallErrors.classify("something odd happened"));
    }

    @Test
    public void shortenIsSingleLineAndBounded() {
        assertEquals("a b", InstallErrors.shorten("a\nb", 10));
        assertEquals("abcde…", InstallErrors.shorten("abcdefghij", 5));
        assertEquals("", InstallErrors.shorten(null, 5));
    }
}
