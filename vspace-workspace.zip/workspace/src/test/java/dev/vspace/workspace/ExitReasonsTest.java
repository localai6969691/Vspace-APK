package dev.vspace.workspace;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ExitReasonsTest {
    @Test
    public void classifiesByAndroidReasonCodes() {
        assertEquals(ExitReasons.Cause.USER, ExitReasons.classifyCause(10));
        assertEquals(ExitReasons.Cause.USER, ExitReasons.classifyCause(11));
        assertEquals(ExitReasons.Cause.FROZEN, ExitReasons.classifyCause(14));
        assertEquals(ExitReasons.Cause.MEMORY, ExitReasons.classifyCause(3));
        assertEquals(ExitReasons.Cause.MEMORY, ExitReasons.classifyCause(9));
        assertEquals(ExitReasons.Cause.SIGNAL, ExitReasons.classifyCause(2));
        assertEquals(ExitReasons.Cause.CRASH, ExitReasons.classifyCause(4));
        assertEquals(ExitReasons.Cause.CRASH, ExitReasons.classifyCause(5));
        assertEquals(ExitReasons.Cause.CRASH, ExitReasons.classifyCause(6));
        assertEquals(ExitReasons.Cause.OTHER, ExitReasons.classifyCause(1));    // EXIT_SELF
        assertEquals(ExitReasons.Cause.OTHER, ExitReasons.classifyCause(999));
    }

    @Test
    public void everyReasonNameHasACause() {
        // mọi mã 0..16 đã có tên phải phân loại được, không ném lỗi
        for (int r = 0; r <= 16; r++) {
            if (ExitReasons.reasonName(r).startsWith("REASON_")) throw new AssertionError("thiếu tên cho mã " + r);
            ExitReasons.classifyCause(r);
        }
    }
}
