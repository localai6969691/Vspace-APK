package dev.vspace.workspace;

import java.io.File;
import java.lang.reflect.Method;

/** Công cụ cho scripts/verify_real.py: lặp lại ĐÚNG chuỗi của SplitMerger.merge + ApkSigner.signInPlace trên JVM (APKEditor thật). Không phải test. */
public final class MergePipelineCli {
    public static void main(String[] a) throws Exception {
        File in = new File(a[0]);
        File out = new File(a[1]);
        Class<?> c = Class.forName("com.reandroid.apkeditor.Main");
        Method m = c.getMethod("execute", String[].class);
        m.invoke(null, (Object) new String[]{"m", "-i", in.getAbsolutePath(), "-o", out.getAbsolutePath()});
        String err = ApkSigner.signInPlace(out, new File(a[2]));
        System.out.println(err == null ? "merged+signed " + out.length() + " bytes" : "SIGN FAIL " + err);
        if (err != null) System.exit(1);
    }
}
