package dev.vspace.workspace;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Test các hàm thuần (không cần thiết bị). Chạy: ./gradlew :workspace:testDebugUnitTest */
public class PureLogicTest {

    private static Set<String> set(String... s) {
        Set<String> r = new HashSet<>();
        for (String x : s) r.add(x);
        return r;
    }

    // ---- Scheduler.nextOccurrence ----

    @Test
    public void nextOccurrence_isInFutureWithinAboutOneDayAndMatchesMinute() {
        long after = 1_700_000_000_000L;
        int[] minutes = {0, 59, 12 * 60 + 30, 23 * 60 + 59};
        for (int minute : minutes) {
            long t = Scheduler.nextOccurrence(minute, after);
            assertTrue("phải ở tương lai", t > after);
            assertTrue("trong vòng ~1 ngày (cho phép lệch DST)", t - after <= 25L * 3600_000L);
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(t);
            assertEquals(minute, c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE));
        }
    }

    @Test
    public void nextOccurrence_exactlyAtTargetRollsToNextDay() {
        Calendar c = Calendar.getInstance();
        c.set(2026, Calendar.JANUARY, 5, 10, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        long exactly = c.getTimeInMillis();
        long t = Scheduler.nextOccurrence(10 * 60, exactly);
        long delta = t - exactly;
        assertTrue(delta >= 23L * 3600_000L && delta <= 25L * 3600_000L);
    }

    // ---- CpuSampler.parseTicks ----

    @Test
    public void parseTicks_sumsUtimeAndStime() {
        // tên tiến trình chứa khoảng trắng và ngoặc; utime=100, stime=50
        String line = "42 (my (proc) x) S 1 1 1 0 -1 4194560 100 0 0 0 100 50 0 0 20 0 1 0 12345 1000 200";
        assertEquals(150L, CpuSampler.parseTicks(line));
    }

    @Test
    public void parseTicks_badInputReturnsMinusOne() {
        assertEquals(-1L, CpuSampler.parseTicks(null));
        assertEquals(-1L, CpuSampler.parseTicks("khong co ngoac"));
        assertEquals(-1L, CpuSampler.parseTicks("1 (a) S 1 2"));
    }

    // ---- ApkImporter.abiVerdict / hex ----

    @Test
    public void abiVerdict_matrix() {
        assertEquals(0, ApkImporter.abiVerdict(set(), true));                       // thuần Java
        assertEquals(0, ApkImporter.abiVerdict(set("arm64-v8a", "armeabi-v7a"), true));
        assertEquals(1, ApkImporter.abiVerdict(set("armeabi-v7a"), true));          // host 64, chỉ có 32
        assertEquals(2, ApkImporter.abiVerdict(set("arm64-v8a"), false));           // host 32, chỉ có 64
        assertEquals(0, ApkImporter.abiVerdict(set("armeabi-v7a"), false));
    }

    @Test
    public void hex_formatsUppercaseWithColons() {
        assertEquals("00:0F:FF", ApkImporter.hex(new byte[]{0x00, 0x0f, (byte) 0xff}));
        assertEquals("", ApkImporter.hex(new byte[0]));
    }

    @Test
    public void shortPerm_stripsPrefix() {
        assertEquals("CAMERA", ApkImporter.shortPerm("android.permission.CAMERA"));
        assertEquals("NODOT", ApkImporter.shortPerm("NODOT"));
    }

    // ---- RiskList ----

    @Test
    public void riskList_knownAndPrefix() {
        assertTrue(RiskList.isRisky("com.tencent.ig"));
        assertTrue(RiskList.isRisky("com.miHoYo.GenshinImpact"));
        assertTrue(RiskList.isRisky("com.tencent.tmgp.anything"));
        assertFalse(RiskList.isRisky("com.example.notes"));
        assertFalse(RiskList.isRisky(null));
    }

    // ---- GameModeController.fmt / GameProfile.key / ExitReasons.reasonName ----

    @Test
    public void fmt_hoursAndMinutes() {
        assertEquals("1h 1m", GameModeController.fmt(3_660_000L));
        assertEquals("0h 0m", GameModeController.fmt(0L));
        assertEquals("0h 0m", GameModeController.fmt(-5_000L));
        assertEquals("8h 0m", GameModeController.fmt(8L * 3600_000L));
    }

    @Test
    public void gameProfile_keyIncludesSpace() {
        assertEquals("a.b.2", GameProfile.key("a.b", 2));
    }

    @Test
    public void exitReasons_namesIncludeFreezer() {
        assertEquals("FREEZER", ExitReasons.reasonName(14));
        assertEquals("LOW_MEMORY", ExitReasons.reasonName(3));
        assertEquals("REASON_999", ExitReasons.reasonName(999));
    }

    // ---- GuestBackup (hàm thuần) ----

    @Test
    public void backup_safeEntryNames() {
        assertTrue(GuestBackup.isSafeEntryName("data/files/save.dat"));
        assertTrue(GuestBackup.isSafeEntryName("ext/Android/data/x/a.obb"));
        assertFalse(GuestBackup.isSafeEntryName("../evil"));
        assertFalse(GuestBackup.isSafeEntryName("data/../../evil"));
        assertFalse(GuestBackup.isSafeEntryName("data/.."));
        assertFalse(GuestBackup.isSafeEntryName("/etc/passwd"));
        assertFalse(GuestBackup.isSafeEntryName("data\\evil"));
        assertFalse(GuestBackup.isSafeEntryName("data/a\u0000b"));
        assertFalse(GuestBackup.isSafeEntryName(""));
        assertFalse(GuestBackup.isSafeEntryName(null));
    }

    @Test
    public void backup_skipsOnlyTopLevelCaches() {
        assertTrue(GuestBackup.shouldSkip("cache"));
        assertTrue(GuestBackup.shouldSkip("cache/img/1.png"));
        assertTrue(GuestBackup.shouldSkip("code_cache/x"));
        assertFalse(GuestBackup.shouldSkip("files/cache/keep.me"));
        assertFalse(GuestBackup.shouldSkip("cachefile"));
        assertFalse(GuestBackup.shouldSkip("databases/game.db"));
        assertFalse(GuestBackup.shouldSkip("shared_prefs/a.xml"));
    }

    @Test
    public void backup_metaRoundTrip() {
        GuestBackup.Meta m = new GuestBackup.Meta();
        m.format = GuestBackup.FORMAT;
        m.pkg = "com.example.game";
        m.user = 2;
        m.label = "Game\nHay";
        m.versionCode = 123456789012L;
        m.hasApk = true;
        m.createdAt = 1700000000000L;
        GuestBackup.Meta r = GuestBackup.parseMeta(GuestBackup.buildMeta(m));
        assertEquals(GuestBackup.FORMAT, r.format);
        assertEquals("com.example.game", r.pkg);
        assertEquals(2, r.user);
        assertEquals("Game Hay", r.label); // xuống dòng được thay bằng khoảng trắng
        assertEquals(123456789012L, r.versionCode);
        assertTrue(r.hasApk);
        assertEquals(1700000000000L, r.createdAt);
    }

    @Test
    public void backup_parseMetaIgnoresGarbage() {
        GuestBackup.Meta r = GuestBackup.parseMeta("rac roi\nuser=abc\nformat=1\npkg=a.b\n=x\n");
        assertEquals(1, r.format);
        assertEquals("a.b", r.pkg);
        assertEquals(0, r.user);
    }

    @Test
    public void backup_fileNameSortsByTimeAndKeepsPrefix() {
        String a = GuestBackup.backupFileName("a.b", 2, 1_700_000_000_000L);
        String b = GuestBackup.backupFileName("a.b", 2, 1_700_000_000_000L + 3600_000L * 5);
        assertTrue(a.startsWith(GuestBackup.backupPrefix("a.b", 2)));
        assertTrue(a.endsWith(".zip"));
        assertTrue("mốc sau phải lớn hơn khi so chuỗi", b.compareTo(a) > 0);
        assertFalse(a.startsWith(GuestBackup.backupPrefix("a.b", 1)));
    }

    // ---- TraceText ----

    @Test
    public void traceText_extractsPrintableRunsDedupedInOrder() {
        byte[] d = "\u0000\u0000abc\u0000libfoo.so\u0000\u0001libfoo.so\u0000hello world\u0000"
                .getBytes(StandardCharsets.ISO_8859_1);
        assertEquals(Arrays.asList("libfoo.so", "hello world"), TraceText.strings(d, 5, 10));
        assertEquals(1, TraceText.strings(d, 5, 1).size()); // giới hạn số dòng
    }

    // ---- ProcessPinner.isPinTarget / isGuestProcess ----

    @Test
    public void pinner_recognisesGuestAndDaemonProcesses() {
        String host = "dev.vspace.workspace";
        assertTrue(ProcessPinner.isPinTarget(host, host + ":p0"));
        assertTrue(ProcessPinner.isPinTarget(host, host + ":p49"));
        assertTrue(ProcessPinner.isPinTarget(host, host + ":daemon"));
        assertFalse(ProcessPinner.isPinTarget(host, host));
        assertFalse(ProcessPinner.isPinTarget(host, host + ":p"));
        assertFalse(ProcessPinner.isPinTarget(host, "other.app:p0"));
        assertFalse(ProcessPinner.isPinTarget(host, null));
        assertTrue(ProcessPinner.isGuestProcess(host, host + ":p3"));
        assertFalse(ProcessPinner.isGuestProcess(host, host + ":daemon"));
    }

    // ---- GuestRegistry ----

    @Test
    public void registry_tracksByPackageAndSpace() {
        GuestRegistry.Info a = new GuestRegistry.Info(1001, "com.g", "h:p0", 0);
        GuestRegistry.Info b = new GuestRegistry.Info(1002, "com.g", "h:p1", 1);
        GuestRegistry.put(a);
        GuestRegistry.put(b);
        try {
            assertEquals(1, GuestRegistry.forPackage("com.g", 0).size());
            assertEquals(1, GuestRegistry.forPackage("com.g", 1).size());
            assertTrue(GuestRegistry.pidsFor("com.g", 1).contains(1002));
            assertEquals(0, GuestRegistry.forPackage("com.other", 0).size());
            assertEquals(0, GuestRegistry.send("com.g", 0, "{}")); // chưa có kết nối thật
        } finally {
            GuestRegistry.remove(1001);
            GuestRegistry.remove(1002);
        }
        assertEquals(0, GuestRegistry.forPackage("com.g", 0).size());
        assertTrue(GuestRegistry.waitUntilGone("com.g", 0, 50));
    }

    // ---- ScreenPower (hàm thuần) ----

    @Test
    public void screenPower_parseSecondsDefaultsAndClamps() {
        assertEquals(28800, ScreenPower.parseSeconds(new String[]{"off"}));
        assertEquals(600, ScreenPower.parseSeconds(new String[]{"off", "600"}));
        assertEquals(10, ScreenPower.parseSeconds(new String[]{"off", "1"}));
        assertEquals(86400, ScreenPower.parseSeconds(new String[]{"off", "999999999"}));
        assertEquals(28800, ScreenPower.parseSeconds(new String[]{"off", "abc"}));
        assertTrue(ScreenPower.hasFlag(new String[]{"off", "600", "detach"}, "detach"));
        assertFalse(ScreenPower.hasFlag(new String[]{"off", "600"}, "detach"));
        assertFalse(ScreenPower.hasFlag(new String[]{"detach"}, "detach")); // chỉ xét tham số sau hành động
    }

    @Test
    public void screenPower_commandShape() {
        assertEquals("adb shell \"CLASSPATH=/data/app/x/base.apk app_process / dev.vspace.workspace.ScreenPower off 3600\"",
                ScreenPower.command("/data/app/x/base.apk", "off", 3600));
        assertEquals("adb shell \"CLASSPATH=/a.apk app_process / dev.vspace.workspace.ScreenPower on\"",
                ScreenPower.command("/a.apk", "on", 123));
        assertTrue(ScreenPower.command("/a.apk", "off", 1).endsWith("off 10\""));
        assertTrue(ScreenPower.command("/a.apk", "off", 9_999_999).endsWith("off 86400\""));
    }

    // ---- Preflight.evaluate ----

    private static Preflight.Snapshot goodSnapshot() {
        return new Preflight.Snapshot();
    }

    @Test
    public void preflight_cleanSnapshotHasNoIssues() {
        assertTrue(Preflight.evaluate(goodSnapshot()).isEmpty());
        assertFalse(Preflight.hasWarnings(Preflight.evaluate(goodSnapshot())));
    }

    @Test
    public void preflight_flagsEachProblem() {
        Preflight.Snapshot s = goodSnapshot();
        s.ignoringBattery = false;
        s.bucket = 45;
        s.restrictBackground = 3;
        s.thermal = 3;
        s.batteryPct = 17;
        s.minBattery = 15;
        s.mode = GameProfile.MODE_FAKE_OFF;
        s.overlay = false;
        s.notifications = false;
        s.availMb = 120;
        List<Preflight.Issue> r = Preflight.evaluate(s);
        for (String code : new String[]{Preflight.BATTERY_OPT, Preflight.BUCKET, Preflight.DATA_SAVER, Preflight.THERMAL,
                Preflight.BATTERY_LOW, Preflight.OVERLAY, Preflight.NOTIF, Preflight.LOW_MEMORY}) {
            assertTrue(code, Preflight.has(r, code));
        }
        assertTrue(Preflight.hasWarnings(r));
        assertEquals("RESTRICTED", Preflight.bucketName(45));
    }

    @Test
    public void preflight_bucketThresholdIsRareNotFrequent() {
        Preflight.Snapshot s = goodSnapshot();
        s.bucket = 30; // FREQUENT: chấp nhận được
        assertFalse(Preflight.has(Preflight.evaluate(s), Preflight.BUCKET));
        s.bucket = 40; // RARE: job/alarm/mạng bị hoãn mạnh
        assertTrue(Preflight.has(Preflight.evaluate(s), Preflight.BUCKET));
        assertEquals("RARE", Preflight.bucketName(40));
        assertEquals("FREQUENT", Preflight.bucketName(30));
        assertEquals("ACTIVE", Preflight.bucketName(10));
    }

    @Test
    public void preflight_overlayOnlyMattersForFakeOffAndChargingSilencesBattery() {
        Preflight.Snapshot s = goodSnapshot();
        s.overlay = false;
        s.mode = GameProfile.MODE_DIM;
        assertFalse(Preflight.has(Preflight.evaluate(s), Preflight.OVERLAY));
        s.mode = GameProfile.MODE_FAKE_OFF;
        assertTrue(Preflight.has(Preflight.evaluate(s), Preflight.OVERLAY));
        s.batteryPct = 10;
        s.minBattery = 15;
        s.charging = true;
        assertFalse(Preflight.has(Preflight.evaluate(s), Preflight.BATTERY_LOW));
        s.charging = false;
        assertTrue(Preflight.has(Preflight.evaluate(s), Preflight.BATTERY_LOW));
    }

    @Test
    public void preflight_infoOnlyIssuesAreNotWarnings() {
        Preflight.Snapshot s = goodSnapshot();
        s.host64 = false;
        s.autoRevoke = 0;
        s.oemAggressive = true;
        List<Preflight.Issue> r = Preflight.evaluate(s);
        assertTrue(Preflight.has(r, Preflight.HOST32));
        assertTrue(Preflight.has(r, Preflight.AUTO_REVOKE));
        assertTrue(Preflight.has(r, Preflight.OEM));
        assertFalse(Preflight.hasWarnings(r));
        s.mode = GameProfile.MODE_SAVER;
        assertFalse(Preflight.has(Preflight.evaluate(s), Preflight.HOST32));
    }

    @Test
    public void preflight_unknownValuesAreNotFlagged() {
        Preflight.Snapshot s = goodSnapshot(); // bucket/thermal/restrict = -1, availMb = -1
        assertFalse(Preflight.has(Preflight.evaluate(s), Preflight.BUCKET));
        assertFalse(Preflight.has(Preflight.evaluate(s), Preflight.THERMAL));
        assertFalse(Preflight.has(Preflight.evaluate(s), Preflight.DATA_SAVER));
        assertFalse(Preflight.has(Preflight.evaluate(s), Preflight.LOW_MEMORY));
    }

    // ---- OemGuide ----

    @Test
    public void oemGuide_familyMapping() {
        assertEquals(OemGuide.XIAOMI, OemGuide.family("Xiaomi"));
        assertEquals(OemGuide.XIAOMI, OemGuide.family("POCO"));
        assertEquals(OemGuide.XIAOMI, OemGuide.family("Redmi"));
        assertEquals(OemGuide.HUAWEI, OemGuide.family("HONOR"));
        assertEquals(OemGuide.OPPO, OemGuide.family("realme"));
        assertEquals(OemGuide.ONEPLUS, OemGuide.family("OnePlus"));
        assertEquals(OemGuide.VIVO, OemGuide.family("iQOO"));
        assertEquals(OemGuide.SAMSUNG, OemGuide.family("samsung"));
        assertEquals(OemGuide.NOKIA, OemGuide.family("HMD Global"));
        assertEquals(OemGuide.GENERIC, OemGuide.family("Google"));
        assertEquals(OemGuide.GENERIC, OemGuide.family(null));
        assertTrue(OemGuide.isAggressive("Samsung"));
        assertFalse(OemGuide.isAggressive("Google"));
        assertEquals("https://dontkillmyapp.com/xiaomi", OemGuide.url(OemGuide.XIAOMI));
        assertEquals("https://dontkillmyapp.com/", OemGuide.url(OemGuide.GENERIC));
    }

    @Test
    public void oemGuide_otaReminderOnlyWhenExemptionLostAfterBuildChange() {
        assertTrue(OemGuide.otaReminderNeeded("fp-old", "fp-new", false));
        assertFalse(OemGuide.otaReminderNeeded("fp-old", "fp-new", true));   // vẫn miễn trừ
        assertFalse(OemGuide.otaReminderNeeded("fp-same", "fp-same", false)); // cùng bản build
        assertFalse(OemGuide.otaReminderNeeded(null, "fp-new", false));       // chưa từng miễn trừ
        assertFalse(OemGuide.otaReminderNeeded("", "fp-new", false));
    }

    // ---- SessionStats ----

    private static SessionStats.Entry entry(long start, long durMin, int b0, int b1, boolean plugged) {
        SessionStats.Entry e = new SessionStats.Entry();
        e.start = start;
        e.durMs = durMin * 60_000L;
        e.batStart = b0;
        e.batEnd = b1;
        e.plugged = plugged;
        e.maxTempDeci = 412;
        e.deaths = 1;
        e.reason = "het gio; ok=1";
        return e;
    }

    @Test
    public void sessionStats_lineRoundTripAndSanitizesReason() {
        SessionStats.Entry e = entry(1000, 120, 80, 60, false);
        SessionStats.Entry r = SessionStats.parseLine(SessionStats.line(e));
        assertEquals(1000L, r.start);
        assertEquals(120 * 60_000L, r.durMs);
        assertEquals(80, r.batStart);
        assertEquals(60, r.batEnd);
        assertEquals(412, r.maxTempDeci);
        assertEquals(1, r.deaths);
        assertFalse(r.plugged);
        assertEquals("het gio, ok 1", r.reason); // ; và = bị thay để không phá định dạng
    }

    @Test
    public void sessionStats_parseSurvivesGarbage() {
        assertEquals(null, SessionStats.parseLine("hong het"));
        assertEquals(null, SessionStats.parseLine(null));
        SessionStats.Entry e = SessionStats.parseLine("s=5;d=abc;b0=70;zzz;x=2");
        assertEquals(5L, e.start);
        assertEquals(70, e.batStart);
        assertEquals(2, e.deaths);
        assertEquals(0L, e.durMs); // trường hỏng bị bỏ qua
        assertEquals(0, SessionStats.parse("\n\nrac\n").size());
    }

    @Test
    public void sessionStats_appendKeepsOnlyLastCap() {
        String text = null;
        for (int i = 1; i <= 7; i++) text = SessionStats.append(text, entry(i, 30, 90, 80, false), 5);
        List<SessionStats.Entry> list = SessionStats.parse(text);
        assertEquals(5, list.size());
        assertEquals(3L, list.get(0).start);
        assertEquals(7L, list.get(4).start);
    }

    @Test
    public void sessionStats_drainPerHour() {
        assertEquals(20.0, SessionStats.drainPerHour(entry(1, 60, 90, 70, false)), 0.001);
        assertEquals(10.0, SessionStats.drainPerHour(entry(1, 120, 90, 70, false)), 0.001);
        assertEquals(-1.0, SessionStats.drainPerHour(entry(1, 5, 90, 80, false)), 0.001);   // quá ngắn
        assertEquals(-1.0, SessionStats.drainPerHour(entry(1, 60, 90, 70, true)), 0.001);   // có cắm sạc
        assertEquals(-1.0, SessionStats.drainPerHour(entry(1, 60, 60, 70, false)), 0.001);  // pin tăng
        assertEquals(-1.0, SessionStats.drainPerHour(entry(1, 60, -1, 70, false)), 0.001);  // thiếu số liệu
    }

    @Test
    public void sessionStats_summarizeAveragesOnlyEligible() {
        java.util.List<SessionStats.Entry> l = new java.util.ArrayList<>();
        l.add(entry(1, 60, 90, 70, false)); // 20/h
        l.add(entry(2, 60, 90, 80, false)); // 10/h
        l.add(entry(3, 60, 90, 50, true));  // bỏ qua (sạc)
        SessionStats.Summary s = SessionStats.summarize(l);
        assertEquals(3, s.sessions);
        assertEquals(15.0, s.avgDrainPerHour, 0.001);
        assertEquals(3, s.deaths);
        assertEquals(412, s.maxTempDeci);
        assertEquals(-1.0, SessionStats.summarize(new java.util.ArrayList<SessionStats.Entry>()).avgDrainPerHour, 0.001);
    }

    // ---- ProcessPinner.shouldPin / AppSort ----

    @Test
    public void pinPolicy_onlySkipsKnownGamesWithPinOff() {
        assertTrue(ProcessPinner.shouldPin(false, true));
        assertTrue(ProcessPinner.shouldPin(false, false)); // chưa biết game nào: vẫn ghim
        assertTrue(ProcessPinner.shouldPin(true, true));
        assertFalse(ProcessPinner.shouldPin(true, false));
    }

    @Test
    public void appSort_modes() {
        assertTrue(AppSort.compare(AppSort.BY_NAME, "Zed", 0, true, "alpha", 0, false) > 0);
        assertTrue(AppSort.compare(AppSort.BY_NAME, "alpha", 1, false, "Alpha", 0, false) > 0); // cùng tên: theo không gian
        assertTrue(AppSort.compare(AppSort.BY_SPACE, "Zed", 0, false, "alpha", 1, false) < 0);
        assertTrue(AppSort.compare(AppSort.RUNNING_FIRST, "Zed", 0, true, "alpha", 0, false) < 0);
        assertEquals(0, AppSort.compare(AppSort.BY_NAME, "a", 0, false, "A", 0, true));
        assertEquals(1, AppSort.next(0));
        assertEquals(0, AppSort.next(AppSort.MODES - 1));
    }

    // ---- DisplayTuning ----

    @Test
    public void displayTuning_picksLowestRateAtSameResolution() {
        int[] ids = {1, 2, 3, 4, 5};
        float[] rates = {120f, 60f, 90f, 60f, 30f};
        int[] w = {1080, 1080, 1080, 1440, 1080};
        int[] h = {2400, 2400, 2400, 3200, 2400};
        assertEquals(5, DisplayTuning.pickModeId(ids, rates, w, h, 1, 30f));  // có 30Hz cùng độ phân giải
        assertEquals(2, DisplayTuning.pickModeId(ids, rates, w, h, 1, 45f));  // 45 -> thấp nhất >= 45 là 60 (id 2)
        assertEquals(0, DisplayTuning.pickModeId(ids, rates, w, h, 5, 30f));  // đã là thấp nhất: không cần đổi
        assertEquals(0, DisplayTuning.pickModeId(ids, rates, w, h, 99, 30f)); // id hiện tại không tồn tại
        assertEquals(0, DisplayTuning.pickModeId(new int[]{1}, new float[]{60f}, new int[]{1}, new int[]{1}, 1, 30f)); // chỉ có 1 chế độ
    }

    @Test
    public void displayTuning_neverPicksModeBelowTarget() {
        int[] ids = {1, 2};
        float[] rates = {120f, 24f};
        int[] w = {1080, 1080};
        int[] h = {2400, 2400};
        assertEquals(0, DisplayTuning.pickModeId(ids, rates, w, h, 1, 30f)); // 24 < 30 nên không chọn, 120 là hiện tại
    }

    @Test
    public void displayTuning_scaledSizeEvenClampedAndNeverUpscales() {
        int[] r = DisplayTuning.scaledSize(1080, 2400, 50);
        assertEquals(540, r[0]);
        assertEquals(1200, r[1]);
        assertEquals(0, r[0] % 2);
        int[] tiny = DisplayTuning.scaledSize(400, 600, 25);
        assertEquals(320, tiny[0]);                       // không nhỏ hơn MIN_SIDE
        assertEquals(200, DisplayTuning.scaledSize(200, 200, 50)[0]); // cạnh nhỏ hơn MIN_SIDE giữ nguyên, không phóng to
        int[] full = DisplayTuning.scaledSize(1080, 2400, 100);
        assertEquals(1080, full[0]);
        assertEquals(2400, full[1]);
        int[] over = DisplayTuning.scaledSize(1080, 2400, 500); // clamp về 100: không phóng to
        assertEquals(1080, over[0]);
        assertEquals(0, DisplayTuning.scaledSize(0, 100, 50)[0]);
    }

    // ---- ThreadBoost ----

    @Test
    public void threadBoost_recognizesEngineThreads() {
        assertTrue(ThreadBoost.isGameThreadName("UnityMain"));
        assertTrue(ThreadBoost.isGameThreadName("UnityGfxDevice(0"));
        assertTrue(ThreadBoost.isGameThreadName("GLThread 1234"));
        assertTrue(ThreadBoost.isGameThreadName("RenderThread"));
        assertTrue(ThreadBoost.isGameThreadName("GameThread"));
        assertFalse(ThreadBoost.isGameThreadName("OkHttp Dispatcher"));
        assertFalse(ThreadBoost.isGameThreadName("binder:1234_1"));
        assertFalse(ThreadBoost.isGameThreadName(null));
    }

    // ---- GameModeController: hàm thuần mới ----

    @Test
    public void gameMode_shouldRestartRules() {
        long gap = GameModeController.RESTART_MIN_GAP_MS;
        assertTrue(GameModeController.shouldRestart(true, true, false, 0, 10 * gap, 0));
        assertFalse(GameModeController.shouldRestart(false, true, false, 0, 10 * gap, 0));          // tắt tùy chọn
        assertFalse(GameModeController.shouldRestart(true, false, false, 0, 10 * gap, 0));          // chưa từng thấy game
        assertFalse(GameModeController.shouldRestart(true, true, true, 0, 10 * gap, 0));            // game vẫn còn
        assertFalse(GameModeController.shouldRestart(true, true, false, GameModeController.MAX_RESTARTS, 10 * gap, 0)); // hết lượt
        assertFalse(GameModeController.shouldRestart(true, true, false, 1, 10 * gap, 10 * gap - 1)); // chưa đủ khoảng cách
        assertTrue(GameModeController.shouldRestart(true, true, false, 1, 10 * gap, 9 * gap));
    }

    @Test
    public void gameMode_shouldRemindLongOnce() {
        assertFalse(GameModeController.shouldRemindLong(GameModeController.LONG_SESSION_MS - 1, false, true));
        assertTrue(GameModeController.shouldRemindLong(GameModeController.LONG_SESSION_MS, false, true));
        assertFalse(GameModeController.shouldRemindLong(GameModeController.LONG_SESSION_MS * 2, true, true)); // đã nhắc
        assertFalse(GameModeController.shouldRemindLong(GameModeController.LONG_SESSION_MS * 2, false, false)); // tắt trong Cài đặt
    }

    @Test
    public void gameMode_tuningCommandsPerMode() {
        GameProfile p = new GameProfile();
        p.mode = GameProfile.MODE_SAVER;
        p.boost = true;
        p.lowRefresh = true;
        p.lowRes = true;
        List<String> saver = GameModeController.tuningCommands(p, true);
        assertEquals(1, saver.size()); // tắt màn hình thật: chỉ boost (không có cửa sổ để giảm fps/độ phân giải)
        assertTrue(saver.get(0).contains("\"boost\"") && saver.get(0).contains("true"));

        p.mode = GameProfile.MODE_DIM;
        List<String> dim = GameModeController.tuningCommands(p, true);
        assertEquals(4, dim.size());
        assertTrue(dim.get(1).contains("\"dim\""));
        assertTrue(dim.get(2).contains("\"hz\":30"));
        assertTrue(dim.get(3).contains("\"pct\":" + GameProfile.LOW_RES_PCT));

        List<String> off = GameModeController.tuningCommands(p, false); // lệnh hoàn nguyên
        assertTrue(off.get(2).contains("\"hz\":0"));
        assertTrue(off.get(3).contains("\"pct\":0"));
        assertTrue(off.get(0).contains("false"));

        p.boost = false;
        p.lowRes = false;
        p.lowRefresh = false;
        p.mode = GameProfile.MODE_FAKE_OFF;
        assertTrue(GameModeController.tuningCommands(p, true).isEmpty());
    }

    // ---- UpdateKeeper / GuestMonitor ----

    @Test
    public void updateKeeper_restoreDecision() {
        assertTrue(UpdateKeeper.needsRestore(1000, 100, true));    // mất gần hết
        assertFalse(UpdateKeeper.needsRestore(1000, 600, true));   // còn quá nửa
        assertFalse(UpdateKeeper.needsRestore(1000, 0, false));    // cài thất bại: không đụng
        assertFalse(UpdateKeeper.needsRestore(0, 0, true));        // trước đó không có dữ liệu
        assertTrue(UpdateKeeper.enoughSpace(1000, 1200));
        assertFalse(UpdateKeeper.enoughSpace(1000, 1199));
    }

    @Test
    public void guestMonitor_totalsAndShare() {
        java.util.List<GuestMonitor.Row> rows = new java.util.ArrayList<>();
        GuestMonitor.Row a = new GuestMonitor.Row();
        a.pssKb = 200_000;
        a.cpu = 60;
        GuestMonitor.Row b = new GuestMonitor.Row();
        b.pssKb = 100_000;
        b.cpu = 20;
        GuestMonitor.Row c = new GuestMonitor.Row(); // chưa có số liệu
        rows.add(a);
        rows.add(b);
        rows.add(c);
        assertEquals(300_000L, GuestMonitor.totalPssKb(rows));
        assertEquals(80.0, GuestMonitor.totalCpu(rows), 0.001);
        assertEquals(75.0, GuestMonitor.cpuShare(a, 80.0), 0.001);
        assertEquals(-1.0, GuestMonitor.cpuShare(c, 80.0), 0.001);
        assertEquals(-1.0, GuestMonitor.cpuShare(a, 0.0), 0.001);
    }
}
