package dev.vspace.workspace;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Random;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/**
 * Kiểm BackupCrypto trên JVM bằng một SecretKey AES thường (javax.crypto thuần, không cần provider "AndroidKeyStore"
 * — provider đó chỉ có trên thiết bị Android thật). Các overload (OutputStream,SecretKey)/(InputStream,SecretKey)
 * tồn tại chính là để bài test này chạy được mà không đụng tới KeyStore thật; trên app, chỉ các overload không tham
 * số khóa (gọi AndroidKeyStore) được dùng — xem MainActivity.
 */
public class BackupCryptoTest {

    private static SecretKey key() throws Exception {
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        kg.init(256);
        return kg.generateKey();
    }

    private static byte[] roundTrip(byte[] plain, SecretKey k) throws Exception {
        ByteArrayOutputStream raw = new ByteArrayOutputStream();
        try (OutputStream enc = BackupCrypto.wrapEncrypt(raw, k)) {
            enc.write(plain);
        }
        byte[] cipherBytes = raw.toByteArray();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream dec = BackupCrypto.wrapDecrypt(new ByteArrayInputStream(cipherBytes), k)) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = dec.read(buf)) > 0) out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    @Test
    public void encryptThenDecryptRoundTripsExactly() throws Exception {
        byte[] plain = "PK\u0003\u0004 giả làm nội dung zip, có cả tiếng Việt: đẹp trai".getBytes("UTF-8");
        assertArrayEquals(plain, roundTrip(plain, key()));
    }

    @Test
    public void largePayloadAcrossManyCipherBlocksRoundTrips() throws Exception {
        byte[] plain = new byte[500_000];
        new Random(7).nextBytes(plain);
        assertArrayEquals(plain, roundTrip(plain, key()));
    }

    @Test
    public void emptyPayloadRoundTrips() throws Exception {
        assertArrayEquals(new byte[0], roundTrip(new byte[0], key()));
    }

    @Test
    public void ciphertextStartsWithMagicThenDeclaredIvLength() throws Exception {
        ByteArrayOutputStream raw = new ByteArrayOutputStream();
        try (OutputStream enc = BackupCrypto.wrapEncrypt(raw, key())) {
            enc.write("x".getBytes("UTF-8"));
        }
        byte[] b = raw.toByteArray();
        assertTrue(BackupCrypto.looksEncrypted(b));
        assertEquals(12, b[8] & 0xff); // độ dài IV khai ở byte thứ 9 (chỉ số 8), phải là 12 (GCM chuẩn)
    }

    @Test
    public void wrongKeyFailsWithAuthTagMismatch() throws Exception {
        ByteArrayOutputStream raw = new ByteArrayOutputStream();
        try (OutputStream enc = BackupCrypto.wrapEncrypt(raw, key())) {
            enc.write("bi mat".getBytes("UTF-8"));
        }
        SecretKey wrong = key();
        try (InputStream dec = BackupCrypto.wrapDecrypt(new ByteArrayInputStream(raw.toByteArray()), wrong)) {
            byte[] buf = new byte[32];
            dec.read(buf);
            throw new AssertionError("phải báo lỗi khóa sai, không được đọc được dữ liệu");
        } catch (Exception e) {
            assertTrue("phải là lỗi xác thực GCM: " + e, BackupCrypto.isKeyOrIntegrityFailure(e));
        }
    }

    /** Ngay cả với ĐÚNG khóa, sửa 1 byte ở đuôi (vùng chứa thẻ xác thực GCM) cũng phải làm giải mã thất bại. */
    @Test
    public void tamperedCiphertextIsRejectedEvenWithTheRightKey() throws Exception {
        SecretKey k = key();
        ByteArrayOutputStream raw = new ByteArrayOutputStream();
        try (OutputStream enc = BackupCrypto.wrapEncrypt(raw, k)) {
            enc.write("du lieu quan trong".getBytes("UTF-8"));
        }
        byte[] b = raw.toByteArray();
        b[b.length - 1] ^= 0x01;
        try (InputStream dec = BackupCrypto.wrapDecrypt(new ByteArrayInputStream(b), k)) {
            byte[] buf = new byte[64];
            dec.read(buf);
            throw new AssertionError("sửa 1 byte đuôi phải làm thẻ xác thực GCM sai");
        } catch (Exception e) {
            assertTrue(BackupCrypto.isKeyOrIntegrityFailure(e));
        }
    }

    @Test
    public void plainUnencryptedStreamPassesThroughUnchanged() throws Exception {
        byte[] plainZipLike = "PK\u0003\u0004 noi dung zip binh thuong, khong ma hoa".getBytes("UTF-8");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream dec = BackupCrypto.wrapDecrypt(new ByteArrayInputStream(plainZipLike), key())) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = dec.read(buf)) > 0) out.write(buf, 0, n);
        }
        assertArrayEquals(plainZipLike, out.toByteArray());
    }

    @Test
    public void shortPlainStreamUnderMagicLengthAlsoPassesThrough() throws Exception {
        byte[] tiny = "PK".getBytes("UTF-8"); // ngắn hơn cả độ dài magic (8 byte)
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream dec = BackupCrypto.wrapDecrypt(new ByteArrayInputStream(tiny), key())) {
            byte[] buf = new byte[16];
            int n;
            while ((n = dec.read(buf)) > 0) out.write(buf, 0, n);
        }
        assertArrayEquals(tiny, out.toByteArray());
    }

    @Test
    public void looksEncryptedDetectsMagicOnly() {
        assertTrue(BackupCrypto.looksEncrypted("VSPACEE1xxxx".getBytes()));
        assertFalse(BackupCrypto.looksEncrypted("PK\u0003\u0004xxxx".getBytes()));
        assertFalse(BackupCrypto.looksEncrypted(new byte[]{1, 2, 3}));
        assertFalse(BackupCrypto.looksEncrypted(null));
    }

    @Test
    public void isKeyOrIntegrityFailureIgnoresUnrelatedExceptions() {
        assertFalse(BackupCrypto.isKeyOrIntegrityFailure(new java.io.IOException("đĩa đầy")));
        assertFalse(BackupCrypto.isKeyOrIntegrityFailure(null));
        assertTrue(BackupCrypto.isKeyOrIntegrityFailure(
                new RuntimeException("bọc ngoài", new javax.crypto.AEADBadTagException("Tag mismatch!"))));
    }
}
