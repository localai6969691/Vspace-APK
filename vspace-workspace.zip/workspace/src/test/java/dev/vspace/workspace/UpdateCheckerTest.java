package dev.vspace.workspace;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class UpdateCheckerTest {

    private static final String SAMPLE = "{\"url\":\"https://api.github.com/repos/o/r/releases/1\",\"tag_name\":\"v1.3.0\","
            + "\"name\":\"Bản 1.3.0\",\"draft\":false,\"prerelease\":false,\"html_url\":\"https://github.com/o/r/releases/tag/v1.3.0\","
            + "\"body\":\"- sửa lỗi A\\n- thêm B \\u00e9 \\\"quoted\\\"\","
            + "\"assets\":[{\"name\":\"workspace-armeabi-v7a-Release.apk\",\"size\":1234,"
            + "\"browser_download_url\":\"https://github.com/o/r/releases/download/v1.3.0/workspace-armeabi-v7a-Release.apk\","
            + "\"digest\":\"sha256:" + "a".repeat(64) + "\"},"
            + "{\"name\":\"workspace-arm64-v8a-Release.apk\",\"size\":5678,"
            + "\"browser_download_url\":\"https://github.com/o/r/releases/download/v1.3.0/workspace-arm64-v8a-Release.apk\","
            + "\"digest\":null},"
            + "{\"name\":\"notes.txt\",\"size\":1,\"browser_download_url\":\"https://github.com/x\"}]}";

    @Test
    public void parsesRealisticGithubRelease() {
        UpdateChecker.Release r = UpdateChecker.parseRelease(SAMPLE);
        assertEquals("v1.3.0", r.tag);
        assertEquals("Bản 1.3.0", r.title);
        assertTrue(r.body.contains("thêm B é \"quoted\""));
        assertEquals(3, r.assets.size());
        assertEquals("a".repeat(64), r.assets.get(0).sha256);
        assertEquals(null, r.assets.get(1).sha256);
        assertEquals(5678, r.assets.get(1).size);
        assertFalse(r.draft);
    }

    @Test
    public void picksAssetByAbi() {
        UpdateChecker.Release r = UpdateChecker.parseRelease(SAMPLE);
        assertEquals("workspace-arm64-v8a-Release.apk", UpdateChecker.pickAsset(r, true).name);
        assertEquals("workspace-armeabi-v7a-Release.apk", UpdateChecker.pickAsset(r, false).name);
        UpdateChecker.Release none = new UpdateChecker.Release();
        assertEquals(null, UpdateChecker.pickAsset(none, true));
    }

    @Test
    public void rejectsBadDigestFormats() {
        String j = "{\"tag_name\":\"v1\",\"assets\":[{\"name\":\"a.apk\",\"digest\":\"sha256:zzz\"},{\"name\":\"b.apk\",\"digest\":\"md5:abc\"}]}";
        UpdateChecker.Release r = UpdateChecker.parseRelease(j);
        assertEquals(null, r.assets.get(0).sha256);
        assertEquals(null, r.assets.get(1).sha256);
    }

    @Test
    public void versionComparison() {
        assertTrue(UpdateChecker.isNewer("v1.3.0", "1.2.9"));
        assertTrue(UpdateChecker.isNewer("1.10.0", "1.9.9"));
        assertFalse(UpdateChecker.isNewer("v1.1.0", "1.1.0"));
        assertFalse(UpdateChecker.isNewer("v1.0.9", "1.1.0"));
        assertTrue(UpdateChecker.isNewer("2.0", "1.99.99"));
        assertFalse(UpdateChecker.isNewer("1.2.0-beta", "1.2.0"));
        assertTrue(UpdateChecker.isNewer("1.2.0", "1.2.0-beta"));
        assertFalse(UpdateChecker.isNewer("", "1.0"));
        assertFalse(UpdateChecker.isNewer(null, "1.0"));
        assertEquals(0, UpdateChecker.compareVersions("v1.2", "1.2.0"));
    }

    @Test
    public void repoValidation() {
        assertTrue(UpdateChecker.validRepo("owner/repo"));
        assertTrue(UpdateChecker.validRepo("A-b_c.d/e.f-g"));
        assertFalse(UpdateChecker.validRepo(""));
        assertFalse(UpdateChecker.validRepo(null));
        assertFalse(UpdateChecker.validRepo("owner"));
        assertFalse(UpdateChecker.validRepo("owner/repo/extra"));
        assertFalse(UpdateChecker.validRepo("../repo"));
        assertFalse(UpdateChecker.validRepo("owner/re po"));
        assertFalse(UpdateChecker.validRepo("owner/repo?x=1"));
    }

    @Test
    public void hostAllowlist() {
        assertTrue(UpdateChecker.allowedHost("github.com"));
        assertTrue(UpdateChecker.allowedHost("API.github.com"));
        assertTrue(UpdateChecker.allowedHost("objects.githubusercontent.com"));
        assertTrue(UpdateChecker.allowedHost("release-assets.githubusercontent.com"));
        assertFalse(UpdateChecker.allowedHost("evilgithub.com"));
        assertFalse(UpdateChecker.allowedHost("github.com.evil.example"));
        assertFalse(UpdateChecker.allowedHost("githubusercontent.com.evil.io"));
        assertFalse(UpdateChecker.allowedHost(null));
    }

    @Test
    public void downloadRefusesPlainHttpAndForeignHostsBeforeAnyNetwork() throws Exception {
        File dest = File.createTempFile("upd", ".apk");
        UpdateChecker.Asset a = new UpdateChecker.Asset();
        a.url = "http://github.com/o/r/releases/download/v1/x.apk";
        assertRefused(dest, a, "HTTPS");
        a.url = "https://evil.example/x.apk";
        assertRefused(dest, a, "host");
        a.url = "file:///etc/passwd";
        assertRefused(dest, a, "HTTPS");
    }

    private static void assertRefused(File dest, UpdateChecker.Asset a, String why) {
        try {
            UpdateChecker.download(dest, a, "t", null);
            throw new AssertionError("phải bị từ chối: " + a.url);
        } catch (IOException e) {
            assertTrue(e.getMessage(), e.getMessage().contains(why));
        }
    }

    @Test
    public void sha256OfFile() throws Exception {
        File f = File.createTempFile("sha", ".bin");
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write("abc".getBytes("UTF-8"));
        }
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", UpdateChecker.sha256Hex(f));
    }

    @Test
    public void miniJsonEdgeCases() {
        Map<String, Object> m = MiniJson.asObject(MiniJson.parse(" {\"a\":[1,2.5,true,null,\"x\"],\"b\":{\"c\":-3e2}} "));
        List<Object> a = MiniJson.asArray(m.get("a"));
        assertEquals(5, a.size());
        assertEquals(2.5, (Double) a.get(1), 0.0);
        assertEquals(null, a.get(3));
        assertEquals(-300, MiniJson.num(MiniJson.asObject(m.get("b")), "c", 0));
        assertEquals("\u00e9\n", MiniJson.parse("\"\\u00e9\\n\""));
        for (String bad : new String[]{"", "{", "{\"a\"}", "[1,]", "{\"a\":1,}", "tru", "\"abc", "{\"a\":1} x", "\"\\q\""}) {
            try {
                MiniJson.parse(bad);
                throw new AssertionError("phải lỗi: " + bad);
            } catch (IllegalArgumentException expected) {
                // đúng
            }
        }
    }

    @Test
    public void miniJsonRejectsHostileDepth() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 100; i++) sb.append('[');
        for (int i = 0; i < 100; i++) sb.append(']');
        try {
            MiniJson.parse(sb.toString());
            throw new AssertionError("phải từ chối lồng quá sâu");
        } catch (IllegalArgumentException expected) {
            // đúng
        }
    }
}
