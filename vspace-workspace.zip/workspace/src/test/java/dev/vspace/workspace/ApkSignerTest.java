package dev.vspace.workspace;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Kiểm ApkSigner trên JVM. Bằng chứng mạnh hơn nằm ở scripts/verify_real.py: nó cho apksigner THẬT (AOSP) xác minh đầu ra
 * và còn kiểm một ca âm (sửa 1 byte → phải bị từ chối). Test này chỉ giữ cho cấu trúc không hồi quy khi không có apksigner.
 */
public class ApkSignerTest {

    private static File tmpDir() throws Exception {
        File d = File.createTempFile("vsign", "");
        d.delete();
        d.mkdirs();
        d.deleteOnExit();
        return d;
    }

    /** ZIP có 3 mục: nhỏ, 2,2 MB không nén (3 đoạn 1 MiB), nhỏ đã nén. */
    private static File makeZip(File dir) throws Exception {
        File f = new File(dir, "in.apk");
        byte[] big = new byte[2_300_000];
        new Random(42).nextBytes(big);
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(f))) {
            z.putNextEntry(new ZipEntry("AndroidManifest.xml"));
            z.write("manifest".getBytes("UTF-8"));
            z.closeEntry();
            ZipEntry stored = new ZipEntry("assets/big.bin");
            stored.setMethod(ZipEntry.STORED);
            stored.setSize(big.length);
            stored.setCompressedSize(big.length);
            java.util.zip.CRC32 crc = new java.util.zip.CRC32();
            crc.update(big);
            stored.setCrc(crc.getValue());
            z.putNextEntry(stored);
            z.write(big);
            z.closeEntry();
            z.putNextEntry(new ZipEntry("res/small.txt"));
            for (int i = 0; i < 100; i++) z.write("hello world ".getBytes("UTF-8"));
            z.closeEntry();
        }
        return f;
    }

    private static int count(byte[] hay, byte[] needle) {
        int n = 0;
        outer:
        for (int i = 0; i + needle.length <= hay.length; i++) {
            for (int j = 0; j < needle.length; j++) if (hay[i + j] != needle[j]) continue outer;
            n++;
        }
        return n;
    }

    private static byte[] readAll(File f) throws Exception {
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            byte[] b = new byte[(int) r.length()];
            r.readFully(b);
            return b;
        }
    }

    /** Bộ kiểm độc lập, viết lại theo đặc tả (không dùng hàm digest của ApkSigner) cho ZIP nhỏ nằm gọn trong bộ nhớ. */
    private static void verifyV2(byte[] apk) throws Exception {
        int eocd = -1;
        for (int i = apk.length - 22; i >= 0; i--) {
            if (ApkSigner.readU32(apk, i) == 0x06054b50L) {
                eocd = i;
                break;
            }
        }
        assertTrue("có EOCD", eocd >= 0);
        long cdOffset = ApkSigner.readU32(apk, eocd + 16);
        long cdSize = ApkSigner.readU32(apk, eocd + 12);
        assertEquals("CD liền ngay trước EOCD", eocd, cdOffset + cdSize);
        assertEquals("CD bắt đầu bằng PK\\1\\2", 0x02014b50L, ApkSigner.readU32(apk, (int) cdOffset));
        assertTrue("có magic ngay trước CD", Arrays.equals(Arrays.copyOfRange(apk, (int) cdOffset - 16, (int) cdOffset), ApkSigner.MAGIC));
        long sizeField = ApkSigner.readU64(apk, (int) cdOffset - 24);
        int blockStart = (int) (cdOffset - sizeField - 8);
        assertEquals("hai trường kích thước khối bằng nhau", sizeField, ApkSigner.readU64(apk, blockStart));
        // cặp đầu tiên
        long pairLen = ApkSigner.readU64(apk, blockStart + 8);
        assertEquals(ApkSigner.V2_BLOCK_ID, (int) ApkSigner.readU32(apk, blockStart + 16));
        int p = blockStart + 20;           // đầu "signers"
        int signersEnd = p + 4 + (int) (pairLen - 4);
        p += 4;                             // qua độ dài chuỗi signers
        p += 4;                             // qua độ dài signer đầu tiên
        int signedLen = (int) ApkSigner.readU32(apk, p);
        int signedStart = p + 4;
        int sigSeqStart = signedStart + signedLen;
        int sigSeqLen = (int) ApkSigner.readU32(apk, sigSeqStart);
        int pkStart = sigSeqStart + 4 + sigSeqLen;
        int pkLen = (int) ApkSigner.readU32(apk, pkStart);
        byte[] signedData = Arrays.copyOfRange(apk, signedStart, signedStart + signedLen);
        byte[] spki = Arrays.copyOfRange(apk, pkStart + 4, pkStart + 4 + pkLen);
        assertTrue(pkStart + 4 + pkLen <= signersEnd);

        // chữ ký
        int sp = sigSeqStart + 4 + 4;       // qua độ dài chuỗi + độ dài bản ghi
        assertEquals(ApkSigner.ALG_RSA_PKCS1_SHA256, (int) ApkSigner.readU32(apk, sp));
        int sigLen = (int) ApkSigner.readU32(apk, sp + 4);
        byte[] sig = Arrays.copyOfRange(apk, sp + 8, sp + 8 + sigLen);
        PublicKey pub = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(spki));
        Signature v = Signature.getInstance("SHA256withRSA");
        v.initVerify(pub);
        v.update(signedData);
        assertTrue("chữ ký RSA đúng", v.verify(sig));

        // digest trong signedData == digest tính lại độc lập
        int dp = 4 + 4 + 4;                 // độ dài chuỗi digests, độ dài bản ghi, thuật toán
        int dl = (int) ApkSigner.readU32(signedData, dp);
        byte[] storedDigest = Arrays.copyOfRange(signedData, dp + 4, dp + 4 + dl);

        byte[] eocdBytes = Arrays.copyOfRange(apk, eocd, apk.length);
        System.arraycopy(ApkSigner.u32(blockStart), 0, eocdBytes, 16, 4);
        byte[][] sections = {
                Arrays.copyOfRange(apk, 0, blockStart),
                Arrays.copyOfRange(apk, (int) cdOffset, eocd),
                eocdBytes};
        java.io.ByteArrayOutputStream all = new java.io.ByteArrayOutputStream();
        int chunks = 0;
        for (byte[] sec : sections) {
            for (int off = 0; off < sec.length; off += 1 << 20) {
                int n = Math.min(1 << 20, sec.length - off);
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update((byte) 0xa5);
                md.update(ApkSigner.u32(n));
                md.update(sec, off, n);
                all.write(md.digest());
                chunks++;
            }
        }
        MessageDigest top = MessageDigest.getInstance("SHA-256");
        top.update((byte) 0x5a);
        top.update(ApkSigner.u32(chunks));
        top.update(all.toByteArray());
        assertTrue("digest nội dung khớp", Arrays.equals(top.digest(), storedDigest));
        assertTrue("APK ≥ 2,3 MB phải có ≥ 4 đoạn", chunks >= 4);
    }

    @Test
    public void signedApkHasValidV2BlockAndStaysReadableZip() throws Exception {
        File dir = tmpDir();
        File in = makeZip(dir);
        File out = new File(dir, "out.apk");
        ApkSigner.sign(in, out, ApkSigner.loadOrCreate(new File(dir, "keys")));
        verifyV2(readAll(out));
        try (ZipFile z = new ZipFile(out)) {
            assertEquals(3, z.size());
            ZipEntry e = z.getEntry("assets/big.bin");
            assertEquals(2_300_000, e.getSize());
            try (InputStream s = z.getInputStream(z.getEntry("AndroidManifest.xml"))) {
                byte[] b = new byte[16];
                int n = s.read(b);
                assertEquals("manifest", new String(b, 0, n, "UTF-8"));
            }
        }
    }

    @Test
    public void resigningReplacesTheOldBlock() throws Exception {
        File dir = tmpDir();
        File in = makeZip(dir);
        File once = new File(dir, "once.apk");
        File twice = new File(dir, "twice.apk");
        ApkSigner.Signer s = ApkSigner.loadOrCreate(new File(dir, "keys"));
        ApkSigner.sign(in, once, s);
        ApkSigner.sign(once, twice, s);
        byte[] b = readAll(twice);
        assertEquals("chỉ một khối chữ ký", 1, count(b, ApkSigner.MAGIC));
        verifyV2(b);
        assertEquals("ký lại không phình file", once.length(), twice.length());
    }

    @Test
    public void tamperingBreaksTheDigest() throws Exception {
        File dir = tmpDir();
        File out = new File(dir, "out.apk");
        ApkSigner.sign(makeZip(dir), out, ApkSigner.loadOrCreate(new File(dir, "keys")));
        byte[] b = readAll(out);
        b[200] ^= 0x5a;
        boolean threw = false;
        try {
            verifyV2(b);
        } catch (AssertionError expected) {
            threw = true;
        }
        assertTrue("sửa 1 byte phải làm kiểm tra thất bại", threw);
    }

    @Test
    public void selfSignedCertificateParsesAndVerifies() throws Exception {
        File dir = tmpDir();
        ApkSigner.Signer s = ApkSigner.loadOrCreate(new File(dir, "keys"));
        X509Certificate c = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(s.certDer));
        c.verify(c.getPublicKey());
        assertTrue(c.getSubjectX500Principal().getName().contains("VSpace merge signer"));
        assertEquals(c.getSubjectX500Principal(), c.getIssuerX500Principal());
        assertTrue(Arrays.equals(c.getPublicKey().getEncoded(), s.spki));
    }

    @Test
    public void keyIsGeneratedOnceThenReused() throws Exception {
        File dir = new File(tmpDir(), "keys");
        ApkSigner.Signer a = ApkSigner.loadOrCreate(dir);
        ApkSigner.Signer b = ApkSigner.loadOrCreate(dir);
        assertTrue(Arrays.equals(a.certDer, b.certDer));
        assertTrue(new File(dir, "key.pk8").isFile());
        // file khóa hỏng → sinh lại, không ném lỗi
        try (FileOutputStream o = new FileOutputStream(new File(dir, "key.pk8"))) {
            o.write(new byte[]{1, 2, 3});
        }
        ApkSigner.Signer c = ApkSigner.loadOrCreate(dir);
        assertFalse(Arrays.equals(a.certDer, c.certDer));
    }

    @Test
    public void derLengthEncoding() {
        assertTrue(Arrays.equals(new byte[]{0x7f}, ApkSigner.derLen(0x7f)));
        assertTrue(Arrays.equals(new byte[]{(byte) 0x81, (byte) 0x80}, ApkSigner.derLen(0x80)));
        assertTrue(Arrays.equals(new byte[]{(byte) 0x81, (byte) 0xff}, ApkSigner.derLen(0xff)));
        assertTrue(Arrays.equals(new byte[]{(byte) 0x82, 0x01, 0x00}, ApkSigner.derLen(0x100)));
        assertTrue(Arrays.equals(new byte[]{(byte) 0x83, 0x01, 0x00, 0x00}, ApkSigner.derLen(0x10000)));
        byte[] x = ApkSigner.der(0x04, new byte[200]);
        assertEquals(0x04, x[0] & 0xff);
        assertEquals(0x81, x[1] & 0xff);
        assertEquals(203, x.length);
    }

    @Test
    public void nonZipIsRejectedWithoutDamage() throws Exception {
        File dir = tmpDir();
        File junk = new File(dir, "junk.bin");
        try (FileOutputStream o = new FileOutputStream(junk)) {
            o.write(new byte[4096]);
        }
        String err = ApkSigner.signInPlace(junk, new File(dir, "keys"));
        assertTrue("phải báo lỗi", err != null);
        assertEquals("file gốc nguyên vẹn", 4096, junk.length());
        assertFalse(new File(junk.getPath() + ".signed").exists());
    }

    @Test
    public void signInPlaceReplacesFile() throws Exception {
        File dir = tmpDir();
        File apk = makeZip(dir);
        long before = apk.length();
        assertEquals(null, ApkSigner.signInPlace(apk, new File(dir, "keys")));
        assertTrue(apk.length() > before);
        verifyV2(readAll(apk));
    }
}
