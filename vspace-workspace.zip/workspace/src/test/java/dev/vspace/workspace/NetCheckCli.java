package dev.vspace.workspace;

import java.io.File;
import java.io.IOException;

/**
 * Chạy lớp THẬT {@link UpdateChecker} với mạng thật (không phải test đơn vị, không chạy trong CI mặc định).
 * Dùng bởi scripts/net_check.py. In mỗi ca một dòng: "OK|FAIL|SKIP <tên> :: <chi tiết>".
 * Tài sản thử: APKEditor V1.4.9 (sha256 đã ghim trong scripts/verify_real.py) — có thật trên GitHub Releases,
 * tải qua chuyển hướng github.com → release-assets.githubusercontent.com giống đường tải bản cập nhật thật.
 */
public final class NetCheckCli {
    private static final String UA = "VSpaceWorkspace-netcheck";
    private static int fails;

    private static void ok(String n, String d) { System.out.println("OK   " + n + " :: " + d); }
    private static void fail(String n, String d) { fails++; System.out.println("FAIL " + n + " :: " + d); }
    private static void skip(String n, String d) { System.out.println("SKIP " + n + " :: " + d); }

    public static void main(String[] args) throws Exception {
        String url = args[0];
        String goodSha = args[1];
        File dir = new File(args[2]);
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();

        UpdateChecker.Asset a = new UpdateChecker.Asset();
        a.name = "APKEditor.jar";
        a.url = url;
        a.sha256 = goodSha;

        // 1. tải thật qua chuyển hướng, sha256 đúng → phải thành công, không còn .part
        File d1 = new File(dir, "good.bin");
        try {
            long[] last = new long[1];
            boolean r = UpdateChecker.download(d1, a, UA, (done, total) -> { last[0] = done; return true; });
            if (r && d1.isFile() && !new File(d1.getPath() + ".part").exists()
                    && UpdateChecker.sha256Hex(d1).equals(goodSha)) {
                ok("download+redirect+sha256", d1.length() + " byte, sha256 khớp, không còn .part");
            } else fail("download+redirect+sha256", "r=" + r + " exists=" + d1.isFile());
        } catch (IOException e) { fail("download+redirect+sha256", e.toString()); }

        // 2. sha256 sai → phải bị từ chối và xóa tệp
        File d2 = new File(dir, "bad.bin");
        UpdateChecker.Asset bad = new UpdateChecker.Asset();
        bad.name = a.name; bad.url = a.url;
        bad.sha256 = "0000000000000000000000000000000000000000000000000000000000000000";
        try {
            UpdateChecker.download(d2, bad, UA, null);
            fail("sha256-sai", "KHÔNG bị từ chối");
        } catch (IOException e) {
            boolean clean = !d2.exists() && !new File(d2.getPath() + ".part").exists();
            if (clean && String.valueOf(e.getMessage()).contains("sha256")) ok("sha256-sai", "bị từ chối, đã xóa tệp: " + e.getMessage());
            else fail("sha256-sai", "clean=" + clean + " msg=" + e.getMessage());
        }

        // 3. kích thước công bố sai → từ chối
        File d3 = new File(dir, "size.bin");
        UpdateChecker.Asset sz = new UpdateChecker.Asset();
        sz.name = a.name; sz.url = a.url; sz.sha256 = goodSha; sz.size = 12345;
        try {
            UpdateChecker.download(d3, sz, UA, null);
            fail("size-sai", "KHÔNG bị từ chối");
        } catch (IOException e) {
            if (!d3.exists() && !new File(d3.getPath() + ".part").exists()) ok("size-sai", e.getMessage());
            else fail("size-sai", "còn tệp rác");
        }

        // 4. hủy giữa chừng → trả false, không để lại .part
        File d4 = new File(dir, "cancel.bin");
        try {
            boolean r = UpdateChecker.download(d4, a, UA, (done, total) -> false);
            if (!r && !d4.exists() && !new File(d4.getPath() + ".part").exists()) ok("huy-giua-chung", "trả false, dọn sạch");
            else fail("huy-giua-chung", "r=" + r);
        } catch (IOException e) { fail("huy-giua-chung", e.toString()); }

        // 5. host/giao thức ngoài allowlist bị chặn TRƯỚC khi mở kết nối
        String[] evil = { "http://github.com/x", "https://example.com/x", "https://github.com.evil.io/x" };
        for (String u : evil) {
            UpdateChecker.Asset e = new UpdateChecker.Asset();
            e.url = u;
            try {
                UpdateChecker.download(new File(dir, "evil.bin"), e, UA, null);
                fail("chan-host:" + u, "KHÔNG bị chặn");
            } catch (IOException ex) { ok("chan-host:" + u, ex.getMessage()); }
        }

        // 6. fetchLatest thật tới api.github.com (có thể bị giới hạn tốc độ vì IP dùng chung → SKIP chứ không báo đạt giả)
        String repo = args.length > 3 ? args[3] : "REAndroid/APKEditor";
        boolean done6 = false;
        for (int i = 0; i < 3 && !done6; i++) {
            try {
                UpdateChecker.Release rel = UpdateChecker.fetchLatest(repo, UA);
                int withSha = 0;
                for (UpdateChecker.Asset x : rel.assets) if (x.sha256 != null) withSha++;
                ok("fetchLatest:" + repo, "tag=" + rel.tag + " assets=" + rel.assets.size() + " có-sha256=" + withSha);
                done6 = true;
            } catch (IOException e) {
                String m = String.valueOf(e.getMessage());
                if (m.contains("403") || m.contains("429")) {
                    if (i == 2) { skip("fetchLatest:" + repo, "api.github.com giới hạn tốc độ (IP dùng chung): " + m); done6 = true; }
                    else Thread.sleep(4000);
                } else { fail("fetchLatest:" + repo, m); done6 = true; }
            }
        }
        System.exit(fails == 0 ? 0 : 1);
    }
}
