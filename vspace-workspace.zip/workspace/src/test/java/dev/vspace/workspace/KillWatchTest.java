package dev.vspace.workspace;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class KillWatchTest {
    private static final long RENEW = 5 * 60 * 1000L;
    private static final long BOOT = 1_000_000L;

    @Test
    public void killedMidSession() {
        long last = BOOT + 60_000L;
        assertTrue(KillWatch.looksKilled(true, last, last + 11 * 60_000L, BOOT, RENEW));
    }

    @Test
    public void notKilledWhenUserTurnedOff() {
        long last = BOOT + 60_000L;
        assertFalse(KillWatch.looksKilled(false, last, last + 60 * 60_000L, BOOT, RENEW));
    }

    @Test
    public void rebootIsNotAKill() {
        // nhịp cuối trước khi máy khởi động lại
        assertFalse(KillWatch.looksKilled(true, BOOT - 5000L, BOOT + 3_600_000L, BOOT, RENEW));
    }

    @Test
    public void shortGapIsNormalRestart() {
        long last = BOOT + 60_000L;
        assertFalse(KillWatch.looksKilled(true, last, last + 9 * 60_000L, BOOT, RENEW));   // ngưỡng là > 2 chu kỳ (10 phút)
        assertTrue(KillWatch.looksKilled(true, last, last + 10 * 60_000L + 1, BOOT, RENEW));
    }

    @Test
    public void neverRecordedIsNotKilled() {
        assertFalse(KillWatch.looksKilled(true, 0L, BOOT + 10_000_000L, BOOT, RENEW));
    }

    @Test
    public void gapMinutes() {
        assertEquals(12L, KillWatch.gapMinutes(0L, 12 * 60_000L + 5000L));
        assertEquals(0L, KillWatch.gapMinutes(100L, 50L));
    }
}
