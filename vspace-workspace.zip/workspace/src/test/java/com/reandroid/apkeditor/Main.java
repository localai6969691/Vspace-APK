package com.reandroid.apkeditor;

import java.io.File;
import java.io.FileOutputStream;

/**
 * GIẢ của APKEditor chỉ dùng trong test đơn vị (không đóng gói vào app): kiểm tra đường reflection của SplitMerger.
 * mode 0 = thành công và ghi một "APK" hợp lệ; 1 = trả mã lỗi, không ghi file; 2 = ném ngoại lệ; 3 = ghi file rác (không phải ZIP).
 */
public final class Main {
    public static volatile int mode = 0;
    public static volatile String[] lastArgs;

    private Main() {}

    public static int execute(String[] args) throws Exception {
        lastArgs = args;
        if (mode == 2) throw new IllegalStateException("boom");
        if (mode == 1) return 1;
        File out = null;
        for (int i = 0; i + 1 < args.length; i++) {
            if ("-o".equals(args[i])) out = new File(args[i + 1]);
        }
        if (out == null) return 2;
        try (FileOutputStream fos = new FileOutputStream(out)) {
            byte[] data = new byte[2048];
            if (mode == 0) {
                data[0] = 'P';
                data[1] = 'K';
                data[2] = 3;
                data[3] = 4;
            }
            fos.write(data);
        }
        return 0;
    }
}
